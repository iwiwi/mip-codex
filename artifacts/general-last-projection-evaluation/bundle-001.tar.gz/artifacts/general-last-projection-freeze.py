from pathlib import Path
import tarfile,json,hashlib,subprocess
root=Path.cwd();out=root/'artifacts/general-last-projection-frozen';files=[]
for base in ['src','scripts','tests']:
 files.extend(p for p in(root/base).rglob('*')if p.is_file()and '__pycache__'not in p.parts)
files.extend(root/p for p in ['Cargo.toml','Cargo.lock','build.rs']if(root/p).exists())
with tarfile.open(out/'source.tar.gz','w:gz')as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(root)),recursive=False)
(out/'source-sha256.json').write_text(json.dumps({str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(files)},indent=2)+'\n')
(out/'source.patch').write_bytes(subprocess.check_output(['git','diff','a326be92a59eea70d31d057a7121a5ea9fef6746','--','src','scripts','tests','Cargo.toml','Cargo.lock','build.rs']))
