from pathlib import Path
import json,subprocess,sys,hashlib
root=Path.cwd();sys.path.insert(0,'scripts');from benchmark_common import atomic_json
binary=root/'artifacts/general-recovery-frozen/bin/mip-codex';out=root/'artifacts/general-recovery-structural-screen';out.mkdir(exist_ok=True);candidates=[];rows=[]
for m in json.load(open('data/manifest.json'))['instances']:
 if m['split']!='development':continue
 info=json.loads(subprocess.check_output([str(binary),'inspect',m['path']]))
 if not 0<info['integers']<=1024 or info['nonzeros']>200000:continue
 model=json.loads(subprocess.check_output([str(binary),'dump',m['path']]))
 vs=model['variables'];nb=sum(v['integer'] and not(v['lower'] is not None and v['upper']is not None and (v['lower']>=0 and v['upper']<=1 or __import__('math').ceil(v['lower'])==__import__('math').floor(v['upper']))) for v in vs)
 rows.append(dict(info, name=m['name'],nonbinary=nb))
 if nb and m['name']not in ['enlight_hard.mps.gz','icir97_tension.mps.gz','neos-2657525-crna.mps.gz','roll3000.mps.gz']:candidates.append(m['name'])
atomic_json(out/'domains.json',rows);selected=sorted(candidates,key=lambda n:hashlib.sha256(('general-recovery-20261118:'+n).encode()).hexdigest())[:12];atomic_json(out/'selected.json',dict(rule='development integers1..1024 nnz<=200000 movable nonbinary positive; exclude original4; first12 by fixed salted nameSHA256',eligible=len(candidates),selected=selected));print(json.dumps(selected))
