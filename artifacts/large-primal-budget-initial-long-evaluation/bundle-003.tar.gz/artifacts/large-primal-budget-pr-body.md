大規模で疎な純binary packingでは、主解探索5%の時間配分が改善を制限する場合があります。既存heapのサイズ・operation・memory gateとportfolioが有効な構造だけ、`MIP_GRAPH_LARGE_PRIMAL_BUDGET=1`で25%へ増やす候補です。**初期defaultOFF、draft、採用判断保留**。既存公開APIの配分、数学・認識・枝刈り・反復上限・乱数系列・全体期限は維持します。問題名/既知解/目標値による選択はありません。

同一凍結CLI e180/72aeの0/1、1thread/16GiB。z26/60秒は−1154/LB−1575→−1178/LB−1578（主解改善、下界悪化）。300秒は−1181/LB−1578→−1188/LB−1575（両改善）。CDC/60秒は両−279/LB−438、300秒は進行中。cod105は両−12 root最適、S3は両−16最適/6,042,153nodes。全先行9出力と完了済みlong3出力が元GMP/strict proof valid。

Rust353passed/4ignored、1200小規模GMP/全列挙/strict proof・7410改ざん拒否、12large/GMP/proof/component oracle成功。生成large主解6組同値、upper2同値/4悪化も保持。開発188件376fresh strict proof、128点全GMP/公式成功。主解187同値/1悪化、下界172同値/3改善/13比較不能、finite各175、status両182time/2optimal/4numerical_error。新予算発動0なので、未発動路の損益を機能効果とは主張しません。supportcase12−13→−12の元損失を保持し、交互3pairsを追加確認中。holdout52個別成績未参照。

同日native z26/300秒はHS−1147/LB−2114、SCIP−1013/LB−1539.9495、両GMP。候補は主解で勝る一方SCIPの下界が強い。GLPKは420秒watchdog、441.545秒遅着−460は別GMP validだが時間同条件比較から除外。全失敗/遅着を保存し、新CDC300秒driverではprocess group全体watchdogに修正。CPUは候補long実45/native46（copied long metadata label44誤記は訂正receipt/raw両保持）。

初回検査器path未発見1200未検証、生成driver旧heap assert、worktreeのbroad sparse checkout中断と再生成可能ファイル回復をすべてjournal/archivesへ記録。検査driver失敗をsolver誤答とは扱わず、初版/rawと修正後全検査を保持しています。詳細は `docs/GRAPH_LARGE_PRIMAL_BUDGET_HYPOTHESIS.md` / `RESULTS.md`。

この枝にはmain128統合後4検査・未起動final snapshot9e5（113files/147libs全SHA）の証拠、評価外CDCの比較、私的親LNS不改善も保管しています。本候補を採用するまでmain128と最終評価snapshotは維持。全体優位・新記録は未達です。

作成時AI資源量:
```json
{
  "sessions": 1,
  "totals": {
    "input_tokens": 1827513209,
    "cached_input_tokens": 1814443264,
    "output_tokens": 9080692,
    "reasoning_output_tokens": 5568797,
    "total_tokens": 1836593901
  },
  "note": "input_tokensはキャッシュ分を含む。reasoningはoutputの内数。ローカルログの最終記録まで。"
}
```
