from pathlib import Path
import subprocess,json,os
os.sched_setaffinity(0,{43});assert json.load(open('artifacts/large-primal-budget-inactive-recheck/summary.json'))==dict(outputs=6,gmp_valid=6,proof_valid=6)
a=json.load(open('artifacts/large-primal-budget-development-analysis.json'));assert a['completed_pairs']==188
text='''初期defaultOFF源515fd/e180の開発188問と376fresh監査は完了。128可行点全GMP/公式、全376strict proof valid。primal187同値/1悪化、dual172同値/3改善/13比較不能、両182time_limit/2optimal/4numerical_error、finite各175。新配分発動0。supportcase12の元188損失−13→−12を残したうえ、CPU44同一・交互順3pairsを再測定し全6点−13/下界−537783.5007328897、6GMP/proof validを確認しました。未発動路の時間差という解釈は推論であり、元損失は削除/置換しません。

z26/300秒の候補比較は実CPU45で−1181/LB−1578→−1188/LB−1575、両GMP/strict proof valid。先の60秒では主解24改善・下界3悪化であり、この損失も保持。CDC/60秒は両−279/LB−438、300秒OFF−279/LB−434は完了、ONは測定中です。

correctness archiveは353Rust/4ignored・1200oracle/GMP/proof・7410tampers・12large/GMP/proof、全payloadSHA照合。development archiveは188/376fresh監査と全失敗status、control60 archiveは9点GMP/proofとprior native300/watchdog/遅着の全rawを封入。新既定値の採否は残るCDC300と比較native300を確認後に判断します。main128/9e5最終snapshot未起動のままです。
'''
usage=subprocess.check_output(['python3','scripts/ai_usage.py'],text=True)
Path('artifacts/large-primal-budget-initial-comment-ai-usage.json').write_text(usage)
p=Path('artifacts/large-primal-budget-initial-comment.md');p.write_text(text+'\n現在までのAI資源量:\n```json\n'+usage+'```\n')
r=subprocess.run(['gh','pr','comment','129','--repo','iwiwi/mip-codex','--body-file',str(p)],capture_output=True,text=True);Path('artifacts/large-primal-budget-initial-comment.log').write_text(r.stdout+r.stderr);r.check_returncode();print(r.stdout)
