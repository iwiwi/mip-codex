from pathlib import Path
import os,sys,json,subprocess,time,resource,signal
os.sched_setaffinity(0,{46});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,)*2);root=Path.cwd();os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',MIP_ABSOLUTE_CHECKER=str(root/'third_party/miplib-checker/bin/solchecker-absolute'));sys.path.insert(0,'scripts')
from benchmark_common import sha256,atomic_json
from validate_solution import validate
from verify_cover_cuts import validate_cut_proofs
out=root/'artifacts/cdc-packing-native300';out.mkdir();model=root/'data/raw/exploratory/cdc7-4-3-2.mps.gz';binary=root/'artifacts/cover-choice-heap-main-primary-audit/bin/mip-codex';atomic_json(out/'experiment.json',dict(cpu=46,seconds=300,watchdog=420,threads=1,memory_bytes=16*1024**3,input_sha256=sha256(model),own_binary_sha256=sha256(binary),outside_all_240=True,point_transfer=False,process_group_watchdog=True));records=[]
for solver in ['highs','scip','glpk']:
 d=out/solver;d.mkdir();cmd=([str(binary),'solve',str(model),'300']if solver=='rust'else[str(root/'.venv/bin/python'),str(root/'scripts/comparison_worker.py'),solver,str(model),'300',str(d)])
 atomic_json(d/'job.json',dict(command=cmd));start=time.monotonic();timed=False
 with(d/'stdout.log').open('w')as so,(d/'stderr.log').open('w')as se:
  p=subprocess.Popen(cmd,stdout=so,stderr=se,start_new_session=True)
  try:p.wait(timeout=420)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
 atomic_json(d/'execution.json',dict(exit_code=p.returncode,watchdog=timed,wall_seconds=time.monotonic()-start,process_group_killed=timed))
 if timed or p.returncode!=0:
  records.append(dict(solver=solver,status='watchdog'if timed else'execution_error',exit_code=p.returncode));atomic_json(out/'records.json',records);continue
 if solver=='rust':atomic_json(d/'result.json',json.load(open(d/'stdout.log')))
 r=json.load(open(d/'result.json'));v=None
 if r.get('values')is not None:
  v=validate(model,r);atomic_json(d/'validation.json',v);assert v['valid']
 if solver=='rust':
  proof=validate_cut_proofs(model,r);atomic_json(d/'proof-validation.json',proof);assert proof['valid']
 records.append(dict(solver=solver,**{k:r.get(k)for k in ['status','objective','dual_bound','seconds','nodes','version']},gmp_valid=None if v is None else v['valid']));atomic_json(out/'records.json',records);print(json.dumps(records[-1]),flush=True)
atomic_json(out/'exit.json',dict(status='complete',cases=len(records)))
