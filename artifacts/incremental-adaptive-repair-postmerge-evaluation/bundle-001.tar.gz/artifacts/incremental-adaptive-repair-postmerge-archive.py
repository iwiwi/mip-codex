from pathlib import Path
import json,hashlib,tarfile,shutil
root=Path.cwd();research=Path('/home/ubuntu/mip-incremental-adaptive-repair')
for pattern in ['incremental-adaptive-repair-pr*','incremental-adaptive-repair-final-ai-usage.json','incremental-adaptive-repair-final-pr-comment*','incremental-adaptive-repair-create-pr-and-comment.py','incremental-adaptive-repair-final-push.log']:
 for p in (research/'artifacts').glob(pattern):
  if p.is_file():
   dst=root/'artifacts'/p.name
   if dst.exists():assert dst.read_bytes()==p.read_bytes(),p.name
   else:shutil.copy2(p,dst)
out=root/'artifacts/incremental-adaptive-repair-postmerge-evaluation';assert not out.exists();out.mkdir();paths=set()
patterns=['incremental-adaptive-repair-main-*','incremental-adaptive-repair-final-create*','incremental-adaptive-repair-final-verify*','incremental-adaptive-repair-final-snapshot-verification.json','incremental-adaptive-repair-postmerge-*','incremental-adaptive-repair-pr*','incremental-adaptive-repair-final-ai-usage.json','incremental-adaptive-repair-final-pr-comment*','incremental-adaptive-repair-create-pr-and-comment.py','incremental-adaptive-repair-final-push.log','native-baseline-health-20261117-2210.json']
for pattern in patterns:
 for p in (root/'artifacts').glob(pattern):
  if p==out or p.name=='incremental-adaptive-repair-postmerge-archive.log':continue
  if p.is_file():paths.add(p)
  elif p.is_dir():paths.update(q for q in p.rglob('*')if q.is_file())
paths.update(p for p in (root/'artifacts/smoke-20261117-220834-gcwa5x4j').rglob('*')if p.is_file());run=root/'artifacts/runs/incremental-adaptive-final-20261117';paths.add(run/'config.json');paths.update(p for p in(run/'snapshot').rglob('*')if p.is_file());paths.add(root/'artifacts/runs/zero-phase-one-final-20261117/OBSOLETE.json');paths.add(root/'experiments/incremental-adaptive-snapshot-20261117.json');ledger=[];excluded=[]
for p in sorted(paths):
 assert not p.is_symlink();data=p.read_bytes();r=dict(path=str(p.relative_to(root)),bytes=len(data),sha256=hashlib.sha256(data).hexdigest());(excluded if data[:4]==b'\x7fELF'else ledger).append(r)
bundle=out/'bundle-001.tar.gz'
with tarfile.open(bundle,'w:gz',compresslevel=6)as t:
 for r in ledger:t.add(root/r['path'],arcname=r['path'],recursive=False)
assert bundle.stat().st_size<95*1024**2
with tarfile.open(bundle,'r:gz')as t:
 members=t.getmembers();assert len(members)==len(ledger)
 for m,r in zip(members,ledger):
  data=t.extractfile(m).read();assert m.name==r['path']and len(data)==r['bytes']and hashlib.sha256(data).hexdigest()==r['sha256']
(out/'manifest.json').write_text(json.dumps(ledger,indent=2));(out/'excluded-elf.json').write_text(json.dumps(excluded,indent=2));s=dict(files=len(ledger),raw_bytes=sum(r['bytes']for r in ledger),compressed_bytes=bundle.stat().st_size,excluded_elfs=len(excluded),all_payload_sha256_verified=True,bundle_sha256=hashlib.sha256(bundle.read_bytes()).hexdigest());(out/'summary.json').write_text(json.dumps(s,indent=2));print(s)
