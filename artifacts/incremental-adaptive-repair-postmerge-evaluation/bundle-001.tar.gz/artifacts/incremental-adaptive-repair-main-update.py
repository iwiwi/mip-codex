from pathlib import Path
import subprocess,json,hashlib,shutil,datetime,sys
root=Path.cwd();expected=json.loads(Path('/home/ubuntu/mip-incremental-adaptive-repair/artifacts/incremental-adaptive-repair-pr-merged.json').read_text())['mergeCommit']['oid'];assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True).strip();old=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
with(root/'artifacts/incremental-adaptive-repair-main-fetch.log').open('w')as f:subprocess.run(['git','fetch','origin','main'],check=True,stdout=f,stderr=subprocess.STDOUT)
target=subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip();assert target==expected,(target,expected);tracked=set(subprocess.check_output(['git','ls-files'],text=True).splitlines());added=subprocess.check_output(['git','diff','--name-only','--diff-filter=A',old,target],text=True).splitlines();collisions=[]
for rel in added:
 p=root/rel
 if p.exists()and rel not in tracked:
  assert p.is_file()and not p.is_symlink(),rel
  expected_bytes=subprocess.check_output(['git','show',target+':'+rel]);data=p.read_bytes();assert data==expected_bytes,('nonidentical incoming untracked path',rel);collisions.append(dict(path=rel,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
backup=Path('/tmp/incremental-adaptive-main121-untracked');backup.mkdir(exist_ok=True)
for r in collisions:
 src=root/r['path'];dst=backup/r['path'];assert not dst.exists(),str(dst);dst.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(src),str(dst))
ledger=dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),old=old,target=target,backup=str(backup),collisions=collisions,all_byte_identical=True);(root/'artifacts/incremental-adaptive-repair-main-collision-prevention.json').write_text(json.dumps(ledger,indent=2))
with(root/'artifacts/incremental-adaptive-repair-main-pull.log').open('w')as f:subprocess.run(['git','merge','--ff-only',target],check=True,stdout=f,stderr=subprocess.STDOUT)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==target
sys.path.insert(0,'scripts');from benchmark_common import solver_source_fingerprint,require_solver_origin
assert solver_source_fingerprint(root)=='cb0ba03a36c3f07e'
env=__import__('os').environ.copy();env['CARGO_INCREMENTAL']='0'
with(root/'artifacts/incremental-adaptive-repair-main-build.log').open('w')as f:subprocess.run(['taskset','-c','56-63','cargo','build','--release','--bin','mip-codex'],env=env,check=True,stdout=f,stderr=subprocess.STDOUT)
info=require_solver_origin(root,root/'target/release/mip-codex');assert info['source_fingerprint']==info['library_source_fingerprint']=='cb0ba03a36c3f07e';(root/'artifacts/incremental-adaptive-repair-main-build-info.json').write_text(json.dumps(dict(head=target,build_info=info),indent=2));print(json.dumps(dict(head=target,collisions=len(collisions),build_info=info)))
