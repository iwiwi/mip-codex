NAME rational
OBJSENSE
 MAX
ROWS
 N obj
 E row
COLUMNS
 y obj 1.00000000000000000001 row 5
RHS
 rhs row 7 obj -0.3
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
