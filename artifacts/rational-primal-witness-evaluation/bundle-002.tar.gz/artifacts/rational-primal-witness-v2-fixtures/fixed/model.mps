NAME fixed
ROWS
 N obj
COLUMNS
 y obj 1
RHS
 rhs obj 0
BOUNDS
 FX b y .3
ENDATA
