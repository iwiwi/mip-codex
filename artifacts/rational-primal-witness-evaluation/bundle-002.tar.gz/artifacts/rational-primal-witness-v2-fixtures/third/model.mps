NAME third
ROWS
 N obj
 E r
COLUMNS
 y obj 1 r 3
RHS
 rhs r 1
ENDATA
