NAME three
ROWS
 N obj
 L a
 L b
 L c
COLUMNS
 x obj -1 a 3
 z obj -1 c 3
 t a 2 b -1
 u b 3 c -6
RHS
 rhs a 3 b 0
 rhs c 1
BOUNDS
 BV bd x
 BV bd z
 FR bd t
 FR bd u
ENDATA
