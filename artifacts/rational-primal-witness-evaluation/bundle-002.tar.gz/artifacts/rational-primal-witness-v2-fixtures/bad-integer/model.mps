NAME implied
ROWS
 N obj
 E link
 L cap
COLUMNS
 x obj -1 link 1
 y link -1 cap 1
RHS
 rhs link 0 cap 0.9999999999999999999999
BOUNDS
 LI b x 0
 UI b x 2
 LO b y 0
 UP b y 2
ENDATA
