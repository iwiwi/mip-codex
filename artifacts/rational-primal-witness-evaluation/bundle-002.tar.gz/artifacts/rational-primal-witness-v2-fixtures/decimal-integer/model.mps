NAME decimal
ROWS
 N obj
 L cap
COLUMNS
 x obj -1 cap .1
RHS
 rhs cap .3
BOUNDS
 LI b x 0
 UI b x 3
ENDATA
