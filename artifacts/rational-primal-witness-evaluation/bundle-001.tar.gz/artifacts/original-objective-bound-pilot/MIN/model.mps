NAME cost
OBJSENSE
 MIN
ROWS
 N obj
COLUMNS
 x obj 0.1
RHS
 rhs obj 0
BOUNDS
 LI b x 3
 UI b x 3
ENDATA
