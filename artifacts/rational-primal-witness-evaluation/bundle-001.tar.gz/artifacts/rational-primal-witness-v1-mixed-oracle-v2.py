from pathlib import Path
from fractions import Fraction as F
import json,subprocess,os,sys,random,time,resource
sys.path.insert(0,'artifacts/rational-primal-witness-v1-diagnostic/scripts');from benchmark_common import atomic_json,sha256
from verify_cover_cuts import validate_cut_proofs
os.environ['MIP_ABSOLUTE_CHECKER']=str(Path.cwd()/'third_party/miplib-checker/bin/solchecker-absolute')
from validate_solution import validate
os.sched_setaffinity(0,{41});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));out=Path('artifacts/rational-primal-witness-v1-mixed-oracle-v2');out.mkdir();rng=random.Random(2026111748);records=[];bins={v:Path('artifacts')/(n+'-diagnostic')/'bin/mip-codex'for v,n in [('before','implied-boundary-final'),('after','rational-primal-witness-v1')]};atomic_json(out/'experiment.json',dict(seed=2026111748,models=100,senses=2,variants=2,cpu=41,seconds=2,binaries={k:dict(path=str(v),sha256=sha256(v))for k,v in bins.items()},purpose='mixed integer/continuous equality lattice and sub-ulp decimal boundaries; independent exact enumeration; old defects counted, new wrong declarations forbidden'))
def decimal(v):
 t=v*10**24;assert t.denominator==1;n=t.numerator;return ('-'if n<0 else'')+str(abs(n)//10**24)+'.'+str(abs(n)%10**24).zfill(24)
try:
 for case in range(100):
  p=rng.randint(1,5);q=rng.randint(1,7);shift=rng.randint(-2,2);target=rng.randint(-1,2);scale=rng.choice([F(1),F(1,10),F(2)]);exact=scale*(F(p*target+shift,q));cap=F((exact*10**24).__floor__()+rng.choice([-2,-1,0,1,2]),10**24);lower=case%3==0;kind='G'if lower else'L';cost=rng.choice([-3,-1,1,2]);offset=rng.randint(-5,5)
  feasible=[(x,F(p*x+shift,q))for x in range(-2,3)if -4<=F(p*x+shift,q)<=4 and ((scale*F(p*x+shift,q)>=cap)if lower else(scale*F(p*x+shift,q)<=cap))]
  for maximize in [False,True]:
   d=out/f'{case}-{int(maximize)}';d.mkdir();m=d/'model.mps';text='NAME lattice\nOBJSENSE\n '+('MAX'if maximize else'MIN')+f'\nROWS\n N obj\n E link\n {kind} cap\nCOLUMNS\n x obj {cost} link {p}\n y link {-q} cap {decimal(scale)}\nRHS\n rhs obj {-offset} link {-shift}\n rhs cap {decimal(cap)}\nBOUNDS\n LI b x -2\n UI b x 2\n LO b y -4\n UP b y 4\nENDATA\n';m.write_text(text);opt=(max if maximize else min)(offset+cost*x for x,y in feasible)if feasible else None
   for label,b in bins.items():
    e=d/label;e.mkdir();env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_INTEGER_ROW_ROUNDING=str(case%2),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');run=subprocess.run([str(b),'solve',str(m),'2'],capture_output=True,text=True,env=env,timeout=62);(e/'result.json').write_text(run.stdout);(e/'stderr.log').write_text(run.stderr);assert run.returncode==0;r=json.loads(run.stdout);wrong=r['status']=='optimal'and(opt is None or abs(F(str(r['objective']))-opt)>F(1,10**8)*(1+abs(opt)))or r['status']=='infeasible'and opt is not None
    if label=='after':
     assert not wrong,(case,maximize,r['status'],r['objective'],opt)
     assert r['status']in ['optimal','infeasible','numerical_error'],r['status']
     if r['status']=='numerical_error':assert r['dual_bound']is None and r['gap']is None
     if r['dual_bound']is not None:assert opt is not None and(-1 if maximize else 1)*F(str(r['dual_bound']))<=(-1 if maximize else 1)*opt,(case,'dual',r['dual_bound'],opt)
     proof=validate_cut_proofs(m,r);atomic_json(e/'proof-validation.json',proof);assert proof['valid']is True
    point=False
    if r['values']is not None:
     v=validate(m,r);atomic_json(e/'validation.json',v);assert v['valid']is True,(case,label,v);point=True
    records.append(dict(case=case,maximize=maximize,variant=label,status=r['status'],objective=r['objective'],optimum=opt,wrong_declaration=wrong,point_valid=point,rational_proof=r.get('rational_primal_proof')is not None,input_sha256=sha256(m),result_sha256=sha256(e/'result.json')));atomic_json(out/'records.json',records)
   if len(records)%80==0:print(len(records),flush=True)
 from collections import Counter
 summary={v:dict(outputs=sum(r['variant']==v for r in records),statuses=dict(Counter(r['status']for r in records if r['variant']==v)),wrong_declarations=sum(r['wrong_declaration']for r in records if r['variant']==v),rational_proofs=sum(r['rational_proof']for r in records if r['variant']==v),points=sum(r['point_valid']for r in records if r['variant']==v))for v in bins};atomic_json(out/'summary.json',summary);atomic_json(out/'exit.json',dict(status='complete'));print(summary)
except BaseException as error:atomic_json(out/'exit.json',dict(status='failed',completed=len(records),error=str(error)));raise
