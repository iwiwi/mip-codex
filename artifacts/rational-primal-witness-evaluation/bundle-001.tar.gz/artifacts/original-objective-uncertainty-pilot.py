from pathlib import Path
from fractions import Fraction as F
import subprocess,json,sys
sys.path.insert(0,'scripts');from validate_solution import validate
from benchmark_common import atomic_json,sha256
root=Path.cwd();out=root/'artifacts/original-objective-uncertainty-pilot';out.mkdir();m=out/'model.mps';m.write_bytes((root/'artifacts/rational-primal-witness-v2-fractional-lp-oracle/4-0/model.mps').read_bytes());opt=-2*F('1.00000000000000000001');records=[]
for label,prefix in [('main118','implied-boundary-final'),('v2','rational-primal-witness-v2'),('v3','rational-primal-witness-v3')]:
 d=out/label;d.mkdir();b=root/'artifacts'/(prefix+'-diagnostic')/'bin/mip-codex';p=subprocess.run(['taskset','-c','43',str(b),'solve',str(m),'2'],capture_output=True,text=True,timeout=62);(d/'result.json').write_text(p.stdout);(d/'stderr.log').write_text(p.stderr);assert p.returncode==0;r=json.loads(p.stdout);bad=r['dual_bound']is not None and F(str(r['dual_bound']))>opt
 if label=='v3':assert r['status']=='numerical_error'and r['dual_bound']is None and r['gap']is None
 else:assert r['status']=='optimal'and bad
 v=validate(m,r);atomic_json(d/'validation.json',v);assert v['valid']is True;records.append(dict(variant=label,status=r['status'],objective=r['objective'],dual_bound=r['dual_bound'],exact_optimum=str(opt),strict_dual_violation=bad,point_valid=True,result_sha256=sha256(d/'result.json')))
atomic_json(out/'summary.json',dict(records=records));print(records)
