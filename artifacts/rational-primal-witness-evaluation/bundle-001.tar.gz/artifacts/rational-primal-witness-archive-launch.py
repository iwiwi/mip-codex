from pathlib import Path
import time,json,subprocess
for version in ['v2','v3']:
 p=Path(f'artifacts/rational-primal-witness-{version}-development-audit/exit.json')
 while not p.exists():time.sleep(1)
 assert json.loads(p.read_text())['status']=='complete'
 with Path(f'artifacts/rational-primal-witness-{version}-development-analysis-final.log').open('w')as f:subprocess.run(['python3',f'artifacts/rational-primal-witness-{version}-development-analyze.py'],stdout=f,stderr=subprocess.STDOUT,check=True)
subprocess.run(['taskset','-c','43','python3','artifacts/rational-primal-witness-archive.py'],check=True)
