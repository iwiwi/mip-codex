from pathlib import Path
import re
root=Path('/home/ubuntu/mip-primal-witness')
for folder in ['src','tests','examples']:
 for p in (root/folder).rglob('*.rs'):
  s=p.read_text();t=re.sub(r'^(\s*)original_decimal:',r'\1decimal_source: None,\n\1original_decimal:',s,flags=re.M)
  if t!=s:p.write_text(t)
p=root/'src/model.rs';s=p.read_text().replace('pub struct Model {','pub struct Model {\n    #[serde(skip)]\n    pub decimal_source: Option<std::sync::Arc<crate::primal_witness::Source>>,');p.write_text(s)
p=root/'src/mps.rs';s=p.read_text().replace('Result<(f64, bool), String>','Result<(f64, bool, String), String>');s=s.replace('exact_float_token(&format!("{sum}e{exponent}"), value),','exact_float_token(&format!("{sum}e{exponent}"), value),\n        format!("{sum}e{exponent}"),')
s=s.replace('    let mut row_names = HashMap::new();','    let mut source=crate::primal_witness::Source::default();\n    let mut row_names = HashMap::new();')
s=s.replace('    for (j, v) in model.variables.iter_mut().enumerate() {','''    if model.offset_enclosure != Some([model.offset;2]) {
        source.offset=rhs_tokens[objective].as_deref().map(negate_token);
    }
    for (j, v) in model.variables.iter_mut().enumerate() {
        for (side,(bound,enclosure)) in [(v.lower,v.lower_enclosure),(v.upper,v.upper_enclosure)].into_iter().enumerate(){
            if bound.is_some_and(|b|enclosure!=Some([b,b])) {
                source.variable_bounds.insert((j,side),bound_tokens[j][side].clone().ok_or("missing original bound token")?);
            }
        }''')
s=s.replace('let (value, exact_coefficient) = if end == first + 1 {','let (value, exact_coefficient, exact_token) = if end == first + 1 {')
s=s.replace('is_none_or(|t| exact_float_token(t, entries[first].1)),','is_none_or(|t| exact_float_token(t, entries[first].1)),\n                    entries[first].2.clone().unwrap_or_else(||format!("{:.0}",entries[first].1)),')
s=s.replace('            row.exact_coefficients &= exact_coefficient;','''            if !exact_coefficient {
                if i==objective {source.objective.insert(j,exact_token);}
                else if kinds[i]!="N" {source.coefficients.insert((model.rows.len(),j),exact_token);}
            }
            row.exact_coefficients &= exact_coefficient;''')
s=s.replace('        let b = rhs[i];','        let b = rhs[i];\n        let mut endpoint_tokens=[rhs_tokens[i].clone(),rhs_tokens[i].clone()];')
s=s.replace('let (value, exact_endpoint) = decimal_sum_metadata(','let (value, exact_endpoint, exact_token) = decimal_sum_metadata(')
s=s.replace('            let enclosure = enclose(value, exact_endpoint);','''            let enclosure = enclose(value, exact_endpoint);
            let side=match kinds[i].as_str(){"L"=>0,"G"=>1,"E"if r>=0.=>1,"E"=>0,_=>unreachable!()};
            endpoint_tokens[side]=Some(exact_token);''')
s=s.replace('        model.rows.push(row);','''        for (side,(bound,enclosure)) in [(row.lower,row.lower_enclosure),(row.upper,row.upper_enclosure)].into_iter().enumerate(){
            if bound.is_some_and(|b|enclosure!=Some([b,b])) {
                source.row_bounds.insert((model.rows.len(),side),endpoint_tokens[side].clone().ok_or("missing original row endpoint")?);
            }
        }
        model.rows.push(row);''')
s=s.replace('    Ok(model)\n}', '    source.seal(&model);\n    model.decimal_source=Some(std::sync::Arc::new(source));\n    Ok(model)\n}',1)
p.write_text(s)
