NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj 2 link 4
 y link -1 cap 0.100000000000000000000000
RHS
 rhs obj -1 link -2
 rhs cap 0.199999999999999999999998
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
