NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 L cap
COLUMNS
 x obj 2 link 5
 y link -3 cap 2.000000000000000000000000
RHS
 rhs obj 1 link 0
 rhs cap 6.666666666666666666666668
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
