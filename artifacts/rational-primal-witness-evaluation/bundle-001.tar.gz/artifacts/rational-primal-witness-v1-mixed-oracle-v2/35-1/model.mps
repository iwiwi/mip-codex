NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 L cap
COLUMNS
 x obj 1 link 4
 y link -6 cap 2.000000000000000000000000
RHS
 rhs obj -3 link 1
 rhs cap -1.666666666666666666666668
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
