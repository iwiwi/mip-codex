NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 L cap
COLUMNS
 x obj 1 link 3
 y link -4 cap 0.100000000000000000000000
RHS
 rhs obj 3 link 0
 rhs cap 0.075000000000000000000001
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
