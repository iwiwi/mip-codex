NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj 2 link 5
 y link -4 cap 2.000000000000000000000000
RHS
 rhs obj 0 link -1
 rhs cap 0.500000000000000000000001
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
