NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj 2 link 5
 y link -3 cap 1.000000000000000000000000
RHS
 rhs obj 3 link 0
 rhs cap 3.333333333333333333333334
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
