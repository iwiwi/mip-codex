NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E link
 L cap
COLUMNS
 x obj 2 link 5
 y link -1 cap 2.000000000000000000000000
RHS
 rhs obj -2 link 2
 rhs cap 5.999999999999999999999998
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
