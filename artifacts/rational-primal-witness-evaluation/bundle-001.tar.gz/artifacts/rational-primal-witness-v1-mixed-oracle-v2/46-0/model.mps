NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E link
 L cap
COLUMNS
 x obj 1 link 2
 y link -7 cap 1.000000000000000000000000
RHS
 rhs obj -2 link 0
 rhs cap 0.000000000000000000000001
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
