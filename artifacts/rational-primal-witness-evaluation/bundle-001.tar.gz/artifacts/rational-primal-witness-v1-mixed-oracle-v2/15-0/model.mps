NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj -3 link 3
 y link -3 cap 2.000000000000000000000000
RHS
 rhs obj -4 link -1
 rhs cap 4.666666666666666666666664
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
