NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj -3 link 4
 y link -4 cap 2.000000000000000000000000
RHS
 rhs obj 1 link -2
 rhs cap -1.000000000000000000000000
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
