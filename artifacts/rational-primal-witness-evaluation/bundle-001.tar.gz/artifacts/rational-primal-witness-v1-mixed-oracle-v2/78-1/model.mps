NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj -3 link 1
 y link -4 cap 1.000000000000000000000000
RHS
 rhs obj 5 link 1
 rhs cap 0.000000000000000000000001
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
