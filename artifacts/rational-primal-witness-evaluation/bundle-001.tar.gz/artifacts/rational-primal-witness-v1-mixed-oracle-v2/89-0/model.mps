NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E link
 L cap
COLUMNS
 x obj 2 link 5
 y link -6 cap 0.100000000000000000000000
RHS
 rhs obj -2 link -1
 rhs cap 0.099999999999999999999999
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
