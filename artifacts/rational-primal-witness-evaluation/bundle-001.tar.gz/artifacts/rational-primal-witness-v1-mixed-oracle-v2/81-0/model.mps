NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj -1 link 1
 y link -3 cap 1.000000000000000000000000
RHS
 rhs obj -1 link -1
 rhs cap 0.666666666666666666666667
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
