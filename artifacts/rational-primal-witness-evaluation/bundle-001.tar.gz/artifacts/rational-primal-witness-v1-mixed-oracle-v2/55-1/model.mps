NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 L cap
COLUMNS
 x obj 1 link 4
 y link -7 cap 0.100000000000000000000000
RHS
 rhs obj 3 link 0
 rhs cap 0.057142857142857142857142
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
