NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj 1 link 3
 y link -5 cap 1.000000000000000000000000
RHS
 rhs obj -5 link 2
 rhs cap -0.999999999999999999999998
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
