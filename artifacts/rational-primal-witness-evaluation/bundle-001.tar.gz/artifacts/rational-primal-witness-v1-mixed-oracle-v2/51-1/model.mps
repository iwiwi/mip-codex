NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj 2 link 2
 y link -5 cap 2.000000000000000000000000
RHS
 rhs obj -4 link -1
 rhs cap 1.199999999999999999999999
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
