NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 L cap
COLUMNS
 x obj -3 link 1
 y link -7 cap 2.000000000000000000000000
RHS
 rhs obj -2 link 0
 rhs cap -0.285714285714285714285713
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
