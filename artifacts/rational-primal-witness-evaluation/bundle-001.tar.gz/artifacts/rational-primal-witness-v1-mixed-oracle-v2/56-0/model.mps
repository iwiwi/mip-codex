NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E link
 L cap
COLUMNS
 x obj 1 link 4
 y link -2 cap 1.000000000000000000000000
RHS
 rhs obj -1 link 2
 rhs cap -2.999999999999999999999999
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
