NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj 1 link 5
 y link -2 cap 0.100000000000000000000000
RHS
 rhs obj 0 link 2
 rhs cap -0.100000000000000000000000
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
