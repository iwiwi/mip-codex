NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj 2 link 3
 y link -2 cap 0.100000000000000000000000
RHS
 rhs obj 5 link -2
 rhs cap 0.250000000000000000000002
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
