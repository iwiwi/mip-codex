NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj -1 link 3
 y link -7 cap 0.100000000000000000000000
RHS
 rhs obj -3 link -2
 rhs cap 0.028571428571428571428569
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
