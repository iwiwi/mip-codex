NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 L cap
COLUMNS
 x obj -1 link 1
 y link -2 cap 1.000000000000000000000000
RHS
 rhs obj -2 link 1
 rhs cap 0.000000000000000000000001
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
