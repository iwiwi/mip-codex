NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj 1 link 5
 y link -7 cap 2.000000000000000000000000
RHS
 rhs obj -1 link 2
 rhs cap 0.857142857142857142857144
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
