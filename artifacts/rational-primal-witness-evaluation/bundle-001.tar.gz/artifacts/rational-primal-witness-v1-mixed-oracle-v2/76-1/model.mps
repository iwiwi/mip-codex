NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 L cap
COLUMNS
 x obj 2 link 1
 y link -6 cap 2.000000000000000000000000
RHS
 rhs obj -4 link 2
 rhs cap -0.666666666666666666666668
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
