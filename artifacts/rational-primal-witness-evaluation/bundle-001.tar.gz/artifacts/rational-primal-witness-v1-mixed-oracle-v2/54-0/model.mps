NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj -3 link 2
 y link -6 cap 0.100000000000000000000000
RHS
 rhs obj -5 link 0
 rhs cap 0.066666666666666666666665
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
