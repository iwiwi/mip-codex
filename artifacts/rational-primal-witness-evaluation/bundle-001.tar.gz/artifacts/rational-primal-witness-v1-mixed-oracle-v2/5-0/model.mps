NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E link
 L cap
COLUMNS
 x obj -1 link 1
 y link -1 cap 1.000000000000000000000000
RHS
 rhs obj -1 link 2
 rhs cap -3.000000000000000000000000
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
