NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 L cap
COLUMNS
 x obj -3 link 5
 y link -3 cap 2.000000000000000000000000
RHS
 rhs obj -5 link 2
 rhs cap -1.333333333333333333333333
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
