NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E link
 L cap
COLUMNS
 x obj -3 link 2
 y link -6 cap 2.000000000000000000000000
RHS
 rhs obj 0 link -2
 rhs cap 1.333333333333333333333332
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
