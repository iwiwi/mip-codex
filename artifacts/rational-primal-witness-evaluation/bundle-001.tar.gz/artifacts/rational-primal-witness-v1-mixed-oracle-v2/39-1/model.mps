NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj 1 link 1
 y link -4 cap 2.000000000000000000000000
RHS
 rhs obj -2 link 0
 rhs cap 0.500000000000000000000002
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
