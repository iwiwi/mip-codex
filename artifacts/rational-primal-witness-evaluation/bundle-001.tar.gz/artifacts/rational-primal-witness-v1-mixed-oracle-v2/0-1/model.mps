NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E link
 G cap
COLUMNS
 x obj -1 link 4
 y link -1 cap 2.000000000000000000000000
RHS
 rhs obj 0 link -1
 rhs cap 17.999999999999999999999998
BOUNDS
 LI b x -2
 UI b x 2
 LO b y -4
 UP b y 4
ENDATA
