from pathlib import Path
from fractions import Fraction as F
import json,subprocess,os,sys,random,resource,copy
root=Path.cwd();frozen=root/'artifacts/rational-primal-witness-v3-diagnostic';sys.path.insert(0,str(frozen/'scripts'));from verify_cover_cuts import validate_cut_proofs
from verify_primal_witness import verify
from benchmark_common import atomic_json,sha256
os.environ['MIP_ABSOLUTE_CHECKER']=str(root/'third_party/miplib-checker/bin/solchecker-absolute');from validate_solution import validate
os.sched_setaffinity(0,{41});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));out=root/'artifacts/rational-primal-witness-v3-fractional-lp-oracle';out.mkdir();rng=random.Random(2026111751);bins={v:root/'artifacts'/(p+'-diagnostic')/'bin/mip-codex'for v,p in [('before','implied-boundary-final'),('after','rational-primal-witness-v3')]};records=[];tampered=0
atomic_json(out/'experiment.json',dict(seed=2026111751,templates=100,senses=2,variants=2,cpu=41,seconds=2,purpose='unique rational LP optimum q*y=p, signed decimal costs/offsets; exact objective and dual checks; all points/GMP and rational witnesses checked',binaries={v:dict(path=str(p),sha256=sha256(p))for v,p in bins.items()}))
def fraction(s):return F(s.replace('D','e'))
def negate(s):return s[1:]if s.startswith('-')else'-'+s
try:
 for case in range(100):
  p=rng.randint(-8,8);q=rng.randint(1,9);c=rng.choice(['-3','-1','1','2','0.1','-0.2','1D-1','1e-20','1.00000000000000000001']);offset=rng.choice(['0','0.3','-0.7','1.00000000000000000001']);opt=fraction(offset)+fraction(c)*F(p,q)
  for maximize in [False,True]:
   d=out/f'{case}-{int(maximize)}';d.mkdir();m=d/'model.mps';m.write_text('NAME rational\nOBJSENSE\n '+('MAX'if maximize else'MIN')+f'\nROWS\n N obj\n E row\nCOLUMNS\n y obj {c} row {q}\nRHS\n rhs row {p} obj {negate(offset)}\nBOUNDS\n LO b y -10\n UP b y 10\nENDATA\n')
   for label,b in bins.items():
    e=d/label;e.mkdir();env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};p0=subprocess.run([str(b),'solve',str(m),'2'],env=env,capture_output=True,text=True,timeout=62);(e/'result.json').write_text(p0.stdout);(e/'stderr.log').write_text(p0.stderr);assert p0.returncode==0;r=json.loads(p0.stdout);assert r['status']in ['optimal','numerical_error'],(case,label,r['status'])
    if r['status']=='optimal':assert abs(F(str(r['objective']))-opt)<=F(1,10**8)*(1+abs(opt)),(case,label,'objective',r['objective'],opt)
    else:assert r['dual_bound']is None and r['gap']is None
    bad_dual=r['dual_bound']is not None and(-1 if maximize else 1)*F(str(r['dual_bound']))>(-1 if maximize else 1)*opt
    if label=='after':assert not bad_dual,(case,label,'dual',r['dual_bound'],opt)
    check=validate_cut_proofs(m,r);atomic_json(e/'proof-validation.json',check);assert check['valid']is True,(case,label,check)
    point=False
    if r['values']is not None:
     v=validate(m,r);atomic_json(e/'validation.json',v);assert v['valid']is True,(case,label,v);point=True
    if r.get('rational_primal_proof')is not None:
     check=verify(m,r);atomic_json(e/'primal-proof-validation.json',check);assert check['valid']and check['present']
     for edit in ['schema','index','objective','dual']+(['numerator','denominator','empty']if r['rational_primal_proof']['values']else[]):
      bad=copy.deepcopy(r);a=bad['rational_primal_proof']['values']
      if edit=='schema':bad['rational_primal_proof']['extra']=0
      elif edit=='numerator':a[0]['numerator']=str(int(a[0]['numerator'])+1)
      elif edit=='denominator':a[0]['denominator']='0'
      elif edit=='index':a.append(dict(variable=-1,numerator='0',denominator='1'))
      elif edit=='objective':bad['objective']+=1
      elif edit=='dual':bad['dual_bound']=float(opt)+(-1 if maximize else 1)
      else:a.clear()
      try:verify(m,bad)
      except (ValueError,AssertionError):tampered+=1
      else:raise AssertionError((case,label,'accepted tamper',edit))
    records.append(dict(case=case,maximize=maximize,variant=label,status=r['status'],objective=r['objective'],optimum=str(opt),strict_dual_violation=bad_dual,point_valid=point,rational_proof=r.get('rational_primal_proof')is not None,result_sha256=sha256(e/'result.json')));atomic_json(out/'records.json',records)
   if len(records)%80==0:print(len(records),flush=True)
 from collections import Counter
 assert len(records)==400;summary={v:dict(outputs=sum(r['variant']==v for r in records),statuses=dict(Counter(r['status']for r in records if r['variant']==v)),strict_dual_violations=sum(r['strict_dual_violation']for r in records if r['variant']==v),rational_proofs=sum(r['rational_proof']for r in records if r['variant']==v),points=sum(r['point_valid']for r in records if r['variant']==v))for v in bins};summary['tampered_rejected']=tampered;atomic_json(out/'summary.json',summary);atomic_json(out/'exit.json',dict(status='complete'));print(summary)
except BaseException as error:atomic_json(out/'exit.json',dict(status='failed',completed=len(records),error=str(error)));raise
