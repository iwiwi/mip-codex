from pathlib import Path
import hashlib,json,tarfile
root=Path.cwd();out=root/'artifacts/zero-phase-one-postmerge-evaluation';assert not out.exists();out.mkdir();paths=set()
patterns=['zero-phase-one-main-*','zero-phase-one-final-create*','zero-phase-one-final-snapshot-verification.json','zero-phase-one-main-collision-prevention.json','zero-phase-one-main-update*','zero-phase-one-postmerge-*','zero-phase-one-pr-*','zero-phase-one-final-pr-*','zero-phase-one-final-ai-usage.json']
for pattern in patterns:
 for p in (root/'artifacts').glob(pattern):
  if p==out or p.name=='zero-phase-one-postmerge-archive-run.log':continue
  if p.is_file():paths.add(p)
  elif p.is_dir():paths.update(q for q in p.rglob('*')if q.is_file())
paths.update(p for p in (root/'artifacts/smoke-20261117-201445-tm1umz7t').rglob('*')if p.is_file())
for name in ['zero-phase-one-final-20261117']:
 run=root/'artifacts/runs'/name;paths.add(run/'config.json');paths.update(p for p in (run/'snapshot').rglob('*')if p.is_file());p=run/'OBSOLETE.json'
 if p.exists():paths.add(p)
ledger=[];excluded=[]
for p in sorted(paths):
 assert not p.is_symlink();r=dict(path=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 with p.open('rb')as f:elf=f.read(4)==b'\x7fELF'
 (excluded if elf else ledger).append(r)
bundle=out/'bundle-001.tar.gz'
with tarfile.open(bundle,'w:gz',compresslevel=6)as t:
 for r in ledger:t.add(root/r['path'],arcname=r['path'],recursive=False)
with tarfile.open(bundle,'r:gz')as t:
 assert len(t.getmembers())==len(ledger)
 for m,r in zip(t.getmembers(),ledger):
  assert m.name==r['path'];data=t.extractfile(m).read();assert len(data)==r['bytes']and hashlib.sha256(data).hexdigest()==r['sha256']
(out/'manifest.json').write_text(json.dumps(ledger,indent=2));(out/'excluded-elf.json').write_text(json.dumps(excluded,indent=2));s=dict(files=len(ledger),raw_bytes=sum(r['bytes']for r in ledger),compressed_bytes=bundle.stat().st_size,excluded_elfs=len(excluded),all_payload_sha256_verified=True,bundle_sha256=hashlib.sha256(bundle.read_bytes()).hexdigest());(out/'summary.json').write_text(json.dumps(s,indent=2));print(s)
p=root/'experiments/zero-phase-one-snapshot-20261117.json';p.parent.mkdir(exist_ok=True);p.write_bytes((root/'artifacts/zero-phase-one-final-snapshot-verification.json').read_bytes())
