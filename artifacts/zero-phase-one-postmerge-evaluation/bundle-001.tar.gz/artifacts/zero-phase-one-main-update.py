from pathlib import Path
import subprocess,hashlib,json
root=Path.cwd();record=json.loads((root/'artifacts/zero-phase-one-pr-merged.json').read_text());assert record['state']=='MERGED';target=record['mergeCommit']['oid'];subprocess.run(['git','fetch','origin','main'],check=True);assert subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()==target
backup=Path('/tmp/zero-phase-main120-untracked');assert not backup.exists();backup.mkdir();rows=[]
for name in subprocess.check_output(['git','diff','--name-only','--diff-filter=A','-z','HEAD..origin/main']).decode().split('\0'):
 if not name:continue
 p=root/name
 if not p.is_file()or subprocess.run(['git','ls-files','--error-unmatch','--',name],capture_output=True).returncode==0:continue
 blob=subprocess.check_output(['git','show','origin/main:'+name]);h=hashlib.sha256(blob).hexdigest();assert hashlib.sha256(p.read_bytes()).hexdigest()==h,name;q=backup/name;q.parent.mkdir(parents=True,exist_ok=True);p.rename(q);rows.append(dict(path=name,sha256=h,backup=str(q)))
(root/'artifacts/zero-phase-one-main-collision-prevention.json').write_text(json.dumps(dict(files=rows,reason='pre-compare all incoming untracked paths before pull'),indent=2));subprocess.run(['git','pull','--ff-only'],check=True);assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==target;print('updated',target,'identical untracked files preserved',len(rows))
