from pathlib import Path
import os,sys,json,subprocess,time,shutil,resource
sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256,require_solver_origin
root=Path.cwd();out=root/'artifacts/resource-priced-repair-prototype';out.mkdir();binary=root/'target/release/examples/resource_priced_repair';info=require_solver_origin(root,binary);shutil.copy2(binary,out/'resource_priced_repair');shutil.copy2(root/'examples/resource_priced_repair.rs',out/'source.rs');binary=out/'resource_priced_repair';os.sched_setaffinity(0,{46});manifest=json.loads((root/'data/manifest.json').read_text())['instances'];records=[]
def restrict():resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3))
for name in ['map10','map16715-04']:
 r=next(v for v in manifest if v['name'].split('.')[0]==name);assert r['split']=='development';model=root/r['path'];assert sha256(model)==r['sha256'];parent=root/'artifacts/feasible-bound-start-root-pilot'/name/'0/result.json'
 for seed in range(3):
  d=out/name/str(seed);d.mkdir(parents=True);candidate=d/'candidate.json';cmd=[str(binary),str(model),str(parent),'3',str(candidate),str(seed)];atomic_json(d/'job.json',dict(command=cmd,cpu=46,memory_bytes=16*1024**3,input_sha256=r['sha256'],parent_sha256=sha256(parent),binary_sha256=sha256(binary),build_info=info));start=time.monotonic();run=subprocess.run(cmd,capture_output=True,text=True,preexec_fn=restrict,timeout=60);(d/'stdout.log').write_text(run.stdout);(d/'stderr.log').write_text(run.stderr);atomic_json(d/'execution.json',dict(exit_code=run.returncode,wall_seconds=time.monotonic()-start));assert run.returncode==0;v=json.loads(run.stdout);records.append(dict(name=name,seed=seed,**v));print(json.dumps(records[-1]),flush=True)
atomic_json(out/'records.json',records);atomic_json(out/'exit.json',dict(status='complete',trials=len(records),candidates=sum(r['candidate']for r in records)))
