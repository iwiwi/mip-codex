from pathlib import Path
from fractions import Fraction as F
import random,json,subprocess,os,sys
import highspy,numpy as np
sys.path.insert(0,'scripts')
from benchmark_common import atomic_json,sha256,require_solver_origin
os.sched_setaffinity(0,{42})
root=Path.cwd();out=root/'artifacts/feasible-bound-start-oracle';out.mkdir(exist_ok=True)
binary=root/'target/release/examples/bound_start_lp';info=require_solver_origin(root,binary)
rng=random.Random(2026111741);records=[];tol=F(1,10**6)
atomic_json(out/'experiment.json',dict(seed=2026111741,build_info=info,binary_sha256=sha256(binary),templates=100,senses=2,columns=1300,cpu=42))
def oracle(v,c):
 active=[j for j,col in enumerate(v['columns'])if col or c[j]];cols=[v['columns'][j]for j in active]
 h=highspy.Highs();h.setOptionValue('output_flag',False);h.setOptionValue('threads',1);h.setOptionValue('presolve','off');p=highspy.HighsLp();p.num_col_=len(active);p.num_row_=len(v['rhs']);p.col_cost_=np.array([c[j]for j in active]);p.col_lower_=np.zeros(len(active));p.col_upper_=np.array([v['upper'][j]for j in active]);p.row_upper_=np.array(v['rhs']);p.row_lower_=np.array([b if e else b-u for b,e,u in zip(v['rhs'],v['equality'],v['slack_upper'])]);p.a_matrix_.format_=highspy.MatrixFormat.kColwise;p.a_matrix_.start_=np.array([sum(map(len,cols[:j]))for j in range(len(cols)+1)],dtype=np.int32);p.a_matrix_.index_=np.array([i for col in cols for i,a in col],dtype=np.int32);p.a_matrix_.value_=np.array([a for col in cols for i,a in col]);h.passModel(p);h.run();assert h.getModelStatus()==highspy.HighsModelStatus.kOptimal;return h.getObjectiveValue()
def verify(v,c,a,expected):
 a=a['outcome'];assert a['status']=='optimal',a
 x=list(map(lambda z:F(str(z)),a['x']));assert len(x)==1300
 assert all(-tol<=z<=F(str(u))+tol for z,u in zip(x,v['upper']))
 sums=[F(0)]*len(v['rhs'])
 for col,z in zip(v['columns'],x):
  for i,coefficient in col:sums[i]+=F(str(coefficient))*z
 for s,b,e,u in zip(sums,v['rhs'],v['equality'],v['slack_upper']):
  residual=F(str(b))-s
  assert abs(residual)<=tol if e else -tol<=residual<=F(str(u))+tol
 obj=sum(F(str(a))*z for a,z in zip(c,x));assert abs(obj-F(str(a['objective'])))<=F(1,10**8)*(1+abs(obj));assert abs(float(obj)-expected)<=1e-8*(1+abs(expected))
for case in range(100):
 n=rng.randint(2,8);m=rng.randint(2,8);upper=[float(rng.randint(1,4))for _ in range(1300)];mask=[bool(rng.getrandbits(1))for _ in range(n)]+[False]*(1300-n);mask[0]=True;plant=[u if b else 0 for u,b in zip(upper,mask)];columns=[[]for _ in upper];rhs=[];eq=[];su=[]
 rows=[]
 for i in range(m+2):
  co=[(j,float(rng.randint(-4,4)))for j in range(n)];co=[(j,a)for j,a in co if a];e=i%3==0;u=float(rng.randint(1,5));b=sum(a*plant[j]for j,a in co)+(0 if e else rng.randint(0,int(u)))
  if i<m:
   for j,a in co:columns[j].append((i,a))
   rhs.append(b);eq.append(e);su.append(u)
  else:rows.append(dict(coefficients=co,rhs=b,equality=e,slack_upper=u))
 for sense in [1,-1]:
  costs=[[float(sense*rng.randint(-5,5))for _ in range(n)]+[0.]*(1300-n)for _ in range(3)]
  v=dict(columns=columns,rhs=rhs,upper=upper,equality=eq,slack_upper=su,costs=costs,at_upper=mask,rows=rows)
  d=out/f'{case}-{sense}';d.mkdir(exist_ok=True);atomic_json(d/'input.json',[v]);run=subprocess.run([str(binary)],input=json.dumps([v]),text=True,capture_output=True,timeout=30);(d/'result.jsonl').write_text(run.stdout);(d/'stderr').write_text(run.stderr);assert run.returncode==0
  results=[json.loads(z)for z in run.stdout.splitlines()];assert len(results)==5
  current=json.loads(json.dumps(v))
  for k,r in enumerate(results):
   c=costs[min(k,2)]
   if k>=3:
    row=rows[k-3];idx=len(current['rhs']);current['rhs'].append(row['rhs']);current['equality'].append(row['equality']);current['slack_upper'].append(row['slack_upper'])
    for j,a in row['coefficients']:current['columns'][j].append((idx,a))
   expected=oracle(current,c)
   for mode in ['seeded','warm','cold']:verify(current,c,r[mode],expected)
   records.append(dict(case=case,sense=sense,step=k,expected=expected,seeded_successes=r['seeded']['successes'],seeded_pivots=r['seeded']['pivots'],cold_pivots=r['cold']['pivots']))
  atomic_json(out/'progress.json',dict(comparisons=len(records),point_checks=3*len(records)))
atomic_json(out/'records.json',records);atomic_json(out/'summary.json',dict(comparisons=len(records),point_checks=3*len(records),successes=sum(r['seeded_successes']for r in records),seeded_pivots=sum(r['seeded_pivots']for r in records),cold_pivots=sum(r['cold_pivots']for r in records)));atomic_json(out/'exit.json',dict(status='complete'));print((out/'summary.json').read_text())
