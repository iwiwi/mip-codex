from pathlib import Path
import os,sys,json,re,subprocess,time,resource,importlib.util
root=Path.cwd();os.sched_setaffinity(0,{47});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',MIP_ABSOLUTE_CHECKER='/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker-absolute');sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256,require_solver_origin;from validate_solution import validate;from verify_cover_cuts import exact_model
spec=importlib.util.spec_from_file_location('orbit_guard',root/'artifacts/orbit-packing-guard.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
old=Path('/home/ubuntu/mip-adaptive-cover-portfolio');binary=old/'artifacts/cover-portfolio-default-frozen/bin/mip-codex';origin=require_solver_origin(old,binary);assert sha256(binary)=='6be1a01b69d3895c9d0faea159bcc131538e53c0acc2650d29c0177a9b53ca8c';transform=sys.argv[1];assert transform in ['reverse','complement-reverse'];out=root/('artifacts/orbit-'+transform+'-profile');out.mkdir();original=root/'data/raw/exploratory/sorrell7.mps.gz';exact=exact_model(original,True);names,conflict=guard.packing_graph(original,exact);n=len(names);ordering=sorted(range(n),key=lambda v:[int(t)if t.isdigit()else t for t in re.split(r'(\d+)',names[v])]);permutation=[0]*n
assert n&(n-1)==0
bits=n.bit_length()-1
for i,v in enumerate(ordering):
 target=int(f'{i:0{bits}b}'[::-1],2)
 if transform=='complement-reverse':target=n-1-target
 permutation[v]=ordering[target]
assert all(permutation[permutation[v]]==v for v in range(n));assert all(bool(conflict[a]&(1<<b))==bool(conflict[permutation[a]]&(1<<permutation[b]))for a in range(n)for b in range(a+1,n))
orbits=[(v,permutation[v])for v in range(n)if v<permutation[v]and not conflict[v]&(1<<permutation[v])];orbit_index={v:i for i,pair in enumerate(orbits)for v in pair};edges=[];adj=[[]for _ in orbits]
for i,(a,b)in enumerate(orbits):
 for j in range(i+1,len(orbits)):
  if any(conflict[u]&(1<<v)for u in[a,b]for v in orbits[j]):edges.append((i,j));adj[i].append(len(edges)-1);adj[j].append(len(edges)-1)
model=out/'quotient.mps';lines=['NAME orbit_restriction','ROWS',' N obj',*[f' L r{i}'for i in range(len(edges))],'COLUMNS']
for v in range(len(orbits)):lines.append(f' x{v} obj -2');lines.extend(f' x{v} r{i} 1'for i in adj[v])
lines+=['RHS',*[f' rhs r{i} 1'for i in range(len(edges))],'BOUNDS',*[f' BV b x{v}'for v in range(len(orbits))],'ENDATA'];model.write_text('\n'.join(lines)+'\n');atomic_json(out/'mapping.json',dict(original_names=names,permutation=permutation,orbits=orbits));atomic_json(out/'experiment.json',dict(cpu=47,threads=1,memory_bytes=16*1024**3,original_sha256=sha256(original),quotient_sha256=sha256(model),original_vertices=n,feasible_pair_orbits=len(orbits),quotient_edges=len(edges),strict_automorphism=True,transform=transform,fixed_points=sum(permutation[v]==v for v in range(n)),seconds=[60,180,3600],nodes=0,binary_sha256=sha256(binary),origin=origin,purpose='primal-only restricted quotient; own frozen Rust340 optimizer; no bound/optimality transfer; Python prototype transform must be ported before main adoption'));records=[]
for seconds in[60,180,3600]:
 d=out/str(seconds);d.mkdir();cmd=[str(binary),'solve',str(model),str(seconds),'0'];atomic_json(d/'job.json',dict(command=cmd,binary_sha256=sha256(binary),cpu=47));start=time.monotonic();run=subprocess.run(cmd,capture_output=True,text=True,timeout=seconds+60,env={**os.environ,'MIP_GRAPH_COVER_RESTARTS':'1'});(d/'stdout.log').write_text(run.stdout);(d/'stderr.log').write_text(run.stderr);atomic_json(d/'execution.json',dict(exit_code=run.returncode,wall_seconds=time.monotonic()-start));assert run.returncode==0,run.stderr;r=json.loads(run.stdout);atomic_json(d/'quotient-result.json',r);q=validate(model,r);atomic_json(d/'quotient-point-validation.json',q);assert q['valid'];chosen=[i for i in range(len(orbits))if r['values'][f'x{i}']==1];selected={v for i in chosen for v in orbits[i]};seeds=[]
 for visit in [ordering,list(reversed(ordering)),sorted(range(n),key=lambda v:(conflict[v].bit_count(),v))]:
  augmented=set(selected);mask=sum(1<<v for v in augmented)
  for v in visit:
   if v not in augmented and not conflict[v]&mask:augmented.add(v);mask|=1<<v
  seeds.append(augmented)
 selected=max(seeds,key=len);assert all(not conflict[v]&sum(1<<u for u in selected)for v in selected);values={name:int(v in selected)for v,name in enumerate(names)};objective=exact[4]+sum(exact[3].get(name,0)*value for name,value in values.items());original_result=dict(status='time_limit',objective=float(objective),dual_bound=None,gap=None,values=values,seconds=r['seconds'],purpose='feasible original point only; quotient bound discarded');atomic_json(d/'original-point.json',original_result);v=validate(original,original_result);atomic_json(d/'original-point-validation.json',v);assert v['valid'];record=dict(seconds_requested=seconds,component_seconds=r['seconds'],objective=float(objective),quotient_status=r['status'],selected_pairs=len(chosen),augmented_vertices=len(selected)-2*len(chosen),gmp_original_valid=True,gmp_quotient_valid=True,cover_stats=(r.get('binary_graph')or{}).get('cover_local'));records.append(record);atomic_json(out/'records.json',records);print(json.dumps(record),flush=True)
atomic_json(out/'exit.json',dict(status='complete',outputs=len(records),gmp_original_valid=len(records),gmp_quotient_valid=len(records)))
