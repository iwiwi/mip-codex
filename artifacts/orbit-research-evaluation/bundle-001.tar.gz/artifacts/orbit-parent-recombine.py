from pathlib import Path
import os,sys,json,importlib.util,itertools,time
os.sched_setaffinity(0,{46});os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MIP_ABSOLUTE_CHECKER='/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker-absolute');root=Path.cwd();sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256;from validate_solution import validate;from verify_cover_cuts import exact_model
spec=importlib.util.spec_from_file_location('orbit_guard',root/'artifacts/orbit-packing-guard.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard);model=root/'data/raw/exploratory/sorrell7.mps.gz';exact=exact_model(model,True);names,conflict=guard.packing_graph(model,exact);out=root/'artifacts/orbit-parent-recombine';out.mkdir();paths=[Path('/home/ubuntu/mip-adaptive-cover-portfolio/artifacts/cover-portfolio-default-main-controls/sorrell7.mps.gz/1/result.json')]
paths += [Path('/home/ubuntu/mip-weighted-cover-restarts/artifacts')/name/'result.json'for name in ['cover-restarts-v2-continuous','cover-restarts-v2-reseed','cover-restarts-v3-continuous','cover-restarts-v3-reseed']]
paths += list((root/'artifacts/orbit-seed-continuation').glob('*/*/result.json'));paths += list((root/'artifacts').glob('*-profile/180/original-point.json'));parents={};seed_records=[]
for p in paths:
 if not p.exists():continue
 r=json.load(open(p));v=validate(model,r);assert v['valid'];selected=frozenset(i for i,name in enumerate(names)if r['values'][name]==1);assert all(not conflict[i]&sum(1<<j for j in selected)for i in selected);parents.setdefault(selected,p);seed_records.append(dict(path=str(p),sha256=sha256(p),size=len(selected),gmp_valid=True))
atomic_json(out/'seeds.json',seed_records);solutions=list(parents);records=[];best=max(solutions,key=len);best_before=len(best)
for ia,ib in itertools.combinations(range(len(solutions)),2):
 A,B=solutions[ia],solutions[ib];common=A&B;left=sorted(A-B);right=sorted(B-A);adj=[[j for j,v in enumerate(right)if conflict[u]&(1<<v)]for u in left];mr=[-1]*len(right)
 def augment(u,seen):
  for v in adj[u]:
   if seen[v]:continue
   seen[v]=True
   if mr[v]<0 or augment(mr[v],seen):mr[v]=u;return True
  return False
 matching=sum(augment(u,[False]*len(right))for u in range(len(left)));ml=[-1]*len(left)
 for v,u in enumerate(mr):
  if u>=0:ml[u]=v
 zl={u for u in range(len(left))if ml[u]<0};zr=set();stack=list(zl)
 while stack:
  u=stack.pop()
  for v in adj[u]:
   if ml[u]==v or v in zr:continue
   zr.add(v)
   if mr[v]>=0 and mr[v]not in zl:zl.add(mr[v]);stack.append(mr[v])
 chosen=set(common)|{left[u]for u in zl}|{right[v]for v in range(len(right))if v not in zr};assert len(chosen)==len(A|B)-matching;assert len(chosen)>=max(len(A),len(B));assert all(not conflict[v]&sum(1<<u for u in chosen)for v in chosen)
 if len(chosen)>len(best):best=frozenset(chosen)
 records.append(dict(parent_a=ia,parent_b=ib,a_size=len(A),b_size=len(B),union=len(A|B),matching=matching,recombined_size=len(chosen)))
values={name:int(i in best)for i,name in enumerate(names)};objective=float(exact[4]+sum(exact[3].get(name,0)*v for name,v in values.items()));result=dict(status='time_limit',objective=objective,dual_bound=None,gap=None,values=values,purpose='own-parent bipartite union recombination; feasible point only; no global-bound transfer');atomic_json(out/'original-point.json',result);v=validate(model,result);assert v['valid'];atomic_json(out/'point-validation.json',v);atomic_json(out/'records.json',records);summary=dict(parent_files=len(seed_records),unique_parents=len(parents),pairs=len(records),best_before=best_before,best_after=len(best),objective=objective,gmp_valid=True,purpose='private prototype; optimizer matching implemented here; must port to Rust before main adoption');atomic_json(out/'summary.json',summary);atomic_json(out/'exit.json',dict(status='complete'));print(json.dumps(summary),flush=True)
