from pathlib import Path
import subprocess,json,os,hashlib,shutil,sys
root=Path.cwd();expected=json.load(open('artifacts/decimal-coefficient-safety-merged-state.json'))['mergeCommit']['oid'];assert root==Path('/home/ubuntu/mip-codex');assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='main';assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
def run(cmd,name):
 with(root/'artifacts'/('decimal-coefficient-safety-main-'+name+'.log')).open('w')as s:subprocess.run(cmd,stdout=s,stderr=subprocess.STDOUT,check=True)
run(['taskset','-c','56-63','git','fetch','origin','main'],'fetch');assert subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()==expected
added=subprocess.check_output(['git','diff','--name-only','--diff-filter=A','HEAD','origin/main'],text=True).splitlines();collisions=[];destination=Path('/tmp/decimal-coefficient-main122-untracked')
for name in added:
 p=root/name
 if not p.exists():continue
 assert subprocess.run(['git','ls-files','--error-unmatch',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0,name
 data=p.read_bytes();remote=subprocess.check_output(['git','show','origin/main:'+name]);assert data==remote,name
 blob=subprocess.check_output(['git','hash-object','--stdin'],input=data,text=False).decode().strip();assert blob==subprocess.check_output(['git','rev-parse','origin/main:'+name],text=True).strip()
 q=destination/name;q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();shutil.move(p,q);collisions.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),git_blob=blob,moved_to=str(q)))
(root/'artifacts/decimal-coefficient-safety-main-collision-prevention.json').write_text(json.dumps(collisions,indent=2));run(['taskset','-c','56-63','git','pull','--ff-only','origin','main'],'pull');assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==expected
run(['taskset','-c','56-63','env','CARGO_INCREMENTAL=0','cargo','build','--release'],'build');sys.path.insert(0,'scripts');from benchmark_common import require_solver_origin
os.sched_setaffinity(0,{43});info=require_solver_origin(root,root/'target/release/mip-codex');assert info['source_fingerprint']==info['library_source_fingerprint']=='8b579cacb175412d';assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no']);record=dict(main=expected,build_info=info,collisions=len(collisions),tracked_clean=True);(root/'artifacts/decimal-coefficient-safety-main-update.json').write_text(json.dumps(record,indent=2));print(json.dumps(record))
