from pathlib import Path
import json,subprocess,sys
root=Path.cwd();mode=sys.argv[1];assert mode in ['create','comment'];head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip();assert branch=='decimal-integer-coefficient-safety';summary=json.load(open('artifacts/decimal-coefficient-safety-continue-development-analysis.json'));assert summary['completed_pairs']==188 and summary['comparisons']['primal_pending']==0;archive=json.load(open('artifacts/decimal-coefficient-safety-evaluation/summary.json'));assert archive['all_payload_sha256_verified'];audit=json.load(open('artifacts/decimal-coefficient-safety-continue-development-parallel-audit/summary.json'));assert audit['completed']==audit['cut_valid']==376 and audit['points']==audit['strict_valid']==audit['official_valid']==130
link=f'https://github.com/iwiwi/mip-codex/blob/{head}/docs/DECIMAL_COEFFICIENT_SAFETY_RESULTS.md'
if mode=='create':
 text=f'''小数係数がbinary64で整数に丸まる場合、元のMPSに対して非保守的なLP下界を採用する問題を修正します。min −x、0≤x≤2、0.99999999999999999999 x≤1 に対する旧下界−1は真の最適値より大きく、修正後は元係数の区間証明を要求します。

証明できないLP下界は使わず、証明済み親下界で主解探索を続け、未証明の葉では最適性を撤回します。密LPの乗数返却、元制約からの有限境界導出も同じ検証へ接続します。

検証: Rust334成功4ignored、両LPエンジン各216解析例で不正下界0、混合整数200、全列挙1200・親証明1028・改ざん拒否8224・GMP1200点有効。開発188対は主解1改善4悪化・下界3改善1悪化、数値終了5→5、全376出力/130点GMP・公式有効。性能費用を隠さず正しさの修正として採用します。

[全版の結果と比較ソルバー測定]({link})。本評価240問は未起動、性能優位・新記録は未達成です。main121の統合後記録もmetadataとして保存しています。'''
else:
 text=f'''最終検証結果（ソースfb986443b5、通常/library指紋8b579cacb175412d）です。数値許容は緩めていません。

- 元小数係数の解析LP: 疎/密各216例で旧版の非保守的下界94/108件→0/0件。修正後は全optimal。JSON10進値とbinary64正確値の両方をFraction解析解へ許容なしで照合。両版・両エンジン計864点GMP有効。
- Rust334成功4ignored。混合整数200例は不正下界0、186optimal/14既存元点guardによる数値終了、全200点GMP有効。
- 一般800/二値400出力は全列挙一致、実際の親下界証明1028件・改ざん拒否8224件・GMP1200点が有効。出力検査の件数を全て形式的下界証明とは数えていません。
- 188×10秒、1thread、16GiB: 主解1改善4悪化183同値、下界3改善1悪化171同値13比較不能。前後とも182time/1optimal/5numeric、有限下界176→175。全376出力証明検査/130点GMP・公式有効。
- swath1の未証明下界は保留し、主解探索を続行。glass4の主解改善がある一方、blp-ic98/kasai/neos-911970/swath1は悪化。下界改善3問は検証呼出し0で直接効果と断定しません。

同じCPU46・10秒・1thread・16GiB、HiGHS1.16.0/SCIP10.0.2/GLPK5.0との最終候補比較:

|問題|ソルバー|主解|下界|状態|
|---|---|---:|---:|---|
|swath1|Rust|458.28144755|なし|time_limit|
||HiGHS|380.7482512|340.86466595|time_limit|
||SCIP|380.7482512|354.66394915|time_limit|
||GLPK|384.6757158|347.64582885|feasible_limit|
|glass4|Rust|2350021800|800002400|numerical_error|
||HiGHS|1833350033.333336|800005023.7561488|time_limit|
||SCIP|2066686683.333333|800005024.9445485|time_limit|
||GLPK|2240020202.331371|800004787.8862048|feasible_limit|

全8点GMP・公式/Rust2出力2カット有効。比較ソルバーが明確に良く、性能優位や新記録ではありません。正しさを維持するための修正です。生成1200検証と188比較は全4中間版も保持し、初版の数値終了5→20・主解11悪化等も削除していません。

記録は{archive['files']:,}ファイル、元{archive['raw_bytes']:,}bytes→{archive['compressed_bytes']:,}bytes/{archive['bundles']}束、全payload SHA256検証済み。凍結ELF{archive['excluded_elf']}個は除外して実体を保持。[詳細・全中間結果]({link})。主点検査は絶対1e−6（目的相対1e−8）、親下界・解析下界は許容なしです。

最終240問は未起動。native本評価は23:31UTC集計666/720、検査済最適HS134/SCIP109/GLPK23（集計のみ）。統合後にmain再buildと元点検査、未起動snapshot更新を行い、その後も期限まで汎用性能改善を続けます。'''
# Fresh local cumulative usage immediately before this PR action, with no intervening external calls.
u=json.loads(subprocess.check_output(['python3','scripts/ai_usage.py'],text=True));t=u['totals'];Path(f'artifacts/decimal-coefficient-safety-pr-{mode}-ai-usage.json').write_text(json.dumps(u,ensure_ascii=False,indent=2));text+=f"\n\nAI使用量（直前ローカル最終累積、{u['sessions']} sessions）: total {t['total_tokens']:,}, input {t['input_tokens']:,}（cached {t['cached_input_tokens']:,}を含む）, output {t['output_tokens']:,}（reasoning {t['reasoning_output_tokens']:,}を含む）。内数の二重加算なし。\n";p=root/f'artifacts/decimal-coefficient-safety-pr-{mode}.txt';p.write_text(text)
cmd=['gh','pr','create','--repo','iwiwi/mip-codex','--base','main','--head',branch,'--title','小数係数を含む元問題でLP下界を再検証する','--body-file',str(p)]if mode=='create'else['gh','pr','comment',str(int(sys.argv[2])),'--repo','iwiwi/mip-codex','--body-file',str(p)]
r=subprocess.run(cmd,capture_output=True,text=True);Path(f'artifacts/decimal-coefficient-safety-pr-{mode}.log').write_text(r.stdout+r.stderr);r.check_returncode();print(r.stdout)
