NAME gomory
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj 1
 x0 r0 2
 x0 r1 -1
 x0 r2 4
 x0 r3 -1
 x1 obj 1
 x1 r1 4
 x1 r2 3
RHS
 rhs r0 -6
 rhs r1 1
 rhs r2 -11
 rhs r3 5
BOUNDS
 LI b x0 -3
 UI b x0 -2
 LO b x1 -1
 UP b x1 1
ENDATA
