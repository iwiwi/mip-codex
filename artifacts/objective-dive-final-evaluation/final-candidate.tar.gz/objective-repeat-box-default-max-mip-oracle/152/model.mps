NAME gomory
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj 4
 x0 r0 -5
 x0 r2 -1
 x0 r3 1
 x0 r4 5
 x0 r5 -2
 x1 obj -2
 x1 r0 -4
 x1 r2 -5
 x1 r3 1
 x1 r5 2
RHS
 rhs r0 -3
 rhs r1 4
 rhs r2 -5
 rhs r3 1
 rhs r4 3
 rhs r5 4
BOUNDS
 LI b x0 -1
 UI b x0 0
 LO b x1 1
 UP b x1 2
ENDATA
