NAME gomory
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
COLUMNS
 x0 obj -4
 x0 r0 -5
 x0 r1 -1
 x0 r2 -1
 x0 r3 4
 x0 r4 2
 x1 obj -6
 x1 r0 -2
 x1 r1 3
 x1 r2 -4
 x1 r3 -3
 x1 r4 1
 x2 obj -4
 x2 r0 -4
 x2 r1 1
 x2 r2 2
 x2 r3 -2
 x2 r4 -1
 x3 obj 5
 x3 r1 -1
 x3 r2 -3
 x3 r3 -3
 x3 r4 -4
 x4 obj -3
 x4 r0 4
 x4 r1 3
 x4 r2 2
 x4 r3 -3
 x4 r4 4
RHS
 rhs r0 -21
 rhs r1 8
 rhs r2 -6
 rhs r3 -1
 rhs r4 2
BOUNDS
 LO b x0 -1
 UP b x0 2
 LI b x1 1
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LO b x3 -1
 UP b x3 1
 LI b x4 0
 UI b x4 2
ENDATA
