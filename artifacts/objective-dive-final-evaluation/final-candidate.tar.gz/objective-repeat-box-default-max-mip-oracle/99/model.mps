NAME gomory
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
COLUMNS
 x0 obj 3
 x0 r0 -5
 x0 r1 1
 x0 r2 3
 x1 obj 3
 x1 r0 -4
 x1 r2 -2
 x2 obj -3
 x2 r0 1
 x2 r1 -3
 x2 r2 3
RHS
 rhs r0 -2
 rhs r1 7
 rhs r2 2
BOUNDS
 LI b x0 1
 UI b x0 4
 LI b x1 -2
 UI b x1 1
 LO b x2 -3
 UP b x2 0
ENDATA
