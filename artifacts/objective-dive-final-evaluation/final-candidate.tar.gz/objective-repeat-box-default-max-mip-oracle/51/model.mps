NAME gomory
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
COLUMNS
 x0 obj -1
 x0 r0 4
 x0 r1 2
 x0 r2 -2
 x0 r3 3
 x0 r4 5
 x1 obj 3
 x1 r0 -5
 x1 r1 -2
 x1 r3 -1
 x1 r4 -1
 x2 obj -6
 x2 r0 -5
 x2 r1 -4
 x2 r2 -2
 x2 r3 -5
 x2 r4 -4
 x3 obj -2
 x3 r0 5
 x3 r1 -4
 x3 r2 3
 x3 r4 -3
 x4 obj 4
 x4 r0 -2
 x4 r1 2
 x4 r2 -1
 x4 r3 1
RHS
 rhs r0 33
 rhs r1 -2
 rhs r2 5
 rhs r3 7
 rhs r4 12
BOUNDS
 LO b x0 0
 UP b x0 2
 LI b x1 -3
 UI b x1 -1
 LO b x2 -1
 UP b x2 0
 LI b x3 -2
 UI b x3 1
 LI b x4 -3
 UI b x4 -1
ENDATA
