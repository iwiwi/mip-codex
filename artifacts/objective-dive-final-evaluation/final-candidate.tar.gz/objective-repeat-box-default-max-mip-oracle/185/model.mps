NAME gomory
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
COLUMNS
 x0 obj 3
 x0 r0 3
 x0 r2 3
 x0 r3 1
 x0 r4 4
 x1 obj 0
 x1 r0 2
 x1 r1 -2
 x1 r2 -1
 x1 r4 1
 x2 obj -2
 x2 r1 3
 x2 r2 1
 x2 r3 2
 x2 r4 3
 x3 obj -5
 x3 r1 -1
 x3 r2 5
 x3 r3 -1
 x3 r4 -4
 x4 obj 7
 x4 r0 4
 x4 r1 3
 x4 r2 2
 x4 r3 1
 x4 r4 -2
RHS
 rhs r0 1
 rhs r1 9
 rhs r2 5
 rhs r3 0
 rhs r4 -6
BOUNDS
 LO b x0 -1
 UP b x0 2
 LI b x1 -3
 UI b x1 0
 LI b x2 -2
 UI b x2 1
 LI b x3 0
 UI b x3 3
 LI b x4 1
 UI b x4 4
ENDATA
