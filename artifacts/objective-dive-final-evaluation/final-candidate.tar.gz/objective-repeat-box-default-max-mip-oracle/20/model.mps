NAME gomory
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
COLUMNS
 x0 obj 4
 x0 r0 2
 x0 r1 4
 x0 r2 3
 x1 obj -1
 x1 r0 5
 x1 r1 -2
 x1 r2 -4
 x2 obj -1
 x2 r0 1
 x2 r2 2
 x3 obj 0
 x3 r0 5
 x3 r1 -4
 x3 r2 4
 x4 obj -5
 x4 r0 -1
 x4 r1 1
 x4 r2 -4
 x5 obj -3
 x5 r0 -5
 x5 r1 -4
RHS
 rhs r0 8
 rhs r1 0
 rhs r2 -4
BOUNDS
 LI b x0 -3
 UI b x0 -1
 LI b x1 1
 UI b x1 4
 LO b x2 0
 UP b x2 3
 LI b x3 -2
 UI b x3 1
 LO b x4 -2
 UP b x4 -1
 LI b x5 -1
 UI b x5 0
ENDATA
