NAME gomory
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
COLUMNS
 x0 obj -4
 x0 r0 -1
 x0 r1 4
 x0 r2 2
 x0 r4 -3
 x0 r5 -3
 x0 r6 -2
 x1 obj 3
 x1 r0 4
 x1 r1 1
 x1 r2 -5
 x1 r3 3
 x1 r4 -4
 x1 r5 -3
 x1 r6 4
 x2 obj 1
 x2 r0 2
 x2 r1 4
 x2 r2 2
 x2 r3 -1
 x2 r4 -4
 x2 r5 3
 x2 r6 -1
RHS
 rhs r0 -3
 rhs r1 -3
 rhs r2 5
 rhs r3 1
 rhs r4 11
 rhs r5 10
 rhs r6 1
BOUNDS
 LO b x0 -2
 UP b x0 0
 LO b x1 -1
 UP b x1 1
 LI b x2 -1
 UI b x2 1
ENDATA
