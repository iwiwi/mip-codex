from pathlib import Path
import json,os,signal,time,datetime
root=Path.cwd();records=[]
for prefix in ['decimal-coefficient-safety-first','decimal-coefficient-safety-continue']:
 full=root/'artifacts'/(prefix+'-development-parallel-audit');assert json.load(open(full/'exit.json'))['status']=='complete';s=json.load(open(full/'summary.json'));assert s['completed']==s['cut_valid']==376 and s['strict_valid']==s['official_valid']==s['points']
 prior=root/'artifacts'/(prefix+'-development-audit');ps=[]
 for d in Path('/proc').iterdir():
  if not d.name.isdecimal():continue
  try:args=(d/'cmdline').read_bytes().split(b'\0')
  except OSError:continue
  if len(args)>1 and args[1]==f'artifacts/{prefix}-development-audit.py'.encode():ps.append(int(d.name))
 old=json.load(open(prior/'summary.json'));record=dict(prefix=prefix,prior_summary=old,complete_replacement=str(full),reason='full identical-checker audit validated all376; stop redundant serial work only',processes=[])
 for pid in ps:
  d=Path('/proc')/str(pid);record['processes'].append(dict(pid=pid,cmdline=(d/'cmdline').read_bytes().replace(b'\0',b' ').decode(),stat=(d/'stat').read_text()));os.kill(pid,signal.SIGTERM)
 records.append(record)
(root/'artifacts/decimal-coefficient-safety-duplicate-audit-termination.json').write_text(json.dumps(dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),records=records),indent=2))
print([(r['prefix'],[p['pid']for p in r['processes']])for r in records])
