from pathlib import Path
import json,subprocess,os
os.sched_setaffinity(0,{52});root=Path.cwd();source=root/'artifacts/decimal-coefficient-safety-continue-pilot';out=root/'artifacts/decimal-coefficient-safety-continue-pilot-audit-v2';out.mkdir();os.environ['MIP_ABSOLUTE_CHECKER']='/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker-absolute'
for d in sorted(source.iterdir()):
 job=json.load(open(d/'job.json'));model=job['command'][2];dest=out/d.name;dest.mkdir();cmd=[str(root/'.venv/bin/python'),str(root/'scripts/benchmark_validate.py'),model,str(d/'result.json'),'/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker',str(dest)];run=subprocess.run(cmd,capture_output=True,text=True,timeout=600);(out/(d.name+'.log')).write_text(run.stdout+run.stderr);assert run.returncode==0
 for name in ['strict','official']:
  r=json.load(open(dest/(name+'-validation.json')));assert r['valid']is True,(d,name,r)
 print(d.name,'valid',flush=True)
(out/'summary.json').write_text(json.dumps(dict(points=2,strict_valid=2,official_valid=2)))
