NAME near
ROWS
 N c
 E r
COLUMNS
 x c -1 r 1.00000000000000000001
 y r -1
RHS
 rhs r 0
BOUNDS
 BV b x
 LO b y 0
 UP b y 1
ENDATA
