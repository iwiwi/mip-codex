from pathlib import Path
from fractions import Fraction as F
import subprocess,json,os
sysroot=Path.cwd();out=Path('artifacts/decimal-coefficient-safety-controls-v2');out.mkdir();os.sched_setaffinity(0,{51});eps=F(1,10**20)
models={'integer_link':('NAME near\nROWS\n N c\n E r\nCOLUMNS\n x c -1 r 1.00000000000000000001\n y r -1\nRHS\n rhs r 0\nBOUNDS\n BV b x\n LO b y 0\n UP b y 1\nENDATA\n',F(0)),'continuous_upper':('NAME near\nROWS\n N c\n L r\nCOLUMNS\n x c -1 r 0.99999999999999999999\nRHS\n rhs r 1\nBOUNDS\n LO b x 0\n UP b x 2\nENDATA\n',-1/(1-eps))}
for name,(text,opt)in models.items():
 d=out/name;d.mkdir();model=d/'model.mps';model.write_text(text);cmd=[str(sysroot/'target/release/mip-codex'),'solve',str(model.resolve()),'2'];run=subprocess.run(cmd,capture_output=True,text=True,timeout=62);(d/'result.json').write_text(run.stdout);(d/'stderr.log').write_text(run.stderr);assert run.returncode==0;r=json.loads(run.stdout);dual=r.get('dual_bound');record=dict(status=r['status'],objective=r.get('objective'),dual_bound=dual,exact_optimum=str(opt),dual_conservative=dual is None or F(str(dual))<=opt,optimal_value_matches=r['status']!='optimal'or abs(F(str(r['objective']))-opt)<=F(1,10**8)*(1+abs(opt)));(d/'validation.json').write_text(json.dumps(record,indent=2));print(name,json.dumps(record),flush=True)
