from pathlib import Path
from fractions import Fraction as F
import json,subprocess,os,sys,itertools,resource
sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256
from verify_cover_cuts import exact_model,validate_cut_proofs
from validate_solution import validate
os.sched_setaffinity(0,{42});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));out=Path('artifacts/implied-boundary-integer-replay');out.mkdir();binary=Path('artifacts/implied-boundary-final-diagnostic/bin/mip-codex');records=[];atomic_json(out/'experiment.json',dict(sources=['integer-bound-safety-final-oracle','integer-bound-safety-final-oracle-unplanted'],binary_sha256=sha256(binary),cpu=42,seconds=2,purpose='re-enumerate original 800 decimal integer boundary models and audit all new points/proofs'))
try:
 for source in ['integer-bound-safety-final-oracle','integer-bound-safety-final-oracle-unplanted']:
  for model in sorted((Path('artifacts')/source).glob('*/model.mps')):
   d=out/source/model.parent.name;d.mkdir(parents=True);names,variables,rows,obj,off=exact_model(model,True);assert len(names)==3;feasible=[]
   for coords in itertools.product(range(-3,4),repeat=3):
    x=dict(zip(names,map(F,coords)))
    if all((v['lower']is None or x[n]>=v['lower'])and(v['upper']is None or x[n]<=v['upper'])for n,v in variables.items())and all((r['lower']is None or sum(a*x[n]for n,a in r['coefficients'].items())>=r['lower'])and(r['upper']is None or sum(a*x[n]for n,a in r['coefficients'].items())<=r['upper'])for r in rows):feasible.append(off+sum(obj.get(n,F(0))*x[n]for n in names))
   maximize=model.parent.name.endswith('-1');opt=(max if maximize else min)(feasible)if feasible else None;env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};run=subprocess.run([str(binary),'solve',str(model),'2'],env=env,capture_output=True,text=True,timeout=62);(d/'result.json').write_text(run.stdout);(d/'stderr.log').write_text(run.stderr);assert run.returncode==0;r=json.loads(run.stdout)
   assert r['status']in ['optimal','infeasible','numerical_error']
   if r['status']=='infeasible':assert opt is None
   elif r['status']=='optimal':assert opt is not None and abs(F(str(r['objective']))-opt)<=F(1,10**8)*(1+abs(opt))
   else:assert r['dual_bound']is None and r['gap']is None
   if r['dual_bound']is not None:assert opt is not None and(-1 if maximize else 1)*F(str(r['dual_bound']))<=(-1 if maximize else 1)*opt
   proof=validate_cut_proofs(model,r);atomic_json(d/'proof-validation.json',proof);assert proof['valid']is True
   point=False
   if r['values']is not None:
    v=validate(model,r);atomic_json(d/'validation.json',v);assert v['valid']is True;point=True
   records.append(dict(source=source,case=model.parent.name,status=r['status'],objective=r['objective'],optimum=str(opt),point_valid=point,input_sha256=sha256(model),result_sha256=sha256(d/'result.json')));atomic_json(out/'records.json',records)
   if len(records)%100==0:print(len(records),flush=True)
 from collections import Counter
 assert len(records)==800;atomic_json(out/'summary.json',dict(outputs=len(records),statuses=dict(Counter(r['status']for r in records)),points=sum(r['point_valid']for r in records),proofs_valid=len(records),all_correct=True));atomic_json(out/'exit.json',dict(status='complete'))
except BaseException as error:atomic_json(out/'exit.json',dict(status='failed',completed=len(records),error=str(error)));raise
