import time,subprocess,json
from pathlib import Path
p=Path('artifacts/implied-boundary-final-development-audit/exit.json')
while not p.exists():time.sleep(1)
assert json.loads(p.read_text())['status']=='complete'
with Path('artifacts/implied-boundary-final-development-analysis-final.log').open('w')as f:subprocess.run(['python3','artifacts/implied-boundary-final-development-analyze.py'],stdout=f,stderr=subprocess.STDOUT,check=True)
subprocess.run(['taskset','-c','43','python3','artifacts/implied-boundary-archive.py'],check=True)
