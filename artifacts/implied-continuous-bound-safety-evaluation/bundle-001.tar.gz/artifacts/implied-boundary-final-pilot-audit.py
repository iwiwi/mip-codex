from pathlib import Path
from fractions import Fraction as F
import json,sys,os
sys.path.insert(0,'scripts')
from verify_cover_cuts import exact_model,validate_cut_proofs
from validate_solution import validate
from benchmark_common import atomic_json,sha256
os.sched_setaffinity(0,{42});root=Path('artifacts/implied-boundary-final-pilot');records=[]
for d in sorted(root.iterdir()):
 if not d.is_dir():continue
 p=d/'result.json';r=json.loads(p.read_text());m=d/'model.mps';assert r['status']=='numerical_error'and r['dual_bound']is None and r['gap']is None and r['optimal_original_conflict']
 names,variables,rows,obj,off=exact_model(m,True);x={n:F(str(r['values'][n]))for n in names};violations=[]
 for row in rows:
  value=sum(a*x[n]for n,a in row['coefficients'].items());violations.extend([value-row['upper']]if row['upper']is not None and value>row['upper']else[]);violations.extend([row['lower']-value]if row['lower']is not None and value<row['lower']else[])
 assert violations
 v=validate(m,r);atomic_json(d/'validation.json',v);assert v['valid']is True
 proof=validate_cut_proofs(m,r);atomic_json(d/'proof-validation.json',proof);assert proof['valid']is True
 records.append(dict(name=d.name,input_sha256=sha256(m),result_sha256=sha256(p),strict_absolute_valid=True,positive_exact_violations=[str(v)for v in violations]))
atomic_json(root/'audit-summary.json',dict(points=len(records),strict_valid=len(records),all_withdrawals_have_exact_violation=True,records=records));assert len(records)==5
