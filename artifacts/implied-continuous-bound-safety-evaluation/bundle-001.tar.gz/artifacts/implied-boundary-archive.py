from pathlib import Path
import hashlib,json,tarfile,subprocess
root=Path.cwd();prefix='implied-continuous-bound-safety-evaluation';out=root/'artifacts'/prefix
assert not out.exists()
a=json.loads((root/'artifacts/implied-boundary-final-development-audit/exit.json').read_text());assert a['status']=='complete'
for name in ['implied-boundary-mixed-oracle','implied-boundary-integer-replay-v2']:
 assert json.loads((root/'artifacts'/name/'exit.json').read_text())['status']=='complete'
paths=set()
for pattern in ['implied-boundary-*','implied-lattice-boundary-pilot*','implied-lattice-exact-binary-pilot*']:
 for p in (root/'artifacts').glob(pattern):
  if p.name.startswith(prefix) or p==Path(__file__).resolve() or (p.name.startswith('implied-boundary-archive')and p.suffix=='.log'):continue
  if p.is_file():paths.add(p)
  elif p.is_dir():paths.update(q for q in p.rglob('*')if q.is_file())
paths.add(Path(__file__).resolve());paths.add(root/'artifacts/native-baseline-health-20261117-1738.json');paths.add(root/'artifacts/debug-cache-cleanup-20261117-1802.json');out.mkdir();ledger=[];excluded=[]
for p in sorted(paths):
 assert not p.is_symlink();rel=str(p.relative_to(root));h=hashlib.sha256(p.read_bytes()).hexdigest();r=dict(path=rel,bytes=p.stat().st_size,sha256=h)
 with p.open('rb')as f:elf=f.read(4)==b'\x7fELF'
 if elf:excluded.append(r)
 else:ledger.append(r)
bundle=out/'bundle-001.tar.gz'
with tarfile.open(bundle,'w:gz',compresslevel=6)as tar:
 for r in ledger:tar.add(root/r['path'],arcname=r['path'],recursive=False)
assert bundle.stat().st_size<95*1024**2
with tarfile.open(bundle,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(ledger)
 for r,m in zip(ledger,members):
  assert m.name==r['path'];data=tar.extractfile(m).read();assert len(data)==r['bytes']and hashlib.sha256(data).hexdigest()==r['sha256']
(out/'manifest.json').write_text(json.dumps(ledger,indent=2));(out/'excluded-elf.json').write_text(json.dumps(excluded,indent=2))
summary=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),build_info=json.loads((root/'artifacts/implied-boundary-final-diagnostic/build-info.json').read_text()),files=len(ledger),raw_bytes=sum(r['bytes']for r in ledger),compressed_bytes=bundle.stat().st_size,bundle_sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),excluded_elfs=len(excluded),all_payload_sha256_verified=True)
(out/'summary.json').write_text(json.dumps(summary,indent=2));print(summary)
