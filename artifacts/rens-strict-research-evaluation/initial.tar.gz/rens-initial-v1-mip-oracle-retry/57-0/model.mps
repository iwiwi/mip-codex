NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 G r4
 L r5
COLUMNS
 x0 obj 5
 x1 obj 9
 x2 obj 8
 x3 obj 6
 x4 obj 7
 x5 obj 7
 x6 obj -5
 x6 r0 0.00390625
 x6 r1 16.0
 x6 r3 -256.0
 x6 r4 -256.0
 x7 obj 4
 x8 obj 6
 x9 obj 8
 x10 obj -5
 x10 r1 16.0
 x10 r2 -16.0
 x10 r4 -256.0
 x11 obj -5
 x11 r0 0.00390625
 x11 r2 -16.0
 x11 r3 -256.0
 x11 r5 1.0
 x12 obj 7
 x13 obj 7
 x14 obj 1
 x15 obj 3
 x16 obj 2
 x17 obj 5
 x18 obj 8
 x19 obj 0
 x19 r5 2.0
RHS
 rhs obj -19
 rhs r0 0.00390625
 rhs r1 16.0
 rhs r2 -16.0
 rhs r3 -256.0
 rhs r4 -256.0
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 UP b x19 2
ENDATA
