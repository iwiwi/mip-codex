NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 G r4
 L r5
COLUMNS
 x0 obj 1
 x1 obj 7
 x2 obj -3
 x2 r1 0.00390625
 x2 r2 0.00390625
 x2 r4 -1.0
 x3 obj 1
 x4 obj -3
 x4 r0 1.0
 x4 r2 0.00390625
 x4 r3 0.00390625
 x4 r5 1.0
 x5 obj 1
 x6 obj 4
 x7 obj 4
 x8 obj 3
 x9 obj 9
 x10 obj 4
 x11 obj 1
 x12 obj 3
 x13 obj 1
 x14 obj 4
 x15 obj 6
 x16 obj 9
 x17 obj -3
 x17 r0 1.0
 x17 r1 0.00390625
 x17 r3 0.00390625
 x17 r4 -1.0
 x18 obj 8
 x19 obj 9
 x20 obj 7
 x21 obj 0
 x21 r5 2.0
RHS
 rhs obj 24
 rhs r0 1.0
 rhs r1 0.00390625
 rhs r2 0.00390625
 rhs r3 0.00390625
 rhs r4 -1.0
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 UP b x21 2
ENDATA
