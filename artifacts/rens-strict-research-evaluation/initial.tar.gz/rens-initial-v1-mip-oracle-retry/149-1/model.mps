NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 L r4
 G r5
 G r6
 G r7
 L r8
COLUMNS
 x0 obj -8
 x1 obj -5
 x2 obj -6
 x3 obj -3
 x4 obj 5
 x4 r1 256.0
 x4 r2 -256.0
 x4 r4 0.00390625
 x4 r5 -0.0625
 x4 r7 -0.00390625
 x5 obj -8
 x6 obj -1
 x7 obj -8
 x8 obj -7
 x9 obj -4
 x10 obj 5
 x10 r0 -16.0
 x10 r2 -256.0
 x10 r3 -256.0
 x10 r5 -0.0625
 x10 r6 -0.0625
 x10 r8 1.0
 x11 obj -4
 x12 obj 5
 x12 r0 -16.0
 x12 r1 256.0
 x12 r3 -256.0
 x12 r4 0.00390625
 x12 r6 -0.0625
 x12 r7 -0.00390625
 x13 obj -8
 x14 obj -3
 x15 obj -5
 x16 obj -8
 x17 obj -5
 x18 obj -9
 x19 obj -6
 x20 obj -8
 x21 obj -5
 x22 obj -1
 x23 obj -5
 x24 obj -4
 x25 obj -4
 x26 obj -5
 x27 obj -9
 x28 obj -6
 x29 obj -7
 x30 obj -1
 x31 obj -3
 x32 obj -3
 x33 obj -1
 x34 obj -5
 x35 obj 0
 x35 r8 2.0
RHS
 rhs obj 24
 rhs r0 -16.0
 rhs r1 256.0
 rhs r2 -256.0
 rhs r3 -256.0
 rhs r4 0.00390625
 rhs r5 -0.0625
 rhs r6 -0.0625
 rhs r7 -0.00390625
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 3
 LI b x34 0
 UI b x34 4
 UP b x35 2
ENDATA
