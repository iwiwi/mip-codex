NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 G r3
 L r4
 G r5
 L r6
 L r7
 L r8
COLUMNS
 x0 obj 4
 x1 obj 5
 x2 obj 7
 x3 obj 2
 x4 obj -7
 x4 r0 -16.0
 x4 r1 -1.0
 x4 r3 -16.0
 x4 r4 0.00390625
 x4 r6 16.0
 x4 r7 16.0
 x5 obj 3
 x6 obj 7
 x7 obj 3
 x8 obj 6
 x9 obj 3
 x10 obj 2
 x11 obj -7
 x11 r0 -16.0
 x11 r2 0.0625
 x11 r3 -16.0
 x11 r5 -0.0625
 x11 r6 16.0
 x11 r8 1.0
 x12 obj 6
 x13 obj 7
 x14 obj 8
 x15 obj 4
 x16 obj 3
 x17 obj 9
 x18 obj 9
 x19 obj 8
 x20 obj 7
 x21 obj -7
 x21 r1 -1.0
 x21 r2 0.0625
 x21 r4 0.00390625
 x21 r5 -0.0625
 x21 r7 16.0
 x22 obj 1
 x23 obj 9
 x24 obj 0
 x24 r8 2.0
RHS
 rhs obj 17
 rhs r0 -16.0
 rhs r1 -1.0
 rhs r2 0.0625
 rhs r3 -16.0
 rhs r4 0.00390625
 rhs r5 -0.0625
 rhs r6 16.0
 rhs r7 16.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 UP b x24 2
ENDATA
