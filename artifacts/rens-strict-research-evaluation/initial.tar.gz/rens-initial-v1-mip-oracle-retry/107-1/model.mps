NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 G r4
 L r5
 G r6
 L r7
 L r8
 L r9
COLUMNS
 x0 obj -5
 x1 obj -7
 x2 obj -6
 x3 obj -2
 x4 obj -1
 x5 obj -7
 x6 obj -2
 x7 obj -5
 x8 obj -6
 x9 obj -4
 x10 obj -9
 x11 obj -1
 x12 obj -5
 x13 obj -7
 x14 obj -5
 x15 obj -4
 x16 obj -3
 x17 obj 2
 x17 r0 1.0
 x17 r1 -1.0
 x17 r3 -256.0
 x17 r4 -0.00390625
 x17 r6 -0.0625
 x17 r7 0.00390625
 x18 obj -1
 x19 obj -1
 x20 obj -9
 x21 obj 2
 x21 r0 1.0
 x21 r2 0.00390625
 x21 r3 -256.0
 x21 r5 1.0
 x21 r6 -0.0625
 x21 r8 0.0625
 x21 r9 1.0
 x22 obj 2
 x22 r1 -1.0
 x22 r2 0.00390625
 x22 r4 -0.00390625
 x22 r5 1.0
 x22 r7 0.00390625
 x22 r8 0.0625
 x23 obj 0
 x23 r9 2.0
RHS
 rhs obj 24
 rhs r0 1.0
 rhs r1 -1.0
 rhs r2 0.00390625
 rhs r3 -256.0
 rhs r4 -0.00390625
 rhs r5 1.0
 rhs r6 -0.0625
 rhs r7 0.00390625
 rhs r8 0.0625
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 1
 UP b x23 2
ENDATA
