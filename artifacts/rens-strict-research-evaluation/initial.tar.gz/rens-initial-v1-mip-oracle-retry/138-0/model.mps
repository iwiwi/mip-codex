NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
COLUMNS
 x0 obj 2
 x1 obj 5
 x2 obj 6
 x3 obj 3
 x4 obj -4
 x4 r0 0.0625
 x4 r2 0.00390625
 x4 r3 0.0625
 x4 r5 16.0
 x4 r6 1.0
 x5 obj 1
 x6 obj 1
 x7 obj 1
 x8 obj 3
 x9 obj 7
 x10 obj 1
 x11 obj 3
 x12 obj -4
 x12 r1 1.0
 x12 r2 0.00390625
 x12 r4 16.0
 x12 r5 16.0
 x13 obj 5
 x14 obj 7
 x15 obj 7
 x16 obj 3
 x17 obj 8
 x18 obj -4
 x18 r0 0.0625
 x18 r1 1.0
 x18 r3 0.0625
 x18 r4 16.0
 x19 obj 0
 x19 r6 2.0
RHS
 rhs obj 25
 rhs r0 0.0625
 rhs r1 1.0
 rhs r2 0.00390625
 rhs r3 0.0625
 rhs r4 16.0
 rhs r5 16.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 1
 UP b x19 2
ENDATA
