NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 G r4
 L r5
COLUMNS
 x0 obj -3
 x1 obj -9
 x2 obj -6
 x3 obj -7
 x4 obj -4
 x5 obj -4
 x6 obj -4
 x7 obj -3
 x8 obj -7
 x9 obj -5
 x10 obj -8
 x11 obj -8
 x12 obj -8
 x13 obj -8
 x14 obj -3
 x15 obj 6
 x15 r0 -1.0
 x15 r1 256.0
 x15 r3 16.0
 x15 r4 -0.0625
 x16 obj 6
 x16 r0 -1.0
 x16 r2 -0.00390625
 x16 r3 16.0
 x16 r5 1.0
 x17 obj -3
 x18 obj -1
 x19 obj -8
 x20 obj -5
 x21 obj -8
 x22 obj 6
 x22 r1 256.0
 x22 r2 -0.00390625
 x22 r4 -0.0625
 x23 obj 0
 x23 r5 2.0
RHS
 rhs obj 3
 rhs r0 -1.0
 rhs r1 256.0
 rhs r2 -0.00390625
 rhs r3 16.0
 rhs r4 -0.0625
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 1
 UP b x23 2
ENDATA
