NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 G r4
 G r5
 L r6
COLUMNS
 x0 obj -2
 x1 obj -5
 x2 obj -1
 x3 obj 5
 x3 r0 -16.0
 x3 r1 256.0
 x3 r3 -1.0
 x3 r4 -16.0
 x4 obj -3
 x5 obj -7
 x6 obj -5
 x7 obj -6
 x8 obj -2
 x9 obj -6
 x10 obj -3
 x11 obj -2
 x12 obj -7
 x13 obj -6
 x14 obj -9
 x15 obj -6
 x16 obj -8
 x17 obj -9
 x18 obj -9
 x19 obj 5
 x19 r0 -16.0
 x19 r2 1.0
 x19 r3 -1.0
 x19 r5 -256.0
 x19 r6 1.0
 x20 obj -2
 x21 obj -3
 x22 obj -8
 x23 obj -9
 x24 obj 5
 x24 r1 256.0
 x24 r2 1.0
 x24 r4 -16.0
 x24 r5 -256.0
 x25 obj 0
 x25 r6 2.0
RHS
 rhs obj 9
 rhs r0 -16.0
 rhs r1 256.0
 rhs r2 1.0
 rhs r3 -1.0
 rhs r4 -16.0
 rhs r5 -256.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 1
 UP b x25 2
ENDATA
