NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj -4
 x0 r1 0.0625
 x0 r2 256.0
 x1 obj 6
 x2 obj 3
 x3 obj 2
 x4 obj 3
 x5 obj 8
 x6 obj 6
 x7 obj 3
 x8 obj 7
 x9 obj 6
 x10 obj 5
 x11 obj 4
 x12 obj 5
 x13 obj -4
 x13 r0 16.0
 x13 r2 256.0
 x13 r3 1.0
 x14 obj 1
 x15 obj 2
 x16 obj -4
 x16 r0 16.0
 x16 r1 0.0625
 x17 obj 2
 x18 obj 2
 x19 obj 6
 x20 obj 6
 x21 obj 8
 x22 obj 4
 x23 obj 5
 x24 obj 4
 x25 obj 2
 x26 obj 9
 x27 obj 5
 x28 obj 7
 x29 obj 0
 x29 r3 2.0
RHS
 rhs obj 30
 rhs r0 16.0
 rhs r1 0.0625
 rhs r2 256.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 3
 UP b x29 2
ENDATA
