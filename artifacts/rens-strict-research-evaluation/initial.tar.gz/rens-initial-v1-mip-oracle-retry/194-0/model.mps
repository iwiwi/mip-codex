NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
 G r4
 L r5
 G r6
 G r7
 L r8
COLUMNS
 x0 obj 9
 x1 obj 8
 x2 obj 3
 x3 obj 3
 x4 obj 2
 x5 obj 6
 x6 obj 6
 x7 obj -4
 x7 r0 -0.00390625
 x7 r1 -0.0625
 x7 r3 256.0
 x7 r4 -16.0
 x7 r6 -256.0
 x7 r7 -1.0
 x8 obj 7
 x9 obj 8
 x10 obj 6
 x11 obj 5
 x12 obj 4
 x13 obj 3
 x14 obj -4
 x14 r1 -0.0625
 x14 r2 -0.00390625
 x14 r4 -16.0
 x14 r5 16.0
 x14 r7 -1.0
 x15 obj 4
 x16 obj 2
 x17 obj 7
 x18 obj 3
 x19 obj 3
 x20 obj 1
 x21 obj -4
 x21 r0 -0.00390625
 x21 r2 -0.00390625
 x21 r3 256.0
 x21 r5 16.0
 x21 r6 -256.0
 x21 r8 1.0
 x22 obj 7
 x23 obj 0
 x23 r8 2.0
RHS
 rhs obj 22
 rhs r0 -0.00390625
 rhs r1 -0.0625
 rhs r2 -0.00390625
 rhs r3 256.0
 rhs r4 -16.0
 rhs r5 16.0
 rhs r6 -256.0
 rhs r7 -1.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 2
 UP b x23 2
ENDATA
