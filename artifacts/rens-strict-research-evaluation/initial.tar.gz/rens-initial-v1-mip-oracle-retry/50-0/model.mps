NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 L r4
 G r5
 G r6
 G r7
 G r8
 L r9
COLUMNS
 x0 obj 3
 x1 obj 1
 x2 obj 9
 x3 obj 6
 x4 obj -4
 x4 r0 0.00390625
 x4 r1 1.0
 x4 r3 -0.00390625
 x4 r4 0.00390625
 x4 r6 -16.0
 x4 r7 -0.0625
 x5 obj -4
 x5 r0 0.00390625
 x5 r2 0.0625
 x5 r3 -0.00390625
 x5 r5 -1.0
 x5 r6 -16.0
 x5 r8 -256.0
 x5 r9 1.0
 x6 obj 2
 x7 obj -4
 x7 r1 1.0
 x7 r2 0.0625
 x7 r4 0.00390625
 x7 r5 -1.0
 x7 r7 -0.0625
 x7 r8 -256.0
 x8 obj 5
 x9 obj 3
 x10 obj 2
 x11 obj 6
 x12 obj 1
 x13 obj 8
 x14 obj 2
 x15 obj 3
 x16 obj 3
 x17 obj 7
 x18 obj 0
 x18 r9 2.0
RHS
 rhs obj -30
 rhs r0 0.00390625
 rhs r1 1.0
 rhs r2 0.0625
 rhs r3 -0.00390625
 rhs r4 0.00390625
 rhs r5 -1.0
 rhs r6 -16.0
 rhs r7 -0.0625
 rhs r8 -256.0
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 UP b x18 2
ENDATA
