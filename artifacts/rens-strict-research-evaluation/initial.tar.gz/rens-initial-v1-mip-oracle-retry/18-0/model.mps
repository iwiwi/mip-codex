NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj 6
 x1 obj 7
 x2 obj 4
 x3 obj 8
 x4 obj 6
 x5 obj 1
 x6 obj 2
 x7 obj 3
 x8 obj 7
 x9 obj -7
 x9 r0 -0.0625
 x9 r2 0.0625
 x9 r3 1.0
 x10 obj 5
 x11 obj 9
 x12 obj 7
 x13 obj 2
 x14 obj -7
 x14 r1 0.00390625
 x14 r2 0.0625
 x15 obj 1
 x16 obj 1
 x17 obj 5
 x18 obj 6
 x19 obj 3
 x20 obj -7
 x20 r0 -0.0625
 x20 r1 0.00390625
 x21 obj 9
 x22 obj 5
 x23 obj 9
 x24 obj 5
 x25 obj 5
 x26 obj 9
 x27 obj 8
 x28 obj 8
 x29 obj 8
 x30 obj 0
 x30 r3 2.0
RHS
 rhs obj -11
 rhs r0 -0.0625
 rhs r1 0.00390625
 rhs r2 0.0625
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 UP b x30 2
ENDATA
