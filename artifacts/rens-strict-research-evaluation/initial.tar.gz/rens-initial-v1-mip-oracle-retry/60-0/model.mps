NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 L r4
COLUMNS
 x0 obj 1
 x1 obj 6
 x2 obj 5
 x3 obj 8
 x4 obj 7
 x5 obj 9
 x6 obj 1
 x7 obj 5
 x8 obj 2
 x9 obj 5
 x10 obj 9
 x11 obj 5
 x12 obj 9
 x13 obj 9
 x14 obj 5
 x15 obj -4
 x15 r0 0.00390625
 x15 r1 16.0
 x15 r3 -0.0625
 x16 obj 9
 x17 obj 5
 x18 obj 9
 x19 obj -4
 x19 r1 16.0
 x19 r2 0.0625
 x20 obj -4
 x20 r0 0.00390625
 x20 r2 0.0625
 x20 r3 -0.0625
 x20 r4 1.0
 x21 obj 3
 x22 obj 4
 x23 obj 9
 x24 obj 8
 x25 obj 5
 x26 obj 6
 x27 obj 2
 x28 obj 0
 x28 r4 2.0
RHS
 rhs obj -24
 rhs r0 0.00390625
 rhs r1 16.0
 rhs r2 0.0625
 rhs r3 -0.0625
 rhs r4 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 4
 UP b x28 2
ENDATA
