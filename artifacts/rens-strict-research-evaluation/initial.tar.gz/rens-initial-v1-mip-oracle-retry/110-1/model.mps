NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
COLUMNS
 x0 obj -3
 x1 obj -1
 x2 obj -5
 x3 obj -8
 x4 obj -9
 x5 obj -3
 x6 obj -7
 x7 obj -2
 x8 obj 1
 x8 r1 -1.0
 x8 r2 0.00390625
 x9 obj -1
 x10 obj -6
 x11 obj -4
 x12 obj -7
 x13 obj -9
 x14 obj -9
 x15 obj -7
 x16 obj -1
 x17 obj -9
 x18 obj -5
 x19 obj -3
 x20 obj -8
 x21 obj -9
 x22 obj 1
 x22 r0 -0.0625
 x22 r1 -1.0
 x23 obj -9
 x24 obj 1
 x24 r0 -0.0625
 x24 r2 0.00390625
 x24 r3 1.0
 x25 obj -9
 x26 obj -1
 x27 obj -6
 x28 obj -5
 x29 obj -6
 x30 obj 0
 x30 r3 2.0
RHS
 rhs obj 8
 rhs r0 -0.0625
 rhs r1 -1.0
 rhs r2 0.00390625
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 1
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 2
 UP b x30 2
ENDATA
