NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
COLUMNS
 x0 obj 5
 x1 obj 8
 x2 obj 4
 x3 obj 4
 x4 obj 1
 x5 obj 6
 x6 obj -8
 x6 r1 -1.0
 x6 r2 0.0625
 x7 obj 2
 x8 obj 7
 x9 obj 1
 x10 obj 1
 x11 obj 2
 x12 obj 5
 x13 obj -8
 x13 r0 -1.0
 x13 r2 0.0625
 x13 r3 1.0
 x14 obj 7
 x15 obj 5
 x16 obj 5
 x17 obj -8
 x17 r0 -1.0
 x17 r1 -1.0
 x18 obj 8
 x19 obj 0
 x19 r3 2.0
RHS
 rhs obj 19
 rhs r0 -1.0
 rhs r1 -1.0
 rhs r2 0.0625
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 3
 UP b x19 2
ENDATA
