NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
 L r4
 G r5
 L r6
COLUMNS
 x0 obj -6
 x1 obj -3
 x2 obj -8
 x3 obj -2
 x4 obj -2
 x5 obj -2
 x6 obj -2
 x7 obj -8
 x8 obj -8
 x9 obj -6
 x10 obj -2
 x11 obj 4
 x11 r0 -256.0
 x11 r1 -256.0
 x11 r3 16.0
 x11 r4 0.0625
 x12 obj -7
 x13 obj 4
 x13 r0 -256.0
 x13 r2 256.0
 x13 r3 16.0
 x13 r5 -1.0
 x13 r6 1.0
 x14 obj -3
 x15 obj -5
 x16 obj -4
 x17 obj -7
 x18 obj -2
 x19 obj -1
 x20 obj -5
 x21 obj -9
 x22 obj 4
 x22 r1 -256.0
 x22 r2 256.0
 x22 r4 0.0625
 x22 r5 -1.0
 x23 obj -2
 x24 obj -6
 x25 obj -8
 x26 obj -8
 x27 obj -8
 x28 obj -3
 x29 obj -7
 x30 obj -8
 x31 obj 0
 x31 r6 2.0
RHS
 rhs obj 20
 rhs r0 -256.0
 rhs r1 -256.0
 rhs r2 256.0
 rhs r3 16.0
 rhs r4 0.0625
 rhs r5 -1.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 2
 UP b x31 2
ENDATA
