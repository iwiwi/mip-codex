NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 G r3
 L r4
 L r5
 G r6
 L r7
 G r8
 L r9
 L r10
COLUMNS
 x0 obj -6
 x1 obj -2
 x2 obj -9
 x3 obj -2
 x4 obj -4
 x5 obj -7
 x6 obj -1
 x7 obj -7
 x8 obj -8
 x9 obj -6
 x10 obj -6
 x11 obj -9
 x12 obj 7
 x12 r0 -16.0
 x12 r2 1.0
 x12 r3 -256.0
 x12 r5 16.0
 x12 r6 -0.00390625
 x12 r8 -0.0625
 x12 r9 0.00390625
 x12 r10 1.0
 x13 obj -4
 x14 obj -3
 x15 obj -2
 x16 obj -8
 x17 obj -1
 x18 obj -1
 x19 obj -4
 x20 obj 7
 x20 r0 -16.0
 x20 r1 -1.0
 x20 r3 -256.0
 x20 r4 256.0
 x20 r6 -0.00390625
 x20 r7 16.0
 x20 r9 0.00390625
 x21 obj -7
 x22 obj 7
 x22 r1 -1.0
 x22 r2 1.0
 x22 r4 256.0
 x22 r5 16.0
 x22 r7 16.0
 x22 r8 -0.0625
 x23 obj -8
 x24 obj -2
 x25 obj 0
 x25 r10 2.0
RHS
 rhs obj -16
 rhs r0 -16.0
 rhs r1 -1.0
 rhs r2 1.0
 rhs r3 -256.0
 rhs r4 256.0
 rhs r5 16.0
 rhs r6 -0.00390625
 rhs r7 16.0
 rhs r8 -0.0625
 rhs r9 0.00390625
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 2
 UP b x25 2
ENDATA
