NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 G r2
 G r3
 G r4
 L r5
 G r6
 L r7
 G r8
 L r9
COLUMNS
 x0 obj -3
 x1 obj -4
 x2 obj -2
 x3 obj -9
 x4 obj -6
 x5 obj -7
 x6 obj -8
 x7 obj -6
 x8 obj -7
 x9 obj -1
 x10 obj -9
 x11 obj -5
 x12 obj -8
 x13 obj -6
 x14 obj 9
 x14 r1 -256.0
 x14 r2 -1.0
 x14 r4 -0.0625
 x14 r5 0.0625
 x14 r7 0.00390625
 x14 r8 -0.00390625
 x15 obj -8
 x16 obj -7
 x17 obj -4
 x18 obj -3
 x19 obj -3
 x20 obj -9
 x21 obj 9
 x21 r0 256.0
 x21 r1 -256.0
 x21 r3 -1.0
 x21 r4 -0.0625
 x21 r6 -0.0625
 x21 r7 0.00390625
 x22 obj -7
 x23 obj -5
 x24 obj -3
 x25 obj -6
 x26 obj -7
 x27 obj -1
 x28 obj -7
 x29 obj -9
 x30 obj -3
 x31 obj 9
 x31 r0 256.0
 x31 r2 -1.0
 x31 r3 -1.0
 x31 r5 0.0625
 x31 r6 -0.0625
 x31 r8 -0.00390625
 x31 r9 1.0
 x32 obj -1
 x33 obj -9
 x34 obj -2
 x35 obj 0
 x35 r9 2.0
RHS
 rhs obj -18
 rhs r0 256.0
 rhs r1 -256.0
 rhs r2 -1.0
 rhs r3 -1.0
 rhs r4 -0.0625
 rhs r5 0.0625
 rhs r6 -0.0625
 rhs r7 0.00390625
 rhs r8 -0.00390625
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 2
 LI b x31 0
 UI b x31 1
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 2
 LI b x34 0
 UI b x34 4
 UP b x35 2
ENDATA
