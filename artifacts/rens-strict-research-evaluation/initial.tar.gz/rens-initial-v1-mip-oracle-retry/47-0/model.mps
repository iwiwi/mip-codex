NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
 L r4
 G r5
 G r6
 G r7
 L r8
COLUMNS
 x0 obj 4
 x1 obj 1
 x2 obj 9
 x3 obj 8
 x4 obj 3
 x5 obj 6
 x6 obj 7
 x7 obj 3
 x8 obj 4
 x9 obj 4
 x10 obj -3
 x10 r0 -0.0625
 x10 r1 -16.0
 x10 r3 0.0625
 x10 r4 16.0
 x10 r6 -16.0
 x10 r7 -256.0
 x11 obj 3
 x12 obj 5
 x13 obj 6
 x14 obj 2
 x15 obj 6
 x16 obj 4
 x17 obj 8
 x18 obj 2
 x19 obj -3
 x19 r0 -0.0625
 x19 r2 256.0
 x19 r3 0.0625
 x19 r5 -0.0625
 x19 r6 -16.0
 x19 r8 1.0
 x20 obj 2
 x21 obj 6
 x22 obj 3
 x23 obj 3
 x24 obj 4
 x25 obj 2
 x26 obj 5
 x27 obj 7
 x28 obj 5
 x29 obj 9
 x30 obj 1
 x31 obj -3
 x31 r1 -16.0
 x31 r2 256.0
 x31 r4 16.0
 x31 r5 -0.0625
 x31 r7 -256.0
 x32 obj 0
 x32 r8 2.0
RHS
 rhs obj -6
 rhs r0 -0.0625
 rhs r1 -16.0
 rhs r2 256.0
 rhs r3 0.0625
 rhs r4 16.0
 rhs r5 -0.0625
 rhs r6 -16.0
 rhs r7 -256.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 2
 LI b x31 0
 UI b x31 1
 UP b x32 2
ENDATA
