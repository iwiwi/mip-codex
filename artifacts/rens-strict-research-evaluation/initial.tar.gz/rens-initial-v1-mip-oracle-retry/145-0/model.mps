NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 G r3
 G r4
 G r5
 G r6
 G r7
 L r8
 L r9
 L r10
COLUMNS
 x0 obj 1
 x1 obj 5
 x2 obj 1
 x3 obj 5
 x4 obj 4
 x5 obj 9
 x6 obj 4
 x7 obj -7
 x7 r1 -256.0
 x7 r2 16.0
 x7 r4 -0.0625
 x7 r5 -16.0
 x7 r7 -16.0
 x7 r8 256.0
 x8 obj 2
 x9 obj 9
 x10 obj 8
 x11 obj 3
 x12 obj 4
 x13 obj 6
 x14 obj 1
 x15 obj 6
 x16 obj 1
 x17 obj 4
 x18 obj 8
 x19 obj 4
 x20 obj 5
 x21 obj 8
 x22 obj 9
 x23 obj 9
 x24 obj 5
 x25 obj -7
 x25 r0 -256.0
 x25 r2 16.0
 x25 r3 -16.0
 x25 r5 -16.0
 x25 r6 -256.0
 x25 r8 256.0
 x25 r9 256.0
 x25 r10 1.0
 x26 obj 7
 x27 obj 7
 x28 obj 4
 x29 obj 8
 x30 obj 1
 x31 obj 5
 x32 obj 1
 x33 obj -7
 x33 r0 -256.0
 x33 r1 -256.0
 x33 r3 -16.0
 x33 r4 -0.0625
 x33 r6 -256.0
 x33 r7 -16.0
 x33 r9 256.0
 x34 obj 3
 x35 obj 0
 x35 r10 2.0
RHS
 rhs obj -4
 rhs r0 -256.0
 rhs r1 -256.0
 rhs r2 16.0
 rhs r3 -16.0
 rhs r4 -0.0625
 rhs r5 -16.0
 rhs r6 -256.0
 rhs r7 -16.0
 rhs r8 256.0
 rhs r9 256.0
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 1
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 1
 LI b x34 0
 UI b x34 2
 UP b x35 2
ENDATA
