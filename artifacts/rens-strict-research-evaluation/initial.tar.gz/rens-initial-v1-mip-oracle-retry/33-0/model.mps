NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 G r4
 L r5
 G r6
 G r7
 G r8
 L r9
COLUMNS
 x0 obj 2
 x1 obj 5
 x2 obj 4
 x3 obj 8
 x4 obj 5
 x5 obj 2
 x6 obj 3
 x7 obj 2
 x8 obj 2
 x9 obj 8
 x10 obj 3
 x11 obj 4
 x12 obj -1
 x12 r0 256.0
 x12 r1 -16.0
 x12 r3 -0.0625
 x12 r4 -1.0
 x12 r6 -0.0625
 x12 r7 -256.0
 x13 obj 3
 x14 obj 5
 x15 obj 4
 x16 obj 3
 x17 obj -1
 x17 r1 -16.0
 x17 r2 256.0
 x17 r4 -1.0
 x17 r5 1.0
 x17 r7 -256.0
 x17 r8 -1.0
 x18 obj 8
 x19 obj 7
 x20 obj 5
 x21 obj 8
 x22 obj 4
 x23 obj 6
 x24 obj 2
 x25 obj 7
 x26 obj 2
 x27 obj -1
 x27 r0 256.0
 x27 r2 256.0
 x27 r3 -0.0625
 x27 r5 1.0
 x27 r6 -0.0625
 x27 r8 -1.0
 x27 r9 1.0
 x28 obj 0
 x28 r9 2.0
RHS
 rhs obj 11
 rhs r0 256.0
 rhs r1 -16.0
 rhs r2 256.0
 rhs r3 -0.0625
 rhs r4 -1.0
 rhs r5 1.0
 rhs r6 -0.0625
 rhs r7 -256.0
 rhs r8 -1.0
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 1
 UP b x28 2
ENDATA
