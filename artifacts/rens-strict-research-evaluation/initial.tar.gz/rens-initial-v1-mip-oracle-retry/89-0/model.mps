NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 L r4
 G r5
 L r6
 L r7
COLUMNS
 x0 obj 5
 x1 obj -7
 x1 r1 -0.00390625
 x1 r2 -1.0
 x1 r4 16.0
 x1 r5 -256.0
 x2 obj 6
 x3 obj 7
 x4 obj 3
 x5 obj 8
 x6 obj -7
 x6 r0 -256.0
 x6 r1 -0.00390625
 x6 r3 -0.0625
 x6 r4 16.0
 x6 r6 16.0
 x7 obj 2
 x8 obj 9
 x9 obj 5
 x10 obj -7
 x10 r0 -256.0
 x10 r2 -1.0
 x10 r3 -0.0625
 x10 r5 -256.0
 x10 r6 16.0
 x10 r7 1.0
 x11 obj 2
 x12 obj 6
 x13 obj 3
 x14 obj 3
 x15 obj 7
 x16 obj 1
 x17 obj 1
 x18 obj 4
 x19 obj 7
 x20 obj 1
 x21 obj 5
 x22 obj 6
 x23 obj 3
 x24 obj 5
 x25 obj 5
 x26 obj 9
 x27 obj 3
 x28 obj 5
 x29 obj 1
 x30 obj 2
 x31 obj 0
 x31 r7 2.0
RHS
 rhs obj -12
 rhs r0 -256.0
 rhs r1 -0.00390625
 rhs r2 -1.0
 rhs r3 -0.0625
 rhs r4 16.0
 rhs r5 -256.0
 rhs r6 16.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 2
 UP b x31 2
ENDATA
