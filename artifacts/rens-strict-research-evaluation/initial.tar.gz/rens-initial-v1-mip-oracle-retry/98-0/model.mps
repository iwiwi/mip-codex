NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
 G r4
 G r5
 L r6
 G r7
 G r8
 L r9
 L r10
COLUMNS
 x0 obj 2
 x1 obj 7
 x2 obj 5
 x3 obj 9
 x4 obj 9
 x5 obj -1
 x5 r1 -1.0
 x5 r2 -0.0625
 x5 r4 -16.0
 x5 r5 -1.0
 x5 r7 -0.00390625
 x5 r8 -0.00390625
 x6 obj 3
 x7 obj 1
 x8 obj 8
 x9 obj 6
 x10 obj 5
 x11 obj -1
 x11 r0 -0.0625
 x11 r1 -1.0
 x11 r3 0.00390625
 x11 r4 -16.0
 x11 r6 0.0625
 x11 r7 -0.00390625
 x11 r9 16.0
 x12 obj -1
 x12 r0 -0.0625
 x12 r2 -0.0625
 x12 r3 0.00390625
 x12 r5 -1.0
 x12 r6 0.0625
 x12 r8 -0.00390625
 x12 r9 16.0
 x12 r10 1.0
 x13 obj 7
 x14 obj 2
 x15 obj 4
 x16 obj 8
 x17 obj 9
 x18 obj 2
 x19 obj 6
 x20 obj 0
 x20 r10 2.0
RHS
 rhs obj 24
 rhs r0 -0.0625
 rhs r1 -1.0
 rhs r2 -0.0625
 rhs r3 0.00390625
 rhs r4 -16.0
 rhs r5 -1.0
 rhs r6 0.0625
 rhs r7 -0.00390625
 rhs r8 -0.00390625
 rhs r9 16.0
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 UP b x20 2
ENDATA
