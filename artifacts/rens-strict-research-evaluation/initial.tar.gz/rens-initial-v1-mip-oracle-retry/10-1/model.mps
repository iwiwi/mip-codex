NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 L r10
COLUMNS
 x0 obj -6
 x1 obj -6
 x2 obj -7
 x3 obj -4
 x4 obj -6
 x5 obj -6
 x6 obj -3
 x7 obj 4
 x7 r1 -0.0625
 x7 r2 0.0625
 x7 r4 -256.0
 x7 r5 -0.00390625
 x7 r7 -0.0625
 x7 r8 -256.0
 x8 obj -5
 x9 obj 4
 x9 r0 16.0
 x9 r1 -0.0625
 x9 r3 1.0
 x9 r4 -256.0
 x9 r6 -16.0
 x9 r7 -0.0625
 x9 r9 -256.0
 x10 obj -1
 x11 obj -3
 x12 obj -9
 x13 obj -1
 x14 obj 4
 x14 r0 16.0
 x14 r2 0.0625
 x14 r3 1.0
 x14 r5 -0.00390625
 x14 r6 -16.0
 x14 r8 -256.0
 x14 r9 -256.0
 x14 r10 1.0
 x15 obj -9
 x16 obj -5
 x17 obj -6
 x18 obj -2
 x19 obj -1
 x20 obj -9
 x21 obj 0
 x21 r10 2.0
RHS
 rhs obj -24
 rhs r0 16.0
 rhs r1 -0.0625
 rhs r2 0.0625
 rhs r3 1.0
 rhs r4 -256.0
 rhs r5 -0.00390625
 rhs r6 -16.0
 rhs r7 -0.0625
 rhs r8 -256.0
 rhs r9 -256.0
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 UP b x21 2
ENDATA
