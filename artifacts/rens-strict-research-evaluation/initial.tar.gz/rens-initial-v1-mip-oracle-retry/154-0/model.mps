NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 L r4
 L r5
 L r6
 L r7
 G r8
 L r9
COLUMNS
 x0 obj 9
 x1 obj 8
 x2 obj 9
 x3 obj 6
 x4 obj 6
 x5 obj 1
 x6 obj 1
 x7 obj 8
 x8 obj -9
 x8 r1 1.0
 x8 r2 -1.0
 x8 r4 1.0
 x8 r5 16.0
 x8 r7 0.0625
 x8 r8 -256.0
 x9 obj 4
 x10 obj 9
 x11 obj 6
 x12 obj -9
 x12 r0 -256.0
 x12 r1 1.0
 x12 r3 -16.0
 x12 r4 1.0
 x12 r6 256.0
 x12 r7 0.0625
 x13 obj 4
 x14 obj 7
 x15 obj 7
 x16 obj -9
 x16 r0 -256.0
 x16 r2 -1.0
 x16 r3 -16.0
 x16 r5 16.0
 x16 r6 256.0
 x16 r8 -256.0
 x16 r9 1.0
 x17 obj 9
 x18 obj 1
 x19 obj 9
 x20 obj 0
 x20 r9 2.0
RHS
 rhs obj -17
 rhs r0 -256.0
 rhs r1 1.0
 rhs r2 -1.0
 rhs r3 -16.0
 rhs r4 1.0
 rhs r5 16.0
 rhs r6 256.0
 rhs r7 0.0625
 rhs r8 -256.0
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 UP b x20 2
ENDATA
