NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
COLUMNS
 x0 obj 8
 x1 obj 9
 x2 obj 7
 x3 obj -3
 x3 r1 0.0625
 x3 r2 1.0
 x4 obj 5
 x5 obj 1
 x6 obj 6
 x7 obj -3
 x7 r0 0.00390625
 x7 r1 0.0625
 x7 r3 1.0
 x8 obj 1
 x9 obj 9
 x10 obj 3
 x11 obj 3
 x12 obj 9
 x13 obj 4
 x14 obj 6
 x15 obj 9
 x16 obj 1
 x17 obj 6
 x18 obj 7
 x19 obj 4
 x20 obj 8
 x21 obj 4
 x22 obj -3
 x22 r0 0.00390625
 x22 r2 1.0
 x22 r3 1.0
 x22 r4 1.0
 x23 obj 0
 x23 r4 2.0
RHS
 rhs obj 1
 rhs r0 0.00390625
 rhs r1 0.0625
 rhs r2 1.0
 rhs r3 1.0
 rhs r4 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 1
 UP b x23 2
ENDATA
