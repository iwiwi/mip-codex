NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 G r4
 G r5
 L r6
COLUMNS
 x0 obj -6
 x1 obj -5
 x2 obj -1
 x3 obj -1
 x4 obj -8
 x5 obj 2
 x5 r0 -0.0625
 x5 r2 16.0
 x5 r3 256.0
 x5 r5 -16.0
 x5 r6 1.0
 x6 obj -1
 x7 obj -6
 x8 obj -8
 x9 obj -8
 x10 obj -1
 x11 obj -3
 x12 obj -3
 x13 obj -3
 x14 obj -5
 x15 obj 2
 x15 r0 -0.0625
 x15 r1 256.0
 x15 r3 256.0
 x15 r4 -0.00390625
 x16 obj -4
 x17 obj -9
 x18 obj -7
 x19 obj 2
 x19 r1 256.0
 x19 r2 16.0
 x19 r4 -0.00390625
 x19 r5 -16.0
 x20 obj -9
 x21 obj 0
 x21 r6 2.0
RHS
 rhs obj 25
 rhs r0 -0.0625
 rhs r1 256.0
 rhs r2 16.0
 rhs r3 256.0
 rhs r4 -0.00390625
 rhs r5 -16.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 2
 UP b x21 2
ENDATA
