NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
COLUMNS
 x0 obj -1
 x1 obj -1
 x2 obj -9
 x3 obj -8
 x4 obj -7
 x5 obj -5
 x6 obj -8
 x7 obj 5
 x7 r0 256.0
 x7 r1 -0.0625
 x8 obj -7
 x9 obj -5
 x10 obj 5
 x10 r1 -0.0625
 x10 r2 -16.0
 x11 obj -7
 x12 obj -3
 x13 obj -5
 x14 obj -9
 x15 obj -2
 x16 obj 5
 x16 r0 256.0
 x16 r2 -16.0
 x16 r3 1.0
 x17 obj -9
 x18 obj -7
 x19 obj -8
 x20 obj -1
 x21 obj -9
 x22 obj -5
 x23 obj -8
 x24 obj -1
 x25 obj -6
 x26 obj -7
 x27 obj -6
 x28 obj -1
 x29 obj -5
 x30 obj -9
 x31 obj -4
 x32 obj -6
 x33 obj 0
 x33 r3 2.0
RHS
 rhs obj -10
 rhs r0 256.0
 rhs r1 -0.0625
 rhs r2 -16.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 2
 LI b x32 0
 UI b x32 3
 UP b x33 2
ENDATA
