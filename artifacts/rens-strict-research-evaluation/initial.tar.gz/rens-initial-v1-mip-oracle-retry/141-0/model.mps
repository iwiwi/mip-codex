NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 G r4
 L r5
 L r6
COLUMNS
 x0 obj 6
 x1 obj 9
 x2 obj 4
 x3 obj 8
 x4 obj 1
 x5 obj 5
 x6 obj -4
 x6 r0 0.00390625
 x6 r1 -0.00390625
 x6 r3 -0.00390625
 x6 r4 -0.0625
 x7 obj 3
 x8 obj 9
 x9 obj 1
 x10 obj 6
 x11 obj 1
 x12 obj 3
 x13 obj 6
 x14 obj -4
 x14 r1 -0.00390625
 x14 r2 0.00390625
 x14 r4 -0.0625
 x14 r5 1.0
 x15 obj 3
 x16 obj -4
 x16 r0 0.00390625
 x16 r2 0.00390625
 x16 r3 -0.00390625
 x16 r5 1.0
 x16 r6 1.0
 x17 obj 5
 x18 obj 4
 x19 obj 7
 x20 obj 4
 x21 obj 6
 x22 obj 4
 x23 obj 3
 x24 obj 3
 x25 obj 7
 x26 obj 7
 x27 obj 6
 x28 obj 3
 x29 obj 6
 x30 obj 0
 x30 r6 2.0
RHS
 rhs obj 26
 rhs r0 0.00390625
 rhs r1 -0.00390625
 rhs r2 0.00390625
 rhs r3 -0.00390625
 rhs r4 -0.0625
 rhs r5 1.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 4
 UP b x30 2
ENDATA
