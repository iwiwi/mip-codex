NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 G r3
 L r4
 L r5
COLUMNS
 x0 obj 9
 x1 obj 5
 x2 obj 7
 x3 obj 3
 x4 obj 9
 x5 obj 3
 x6 obj 9
 x7 obj 2
 x8 obj 7
 x9 obj 2
 x10 obj 3
 x11 obj -2
 x11 r0 -1.0
 x11 r2 256.0
 x11 r3 -0.00390625
 x11 r5 1.0
 x12 obj 3
 x13 obj 1
 x14 obj -2
 x14 r0 -1.0
 x14 r1 -16.0
 x14 r3 -0.00390625
 x14 r4 0.0625
 x15 obj 3
 x16 obj 9
 x17 obj -2
 x17 r1 -16.0
 x17 r2 256.0
 x17 r4 0.0625
 x18 obj 0
 x18 r5 2.0
RHS
 rhs obj 9
 rhs r0 -1.0
 rhs r1 -16.0
 rhs r2 256.0
 rhs r3 -0.00390625
 rhs r4 0.0625
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 UP b x18 2
ENDATA
