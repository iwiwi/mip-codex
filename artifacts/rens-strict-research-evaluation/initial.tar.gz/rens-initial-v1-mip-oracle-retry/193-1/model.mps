NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
COLUMNS
 x0 obj -9
 x1 obj -3
 x2 obj -4
 x3 obj -7
 x4 obj -8
 x5 obj -5
 x6 obj -4
 x7 obj -7
 x8 obj -5
 x9 obj -1
 x10 obj -2
 x11 obj -5
 x12 obj -7
 x13 obj -7
 x14 obj -7
 x15 obj -3
 x16 obj -7
 x17 obj -2
 x18 obj -1
 x19 obj -4
 x20 obj -2
 x21 obj -4
 x22 obj -2
 x23 obj -4
 x24 obj -7
 x25 obj -1
 x26 obj -3
 x27 obj -5
 x28 obj -6
 x29 obj -6
 x30 obj 8
 x30 r0 1.0
 x30 r1 16.0
 x30 r3 256.0
 x30 r4 0.00390625
 x30 r6 16.0
 x30 r7 16.0
 x31 obj 8
 x31 r1 16.0
 x31 r2 -1.0
 x31 r4 0.00390625
 x31 r5 256.0
 x31 r7 16.0
 x31 r8 0.0625
 x32 obj -4
 x33 obj 8
 x33 r0 1.0
 x33 r2 -1.0
 x33 r3 256.0
 x33 r5 256.0
 x33 r6 16.0
 x33 r8 0.0625
 x33 r9 1.0
 x34 obj 0
 x34 r9 2.0
RHS
 rhs obj -23
 rhs r0 1.0
 rhs r1 16.0
 rhs r2 -1.0
 rhs r3 256.0
 rhs r4 0.00390625
 rhs r5 256.0
 rhs r6 16.0
 rhs r7 16.0
 rhs r8 0.0625
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 1
 LI b x31 0
 UI b x31 1
 LI b x32 0
 UI b x32 3
 LI b x33 0
 UI b x33 1
 UP b x34 2
ENDATA
