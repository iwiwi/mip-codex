NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
COLUMNS
 x0 obj -5
 x1 obj -5
 x2 obj -2
 x3 obj -7
 x4 obj -6
 x5 obj -7
 x6 obj -5
 x7 obj -9
 x8 obj -1
 x9 obj -8
 x10 obj -7
 x11 obj -8
 x12 obj 1
 x12 r1 -0.0625
 x12 r2 -0.0625
 x13 obj -7
 x14 obj -5
 x15 obj -9
 x16 obj 1
 x16 r0 -0.0625
 x16 r1 -0.0625
 x17 obj -7
 x18 obj -2
 x19 obj -9
 x20 obj -2
 x21 obj -6
 x22 obj 1
 x22 r0 -0.0625
 x22 r2 -0.0625
 x22 r3 1.0
 x23 obj -5
 x24 obj -3
 x25 obj -8
 x26 obj -6
 x27 obj 0
 x27 r3 2.0
RHS
 rhs obj 13
 rhs r0 -0.0625
 rhs r1 -0.0625
 rhs r2 -0.0625
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 UP b x27 2
ENDATA
