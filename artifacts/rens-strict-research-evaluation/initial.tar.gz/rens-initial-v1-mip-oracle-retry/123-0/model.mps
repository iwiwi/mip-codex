NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 L r4
 L r5
 G r6
 G r7
 L r8
 L r9
 L r10
COLUMNS
 x0 obj 7
 x1 obj 9
 x2 obj 3
 x3 obj 2
 x4 obj 7
 x5 obj 5
 x6 obj 5
 x7 obj -2
 x7 r0 1.0
 x7 r1 16.0
 x7 r3 1.0
 x7 r4 0.0625
 x7 r6 -0.0625
 x7 r7 -256.0
 x7 r9 16.0
 x8 obj 8
 x9 obj 2
 x10 obj 7
 x11 obj 9
 x12 obj 3
 x13 obj 5
 x14 obj 6
 x15 obj 3
 x16 obj -2
 x16 r1 16.0
 x16 r2 -1.0
 x16 r4 0.0625
 x16 r5 256.0
 x16 r7 -256.0
 x16 r8 16.0
 x17 obj 5
 x18 obj 1
 x19 obj 1
 x20 obj 2
 x21 obj 4
 x22 obj 3
 x23 obj 4
 x24 obj -2
 x24 r0 1.0
 x24 r2 -1.0
 x24 r3 1.0
 x24 r5 256.0
 x24 r6 -0.0625
 x24 r8 16.0
 x24 r9 16.0
 x24 r10 1.0
 x25 obj 0
 x25 r10 2.0
RHS
 rhs obj 11
 rhs r0 1.0
 rhs r1 16.0
 rhs r2 -1.0
 rhs r3 1.0
 rhs r4 0.0625
 rhs r5 256.0
 rhs r6 -0.0625
 rhs r7 -256.0
 rhs r8 16.0
 rhs r9 16.0
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 1
 UP b x25 2
ENDATA
