NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 L r4
COLUMNS
 x0 obj -4
 x1 obj -9
 x2 obj -8
 x3 obj -1
 x4 obj -4
 x5 obj -2
 x6 obj -2
 x7 obj 7
 x7 r0 0.0625
 x7 r2 -0.0625
 x7 r3 16.0
 x7 r4 1.0
 x8 obj -1
 x9 obj -5
 x10 obj -6
 x11 obj -1
 x12 obj -4
 x13 obj 7
 x13 r0 0.0625
 x13 r1 -0.00390625
 x13 r3 16.0
 x14 obj -8
 x15 obj -6
 x16 obj -6
 x17 obj -1
 x18 obj -1
 x19 obj -8
 x20 obj -5
 x21 obj -3
 x22 obj -6
 x23 obj -8
 x24 obj -4
 x25 obj -6
 x26 obj 7
 x26 r1 -0.00390625
 x26 r2 -0.0625
 x27 obj 0
 x27 r4 2.0
RHS
 rhs obj -23
 rhs r0 0.0625
 rhs r1 -0.00390625
 rhs r2 -0.0625
 rhs r3 16.0
 rhs r4 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 1
 UP b x27 2
ENDATA
