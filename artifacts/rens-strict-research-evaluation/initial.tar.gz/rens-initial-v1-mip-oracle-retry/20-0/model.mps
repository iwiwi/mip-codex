NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 L r4
 L r5
 G r6
 G r7
 L r8
COLUMNS
 x0 obj 3
 x1 obj 5
 x2 obj -7
 x2 r0 0.0625
 x2 r1 -1.0
 x2 r3 0.00390625
 x2 r4 0.00390625
 x2 r6 -16.0
 x2 r7 -256.0
 x3 obj 5
 x4 obj 3
 x5 obj -7
 x5 r0 0.0625
 x5 r2 -256.0
 x5 r3 0.00390625
 x5 r5 0.00390625
 x5 r6 -16.0
 x5 r8 1.0
 x6 obj 8
 x7 obj 4
 x8 obj 3
 x9 obj 3
 x10 obj 1
 x11 obj 6
 x12 obj 9
 x13 obj 7
 x14 obj 5
 x15 obj 4
 x16 obj 4
 x17 obj 1
 x18 obj -7
 x18 r1 -1.0
 x18 r2 -256.0
 x18 r4 0.00390625
 x18 r5 0.00390625
 x18 r7 -256.0
 x19 obj 0
 x19 r8 2.0
RHS
 rhs obj -27
 rhs r0 0.0625
 rhs r1 -1.0
 rhs r2 -256.0
 rhs r3 0.00390625
 rhs r4 0.00390625
 rhs r5 0.00390625
 rhs r6 -16.0
 rhs r7 -256.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 1
 UP b x19 2
ENDATA
