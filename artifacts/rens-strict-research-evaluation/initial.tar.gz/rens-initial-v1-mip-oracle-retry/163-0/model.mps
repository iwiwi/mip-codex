NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 L r4
 G r5
 L r6
 L r7
COLUMNS
 x0 obj 3
 x1 obj -9
 x1 r0 256.0
 x1 r1 256.0
 x1 r3 -0.0625
 x1 r4 256.0
 x1 r6 0.0625
 x2 obj 5
 x3 obj 3
 x4 obj 8
 x5 obj -9
 x5 r0 256.0
 x5 r2 -0.00390625
 x5 r3 -0.0625
 x5 r5 -256.0
 x5 r6 0.0625
 x5 r7 1.0
 x6 obj 1
 x7 obj 1
 x8 obj 7
 x9 obj 3
 x10 obj 6
 x11 obj 1
 x12 obj 6
 x13 obj 5
 x14 obj 2
 x15 obj 5
 x16 obj -9
 x16 r1 256.0
 x16 r2 -0.00390625
 x16 r4 256.0
 x16 r5 -256.0
 x17 obj 4
 x18 obj 9
 x19 obj 1
 x20 obj 8
 x21 obj 8
 x22 obj 3
 x23 obj 0
 x23 r7 2.0
RHS
 rhs obj 8
 rhs r0 256.0
 rhs r1 256.0
 rhs r2 -0.00390625
 rhs r3 -0.0625
 rhs r4 256.0
 rhs r5 -256.0
 rhs r6 0.0625
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 UP b x23 2
ENDATA
