NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 G r4
 L r5
 L r6
 L r7
 L r8
COLUMNS
 x0 obj -7
 x0 r0 256.0
 x0 r1 -256.0
 x0 r3 -256.0
 x0 r4 -256.0
 x0 r6 16.0
 x0 r7 0.0625
 x1 obj 8
 x2 obj 5
 x3 obj 3
 x4 obj 9
 x5 obj 8
 x6 obj 7
 x7 obj 5
 x8 obj 4
 x9 obj -7
 x9 r1 -256.0
 x9 r2 16.0
 x9 r4 -256.0
 x9 r5 1.0
 x9 r7 0.0625
 x10 obj 1
 x11 obj 1
 x12 obj 8
 x13 obj 5
 x14 obj 8
 x15 obj -7
 x15 r0 256.0
 x15 r2 16.0
 x15 r3 -256.0
 x15 r5 1.0
 x15 r6 16.0
 x15 r8 1.0
 x16 obj 7
 x17 obj 9
 x18 obj 1
 x19 obj 6
 x20 obj 8
 x21 obj 6
 x22 obj 9
 x23 obj 9
 x24 obj 2
 x25 obj 0
 x25 r8 2.0
RHS
 rhs obj 14
 rhs r0 256.0
 rhs r1 -256.0
 rhs r2 16.0
 rhs r3 -256.0
 rhs r4 -256.0
 rhs r5 1.0
 rhs r6 16.0
 rhs r7 0.0625
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 UP b x25 2
ENDATA
