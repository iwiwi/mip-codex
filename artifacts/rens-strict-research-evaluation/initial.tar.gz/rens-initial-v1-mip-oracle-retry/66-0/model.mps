NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
COLUMNS
 x0 obj 9
 x1 obj 9
 x2 obj 8
 x3 obj 9
 x4 obj 4
 x5 obj 6
 x6 obj 4
 x7 obj 2
 x8 obj -9
 x8 r1 16.0
 x8 r2 0.0625
 x9 obj 5
 x10 obj 6
 x11 obj 4
 x12 obj 4
 x13 obj 3
 x14 obj -9
 x14 r0 1.0
 x14 r1 16.0
 x14 r3 0.00390625
 x15 obj 2
 x16 obj 9
 x17 obj 9
 x18 obj 6
 x19 obj 2
 x20 obj 8
 x21 obj -9
 x21 r0 1.0
 x21 r2 0.0625
 x21 r3 0.00390625
 x21 r4 1.0
 x22 obj 5
 x23 obj 4
 x24 obj 5
 x25 obj 9
 x26 obj 0
 x26 r4 2.0
RHS
 rhs obj -8
 rhs r0 1.0
 rhs r1 16.0
 rhs r2 0.0625
 rhs r3 0.00390625
 rhs r4 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 2
 UP b x26 2
ENDATA
