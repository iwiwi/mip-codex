NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 G r4
 L r5
 L r6
 L r7
 G r8
 L r9
 L r10
COLUMNS
 x0 obj -7
 x1 obj -9
 x2 obj -4
 x3 obj -6
 x4 obj -5
 x5 obj -9
 x6 obj -9
 x7 obj -7
 x8 obj 2
 x8 r0 -0.0625
 x8 r1 1.0
 x8 r3 -16.0
 x8 r4 -0.0625
 x8 r6 0.00390625
 x8 r7 0.00390625
 x8 r9 0.0625
 x9 obj -4
 x10 obj -5
 x11 obj -5
 x12 obj 2
 x12 r1 1.0
 x12 r2 -0.0625
 x12 r4 -0.0625
 x12 r5 256.0
 x12 r7 0.00390625
 x12 r8 -1.0
 x13 obj -8
 x14 obj -8
 x15 obj -3
 x16 obj -7
 x17 obj -5
 x18 obj -6
 x19 obj -9
 x20 obj -4
 x21 obj -4
 x22 obj -6
 x23 obj -2
 x24 obj -6
 x25 obj -3
 x26 obj -1
 x27 obj 2
 x27 r0 -0.0625
 x27 r2 -0.0625
 x27 r3 -16.0
 x27 r5 256.0
 x27 r6 0.00390625
 x27 r8 -1.0
 x27 r9 0.0625
 x27 r10 1.0
 x28 obj -8
 x29 obj -8
 x30 obj -9
 x31 obj -4
 x32 obj -3
 x33 obj -1
 x34 obj 0
 x34 r10 2.0
RHS
 rhs obj -12
 rhs r0 -0.0625
 rhs r1 1.0
 rhs r2 -0.0625
 rhs r3 -16.0
 rhs r4 -0.0625
 rhs r5 256.0
 rhs r6 0.00390625
 rhs r7 0.00390625
 rhs r8 -1.0
 rhs r9 0.0625
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 1
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 2
 LI b x33 0
 UI b x33 3
 UP b x34 2
ENDATA
