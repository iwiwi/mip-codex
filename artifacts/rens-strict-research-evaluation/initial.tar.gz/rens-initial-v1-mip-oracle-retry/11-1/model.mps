NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 L r4
COLUMNS
 x0 obj 7
 x0 r1 16.0
 x0 r2 -256.0
 x1 obj -3
 x2 obj -1
 x3 obj -1
 x4 obj 7
 x4 r0 -256.0
 x4 r2 -256.0
 x4 r3 -1.0
 x4 r4 1.0
 x5 obj -3
 x6 obj -2
 x7 obj -1
 x8 obj -4
 x9 obj -5
 x10 obj -5
 x11 obj -3
 x12 obj -3
 x13 obj -3
 x14 obj -2
 x15 obj -8
 x16 obj 7
 x16 r0 -256.0
 x16 r1 16.0
 x16 r3 -1.0
 x17 obj -3
 x18 obj -1
 x19 obj -2
 x20 obj -7
 x21 obj 0
 x21 r4 2.0
RHS
 rhs obj 28
 rhs r0 -256.0
 rhs r1 16.0
 rhs r2 -256.0
 rhs r3 -1.0
 rhs r4 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 UP b x21 2
ENDATA
