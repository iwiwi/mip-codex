NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 L r4
 G r5
 L r6
 L r7
 L r8
COLUMNS
 x0 obj 3
 x1 obj 4
 x2 obj 1
 x3 obj 1
 x4 obj 4
 x5 obj 4
 x6 obj 8
 x7 obj 8
 x8 obj 4
 x9 obj -4
 x9 r0 -0.0625
 x9 r2 -256.0
 x9 r3 0.00390625
 x9 r5 -16.0
 x9 r6 0.0625
 x9 r8 1.0
 x10 obj 1
 x11 obj 9
 x12 obj 9
 x13 obj 8
 x14 obj 7
 x15 obj 7
 x16 obj 7
 x17 obj 4
 x18 obj -4
 x18 r1 1.0
 x18 r2 -256.0
 x18 r4 256.0
 x18 r5 -16.0
 x18 r7 0.0625
 x19 obj 5
 x20 obj 9
 x21 obj 6
 x22 obj 6
 x23 obj 8
 x24 obj -4
 x24 r0 -0.0625
 x24 r1 1.0
 x24 r3 0.00390625
 x24 r4 256.0
 x24 r6 0.0625
 x24 r7 0.0625
 x25 obj 5
 x26 obj 3
 x27 obj 1
 x28 obj 3
 x29 obj 0
 x29 r8 2.0
RHS
 rhs obj 12
 rhs r0 -0.0625
 rhs r1 1.0
 rhs r2 -256.0
 rhs r3 0.00390625
 rhs r4 256.0
 rhs r5 -16.0
 rhs r6 0.0625
 rhs r7 0.0625
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 1
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 2
 UP b x29 2
ENDATA
