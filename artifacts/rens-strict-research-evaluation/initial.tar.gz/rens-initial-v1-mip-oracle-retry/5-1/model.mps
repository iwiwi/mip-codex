NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 L r4
COLUMNS
 x0 obj -5
 x1 obj -8
 x2 obj -8
 x3 obj 5
 x3 r1 256.0
 x3 r2 1.0
 x4 obj -5
 x5 obj -6
 x6 obj -9
 x7 obj 5
 x7 r0 0.0625
 x7 r2 1.0
 x7 r3 -1.0
 x7 r4 1.0
 x8 obj -6
 x9 obj 5
 x9 r0 0.0625
 x9 r1 256.0
 x9 r3 -1.0
 x10 obj -6
 x11 obj -9
 x12 obj -7
 x13 obj -6
 x14 obj -1
 x15 obj -2
 x16 obj -3
 x17 obj -8
 x18 obj -9
 x19 obj 0
 x19 r4 2.0
RHS
 rhs obj 14
 rhs r0 0.0625
 rhs r1 256.0
 rhs r2 1.0
 rhs r3 -1.0
 rhs r4 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 UP b x19 2
ENDATA
