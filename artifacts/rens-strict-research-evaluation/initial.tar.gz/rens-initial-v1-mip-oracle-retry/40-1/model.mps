NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 G r4
 L r5
COLUMNS
 x0 obj -8
 x1 obj -8
 x2 obj -4
 x3 obj -4
 x4 obj -4
 x5 obj -6
 x6 obj -8
 x7 obj -6
 x8 obj -5
 x9 obj -6
 x10 obj -8
 x11 obj -9
 x12 obj -6
 x13 obj 8
 x13 r1 -16.0
 x13 r2 16.0
 x13 r4 -0.00390625
 x14 obj 8
 x14 r0 16.0
 x14 r2 16.0
 x14 r3 0.00390625
 x14 r5 1.0
 x15 obj 8
 x15 r0 16.0
 x15 r1 -16.0
 x15 r3 0.00390625
 x15 r4 -0.00390625
 x16 obj -3
 x17 obj -3
 x18 obj -6
 x19 obj -9
 x20 obj 0
 x20 r5 2.0
RHS
 rhs obj -10
 rhs r0 16.0
 rhs r1 -16.0
 rhs r2 16.0
 rhs r3 0.00390625
 rhs r4 -0.00390625
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 UP b x20 2
ENDATA
