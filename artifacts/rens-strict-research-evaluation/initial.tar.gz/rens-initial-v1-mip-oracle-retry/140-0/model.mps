NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 G r4
 G r5
 L r6
COLUMNS
 x0 obj 1
 x1 obj 7
 x2 obj 4
 x3 obj 3
 x4 obj 7
 x5 obj 2
 x6 obj 2
 x7 obj 4
 x8 obj 8
 x9 obj -4
 x9 r0 -1.0
 x9 r1 0.0625
 x9 r3 1.0
 x9 r4 -0.0625
 x10 obj 5
 x11 obj 9
 x12 obj -4
 x12 r0 -1.0
 x12 r2 -1.0
 x12 r3 1.0
 x12 r5 -16.0
 x12 r6 1.0
 x13 obj 7
 x14 obj 9
 x15 obj 1
 x16 obj 4
 x17 obj -4
 x17 r1 0.0625
 x17 r2 -1.0
 x17 r4 -0.0625
 x17 r5 -16.0
 x18 obj 2
 x19 obj 1
 x20 obj 6
 x21 obj 1
 x22 obj 2
 x23 obj 9
 x24 obj 4
 x25 obj 8
 x26 obj 8
 x27 obj 0
 x27 r6 2.0
RHS
 rhs obj -14
 rhs r0 -1.0
 rhs r1 0.0625
 rhs r2 -1.0
 rhs r3 1.0
 rhs r4 -0.0625
 rhs r5 -16.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 3
 UP b x27 2
ENDATA
