NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 L r4
 G r5
 L r6
COLUMNS
 x0 obj 2
 x1 obj 8
 x2 obj 8
 x3 obj 1
 x4 obj 4
 x5 obj 9
 x6 obj 2
 x7 obj 4
 x8 obj -1
 x8 r0 1.0
 x8 r2 1.0
 x8 r3 16.0
 x8 r5 -1.0
 x8 r6 1.0
 x9 obj 8
 x10 obj 7
 x11 obj 3
 x12 obj 8
 x13 obj 2
 x14 obj 6
 x15 obj -1
 x15 r1 -0.0625
 x15 r2 1.0
 x15 r4 256.0
 x15 r5 -1.0
 x16 obj 6
 x17 obj 2
 x18 obj 8
 x19 obj -1
 x19 r0 1.0
 x19 r1 -0.0625
 x19 r3 16.0
 x19 r4 256.0
 x20 obj 2
 x21 obj 0
 x21 r6 2.0
RHS
 rhs obj 12
 rhs r0 1.0
 rhs r1 -0.0625
 rhs r2 1.0
 rhs r3 16.0
 rhs r4 256.0
 rhs r5 -1.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 4
 UP b x21 2
ENDATA
