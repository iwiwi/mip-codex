NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj -5
 x0 r1 -0.00390625
 x0 r2 0.00390625
 x0 r4 0.00390625
 x1 obj 7
 x2 obj 7
 x3 obj 2
 x4 obj 7
 x5 obj -5
 x5 r0 -256.0
 x5 r2 0.00390625
 x5 r3 0.0625
 x5 r5 1.0
 x6 obj 9
 x7 obj 3
 x8 obj 8
 x9 obj 5
 x10 obj 2
 x11 obj 8
 x12 obj 7
 x13 obj 2
 x14 obj 6
 x15 obj 5
 x16 obj 9
 x17 obj 1
 x18 obj 8
 x19 obj 2
 x20 obj -5
 x20 r0 -256.0
 x20 r1 -0.00390625
 x20 r3 0.0625
 x20 r4 0.00390625
 x21 obj 8
 x22 obj 5
 x23 obj 0
 x23 r5 2.0
RHS
 rhs obj 7
 rhs r0 -256.0
 rhs r1 -0.00390625
 rhs r2 0.00390625
 rhs r3 0.0625
 rhs r4 0.00390625
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 UP b x23 2
ENDATA
