NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
COLUMNS
 x0 obj -8
 x1 obj -6
 x2 obj -8
 x3 obj -2
 x4 obj -4
 x5 obj -8
 x6 obj 6
 x6 r1 0.0625
 x6 r2 -0.00390625
 x7 obj -5
 x8 obj -5
 x9 obj -7
 x10 obj -3
 x11 obj 6
 x11 r0 0.0625
 x11 r1 0.0625
 x12 obj -7
 x13 obj -6
 x14 obj -5
 x15 obj -7
 x16 obj -6
 x17 obj -8
 x18 obj 6
 x18 r0 0.0625
 x18 r2 -0.00390625
 x18 r3 1.0
 x19 obj -9
 x20 obj -9
 x21 obj -5
 x22 obj -5
 x23 obj -4
 x24 obj -5
 x25 obj -1
 x26 obj -5
 x27 obj -4
 x28 obj -2
 x29 obj -6
 x30 obj -8
 x31 obj -9
 x32 obj -9
 x33 obj 0
 x33 r3 2.0
RHS
 rhs obj 29
 rhs r0 0.0625
 rhs r1 0.0625
 rhs r2 -0.00390625
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 4
 UP b x33 2
ENDATA
