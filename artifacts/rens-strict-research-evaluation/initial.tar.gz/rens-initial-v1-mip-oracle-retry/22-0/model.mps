NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 G r4
 L r5
 L r6
 G r7
 L r8
COLUMNS
 x0 obj 8
 x1 obj -5
 x1 r0 256.0
 x1 r1 -1.0
 x1 r3 0.00390625
 x1 r4 -1.0
 x1 r6 16.0
 x1 r7 -0.0625
 x2 obj 7
 x3 obj 9
 x4 obj 5
 x5 obj 9
 x6 obj 3
 x7 obj 5
 x8 obj 3
 x9 obj 3
 x10 obj 7
 x11 obj 6
 x12 obj 3
 x13 obj 9
 x14 obj 3
 x15 obj 8
 x16 obj 8
 x17 obj 9
 x18 obj -5
 x18 r1 -1.0
 x18 r2 -0.0625
 x18 r4 -1.0
 x18 r5 1.0
 x18 r7 -0.0625
 x19 obj 8
 x20 obj 3
 x21 obj 5
 x22 obj -5
 x22 r0 256.0
 x22 r2 -0.0625
 x22 r3 0.00390625
 x22 r5 1.0
 x22 r6 16.0
 x22 r8 1.0
 x23 obj 6
 x24 obj 8
 x25 obj 3
 x26 obj 2
 x27 obj 8
 x28 obj 5
 x29 obj 6
 x30 obj 3
 x31 obj 5
 x32 obj 2
 x33 obj 9
 x34 obj 1
 x35 obj 0
 x35 r8 2.0
RHS
 rhs obj 8
 rhs r0 256.0
 rhs r1 -1.0
 rhs r2 -0.0625
 rhs r3 0.00390625
 rhs r4 -1.0
 rhs r5 1.0
 rhs r6 16.0
 rhs r7 -0.0625
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 4
 LI b x32 0
 UI b x32 3
 LI b x33 0
 UI b x33 2
 LI b x34 0
 UI b x34 3
 UP b x35 2
ENDATA
