NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj 1
 x1 obj 7
 x2 obj 6
 x3 obj 2
 x4 obj -5
 x4 r0 -16.0
 x4 r1 16.0
 x4 r3 0.00390625
 x4 r4 0.00390625
 x5 obj 1
 x6 obj 4
 x7 obj 4
 x8 obj 2
 x9 obj 2
 x10 obj 6
 x11 obj 2
 x12 obj -5
 x12 r1 16.0
 x12 r2 -16.0
 x12 r4 0.00390625
 x13 obj 3
 x14 obj 6
 x15 obj 7
 x16 obj 1
 x17 obj 4
 x18 obj 3
 x19 obj 3
 x20 obj 2
 x21 obj 9
 x22 obj -5
 x22 r0 -16.0
 x22 r2 -16.0
 x22 r3 0.00390625
 x22 r5 1.0
 x23 obj 8
 x24 obj 3
 x25 obj 4
 x26 obj 0
 x26 r5 2.0
RHS
 rhs obj -8
 rhs r0 -16.0
 rhs r1 16.0
 rhs r2 -16.0
 rhs r3 0.00390625
 rhs r4 0.00390625
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 UP b x26 2
ENDATA
