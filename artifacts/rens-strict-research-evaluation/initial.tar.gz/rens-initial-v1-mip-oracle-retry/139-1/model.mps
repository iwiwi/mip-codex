NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
COLUMNS
 x0 obj 1
 x0 r0 256.0
 x0 r1 -0.0625
 x1 obj -3
 x2 obj -7
 x3 obj -8
 x4 obj -6
 x5 obj -7
 x6 obj -4
 x7 obj -1
 x8 obj -8
 x9 obj -8
 x10 obj -1
 x11 obj -5
 x12 obj -9
 x13 obj -9
 x14 obj -3
 x15 obj -9
 x16 obj -4
 x17 obj 1
 x17 r1 -0.0625
 x17 r2 -0.0625
 x18 obj -8
 x19 obj -1
 x20 obj -7
 x21 obj -2
 x22 obj -4
 x23 obj -3
 x24 obj -2
 x25 obj -6
 x26 obj 1
 x26 r0 256.0
 x26 r2 -0.0625
 x26 r3 1.0
 x27 obj -2
 x28 obj -5
 x29 obj -4
 x30 obj -3
 x31 obj -1
 x32 obj -8
 x33 obj 0
 x33 r3 2.0
RHS
 rhs obj -18
 rhs r0 256.0
 rhs r1 -0.0625
 rhs r2 -0.0625
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 1
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 2
 LI b x31 0
 UI b x31 2
 LI b x32 0
 UI b x32 3
 UP b x33 2
ENDATA
