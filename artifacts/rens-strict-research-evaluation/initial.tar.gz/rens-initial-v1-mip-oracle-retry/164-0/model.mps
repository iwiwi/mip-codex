NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 G r3
 L r4
 L r5
 L r6
 L r7
 L r8
COLUMNS
 x0 obj -6
 x0 r0 256.0
 x0 r2 -1.0
 x0 r3 -16.0
 x0 r5 0.00390625
 x0 r6 0.00390625
 x0 r8 1.0
 x1 obj 2
 x2 obj 9
 x3 obj 4
 x4 obj -6
 x4 r0 256.0
 x4 r1 -1.0
 x4 r3 -16.0
 x4 r4 0.0625
 x4 r6 0.00390625
 x4 r7 1.0
 x5 obj 2
 x6 obj 6
 x7 obj 8
 x8 obj 4
 x9 obj 8
 x10 obj 8
 x11 obj 6
 x12 obj 4
 x13 obj 8
 x14 obj 8
 x15 obj 3
 x16 obj -6
 x16 r1 -1.0
 x16 r2 -1.0
 x16 r4 0.0625
 x16 r5 0.00390625
 x16 r7 1.0
 x17 obj 8
 x18 obj 1
 x19 obj 3
 x20 obj 6
 x21 obj 4
 x22 obj 1
 x23 obj 9
 x24 obj 7
 x25 obj 0
 x25 r8 2.0
RHS
 rhs obj 11
 rhs r0 256.0
 rhs r1 -1.0
 rhs r2 -1.0
 rhs r3 -16.0
 rhs r4 0.0625
 rhs r5 0.00390625
 rhs r6 0.00390625
 rhs r7 1.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 UP b x25 2
ENDATA
