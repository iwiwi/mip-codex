NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
COLUMNS
 x0 obj -4
 x1 obj -1
 x2 obj -1
 x3 obj -8
 x4 obj 9
 x4 r0 1.0
 x4 r2 256.0
 x4 r3 1.0
 x5 obj -5
 x6 obj -4
 x7 obj -1
 x8 obj 9
 x8 r0 1.0
 x8 r1 -0.00390625
 x9 obj -8
 x10 obj 9
 x10 r1 -0.00390625
 x10 r2 256.0
 x11 obj -6
 x12 obj -6
 x13 obj -8
 x14 obj -3
 x15 obj -4
 x16 obj -9
 x17 obj -7
 x18 obj -5
 x19 obj -8
 x20 obj -3
 x21 obj -2
 x22 obj -3
 x23 obj -9
 x24 obj 0
 x24 r3 2.0
RHS
 rhs obj 11
 rhs r0 1.0
 rhs r1 -0.00390625
 rhs r2 256.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 UP b x24 2
ENDATA
