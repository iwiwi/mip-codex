NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
COLUMNS
 x0 obj -3
 x1 obj -4
 x2 obj -3
 x3 obj -7
 x4 obj 3
 x4 r0 -0.0625
 x4 r2 256.0
 x4 r3 1.0
 x5 obj -8
 x6 obj -1
 x7 obj -4
 x8 obj 3
 x8 r0 -0.0625
 x8 r1 -16.0
 x9 obj -1
 x10 obj -8
 x11 obj -6
 x12 obj 3
 x12 r1 -16.0
 x12 r2 256.0
 x13 obj -7
 x14 obj -8
 x15 obj -8
 x16 obj -4
 x17 obj -2
 x18 obj -1
 x19 obj 0
 x19 r3 2.0
RHS
 rhs obj 17
 rhs r0 -0.0625
 rhs r1 -16.0
 rhs r2 256.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 UP b x19 2
ENDATA
