NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 G r4
 L r5
COLUMNS
 x0 obj -6
 x1 obj -9
 x2 obj -5
 x3 obj -7
 x4 obj -6
 x5 obj -8
 x6 obj -5
 x7 obj -5
 x8 obj -1
 x9 obj -4
 x10 obj -8
 x11 obj -6
 x12 obj -1
 x13 obj 5
 x13 r0 16.0
 x13 r1 256.0
 x13 r3 16.0
 x13 r4 -1.0
 x14 obj -4
 x15 obj -3
 x16 obj -9
 x17 obj 5
 x17 r1 256.0
 x17 r2 256.0
 x17 r4 -1.0
 x18 obj -4
 x19 obj -8
 x20 obj 5
 x20 r0 16.0
 x20 r2 256.0
 x20 r3 16.0
 x20 r5 1.0
 x21 obj -9
 x22 obj -7
 x23 obj -1
 x24 obj 0
 x24 r5 2.0
RHS
 rhs obj -11
 rhs r0 16.0
 rhs r1 256.0
 rhs r2 256.0
 rhs r3 16.0
 rhs r4 -1.0
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 UP b x24 2
ENDATA
