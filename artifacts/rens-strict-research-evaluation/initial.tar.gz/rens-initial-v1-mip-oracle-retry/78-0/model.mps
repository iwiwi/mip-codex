NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 G r4
 G r5
 L r6
 L r7
COLUMNS
 x0 obj 2
 x1 obj -7
 x1 r0 0.0625
 x1 r1 -0.00390625
 x1 r3 16.0
 x1 r4 -0.0625
 x1 r6 0.0625
 x2 obj 3
 x3 obj 4
 x4 obj 4
 x5 obj 9
 x6 obj 6
 x7 obj 9
 x8 obj 1
 x9 obj 1
 x10 obj 5
 x11 obj 3
 x12 obj 9
 x13 obj 8
 x14 obj 4
 x15 obj 8
 x16 obj 8
 x17 obj 4
 x18 obj -7
 x18 r1 -0.00390625
 x18 r2 -256.0
 x18 r4 -0.0625
 x18 r5 -256.0
 x19 obj 2
 x20 obj 3
 x21 obj 6
 x22 obj 2
 x23 obj -7
 x23 r0 0.0625
 x23 r2 -256.0
 x23 r3 16.0
 x23 r5 -256.0
 x23 r6 0.0625
 x23 r7 1.0
 x24 obj 4
 x25 obj 0
 x25 r7 2.0
RHS
 rhs obj -14
 rhs r0 0.0625
 rhs r1 -0.00390625
 rhs r2 -256.0
 rhs r3 16.0
 rhs r4 -0.0625
 rhs r5 -256.0
 rhs r6 0.0625
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 1
 LI b x24 0
 UI b x24 4
 UP b x25 2
ENDATA
