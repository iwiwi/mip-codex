NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 G r4
 L r5
 L r6
COLUMNS
 x0 obj -9
 x1 obj -1
 x2 obj -8
 x3 obj -9
 x4 obj -9
 x5 obj -9
 x6 obj -3
 x7 obj -6
 x8 obj -4
 x9 obj -8
 x10 obj -2
 x11 obj -9
 x12 obj 7
 x12 r0 256.0
 x12 r2 1.0
 x12 r3 -16.0
 x12 r5 256.0
 x12 r6 1.0
 x13 obj -8
 x14 obj -2
 x15 obj -6
 x16 obj -9
 x17 obj -9
 x18 obj -6
 x19 obj -3
 x20 obj 7
 x20 r1 -0.00390625
 x20 r2 1.0
 x20 r4 -0.00390625
 x20 r5 256.0
 x21 obj -4
 x22 obj -4
 x23 obj -1
 x24 obj -7
 x25 obj -9
 x26 obj -9
 x27 obj -2
 x28 obj -9
 x29 obj -1
 x30 obj -1
 x31 obj -7
 x32 obj 7
 x32 r0 256.0
 x32 r1 -0.00390625
 x32 r3 -16.0
 x32 r4 -0.00390625
 x33 obj 0
 x33 r6 2.0
RHS
 rhs obj 28
 rhs r0 256.0
 rhs r1 -0.00390625
 rhs r2 1.0
 rhs r3 -16.0
 rhs r4 -0.00390625
 rhs r5 256.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 1
 UP b x33 2
ENDATA
