NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 L r4
 L r5
 G r6
 L r7
COLUMNS
 x0 obj -2
 x1 obj -2
 x2 obj -8
 x3 obj -8
 x4 obj -2
 x5 obj -8
 x6 obj -5
 x7 obj 8
 x7 r1 1.0
 x7 r2 0.0625
 x7 r4 256.0
 x7 r5 0.0625
 x8 obj -1
 x9 obj -3
 x10 obj -4
 x11 obj -6
 x12 obj -5
 x13 obj -7
 x14 obj -1
 x15 obj 8
 x15 r0 -256.0
 x15 r2 0.0625
 x15 r3 -0.0625
 x15 r5 0.0625
 x15 r6 -16.0
 x15 r7 1.0
 x16 obj 8
 x16 r0 -256.0
 x16 r1 1.0
 x16 r3 -0.0625
 x16 r4 256.0
 x16 r6 -16.0
 x17 obj -8
 x18 obj -2
 x19 obj 0
 x19 r7 2.0
RHS
 rhs obj 8
 rhs r0 -256.0
 rhs r1 1.0
 rhs r2 0.0625
 rhs r3 -0.0625
 rhs r4 256.0
 rhs r5 0.0625
 rhs r6 -16.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 UP b x19 2
ENDATA
