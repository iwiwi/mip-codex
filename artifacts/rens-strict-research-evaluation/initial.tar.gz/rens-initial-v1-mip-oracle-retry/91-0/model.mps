NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 G r4
 G r5
 L r6
COLUMNS
 x0 obj 4
 x1 obj 1
 x2 obj 6
 x3 obj 5
 x4 obj 4
 x5 obj -9
 x5 r0 0.00390625
 x5 r2 0.0625
 x5 r3 -0.0625
 x5 r5 -1.0
 x5 r6 1.0
 x6 obj 6
 x7 obj 4
 x8 obj 8
 x9 obj 9
 x10 obj 3
 x11 obj 6
 x12 obj 6
 x13 obj 5
 x14 obj 4
 x15 obj -9
 x15 r0 0.00390625
 x15 r1 -1.0
 x15 r3 -0.0625
 x15 r4 -1.0
 x16 obj 7
 x17 obj 4
 x18 obj 1
 x19 obj -9
 x19 r1 -1.0
 x19 r2 0.0625
 x19 r4 -1.0
 x19 r5 -1.0
 x20 obj 4
 x21 obj 6
 x22 obj 0
 x22 r6 2.0
RHS
 rhs obj 13
 rhs r0 0.00390625
 rhs r1 -1.0
 rhs r2 0.0625
 rhs r3 -0.0625
 rhs r4 -1.0
 rhs r5 -1.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 UP b x22 2
ENDATA
