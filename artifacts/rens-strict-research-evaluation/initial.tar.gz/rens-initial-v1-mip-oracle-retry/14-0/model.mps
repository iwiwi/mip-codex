NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 L r4
 G r5
 L r6
 L r7
COLUMNS
 x0 obj 6
 x1 obj 3
 x2 obj 1
 x3 obj 5
 x4 obj 4
 x5 obj 4
 x6 obj 9
 x7 obj 7
 x8 obj 1
 x9 obj 4
 x10 obj 4
 x11 obj 3
 x12 obj 8
 x13 obj 4
 x14 obj 5
 x15 obj 1
 x16 obj 8
 x17 obj 1
 x18 obj 2
 x19 obj 9
 x20 obj 4
 x21 obj 9
 x22 obj 8
 x23 obj 5
 x24 obj 7
 x25 obj 9
 x26 obj 6
 x27 obj 9
 x28 obj -9
 x28 r1 -0.00390625
 x28 r2 1.0
 x28 r4 0.00390625
 x28 r5 -0.00390625
 x29 obj 6
 x30 obj 1
 x31 obj 3
 x32 obj 6
 x33 obj -9
 x33 r0 256.0
 x33 r2 1.0
 x33 r3 0.0625
 x33 r5 -0.00390625
 x33 r6 0.00390625
 x33 r7 1.0
 x34 obj -9
 x34 r0 256.0
 x34 r1 -0.00390625
 x34 r3 0.0625
 x34 r4 0.00390625
 x34 r6 0.00390625
 x35 obj 0
 x35 r7 2.0
RHS
 rhs obj 9
 rhs r0 256.0
 rhs r1 -0.00390625
 rhs r2 1.0
 rhs r3 0.0625
 rhs r4 0.00390625
 rhs r5 -0.00390625
 rhs r6 0.00390625
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 1
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 2
 LI b x32 0
 UI b x32 3
 LI b x33 0
 UI b x33 1
 LI b x34 0
 UI b x34 1
 UP b x35 2
ENDATA
