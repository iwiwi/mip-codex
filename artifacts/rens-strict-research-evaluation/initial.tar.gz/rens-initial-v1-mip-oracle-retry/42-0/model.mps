NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
 L r4
 G r5
 L r6
COLUMNS
 x0 obj 9
 x1 obj 6
 x2 obj 9
 x3 obj 3
 x4 obj 9
 x5 obj 6
 x6 obj 4
 x7 obj 7
 x8 obj 7
 x9 obj 1
 x10 obj 8
 x11 obj 8
 x12 obj -1
 x12 r1 -0.0625
 x12 r2 256.0
 x12 r4 0.00390625
 x12 r5 -256.0
 x13 obj 5
 x14 obj 3
 x15 obj 4
 x16 obj 7
 x17 obj 5
 x18 obj 1
 x19 obj 7
 x20 obj 9
 x21 obj -1
 x21 r0 -0.00390625
 x21 r1 -0.0625
 x21 r3 256.0
 x21 r4 0.00390625
 x22 obj 6
 x23 obj -1
 x23 r0 -0.00390625
 x23 r2 256.0
 x23 r3 256.0
 x23 r5 -256.0
 x23 r6 1.0
 x24 obj 7
 x25 obj 1
 x26 obj 3
 x27 obj 6
 x28 obj 6
 x29 obj 4
 x30 obj 8
 x31 obj 5
 x32 obj 7
 x33 obj 2
 x34 obj 5
 x35 obj 0
 x35 r6 2.0
RHS
 rhs obj 26
 rhs r0 -0.00390625
 rhs r1 -0.0625
 rhs r2 256.0
 rhs r3 256.0
 rhs r4 0.00390625
 rhs r5 -256.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 1
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 2
 LI b x34 0
 UI b x34 4
 UP b x35 2
ENDATA
