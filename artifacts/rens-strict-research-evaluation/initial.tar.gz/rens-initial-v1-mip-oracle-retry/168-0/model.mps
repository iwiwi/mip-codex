NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 L r4
 G r5
 L r6
 L r7
COLUMNS
 x0 obj -4
 x0 r0 0.00390625
 x0 r2 -1.0
 x0 r3 1.0
 x0 r5 -256.0
 x0 r6 1.0
 x0 r7 1.0
 x1 obj 7
 x2 obj 2
 x3 obj 1
 x4 obj 6
 x5 obj 2
 x6 obj 1
 x7 obj 8
 x8 obj 2
 x9 obj 1
 x10 obj 1
 x11 obj 8
 x12 obj 2
 x13 obj 4
 x14 obj 5
 x15 obj -4
 x15 r0 0.00390625
 x15 r1 -0.00390625
 x15 r3 1.0
 x15 r4 16.0
 x15 r6 1.0
 x16 obj -4
 x16 r1 -0.00390625
 x16 r2 -1.0
 x16 r4 16.0
 x16 r5 -256.0
 x17 obj 3
 x18 obj 5
 x19 obj 4
 x20 obj 4
 x21 obj 3
 x22 obj 5
 x23 obj 3
 x24 obj 0
 x24 r7 2.0
RHS
 rhs obj 27
 rhs r0 0.00390625
 rhs r1 -0.00390625
 rhs r2 -1.0
 rhs r3 1.0
 rhs r4 16.0
 rhs r5 -256.0
 rhs r6 1.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 UP b x24 2
ENDATA
