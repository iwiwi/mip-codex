NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 L r4
 L r5
COLUMNS
 x0 obj -2
 x1 obj -2
 x2 obj -3
 x3 obj -3
 x4 obj 9
 x4 r1 16.0
 x4 r2 1.0
 x4 r4 256.0
 x5 obj -3
 x6 obj -5
 x7 obj -5
 x8 obj -2
 x9 obj -3
 x10 obj -4
 x11 obj -7
 x12 obj -9
 x13 obj 9
 x13 r0 -1.0
 x13 r2 1.0
 x13 r3 -0.0625
 x13 r5 1.0
 x14 obj -7
 x15 obj -8
 x16 obj 9
 x16 r0 -1.0
 x16 r1 16.0
 x16 r3 -0.0625
 x16 r4 256.0
 x17 obj -8
 x18 obj -2
 x19 obj -2
 x20 obj -7
 x21 obj -7
 x22 obj 0
 x22 r5 2.0
RHS
 rhs obj -22
 rhs r0 -1.0
 rhs r1 16.0
 rhs r2 1.0
 rhs r3 -0.0625
 rhs r4 256.0
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 UP b x22 2
ENDATA
