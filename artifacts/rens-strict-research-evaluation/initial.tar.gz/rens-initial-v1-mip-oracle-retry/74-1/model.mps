NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 G r4
 G r5
 L r6
 G r7
 L r8
 L r9
COLUMNS
 x0 obj -4
 x1 obj 3
 x1 r0 0.0625
 x1 r2 -16.0
 x1 r3 256.0
 x1 r5 -256.0
 x1 r6 1.0
 x1 r8 0.0625
 x1 r9 1.0
 x2 obj 3
 x2 r1 1.0
 x2 r2 -16.0
 x2 r4 -0.00390625
 x2 r5 -256.0
 x2 r7 -0.0625
 x2 r8 0.0625
 x3 obj -4
 x4 obj -9
 x5 obj -1
 x6 obj -1
 x7 obj -8
 x8 obj -1
 x9 obj -4
 x10 obj -1
 x11 obj -6
 x12 obj -7
 x13 obj -5
 x14 obj -4
 x15 obj -1
 x16 obj 3
 x16 r0 0.0625
 x16 r1 1.0
 x16 r3 256.0
 x16 r4 -0.00390625
 x16 r6 1.0
 x16 r7 -0.0625
 x17 obj -9
 x18 obj -4
 x19 obj -9
 x20 obj -1
 x21 obj -6
 x22 obj -4
 x23 obj -3
 x24 obj -7
 x25 obj -3
 x26 obj -6
 x27 obj -6
 x28 obj -5
 x29 obj -8
 x30 obj -4
 x31 obj -8
 x32 obj -7
 x33 obj -8
 x34 obj 0
 x34 r9 2.0
RHS
 rhs obj 1
 rhs r0 0.0625
 rhs r1 1.0
 rhs r2 -16.0
 rhs r3 256.0
 rhs r4 -0.00390625
 rhs r5 -256.0
 rhs r6 1.0
 rhs r7 -0.0625
 rhs r8 0.0625
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 4
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 4
 UP b x34 2
ENDATA
