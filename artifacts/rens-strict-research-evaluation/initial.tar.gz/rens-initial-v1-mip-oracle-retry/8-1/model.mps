NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 L r4
 L r5
 L r6
COLUMNS
 x0 obj -6
 x1 obj -5
 x2 obj -4
 x3 obj -8
 x4 obj -7
 x5 obj 2
 x5 r1 0.00390625
 x5 r2 -0.00390625
 x5 r4 0.0625
 x5 r5 0.0625
 x6 obj -9
 x7 obj 2
 x7 r0 -0.0625
 x7 r2 -0.00390625
 x7 r3 -0.0625
 x7 r5 0.0625
 x7 r6 1.0
 x8 obj -1
 x9 obj -6
 x10 obj -8
 x11 obj -2
 x12 obj -4
 x13 obj -6
 x14 obj -4
 x15 obj -3
 x16 obj 2
 x16 r0 -0.0625
 x16 r1 0.00390625
 x16 r3 -0.0625
 x16 r4 0.0625
 x17 obj -2
 x18 obj -4
 x19 obj -5
 x20 obj -7
 x21 obj -3
 x22 obj -4
 x23 obj -1
 x24 obj -2
 x25 obj -4
 x26 obj -4
 x27 obj -2
 x28 obj -8
 x29 obj 0
 x29 r6 2.0
RHS
 rhs obj 13
 rhs r0 -0.0625
 rhs r1 0.00390625
 rhs r2 -0.00390625
 rhs r3 -0.0625
 rhs r4 0.0625
 rhs r5 0.0625
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 2
 UP b x29 2
ENDATA
