NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 L r4
 G r5
 L r6
 L r7
COLUMNS
 x0 obj -5
 x1 obj -8
 x2 obj -6
 x3 obj -2
 x4 obj -9
 x5 obj -4
 x6 obj -4
 x7 obj -2
 x8 obj -9
 x9 obj -6
 x10 obj -6
 x11 obj -8
 x12 obj 9
 x12 r1 1.0
 x12 r2 -256.0
 x12 r4 0.00390625
 x12 r5 -0.0625
 x13 obj -2
 x14 obj -8
 x15 obj -1
 x16 obj -1
 x17 obj -2
 x18 obj -1
 x19 obj -1
 x20 obj 9
 x20 r0 0.00390625
 x20 r1 1.0
 x20 r3 0.0625
 x20 r4 0.00390625
 x20 r6 256.0
 x21 obj -7
 x22 obj -4
 x23 obj -9
 x24 obj -4
 x25 obj -7
 x26 obj -4
 x27 obj -3
 x28 obj -3
 x29 obj -7
 x30 obj -1
 x31 obj -7
 x32 obj 9
 x32 r0 0.00390625
 x32 r2 -256.0
 x32 r3 0.0625
 x32 r5 -0.0625
 x32 r6 256.0
 x32 r7 1.0
 x33 obj 0
 x33 r7 2.0
RHS
 rhs obj 0
 rhs r0 0.00390625
 rhs r1 1.0
 rhs r2 -256.0
 rhs r3 0.0625
 rhs r4 0.00390625
 rhs r5 -0.0625
 rhs r6 256.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 1
 UP b x33 2
ENDATA
