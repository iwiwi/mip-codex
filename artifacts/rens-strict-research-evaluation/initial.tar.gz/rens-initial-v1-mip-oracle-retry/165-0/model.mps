NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 G r3
 G r4
 L r5
 G r6
 L r7
 G r8
 L r9
 L r10
COLUMNS
 x0 obj 2
 x1 obj 3
 x2 obj -6
 x2 r1 -16.0
 x2 r2 0.0625
 x2 r4 -0.00390625
 x2 r5 0.00390625
 x2 r7 16.0
 x2 r8 -0.00390625
 x3 obj -6
 x3 r0 -16.0
 x3 r2 0.0625
 x3 r3 -256.0
 x3 r5 0.00390625
 x3 r6 -16.0
 x3 r8 -0.00390625
 x3 r9 1.0
 x3 r10 1.0
 x4 obj 3
 x5 obj 4
 x6 obj 3
 x7 obj 8
 x8 obj 6
 x9 obj 5
 x10 obj 1
 x11 obj 5
 x12 obj -6
 x12 r0 -16.0
 x12 r1 -16.0
 x12 r3 -256.0
 x12 r4 -0.00390625
 x12 r6 -16.0
 x12 r7 16.0
 x12 r9 1.0
 x13 obj 8
 x14 obj 7
 x15 obj 3
 x16 obj 9
 x17 obj 8
 x18 obj 6
 x19 obj 3
 x20 obj 9
 x21 obj 7
 x22 obj 7
 x23 obj 2
 x24 obj 5
 x25 obj 3
 x26 obj 8
 x27 obj 3
 x28 obj 0
 x28 r10 2.0
RHS
 rhs obj -24
 rhs r0 -16.0
 rhs r1 -16.0
 rhs r2 0.0625
 rhs r3 -256.0
 rhs r4 -0.00390625
 rhs r5 0.00390625
 rhs r6 -16.0
 rhs r7 16.0
 rhs r8 -0.00390625
 rhs r9 1.0
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 3
 UP b x28 2
ENDATA
