NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 L r4
 G r5
 G r6
 L r7
 L r8
 L r9
COLUMNS
 x0 obj 9
 x0 r0 256.0
 x0 r1 -0.0625
 x0 r3 16.0
 x0 r4 0.0625
 x0 r6 -256.0
 x0 r7 16.0
 x1 obj -6
 x2 obj -4
 x3 obj -5
 x4 obj -6
 x5 obj -9
 x6 obj 9
 x6 r1 -0.0625
 x6 r2 -256.0
 x6 r4 0.0625
 x6 r5 -0.00390625
 x6 r7 16.0
 x6 r8 256.0
 x7 obj -2
 x8 obj -4
 x9 obj -9
 x10 obj -6
 x11 obj -3
 x12 obj -5
 x13 obj -1
 x14 obj -2
 x15 obj -6
 x16 obj -4
 x17 obj -4
 x18 obj -1
 x19 obj -5
 x20 obj 9
 x20 r0 256.0
 x20 r2 -256.0
 x20 r3 16.0
 x20 r5 -0.00390625
 x20 r6 -256.0
 x20 r8 256.0
 x20 r9 1.0
 x21 obj -3
 x22 obj -8
 x23 obj -9
 x24 obj -3
 x25 obj -1
 x26 obj 0
 x26 r9 2.0
RHS
 rhs obj -14
 rhs r0 256.0
 rhs r1 -0.0625
 rhs r2 -256.0
 rhs r3 16.0
 rhs r4 0.0625
 rhs r5 -0.00390625
 rhs r6 -256.0
 rhs r7 16.0
 rhs r8 256.0
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 4
 UP b x26 2
ENDATA
