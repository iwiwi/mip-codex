NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
COLUMNS
 x0 obj 2
 x1 obj 8
 x2 obj 4
 x3 obj 3
 x4 obj 8
 x5 obj 7
 x6 obj 6
 x7 obj 6
 x8 obj 3
 x9 obj 3
 x10 obj -5
 x10 r0 -1.0
 x10 r2 -256.0
 x10 r3 1.0
 x11 obj 6
 x12 obj 2
 x13 obj 9
 x14 obj 9
 x15 obj 4
 x16 obj 4
 x17 obj 6
 x18 obj -5
 x18 r1 0.0625
 x18 r2 -256.0
 x19 obj 6
 x20 obj 8
 x21 obj 8
 x22 obj -5
 x22 r0 -1.0
 x22 r1 0.0625
 x23 obj 3
 x24 obj 9
 x25 obj 0
 x25 r3 2.0
RHS
 rhs obj -19
 rhs r0 -1.0
 rhs r1 0.0625
 rhs r2 -256.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 UP b x25 2
ENDATA
