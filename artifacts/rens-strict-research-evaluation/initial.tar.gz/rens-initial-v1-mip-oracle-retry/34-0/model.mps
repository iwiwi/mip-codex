NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
COLUMNS
 x0 obj 7
 x1 obj 4
 x2 obj 1
 x3 obj 6
 x4 obj -4
 x4 r0 -1.0
 x4 r2 256.0
 x4 r3 1.0
 x5 obj 5
 x6 obj 7
 x7 obj -4
 x7 r0 -1.0
 x7 r1 -16.0
 x8 obj 5
 x9 obj 5
 x10 obj 6
 x11 obj 9
 x12 obj 9
 x13 obj 4
 x14 obj 3
 x15 obj 6
 x16 obj 5
 x17 obj -4
 x17 r1 -16.0
 x17 r2 256.0
 x18 obj 6
 x19 obj 5
 x20 obj 2
 x21 obj 4
 x22 obj 5
 x23 obj 4
 x24 obj 0
 x24 r3 2.0
RHS
 rhs obj 2
 rhs r0 -1.0
 rhs r1 -16.0
 rhs r2 256.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 UP b x24 2
ENDATA
