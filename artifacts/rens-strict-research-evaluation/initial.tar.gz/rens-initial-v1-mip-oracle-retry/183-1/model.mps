NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
 G r4
 G r5
 L r6
COLUMNS
 x0 obj -8
 x1 obj -9
 x2 obj -9
 x3 obj -7
 x4 obj -7
 x5 obj 5
 x5 r0 -0.00390625
 x5 r1 -16.0
 x5 r3 256.0
 x5 r4 -1.0
 x6 obj -8
 x7 obj -3
 x8 obj -3
 x9 obj -3
 x10 obj -6
 x11 obj -1
 x12 obj -5
 x13 obj -6
 x14 obj 5
 x14 r1 -16.0
 x14 r2 -0.00390625
 x14 r4 -1.0
 x14 r5 -0.0625
 x15 obj -3
 x16 obj -4
 x17 obj -3
 x18 obj -3
 x19 obj 5
 x19 r0 -0.00390625
 x19 r2 -0.00390625
 x19 r3 256.0
 x19 r5 -0.0625
 x19 r6 1.0
 x20 obj 0
 x20 r6 2.0
RHS
 rhs obj 15
 rhs r0 -0.00390625
 rhs r1 -16.0
 rhs r2 -0.00390625
 rhs r3 256.0
 rhs r4 -1.0
 rhs r5 -0.0625
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 1
 UP b x20 2
ENDATA
