NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 G r4
 G r5
 L r6
 G r7
 L r8
 L r9
COLUMNS
 x0 obj 7
 x1 obj 3
 x2 obj 2
 x3 obj 8
 x4 obj -7
 x4 r1 16.0
 x4 r2 16.0
 x4 r4 -256.0
 x4 r5 -256.0
 x4 r7 -16.0
 x4 r8 0.0625
 x5 obj -7
 x5 r0 1.0
 x5 r1 16.0
 x5 r3 1.0
 x5 r4 -256.0
 x5 r6 0.0625
 x5 r7 -16.0
 x6 obj 6
 x7 obj 8
 x8 obj -7
 x8 r0 1.0
 x8 r2 16.0
 x8 r3 1.0
 x8 r5 -256.0
 x8 r6 0.0625
 x8 r8 0.0625
 x8 r9 1.0
 x9 obj 5
 x10 obj 1
 x11 obj 1
 x12 obj 5
 x13 obj 7
 x14 obj 3
 x15 obj 1
 x16 obj 5
 x17 obj 6
 x18 obj 4
 x19 obj 2
 x20 obj 1
 x21 obj 5
 x22 obj 2
 x23 obj 5
 x24 obj 7
 x25 obj 1
 x26 obj 0
 x26 r9 2.0
RHS
 rhs obj 9
 rhs r0 1.0
 rhs r1 16.0
 rhs r2 16.0
 rhs r3 1.0
 rhs r4 -256.0
 rhs r5 -256.0
 rhs r6 0.0625
 rhs r7 -16.0
 rhs r8 0.0625
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 2
 UP b x26 2
ENDATA
