NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 L r4
 G r5
 L r6
 L r7
 L r8
 L r9
 L r10
COLUMNS
 x0 obj 3
 x1 obj 5
 x2 obj 1
 x3 obj 7
 x4 obj 8
 x5 obj 3
 x6 obj 4
 x7 obj 6
 x8 obj 1
 x9 obj 8
 x10 obj 4
 x11 obj 8
 x12 obj -2
 x12 r0 256.0
 x12 r2 -1.0
 x12 r3 1.0
 x12 r5 -256.0
 x12 r6 1.0
 x12 r8 0.0625
 x12 r9 16.0
 x12 r10 1.0
 x13 obj 7
 x14 obj 3
 x15 obj 6
 x16 obj -2
 x16 r0 256.0
 x16 r1 0.0625
 x16 r3 1.0
 x16 r4 1.0
 x16 r6 1.0
 x16 r7 1.0
 x16 r9 16.0
 x17 obj 9
 x18 obj 8
 x19 obj 6
 x20 obj 8
 x21 obj 7
 x22 obj 3
 x23 obj 9
 x24 obj -2
 x24 r1 0.0625
 x24 r2 -1.0
 x24 r4 1.0
 x24 r5 -256.0
 x24 r7 1.0
 x24 r8 0.0625
 x25 obj 0
 x25 r10 2.0
RHS
 rhs obj 11
 rhs r0 256.0
 rhs r1 0.0625
 rhs r2 -1.0
 rhs r3 1.0
 rhs r4 1.0
 rhs r5 -256.0
 rhs r6 1.0
 rhs r7 1.0
 rhs r8 0.0625
 rhs r9 16.0
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 1
 UP b x25 2
ENDATA
