NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
 G r4
 G r5
 G r6
 L r7
 G r8
 L r9
 L r10
COLUMNS
 x0 obj 3
 x1 obj 5
 x2 obj 5
 x3 obj 4
 x4 obj 7
 x5 obj 1
 x6 obj 6
 x7 obj 9
 x8 obj 4
 x9 obj 1
 x10 obj -5
 x10 r1 -256.0
 x10 r2 256.0
 x10 r4 -0.00390625
 x10 r5 -16.0
 x10 r7 1.0
 x10 r8 -0.0625
 x11 obj 8
 x12 obj 7
 x13 obj 7
 x14 obj 8
 x15 obj -5
 x15 r0 -16.0
 x15 r1 -256.0
 x15 r3 256.0
 x15 r4 -0.00390625
 x15 r6 -1.0
 x15 r7 1.0
 x15 r9 0.00390625
 x16 obj -5
 x16 r0 -16.0
 x16 r2 256.0
 x16 r3 256.0
 x16 r5 -16.0
 x16 r6 -1.0
 x16 r8 -0.0625
 x16 r9 0.00390625
 x16 r10 1.0
 x17 obj 7
 x18 obj 0
 x18 r10 2.0
RHS
 rhs obj -16
 rhs r0 -16.0
 rhs r1 -256.0
 rhs r2 256.0
 rhs r3 256.0
 rhs r4 -0.00390625
 rhs r5 -16.0
 rhs r6 -1.0
 rhs r7 1.0
 rhs r8 -0.0625
 rhs r9 0.00390625
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 3
 UP b x18 2
ENDATA
