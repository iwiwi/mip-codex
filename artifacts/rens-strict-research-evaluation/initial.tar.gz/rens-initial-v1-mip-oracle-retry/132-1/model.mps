NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
 L r4
 L r5
 G r6
 G r7
 L r8
 G r9
 L r10
COLUMNS
 x0 obj -8
 x1 obj -5
 x2 obj 1
 x2 r0 -1.0
 x2 r1 -0.00390625
 x2 r3 1.0
 x2 r4 0.0625
 x2 r6 -0.0625
 x2 r7 -16.0
 x2 r9 -0.0625
 x3 obj -3
 x4 obj 1
 x4 r0 -1.0
 x4 r2 0.0625
 x4 r3 1.0
 x4 r5 0.0625
 x4 r6 -0.0625
 x4 r8 0.00390625
 x4 r9 -0.0625
 x4 r10 1.0
 x5 obj -4
 x6 obj -3
 x7 obj -5
 x8 obj -1
 x9 obj -9
 x10 obj -5
 x11 obj -6
 x12 obj -3
 x13 obj -2
 x14 obj -8
 x15 obj -8
 x16 obj -1
 x17 obj -5
 x18 obj 1
 x18 r1 -0.00390625
 x18 r2 0.0625
 x18 r4 0.0625
 x18 r5 0.0625
 x18 r7 -16.0
 x18 r8 0.00390625
 x19 obj -1
 x20 obj -2
 x21 obj -7
 x22 obj 0
 x22 r10 2.0
RHS
 rhs obj 1
 rhs r0 -1.0
 rhs r1 -0.00390625
 rhs r2 0.0625
 rhs r3 1.0
 rhs r4 0.0625
 rhs r5 0.0625
 rhs r6 -0.0625
 rhs r7 -16.0
 rhs r8 0.00390625
 rhs r9 -0.0625
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 UP b x22 2
ENDATA
