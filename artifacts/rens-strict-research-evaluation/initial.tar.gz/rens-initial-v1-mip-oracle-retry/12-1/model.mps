NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 L r4
COLUMNS
 x0 obj -2
 x1 obj 4
 x1 r1 0.00390625
 x1 r2 1.0
 x2 obj -2
 x3 obj -9
 x4 obj 4
 x4 r0 -0.00390625
 x4 r1 0.00390625
 x4 r3 16.0
 x5 obj -5
 x6 obj -3
 x7 obj -5
 x8 obj -8
 x9 obj -6
 x10 obj -7
 x11 obj -2
 x12 obj -1
 x13 obj -1
 x14 obj -2
 x15 obj -5
 x16 obj -5
 x17 obj 4
 x17 r0 -0.00390625
 x17 r2 1.0
 x17 r3 16.0
 x17 r4 1.0
 x18 obj -3
 x19 obj -8
 x20 obj 0
 x20 r4 2.0
RHS
 rhs obj -4
 rhs r0 -0.00390625
 rhs r1 0.00390625
 rhs r2 1.0
 rhs r3 16.0
 rhs r4 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 UP b x20 2
ENDATA
