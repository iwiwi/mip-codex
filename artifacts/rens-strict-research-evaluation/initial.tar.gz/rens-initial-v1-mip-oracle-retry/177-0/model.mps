NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 L r5
 L r6
COLUMNS
 x0 obj 3
 x1 obj 6
 x2 obj 6
 x3 obj 5
 x4 obj 2
 x5 obj 7
 x6 obj 4
 x7 obj 8
 x8 obj 4
 x9 obj 8
 x10 obj 6
 x11 obj 5
 x12 obj -7
 x12 r1 0.0625
 x12 r2 1.0
 x12 r4 -0.0625
 x12 r5 16.0
 x13 obj 4
 x14 obj 6
 x15 obj 8
 x16 obj -7
 x16 r0 256.0
 x16 r2 1.0
 x16 r3 -1.0
 x16 r5 16.0
 x16 r6 1.0
 x17 obj 8
 x18 obj 2
 x19 obj 4
 x20 obj 3
 x21 obj 3
 x22 obj 7
 x23 obj 9
 x24 obj 7
 x25 obj 9
 x26 obj 4
 x27 obj 3
 x28 obj 3
 x29 obj 2
 x30 obj 2
 x31 obj 6
 x32 obj 5
 x33 obj -7
 x33 r0 256.0
 x33 r1 0.0625
 x33 r3 -1.0
 x33 r4 -0.0625
 x34 obj 0
 x34 r6 2.0
RHS
 rhs obj -10
 rhs r0 256.0
 rhs r1 0.0625
 rhs r2 1.0
 rhs r3 -1.0
 rhs r4 -0.0625
 rhs r5 16.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 2
 LI b x33 0
 UI b x33 1
 UP b x34 2
ENDATA
