NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
 L r4
 G r5
 L r6
 L r7
 G r8
 L r9
COLUMNS
 x0 obj 2
 x0 r0 -1.0
 x0 r2 1.0
 x0 r3 256.0
 x0 r5 -256.0
 x0 r6 0.00390625
 x0 r8 -1.0
 x0 r9 1.0
 x1 obj -3
 x2 obj -1
 x3 obj -2
 x4 obj -9
 x5 obj -2
 x6 obj -8
 x7 obj 2
 x7 r0 -1.0
 x7 r1 -256.0
 x7 r3 256.0
 x7 r4 0.00390625
 x7 r6 0.00390625
 x7 r7 0.00390625
 x8 obj -2
 x9 obj -2
 x10 obj 2
 x10 r1 -256.0
 x10 r2 1.0
 x10 r4 0.00390625
 x10 r5 -256.0
 x10 r7 0.00390625
 x10 r8 -1.0
 x11 obj -3
 x12 obj -8
 x13 obj -3
 x14 obj -4
 x15 obj -4
 x16 obj -4
 x17 obj -8
 x18 obj -8
 x19 obj 0
 x19 r9 2.0
RHS
 rhs obj -5
 rhs r0 -1.0
 rhs r1 -256.0
 rhs r2 1.0
 rhs r3 256.0
 rhs r4 0.00390625
 rhs r5 -256.0
 rhs r6 0.00390625
 rhs r7 0.00390625
 rhs r8 -1.0
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 UP b x19 2
ENDATA
