NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 L r4
 L r5
 L r6
COLUMNS
 x0 obj -3
 x1 obj -1
 x2 obj -5
 x3 obj 8
 x3 r0 -256.0
 x3 r2 -1.0
 x3 r3 -16.0
 x3 r5 256.0
 x3 r6 1.0
 x4 obj -8
 x5 obj -2
 x6 obj -8
 x7 obj -9
 x8 obj -8
 x9 obj -8
 x10 obj -2
 x11 obj 8
 x11 r0 -256.0
 x11 r1 256.0
 x11 r3 -16.0
 x11 r4 16.0
 x12 obj -8
 x13 obj -2
 x14 obj -4
 x15 obj -1
 x16 obj -2
 x17 obj 8
 x17 r1 256.0
 x17 r2 -1.0
 x17 r4 16.0
 x17 r5 256.0
 x18 obj -4
 x19 obj -6
 x20 obj -2
 x21 obj -3
 x22 obj 0
 x22 r6 2.0
RHS
 rhs obj 25
 rhs r0 -256.0
 rhs r1 256.0
 rhs r2 -1.0
 rhs r3 -16.0
 rhs r4 16.0
 rhs r5 256.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 UP b x22 2
ENDATA
