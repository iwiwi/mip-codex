NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
COLUMNS
 x0 obj 6
 x1 obj 4
 x2 obj 1
 x3 obj 4
 x4 obj -8
 x4 r1 -0.00390625
 x4 r2 0.00390625
 x4 r4 1.0
 x4 r5 1.0
 x4 r7 1.0
 x4 r8 256.0
 x5 obj 9
 x6 obj 3
 x7 obj 6
 x8 obj 7
 x9 obj 3
 x10 obj 6
 x11 obj 1
 x12 obj 6
 x13 obj 1
 x14 obj 7
 x15 obj 1
 x16 obj 6
 x17 obj 9
 x18 obj 1
 x19 obj 3
 x20 obj 3
 x21 obj 7
 x22 obj 1
 x23 obj 4
 x24 obj -8
 x24 r0 1.0
 x24 r2 0.00390625
 x24 r3 -16.0
 x24 r5 1.0
 x24 r6 0.00390625
 x24 r8 256.0
 x24 r9 0.0625
 x24 r10 1.0
 x25 obj 9
 x26 obj 2
 x27 obj 7
 x28 obj -8
 x28 r0 1.0
 x28 r1 -0.00390625
 x28 r3 -16.0
 x28 r4 1.0
 x28 r6 0.00390625
 x28 r7 1.0
 x28 r9 0.0625
 x29 obj 7
 x30 obj 3
 x31 obj 1
 x32 obj 7
 x33 obj 0
 x33 r10 2.0
RHS
 rhs obj 7
 rhs r0 1.0
 rhs r1 -0.00390625
 rhs r2 0.00390625
 rhs r3 -16.0
 rhs r4 1.0
 rhs r5 1.0
 rhs r6 0.00390625
 rhs r7 1.0
 rhs r8 256.0
 rhs r9 0.0625
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 1
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 1
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 2
 LI b x31 0
 UI b x31 4
 LI b x32 0
 UI b x32 4
 UP b x33 2
ENDATA
