NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 G r4
 L r5
 G r6
 L r7
COLUMNS
 x0 obj 7
 x1 obj -5
 x1 r0 256.0
 x1 r1 0.0625
 x1 r3 16.0
 x1 r4 -16.0
 x1 r6 -16.0
 x2 obj 2
 x3 obj 1
 x4 obj 2
 x5 obj 7
 x6 obj -5
 x6 r1 0.0625
 x6 r2 0.0625
 x6 r4 -16.0
 x6 r5 16.0
 x7 obj 7
 x8 obj -5
 x8 r0 256.0
 x8 r2 0.0625
 x8 r3 16.0
 x8 r5 16.0
 x8 r6 -16.0
 x8 r7 1.0
 x9 obj 8
 x10 obj 4
 x11 obj 9
 x12 obj 1
 x13 obj 4
 x14 obj 6
 x15 obj 4
 x16 obj 8
 x17 obj 4
 x18 obj 8
 x19 obj 4
 x20 obj 0
 x20 r7 2.0
RHS
 rhs obj -27
 rhs r0 256.0
 rhs r1 0.0625
 rhs r2 0.0625
 rhs r3 16.0
 rhs r4 -16.0
 rhs r5 16.0
 rhs r6 -16.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 UP b x20 2
ENDATA
