NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 G r4
 L r5
 L r6
COLUMNS
 x0 obj 3
 x1 obj -8
 x1 r0 0.00390625
 x1 r1 -256.0
 x1 r3 -0.0625
 x1 r4 -16.0
 x2 obj 6
 x3 obj -8
 x3 r0 0.00390625
 x3 r2 256.0
 x3 r3 -0.0625
 x3 r5 1.0
 x3 r6 1.0
 x4 obj 2
 x5 obj 5
 x6 obj 2
 x7 obj 4
 x8 obj 8
 x9 obj 4
 x10 obj 9
 x11 obj 6
 x12 obj 8
 x13 obj 2
 x14 obj 4
 x15 obj 9
 x16 obj 2
 x17 obj -8
 x17 r1 -256.0
 x17 r2 256.0
 x17 r4 -16.0
 x17 r5 1.0
 x18 obj 7
 x19 obj 7
 x20 obj 5
 x21 obj 0
 x21 r6 2.0
RHS
 rhs obj -21
 rhs r0 0.00390625
 rhs r1 -256.0
 rhs r2 256.0
 rhs r3 -0.0625
 rhs r4 -16.0
 rhs r5 1.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 UP b x21 2
ENDATA
