NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 G r4
 L r5
 G r6
 L r7
 L r8
COLUMNS
 x0 obj -5
 x1 obj 3
 x1 r1 -256.0
 x1 r2 256.0
 x1 r4 -256.0
 x1 r5 16.0
 x1 r7 1.0
 x2 obj 3
 x2 r0 1.0
 x2 r1 -256.0
 x2 r3 0.00390625
 x2 r4 -256.0
 x2 r6 -0.00390625
 x2 r7 1.0
 x3 obj -2
 x4 obj -4
 x5 obj -2
 x6 obj -5
 x7 obj -9
 x8 obj -5
 x9 obj -3
 x10 obj -7
 x11 obj -5
 x12 obj -3
 x13 obj -3
 x14 obj -6
 x15 obj -1
 x16 obj -3
 x17 obj 3
 x17 r0 1.0
 x17 r2 256.0
 x17 r3 0.00390625
 x17 r5 16.0
 x17 r6 -0.00390625
 x17 r8 1.0
 x18 obj -4
 x19 obj -6
 x20 obj -1
 x21 obj -8
 x22 obj -2
 x23 obj -3
 x24 obj -4
 x25 obj 0
 x25 r8 2.0
RHS
 rhs obj -15
 rhs r0 1.0
 rhs r1 -256.0
 rhs r2 256.0
 rhs r3 0.00390625
 rhs r4 -256.0
 rhs r5 16.0
 rhs r6 -0.00390625
 rhs r7 1.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 UP b x25 2
ENDATA
