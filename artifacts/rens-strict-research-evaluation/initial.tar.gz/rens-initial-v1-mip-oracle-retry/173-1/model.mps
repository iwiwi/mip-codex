NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj -6
 x1 obj -3
 x2 obj -4
 x3 obj 3
 x3 r1 -0.00390625
 x3 r2 0.0625
 x3 r4 256.0
 x4 obj -7
 x5 obj -1
 x6 obj -4
 x7 obj -2
 x8 obj 3
 x8 r0 1.0
 x8 r2 0.0625
 x8 r3 16.0
 x8 r5 1.0
 x9 obj -9
 x10 obj -7
 x11 obj -9
 x12 obj -3
 x13 obj -4
 x14 obj -2
 x15 obj 3
 x15 r0 1.0
 x15 r1 -0.00390625
 x15 r3 16.0
 x15 r4 256.0
 x16 obj -5
 x17 obj -7
 x18 obj -1
 x19 obj -3
 x20 obj -4
 x21 obj -6
 x22 obj -5
 x23 obj -9
 x24 obj -8
 x25 obj -5
 x26 obj -6
 x27 obj -6
 x28 obj -8
 x29 obj 0
 x29 r5 2.0
RHS
 rhs obj -7
 rhs r0 1.0
 rhs r1 -0.00390625
 rhs r2 0.0625
 rhs r3 16.0
 rhs r4 256.0
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 2
 UP b x29 2
ENDATA
