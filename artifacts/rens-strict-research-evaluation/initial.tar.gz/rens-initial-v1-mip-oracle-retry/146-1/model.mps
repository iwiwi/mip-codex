NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj -3
 x1 obj -6
 x2 obj -9
 x3 obj -5
 x4 obj -6
 x5 obj -6
 x6 obj 6
 x6 r0 0.00390625
 x6 r2 256.0
 x6 r3 1.0
 x7 obj -8
 x8 obj -6
 x9 obj -7
 x10 obj -5
 x11 obj -1
 x12 obj -8
 x13 obj -4
 x14 obj -6
 x15 obj -8
 x16 obj -1
 x17 obj -9
 x18 obj -2
 x19 obj 6
 x19 r1 256.0
 x19 r2 256.0
 x20 obj -9
 x21 obj -9
 x22 obj 6
 x22 r0 0.00390625
 x22 r1 256.0
 x23 obj 0
 x23 r3 2.0
RHS
 rhs obj 19
 rhs r0 0.00390625
 rhs r1 256.0
 rhs r2 256.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 1
 UP b x23 2
ENDATA
