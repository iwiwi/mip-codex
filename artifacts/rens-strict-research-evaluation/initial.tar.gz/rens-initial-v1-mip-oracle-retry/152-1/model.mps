NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 L r4
 L r5
 L r6
 L r7
 G r8
 L r9
COLUMNS
 x0 obj -1
 x1 obj -4
 x2 obj -2
 x3 obj -7
 x4 obj -8
 x5 obj 8
 x5 r0 0.0625
 x5 r2 -0.00390625
 x5 r3 0.0625
 x5 r5 0.00390625
 x5 r6 16.0
 x5 r8 -1.0
 x5 r9 1.0
 x6 obj -7
 x7 obj -1
 x8 obj -3
 x9 obj -2
 x10 obj 8
 x10 r0 0.0625
 x10 r1 -0.00390625
 x10 r3 0.0625
 x10 r4 16.0
 x10 r6 16.0
 x10 r7 1.0
 x11 obj -7
 x12 obj -2
 x13 obj -1
 x14 obj -8
 x15 obj -4
 x16 obj 8
 x16 r1 -0.00390625
 x16 r2 -0.00390625
 x16 r4 16.0
 x16 r5 0.00390625
 x16 r7 1.0
 x16 r8 -1.0
 x17 obj -3
 x18 obj 0
 x18 r9 2.0
RHS
 rhs obj 14
 rhs r0 0.0625
 rhs r1 -0.00390625
 rhs r2 -0.00390625
 rhs r3 0.0625
 rhs r4 16.0
 rhs r5 0.00390625
 rhs r6 16.0
 rhs r7 1.0
 rhs r8 -1.0
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 3
 UP b x18 2
ENDATA
