NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 G r3
 L r4
 L r5
COLUMNS
 x0 obj 2
 x1 obj -8
 x1 r0 16.0
 x1 r1 -0.0625
 x1 r3 -0.00390625
 x1 r4 256.0
 x2 obj 6
 x3 obj 2
 x4 obj 6
 x5 obj 9
 x6 obj 5
 x7 obj 2
 x8 obj 1
 x9 obj 1
 x10 obj -8
 x10 r1 -0.0625
 x10 r2 -256.0
 x10 r4 256.0
 x11 obj 7
 x12 obj 2
 x13 obj 8
 x14 obj 9
 x15 obj 9
 x16 obj 7
 x17 obj 4
 x18 obj 8
 x19 obj 9
 x20 obj -8
 x20 r0 16.0
 x20 r2 -256.0
 x20 r3 -0.00390625
 x20 r5 1.0
 x21 obj 4
 x22 obj 7
 x23 obj 2
 x24 obj 0
 x24 r5 2.0
RHS
 rhs obj 8
 rhs r0 16.0
 rhs r1 -0.0625
 rhs r2 -256.0
 rhs r3 -0.00390625
 rhs r4 256.0
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 UP b x24 2
ENDATA
