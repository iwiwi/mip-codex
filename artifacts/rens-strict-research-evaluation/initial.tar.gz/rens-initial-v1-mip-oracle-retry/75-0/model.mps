NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 G r4
 G r5
 L r6
 G r7
 L r8
 L r9
COLUMNS
 x0 obj 5
 x1 obj 5
 x2 obj 3
 x3 obj 2
 x4 obj 4
 x5 obj 8
 x6 obj 7
 x7 obj -8
 x7 r0 -0.0625
 x7 r2 256.0
 x7 r3 -1.0
 x7 r5 -256.0
 x7 r6 0.00390625
 x7 r8 0.00390625
 x7 r9 1.0
 x8 obj 4
 x9 obj 3
 x10 obj -8
 x10 r1 256.0
 x10 r2 256.0
 x10 r4 -16.0
 x10 r5 -256.0
 x10 r7 -16.0
 x10 r8 0.00390625
 x11 obj 7
 x12 obj 1
 x13 obj 6
 x14 obj 8
 x15 obj 7
 x16 obj 5
 x17 obj 8
 x18 obj 9
 x19 obj 9
 x20 obj 8
 x21 obj 9
 x22 obj 9
 x23 obj 4
 x24 obj -8
 x24 r0 -0.0625
 x24 r1 256.0
 x24 r3 -1.0
 x24 r4 -16.0
 x24 r6 0.00390625
 x24 r7 -16.0
 x25 obj 7
 x26 obj 0
 x26 r9 2.0
RHS
 rhs obj -23
 rhs r0 -0.0625
 rhs r1 256.0
 rhs r2 256.0
 rhs r3 -1.0
 rhs r4 -16.0
 rhs r5 -256.0
 rhs r6 0.00390625
 rhs r7 -16.0
 rhs r8 0.00390625
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 1
 LI b x25 0
 UI b x25 3
 UP b x26 2
ENDATA
