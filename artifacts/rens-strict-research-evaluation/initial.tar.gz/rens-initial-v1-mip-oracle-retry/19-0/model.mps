NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 L r4
COLUMNS
 x0 obj 3
 x1 obj 7
 x2 obj 6
 x3 obj -9
 x3 r1 256.0
 x3 r2 -0.0625
 x4 obj 8
 x5 obj 2
 x6 obj 2
 x7 obj 5
 x8 obj 4
 x9 obj 6
 x10 obj 3
 x11 obj 1
 x12 obj 8
 x13 obj 8
 x14 obj -9
 x14 r0 0.0625
 x14 r1 256.0
 x14 r3 -16.0
 x15 obj 3
 x16 obj 7
 x17 obj -9
 x17 r0 0.0625
 x17 r2 -0.0625
 x17 r3 -16.0
 x17 r4 1.0
 x18 obj 1
 x19 obj 8
 x20 obj 4
 x21 obj 6
 x22 obj 0
 x22 r4 2.0
RHS
 rhs obj 28
 rhs r0 0.0625
 rhs r1 256.0
 rhs r2 -0.0625
 rhs r3 -16.0
 rhs r4 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 UP b x22 2
ENDATA
