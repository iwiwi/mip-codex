NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 G r3
 G r4
 L r5
 L r6
 L r7
COLUMNS
 x0 obj 2
 x1 obj 6
 x2 obj 2
 x3 obj 9
 x4 obj -6
 x4 r0 256.0
 x4 r2 -1.0
 x4 r3 -16.0
 x4 r5 0.00390625
 x4 r6 256.0
 x4 r7 1.0
 x5 obj 4
 x6 obj 4
 x7 obj 7
 x8 obj -6
 x8 r1 -256.0
 x8 r2 -1.0
 x8 r4 -16.0
 x8 r5 0.00390625
 x9 obj 6
 x10 obj -6
 x10 r0 256.0
 x10 r1 -256.0
 x10 r3 -16.0
 x10 r4 -16.0
 x10 r6 256.0
 x11 obj 6
 x12 obj 3
 x13 obj 2
 x14 obj 4
 x15 obj 9
 x16 obj 6
 x17 obj 3
 x18 obj 3
 x19 obj 9
 x20 obj 8
 x21 obj 6
 x22 obj 6
 x23 obj 3
 x24 obj 0
 x24 r7 2.0
RHS
 rhs obj -10
 rhs r0 256.0
 rhs r1 -256.0
 rhs r2 -1.0
 rhs r3 -16.0
 rhs r4 -16.0
 rhs r5 0.00390625
 rhs r6 256.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 UP b x24 2
ENDATA
