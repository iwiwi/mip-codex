NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 G r4
 L r5
COLUMNS
 x0 obj 6
 x1 obj 6
 x2 obj 1
 x3 obj 3
 x4 obj 5
 x5 obj 9
 x6 obj 9
 x7 obj 7
 x8 obj 5
 x9 obj 9
 x10 obj 1
 x11 obj 8
 x12 obj -3
 x12 r1 0.00390625
 x12 r2 0.0625
 x12 r4 -0.00390625
 x13 obj 1
 x14 obj -3
 x14 r0 -16.0
 x14 r1 0.00390625
 x14 r3 16.0
 x14 r4 -0.00390625
 x15 obj 7
 x16 obj 6
 x17 obj 7
 x18 obj 2
 x19 obj 7
 x20 obj -3
 x20 r0 -16.0
 x20 r2 0.0625
 x20 r3 16.0
 x20 r5 1.0
 x21 obj 6
 x22 obj 6
 x23 obj 7
 x24 obj 0
 x24 r5 2.0
RHS
 rhs obj -20
 rhs r0 -16.0
 rhs r1 0.00390625
 rhs r2 0.0625
 rhs r3 16.0
 rhs r4 -0.00390625
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 UP b x24 2
ENDATA
