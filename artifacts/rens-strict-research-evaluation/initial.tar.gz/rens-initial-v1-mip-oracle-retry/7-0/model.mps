NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
COLUMNS
 x0 obj 4
 x1 obj 7
 x2 obj 3
 x3 obj 8
 x4 obj 3
 x5 obj 4
 x6 obj 3
 x7 obj 1
 x8 obj 8
 x9 obj 9
 x10 obj -5
 x10 r0 -1.0
 x10 r2 16.0
 x10 r3 1.0
 x11 obj 7
 x12 obj 6
 x13 obj 7
 x14 obj 9
 x15 obj -5
 x15 r0 -1.0
 x15 r1 -1.0
 x16 obj 7
 x17 obj 1
 x18 obj 3
 x19 obj 5
 x20 obj -5
 x20 r1 -1.0
 x20 r2 16.0
 x21 obj 2
 x22 obj 4
 x23 obj 2
 x24 obj 1
 x25 obj 2
 x26 obj 3
 x27 obj 3
 x28 obj 0
 x28 r3 2.0
RHS
 rhs obj -10
 rhs r0 -1.0
 rhs r1 -1.0
 rhs r2 16.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 UP b x28 2
ENDATA
