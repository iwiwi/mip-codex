NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 G r4
 L r5
COLUMNS
 x0 obj -4
 x1 obj 5
 x1 r0 -16.0
 x1 r1 16.0
 x1 r3 1.0
 x1 r4 -0.00390625
 x2 obj -3
 x3 obj -1
 x4 obj -6
 x5 obj -5
 x6 obj -9
 x7 obj -5
 x8 obj -1
 x9 obj -2
 x10 obj -4
 x11 obj -2
 x12 obj -6
 x13 obj -2
 x14 obj -7
 x15 obj -3
 x16 obj -5
 x17 obj -6
 x18 obj -3
 x19 obj -2
 x20 obj -1
 x21 obj -8
 x22 obj 5
 x22 r0 -16.0
 x22 r2 -256.0
 x22 r3 1.0
 x22 r5 1.0
 x23 obj -4
 x24 obj -9
 x25 obj -3
 x26 obj 5
 x26 r1 16.0
 x26 r2 -256.0
 x26 r4 -0.00390625
 x27 obj -7
 x28 obj -3
 x29 obj 0
 x29 r5 2.0
RHS
 rhs obj -27
 rhs r0 -16.0
 rhs r1 16.0
 rhs r2 -256.0
 rhs r3 1.0
 rhs r4 -0.00390625
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 1
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 3
 UP b x29 2
ENDATA
