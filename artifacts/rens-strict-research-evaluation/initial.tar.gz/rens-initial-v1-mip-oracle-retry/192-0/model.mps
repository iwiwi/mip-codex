NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 L r4
 L r5
 G r6
 G r7
 L r8
COLUMNS
 x0 obj 4
 x1 obj 8
 x2 obj 7
 x3 obj 9
 x4 obj 6
 x5 obj 6
 x6 obj 9
 x7 obj 1
 x8 obj 6
 x9 obj -5
 x9 r0 -256.0
 x9 r2 0.00390625
 x9 r3 -0.00390625
 x9 r5 1.0
 x9 r6 -16.0
 x9 r8 1.0
 x10 obj -5
 x10 r0 -256.0
 x10 r1 0.0625
 x10 r3 -0.00390625
 x10 r4 256.0
 x10 r6 -16.0
 x10 r7 -16.0
 x11 obj 1
 x12 obj 5
 x13 obj 8
 x14 obj 2
 x15 obj 3
 x16 obj 9
 x17 obj 9
 x18 obj 4
 x19 obj 6
 x20 obj 1
 x21 obj -5
 x21 r1 0.0625
 x21 r2 0.00390625
 x21 r4 256.0
 x21 r5 1.0
 x21 r7 -16.0
 x22 obj 6
 x23 obj 8
 x24 obj 2
 x25 obj 0
 x25 r8 2.0
RHS
 rhs obj 6
 rhs r0 -256.0
 rhs r1 0.0625
 rhs r2 0.00390625
 rhs r3 -0.00390625
 rhs r4 256.0
 rhs r5 1.0
 rhs r6 -16.0
 rhs r7 -16.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 UP b x25 2
ENDATA
