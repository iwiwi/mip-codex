NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 L r4
 L r5
 L r6
COLUMNS
 x0 obj 3
 x1 obj 7
 x2 obj 1
 x3 obj 7
 x4 obj -3
 x4 r1 16.0
 x4 r2 -0.00390625
 x4 r4 1.0
 x4 r5 16.0
 x5 obj 8
 x6 obj 2
 x7 obj 6
 x8 obj -3
 x8 r0 -256.0
 x8 r1 16.0
 x8 r3 16.0
 x8 r4 1.0
 x9 obj 5
 x10 obj 5
 x11 obj 8
 x12 obj -3
 x12 r0 -256.0
 x12 r2 -0.00390625
 x12 r3 16.0
 x12 r5 16.0
 x12 r6 1.0
 x13 obj 2
 x14 obj 5
 x15 obj 7
 x16 obj 9
 x17 obj 8
 x18 obj 9
 x19 obj 1
 x20 obj 3
 x21 obj 5
 x22 obj 1
 x23 obj 3
 x24 obj 2
 x25 obj 8
 x26 obj 8
 x27 obj 9
 x28 obj 5
 x29 obj 7
 x30 obj 9
 x31 obj 3
 x32 obj 8
 x33 obj 5
 x34 obj 0
 x34 r6 2.0
RHS
 rhs obj 14
 rhs r0 -256.0
 rhs r1 16.0
 rhs r2 -0.00390625
 rhs r3 16.0
 rhs r4 1.0
 rhs r5 16.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 4
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 2
 UP b x34 2
ENDATA
