NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 L r5
 G r6
 L r7
COLUMNS
 x0 obj -2
 x1 obj -3
 x2 obj -1
 x3 obj -2
 x4 obj -1
 x5 obj -1
 x6 obj -1
 x7 obj -1
 x8 obj 2
 x8 r0 0.0625
 x8 r1 0.00390625
 x8 r3 -16.0
 x8 r4 -0.00390625
 x8 r6 -16.0
 x9 obj -6
 x10 obj -3
 x11 obj -5
 x12 obj -3
 x13 obj -5
 x14 obj -8
 x15 obj -3
 x16 obj -1
 x17 obj -3
 x18 obj -7
 x19 obj 2
 x19 r1 0.00390625
 x19 r2 0.00390625
 x19 r4 -0.00390625
 x19 r5 256.0
 x20 obj -5
 x21 obj -1
 x22 obj -7
 x23 obj -6
 x24 obj -1
 x25 obj 2
 x25 r0 0.0625
 x25 r2 0.00390625
 x25 r3 -16.0
 x25 r5 256.0
 x25 r6 -16.0
 x25 r7 1.0
 x26 obj -3
 x27 obj -1
 x28 obj 0
 x28 r7 2.0
RHS
 rhs obj 22
 rhs r0 0.0625
 rhs r1 0.00390625
 rhs r2 0.00390625
 rhs r3 -16.0
 rhs r4 -0.00390625
 rhs r5 256.0
 rhs r6 -16.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 1
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 3
 UP b x28 2
ENDATA
