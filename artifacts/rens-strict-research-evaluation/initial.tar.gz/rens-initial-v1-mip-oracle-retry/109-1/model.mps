NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 L r4
 G r5
 G r6
 L r7
COLUMNS
 x0 obj -9
 x1 obj -7
 x2 obj -6
 x3 obj -3
 x4 obj -7
 x5 obj -3
 x6 obj -1
 x7 obj -3
 x8 obj -9
 x9 obj -5
 x10 obj -1
 x11 obj -7
 x12 obj -6
 x13 obj -5
 x14 obj -6
 x15 obj -3
 x16 obj -8
 x17 obj -5
 x18 obj 7
 x18 r1 1.0
 x18 r2 -16.0
 x18 r4 16.0
 x18 r5 -0.00390625
 x19 obj -5
 x20 obj -6
 x21 obj -3
 x22 obj -4
 x23 obj -5
 x24 obj -7
 x25 obj 7
 x25 r0 -1.0
 x25 r2 -16.0
 x25 r3 256.0
 x25 r5 -0.00390625
 x25 r6 -256.0
 x25 r7 1.0
 x26 obj 7
 x26 r0 -1.0
 x26 r1 1.0
 x26 r3 256.0
 x26 r4 16.0
 x26 r6 -256.0
 x27 obj -5
 x28 obj -4
 x29 obj -6
 x30 obj -6
 x31 obj -7
 x32 obj -8
 x33 obj -1
 x34 obj 0
 x34 r7 2.0
RHS
 rhs obj -18
 rhs r0 -1.0
 rhs r1 1.0
 rhs r2 -16.0
 rhs r3 256.0
 rhs r4 16.0
 rhs r5 -0.00390625
 rhs r6 -256.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 1
 LI b x26 0
 UI b x26 1
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 2
 UP b x34 2
ENDATA
