NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 G r4
 L r5
COLUMNS
 x0 obj -3
 x1 obj -3
 x2 obj -4
 x3 obj -6
 x4 obj -1
 x5 obj -3
 x6 obj -5
 x7 obj -7
 x8 obj -9
 x9 obj -5
 x10 obj 5
 x10 r1 1.0
 x10 r2 -0.00390625
 x10 r4 -16.0
 x11 obj -5
 x12 obj 5
 x12 r0 0.00390625
 x12 r2 -0.00390625
 x12 r3 -256.0
 x12 r5 1.0
 x13 obj -3
 x14 obj -4
 x15 obj -5
 x16 obj 5
 x16 r0 0.00390625
 x16 r1 1.0
 x16 r3 -256.0
 x16 r4 -16.0
 x17 obj -8
 x18 obj -6
 x19 obj -4
 x20 obj -5
 x21 obj -1
 x22 obj -3
 x23 obj -7
 x24 obj -6
 x25 obj -9
 x26 obj 0
 x26 r5 2.0
RHS
 rhs obj -27
 rhs r0 0.00390625
 rhs r1 1.0
 rhs r2 -0.00390625
 rhs r3 -256.0
 rhs r4 -16.0
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 UP b x26 2
ENDATA
