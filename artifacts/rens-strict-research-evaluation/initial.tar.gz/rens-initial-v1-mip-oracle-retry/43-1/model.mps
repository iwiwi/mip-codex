NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
COLUMNS
 x0 obj -1
 x1 obj -6
 x2 obj -5
 x3 obj -3
 x4 obj -2
 x5 obj 7
 x5 r1 0.0625
 x5 r2 16.0
 x5 r4 0.00390625
 x5 r5 0.0625
 x5 r7 0.0625
 x5 r8 256.0
 x6 obj -3
 x7 obj -8
 x8 obj -2
 x9 obj -1
 x10 obj -7
 x11 obj -4
 x12 obj -1
 x13 obj -4
 x14 obj -4
 x15 obj -9
 x16 obj -4
 x17 obj -5
 x18 obj -7
 x19 obj -1
 x20 obj -8
 x21 obj -6
 x22 obj -3
 x23 obj -7
 x24 obj -4
 x25 obj -2
 x26 obj -5
 x27 obj -3
 x28 obj -7
 x29 obj 7
 x29 r0 -0.0625
 x29 r2 16.0
 x29 r3 -0.0625
 x29 r5 0.0625
 x29 r6 0.00390625
 x29 r8 256.0
 x29 r9 1.0
 x30 obj -6
 x31 obj 7
 x31 r0 -0.0625
 x31 r1 0.0625
 x31 r3 -0.0625
 x31 r4 0.00390625
 x31 r6 0.00390625
 x31 r7 0.0625
 x32 obj -4
 x33 obj -7
 x34 obj 0
 x34 r9 2.0
RHS
 rhs obj -21
 rhs r0 -0.0625
 rhs r1 0.0625
 rhs r2 16.0
 rhs r3 -0.0625
 rhs r4 0.00390625
 rhs r5 0.0625
 rhs r6 0.00390625
 rhs r7 0.0625
 rhs r8 256.0
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 1
 LI b x30 0
 UI b x30 2
 LI b x31 0
 UI b x31 1
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 3
 UP b x34 2
ENDATA
