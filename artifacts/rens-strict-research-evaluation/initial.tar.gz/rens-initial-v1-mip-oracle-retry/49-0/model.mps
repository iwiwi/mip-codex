NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
COLUMNS
 x0 obj 9
 x1 obj 3
 x2 obj 1
 x3 obj 2
 x4 obj 7
 x5 obj 7
 x6 obj 4
 x7 obj 6
 x8 obj 2
 x9 obj -4
 x9 r1 -1.0
 x9 r2 -16.0
 x10 obj 4
 x11 obj 1
 x12 obj 1
 x13 obj 1
 x14 obj -4
 x14 r0 16.0
 x14 r1 -1.0
 x15 obj 1
 x16 obj -4
 x16 r0 16.0
 x16 r2 -16.0
 x16 r3 1.0
 x17 obj 5
 x18 obj 9
 x19 obj 2
 x20 obj 3
 x21 obj 7
 x22 obj 1
 x23 obj 9
 x24 obj 0
 x24 r3 2.0
RHS
 rhs obj -3
 rhs r0 16.0
 rhs r1 -1.0
 rhs r2 -16.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 UP b x24 2
ENDATA
