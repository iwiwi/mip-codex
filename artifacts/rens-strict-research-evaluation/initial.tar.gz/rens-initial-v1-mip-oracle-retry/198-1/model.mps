NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 L r4
COLUMNS
 x0 obj -3
 x1 obj -7
 x2 obj -3
 x3 obj -3
 x4 obj -4
 x5 obj -1
 x6 obj 1
 x6 r1 -256.0
 x6 r2 0.0625
 x7 obj -7
 x8 obj -9
 x9 obj -1
 x10 obj -9
 x11 obj -9
 x12 obj -8
 x13 obj -5
 x14 obj 1
 x14 r0 16.0
 x14 r2 0.0625
 x14 r3 256.0
 x14 r4 1.0
 x15 obj -6
 x16 obj 1
 x16 r0 16.0
 x16 r1 -256.0
 x16 r3 256.0
 x17 obj -4
 x18 obj -6
 x19 obj 0
 x19 r4 2.0
RHS
 rhs obj -6
 rhs r0 16.0
 rhs r1 -256.0
 rhs r2 0.0625
 rhs r3 256.0
 rhs r4 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 UP b x19 2
ENDATA
