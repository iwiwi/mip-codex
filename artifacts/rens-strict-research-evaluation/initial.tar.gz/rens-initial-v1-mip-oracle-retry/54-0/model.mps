NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 G r3
 G r4
 G r5
 L r6
 L r7
 L r8
COLUMNS
 x0 obj 2
 x1 obj 6
 x2 obj 6
 x3 obj 3
 x4 obj 4
 x5 obj 3
 x6 obj -6
 x6 r0 -0.0625
 x6 r2 16.0
 x6 r3 -0.0625
 x6 r5 -16.0
 x6 r6 1.0
 x6 r8 1.0
 x7 obj 2
 x8 obj 3
 x9 obj 1
 x10 obj 8
 x11 obj 4
 x12 obj -6
 x12 r1 -0.0625
 x12 r2 16.0
 x12 r4 -16.0
 x12 r5 -16.0
 x12 r7 0.0625
 x13 obj 8
 x14 obj 5
 x15 obj 6
 x16 obj 3
 x17 obj 5
 x18 obj 2
 x19 obj 3
 x20 obj 7
 x21 obj 5
 x22 obj -6
 x22 r0 -0.0625
 x22 r1 -0.0625
 x22 r3 -0.0625
 x22 r4 -16.0
 x22 r6 1.0
 x22 r7 0.0625
 x23 obj 1
 x24 obj 0
 x24 r8 2.0
RHS
 rhs obj -23
 rhs r0 -0.0625
 rhs r1 -0.0625
 rhs r2 16.0
 rhs r3 -0.0625
 rhs r4 -16.0
 rhs r5 -16.0
 rhs r6 1.0
 rhs r7 0.0625
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 2
 UP b x24 2
ENDATA
