NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj 9
 x1 obj 8
 x2 obj 1
 x3 obj 4
 x4 obj 5
 x5 obj 7
 x6 obj 2
 x7 obj 4
 x8 obj -9
 x8 r0 16.0
 x8 r1 -0.0625
 x8 r3 16.0
 x8 r4 1.0
 x9 obj 9
 x10 obj 9
 x11 obj 6
 x12 obj 9
 x13 obj 7
 x14 obj -9
 x14 r1 -0.0625
 x14 r2 1.0
 x14 r4 1.0
 x15 obj -9
 x15 r0 16.0
 x15 r2 1.0
 x15 r3 16.0
 x15 r5 1.0
 x16 obj 5
 x17 obj 9
 x18 obj 9
 x19 obj 7
 x20 obj 8
 x21 obj 9
 x22 obj 9
 x23 obj 0
 x23 r5 2.0
RHS
 rhs obj -10
 rhs r0 16.0
 rhs r1 -0.0625
 rhs r2 1.0
 rhs r3 16.0
 rhs r4 1.0
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 UP b x23 2
ENDATA
