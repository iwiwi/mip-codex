NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 G r4
 L r5
 L r6
COLUMNS
 x0 obj 4
 x1 obj 8
 x2 obj 3
 x3 obj 7
 x4 obj 8
 x5 obj 6
 x6 obj -3
 x6 r0 -1.0
 x6 r1 16.0
 x6 r3 -256.0
 x6 r4 -0.0625
 x7 obj 8
 x8 obj 8
 x9 obj 5
 x10 obj 6
 x11 obj -3
 x11 r0 -1.0
 x11 r2 16.0
 x11 r3 -256.0
 x11 r5 16.0
 x11 r6 1.0
 x12 obj 5
 x13 obj -3
 x13 r1 16.0
 x13 r2 16.0
 x13 r4 -0.0625
 x13 r5 16.0
 x14 obj 7
 x15 obj 1
 x16 obj 2
 x17 obj 4
 x18 obj 7
 x19 obj 8
 x20 obj 4
 x21 obj 0
 x21 r6 2.0
RHS
 rhs obj -9
 rhs r0 -1.0
 rhs r1 16.0
 rhs r2 16.0
 rhs r3 -256.0
 rhs r4 -0.0625
 rhs r5 16.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 UP b x21 2
ENDATA
