NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 G r5
 G r6
 G r7
 L r8
 G r9
 L r10
COLUMNS
 x0 obj -1
 x1 obj -2
 x2 obj -7
 x3 obj -4
 x4 obj -7
 x5 obj -8
 x6 obj -8
 x7 obj -7
 x8 obj -1
 x9 obj 9
 x9 r1 0.00390625
 x9 r2 0.0625
 x9 r4 0.00390625
 x9 r5 -0.00390625
 x9 r7 -16.0
 x9 r8 1.0
 x10 obj -9
 x11 obj -8
 x12 obj -5
 x13 obj -3
 x14 obj -2
 x15 obj 9
 x15 r0 0.0625
 x15 r2 0.0625
 x15 r3 256.0
 x15 r5 -0.00390625
 x15 r6 -0.0625
 x15 r8 1.0
 x15 r9 -0.0625
 x15 r10 1.0
 x16 obj 9
 x16 r0 0.0625
 x16 r1 0.00390625
 x16 r3 256.0
 x16 r4 0.00390625
 x16 r6 -0.0625
 x16 r7 -16.0
 x16 r9 -0.0625
 x17 obj -7
 x18 obj -4
 x19 obj -4
 x20 obj -1
 x21 obj -2
 x22 obj 0
 x22 r10 2.0
RHS
 rhs obj -26
 rhs r0 0.0625
 rhs r1 0.00390625
 rhs r2 0.0625
 rhs r3 256.0
 rhs r4 0.00390625
 rhs r5 -0.00390625
 rhs r6 -0.0625
 rhs r7 -16.0
 rhs r8 1.0
 rhs r9 -0.0625
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 UP b x22 2
ENDATA
