NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
COLUMNS
 x0 obj -8
 x1 obj -8
 x2 obj -8
 x3 obj -9
 x4 obj 4
 x4 r0 -256.0
 x4 r2 -256.0
 x4 r3 1.0
 x5 obj 4
 x5 r0 -256.0
 x5 r1 -16.0
 x6 obj -2
 x7 obj -1
 x8 obj -8
 x9 obj -2
 x10 obj -6
 x11 obj -4
 x12 obj -1
 x13 obj -9
 x14 obj -8
 x15 obj -9
 x16 obj -5
 x17 obj -6
 x18 obj 4
 x18 r1 -16.0
 x18 r2 -256.0
 x19 obj -2
 x20 obj -3
 x21 obj -2
 x22 obj -2
 x23 obj 0
 x23 r3 2.0
RHS
 rhs obj -2
 rhs r0 -256.0
 rhs r1 -16.0
 rhs r2 -256.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 UP b x23 2
ENDATA
