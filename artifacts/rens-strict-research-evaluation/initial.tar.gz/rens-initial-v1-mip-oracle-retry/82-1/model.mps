NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 L r4
 G r5
 G r6
 G r7
 L r8
COLUMNS
 x0 obj -3
 x1 obj -5
 x2 obj -5
 x3 obj -2
 x4 obj 5
 x4 r1 0.00390625
 x4 r2 -16.0
 x4 r4 16.0
 x4 r5 -1.0
 x4 r7 -16.0
 x5 obj 5
 x5 r0 0.0625
 x5 r1 0.00390625
 x5 r3 -0.0625
 x5 r4 16.0
 x5 r6 -16.0
 x5 r7 -16.0
 x6 obj -1
 x7 obj -3
 x8 obj -5
 x9 obj -6
 x10 obj -3
 x11 obj -1
 x12 obj -4
 x13 obj -8
 x14 obj -4
 x15 obj 5
 x15 r0 0.0625
 x15 r2 -16.0
 x15 r3 -0.0625
 x15 r5 -1.0
 x15 r6 -16.0
 x15 r8 1.0
 x16 obj -2
 x17 obj -5
 x18 obj -9
 x19 obj 0
 x19 r8 2.0
RHS
 rhs obj 27
 rhs r0 0.0625
 rhs r1 0.00390625
 rhs r2 -16.0
 rhs r3 -0.0625
 rhs r4 16.0
 rhs r5 -1.0
 rhs r6 -16.0
 rhs r7 -16.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 UP b x19 2
ENDATA
