NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
COLUMNS
 x0 obj 5
 x1 obj 8
 x2 obj 2
 x3 obj 4
 x4 obj 5
 x5 obj 9
 x6 obj 1
 x7 obj 2
 x8 obj 6
 x9 obj 6
 x10 obj 4
 x11 obj 7
 x12 obj -6
 x12 r1 -0.0625
 x12 r2 0.00390625
 x13 obj 3
 x14 obj 2
 x15 obj 3
 x16 obj 8
 x17 obj 4
 x18 obj 5
 x19 obj 8
 x20 obj 8
 x21 obj 9
 x22 obj 5
 x23 obj 8
 x24 obj 6
 x25 obj -6
 x25 r0 1.0
 x25 r1 -0.0625
 x26 obj -6
 x26 r0 1.0
 x26 r2 0.00390625
 x26 r3 1.0
 x27 obj 8
 x28 obj 2
 x29 obj 8
 x30 obj 7
 x31 obj 0
 x31 r3 2.0
RHS
 rhs obj -21
 rhs r0 1.0
 rhs r1 -0.0625
 rhs r2 0.00390625
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 1
 LI b x26 0
 UI b x26 1
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 4
 UP b x31 2
ENDATA
