NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
 G r4
 L r5
 L r6
COLUMNS
 x0 obj -6
 x1 obj 7
 x1 r0 -1.0
 x1 r1 -0.00390625
 x1 r3 1.0
 x1 r4 -256.0
 x2 obj -4
 x3 obj -7
 x4 obj -5
 x5 obj -7
 x6 obj -4
 x7 obj -5
 x8 obj -8
 x9 obj 7
 x9 r0 -1.0
 x9 r2 -0.0625
 x9 r3 1.0
 x9 r5 256.0
 x9 r6 1.0
 x10 obj -2
 x11 obj -5
 x12 obj -1
 x13 obj -8
 x14 obj -3
 x15 obj -3
 x16 obj 7
 x16 r1 -0.00390625
 x16 r2 -0.0625
 x16 r4 -256.0
 x16 r5 256.0
 x17 obj -7
 x18 obj -5
 x19 obj -2
 x20 obj -3
 x21 obj 0
 x21 r6 2.0
RHS
 rhs obj 5
 rhs r0 -1.0
 rhs r1 -0.00390625
 rhs r2 -0.0625
 rhs r3 1.0
 rhs r4 -256.0
 rhs r5 256.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 UP b x21 2
ENDATA
