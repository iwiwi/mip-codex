NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
COLUMNS
 x0 obj -2
 x0 r1 256.0
 x0 r2 -16.0
 x1 obj 1
 x2 obj 2
 x3 obj 5
 x4 obj 7
 x5 obj 3
 x6 obj 5
 x7 obj 4
 x8 obj 2
 x9 obj 9
 x10 obj 1
 x11 obj -2
 x11 r0 -0.00390625
 x11 r1 256.0
 x12 obj 9
 x13 obj 2
 x14 obj 9
 x15 obj 3
 x16 obj 9
 x17 obj 7
 x18 obj 4
 x19 obj 3
 x20 obj 4
 x21 obj 3
 x22 obj 3
 x23 obj 6
 x24 obj 4
 x25 obj 8
 x26 obj 9
 x27 obj 4
 x28 obj 6
 x29 obj -2
 x29 r0 -0.00390625
 x29 r2 -16.0
 x29 r3 1.0
 x30 obj 3
 x31 obj 9
 x32 obj 0
 x32 r3 2.0
RHS
 rhs obj -18
 rhs r0 -0.00390625
 rhs r1 256.0
 rhs r2 -16.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 1
 LI b x30 0
 UI b x30 2
 LI b x31 0
 UI b x31 4
 UP b x32 2
ENDATA
