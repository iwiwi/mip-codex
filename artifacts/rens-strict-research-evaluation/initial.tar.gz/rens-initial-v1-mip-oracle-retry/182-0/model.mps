NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 L r4
 L r5
 G r6
 L r7
COLUMNS
 x0 obj 5
 x1 obj 7
 x2 obj 3
 x3 obj 7
 x4 obj 5
 x5 obj 4
 x6 obj -9
 x6 r0 -1.0
 x6 r2 256.0
 x6 r3 -0.0625
 x6 r5 0.0625
 x6 r6 -0.0625
 x6 r7 1.0
 x7 obj 1
 x8 obj 8
 x9 obj 8
 x10 obj 6
 x11 obj -9
 x11 r0 -1.0
 x11 r1 1.0
 x11 r3 -0.0625
 x11 r4 256.0
 x11 r6 -0.0625
 x12 obj 7
 x13 obj 1
 x14 obj 5
 x15 obj 8
 x16 obj 7
 x17 obj 6
 x18 obj 8
 x19 obj 4
 x20 obj -9
 x20 r1 1.0
 x20 r2 256.0
 x20 r4 256.0
 x20 r5 0.0625
 x21 obj 3
 x22 obj 7
 x23 obj 0
 x23 r7 2.0
RHS
 rhs obj 23
 rhs r0 -1.0
 rhs r1 1.0
 rhs r2 256.0
 rhs r3 -0.0625
 rhs r4 256.0
 rhs r5 0.0625
 rhs r6 -0.0625
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 UP b x23 2
ENDATA
