NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 L r4
 G r5
 G r6
 G r7
 L r8
COLUMNS
 x0 obj 3
 x1 obj 3
 x2 obj 9
 x3 obj 6
 x4 obj 7
 x5 obj 8
 x6 obj 6
 x7 obj 8
 x8 obj 6
 x9 obj 9
 x10 obj 5
 x11 obj 4
 x12 obj -2
 x12 r0 0.00390625
 x12 r2 -0.00390625
 x12 r3 16.0
 x12 r5 -256.0
 x12 r6 -1.0
 x12 r8 1.0
 x13 obj -2
 x13 r1 256.0
 x13 r2 -0.00390625
 x13 r4 1.0
 x13 r5 -256.0
 x13 r7 -16.0
 x14 obj 3
 x15 obj 6
 x16 obj 8
 x17 obj 4
 x18 obj -2
 x18 r0 0.00390625
 x18 r1 256.0
 x18 r3 16.0
 x18 r4 1.0
 x18 r6 -1.0
 x18 r7 -16.0
 x19 obj 7
 x20 obj 6
 x21 obj 4
 x22 obj 0
 x22 r8 2.0
RHS
 rhs obj 17
 rhs r0 0.00390625
 rhs r1 256.0
 rhs r2 -0.00390625
 rhs r3 16.0
 rhs r4 1.0
 rhs r5 -256.0
 rhs r6 -1.0
 rhs r7 -16.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 UP b x22 2
ENDATA
