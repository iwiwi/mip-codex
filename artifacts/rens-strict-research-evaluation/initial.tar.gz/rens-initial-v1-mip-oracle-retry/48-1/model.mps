NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj -3
 x1 obj -7
 x2 obj 8
 x2 r1 256.0
 x2 r2 -0.0625
 x2 r4 1.0
 x3 obj -3
 x4 obj 8
 x4 r0 -1.0
 x4 r2 -0.0625
 x4 r3 0.00390625
 x4 r5 1.0
 x5 obj -2
 x6 obj -2
 x7 obj -1
 x8 obj -5
 x9 obj -6
 x10 obj -8
 x11 obj -5
 x12 obj 8
 x12 r0 -1.0
 x12 r1 256.0
 x12 r3 0.00390625
 x12 r4 1.0
 x13 obj -8
 x14 obj -7
 x15 obj -7
 x16 obj -8
 x17 obj -9
 x18 obj -1
 x19 obj -4
 x20 obj -4
 x21 obj -8
 x22 obj -8
 x23 obj -4
 x24 obj -6
 x25 obj -5
 x26 obj -8
 x27 obj 0
 x27 r5 2.0
RHS
 rhs obj 26
 rhs r0 -1.0
 rhs r1 256.0
 rhs r2 -0.0625
 rhs r3 0.00390625
 rhs r4 1.0
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 UP b x27 2
ENDATA
