NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 G r4
 G r5
 L r6
 L r7
 G r8
 L r9
 L r10
COLUMNS
 x0 obj 9
 x1 obj 5
 x2 obj 7
 x3 obj 9
 x4 obj 8
 x5 obj 9
 x6 obj 3
 x7 obj -1
 x7 r0 16.0
 x7 r2 -1.0
 x7 r3 -256.0
 x7 r5 -0.00390625
 x7 r6 256.0
 x7 r8 -0.0625
 x7 r9 16.0
 x7 r10 1.0
 x8 obj 9
 x9 obj 6
 x10 obj 6
 x11 obj 8
 x12 obj 7
 x13 obj -1
 x13 r1 0.0625
 x13 r2 -1.0
 x13 r4 -256.0
 x13 r5 -0.00390625
 x13 r7 0.00390625
 x13 r8 -0.0625
 x14 obj 3
 x15 obj 3
 x16 obj 7
 x17 obj 9
 x18 obj 7
 x19 obj -1
 x19 r0 16.0
 x19 r1 0.0625
 x19 r3 -256.0
 x19 r4 -256.0
 x19 r6 256.0
 x19 r7 0.00390625
 x19 r9 16.0
 x20 obj 6
 x21 obj 8
 x22 obj 7
 x23 obj 2
 x24 obj 9
 x25 obj 6
 x26 obj 0
 x26 r10 2.0
RHS
 rhs obj 20
 rhs r0 16.0
 rhs r1 0.0625
 rhs r2 -1.0
 rhs r3 -256.0
 rhs r4 -256.0
 rhs r5 -0.00390625
 rhs r6 256.0
 rhs r7 0.00390625
 rhs r8 -0.0625
 rhs r9 16.0
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 2
 UP b x26 2
ENDATA
