NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 G r4
 L r5
 G r6
 L r7
COLUMNS
 x0 obj 3
 x1 obj 6
 x2 obj 5
 x3 obj 2
 x4 obj -5
 x4 r1 0.0625
 x4 r2 -16.0
 x4 r4 -0.0625
 x4 r5 256.0
 x5 obj 8
 x6 obj 4
 x7 obj 5
 x8 obj 6
 x9 obj 7
 x10 obj 3
 x11 obj 7
 x12 obj 5
 x13 obj 2
 x14 obj 1
 x15 obj 6
 x16 obj 2
 x17 obj -5
 x17 r0 16.0
 x17 r2 -16.0
 x17 r3 16.0
 x17 r5 256.0
 x17 r6 -256.0
 x17 r7 1.0
 x18 obj 8
 x19 obj 1
 x20 obj 3
 x21 obj 1
 x22 obj 3
 x23 obj 9
 x24 obj 2
 x25 obj 8
 x26 obj -5
 x26 r0 16.0
 x26 r1 0.0625
 x26 r3 16.0
 x26 r4 -0.0625
 x26 r6 -256.0
 x27 obj 7
 x28 obj 8
 x29 obj 6
 x30 obj 6
 x31 obj 3
 x32 obj 0
 x32 r7 2.0
RHS
 rhs obj 8
 rhs r0 16.0
 rhs r1 0.0625
 rhs r2 -16.0
 rhs r3 16.0
 rhs r4 -0.0625
 rhs r5 256.0
 rhs r6 -256.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 1
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 3
 UP b x32 2
ENDATA
