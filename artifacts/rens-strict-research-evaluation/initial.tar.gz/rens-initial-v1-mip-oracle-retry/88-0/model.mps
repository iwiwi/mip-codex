NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 L r4
COLUMNS
 x0 obj 9
 x1 obj 3
 x2 obj 6
 x3 obj 5
 x4 obj 9
 x5 obj 2
 x6 obj 4
 x7 obj 4
 x8 obj 1
 x9 obj 9
 x10 obj -6
 x10 r0 -0.00390625
 x10 r2 -0.0625
 x10 r3 256.0
 x10 r4 1.0
 x11 obj 3
 x12 obj 4
 x13 obj -6
 x13 r1 16.0
 x13 r2 -0.0625
 x14 obj 9
 x15 obj 2
 x16 obj 1
 x17 obj 9
 x18 obj 8
 x19 obj 1
 x20 obj 7
 x21 obj -6
 x21 r0 -0.00390625
 x21 r1 16.0
 x21 r3 256.0
 x22 obj 0
 x22 r4 2.0
RHS
 rhs obj -10
 rhs r0 -0.00390625
 rhs r1 16.0
 rhs r2 -0.0625
 rhs r3 256.0
 rhs r4 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 1
 UP b x22 2
ENDATA
