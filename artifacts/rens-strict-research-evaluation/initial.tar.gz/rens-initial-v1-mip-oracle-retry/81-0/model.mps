NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 G r4
 L r5
COLUMNS
 x0 obj 3
 x1 obj 2
 x2 obj 4
 x3 obj 1
 x4 obj 5
 x5 obj -9
 x5 r0 -1.0
 x5 r1 256.0
 x5 r3 0.0625
 x5 r4 -0.00390625
 x6 obj 9
 x7 obj 9
 x8 obj -9
 x8 r0 -1.0
 x8 r2 -16.0
 x8 r3 0.0625
 x8 r5 1.0
 x9 obj 1
 x10 obj 8
 x11 obj 4
 x12 obj 1
 x13 obj -9
 x13 r1 256.0
 x13 r2 -16.0
 x13 r4 -0.00390625
 x14 obj 3
 x15 obj 6
 x16 obj 6
 x17 obj 8
 x18 obj 8
 x19 obj 0
 x19 r5 2.0
RHS
 rhs obj -2
 rhs r0 -1.0
 rhs r1 256.0
 rhs r2 -16.0
 rhs r3 0.0625
 rhs r4 -0.00390625
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 UP b x19 2
ENDATA
