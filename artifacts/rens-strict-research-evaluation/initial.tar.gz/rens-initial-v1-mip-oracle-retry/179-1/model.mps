NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
COLUMNS
 x0 obj -3
 x1 obj -4
 x2 obj -2
 x3 obj -7
 x4 obj -3
 x5 obj 6
 x5 r0 -0.00390625
 x5 r1 -256.0
 x6 obj -9
 x7 obj -8
 x8 obj -7
 x9 obj -8
 x10 obj -3
 x11 obj -6
 x12 obj -6
 x13 obj -6
 x14 obj -5
 x15 obj -9
 x16 obj -2
 x17 obj -8
 x18 obj -8
 x19 obj 6
 x19 r0 -0.00390625
 x19 r2 -0.00390625
 x19 r3 1.0
 x20 obj -4
 x21 obj -7
 x22 obj 6
 x22 r1 -256.0
 x22 r2 -0.00390625
 x23 obj -3
 x24 obj -3
 x25 obj -9
 x26 obj 0
 x26 r3 2.0
RHS
 rhs obj 5
 rhs r0 -0.00390625
 rhs r1 -256.0
 rhs r2 -0.00390625
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 4
 UP b x26 2
ENDATA
