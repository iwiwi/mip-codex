NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 G r5
 L r6
 L r7
COLUMNS
 x0 obj -2
 x1 obj -9
 x2 obj -6
 x3 obj -5
 x4 obj -8
 x5 obj -6
 x6 obj 7
 x6 r0 0.0625
 x6 r2 0.0625
 x6 r3 -1.0
 x6 r5 -256.0
 x6 r6 0.0625
 x6 r7 1.0
 x7 obj -8
 x8 obj -3
 x9 obj -5
 x10 obj 7
 x10 r1 0.00390625
 x10 r2 0.0625
 x10 r4 -0.00390625
 x10 r5 -256.0
 x11 obj -5
 x12 obj 7
 x12 r0 0.0625
 x12 r1 0.00390625
 x12 r3 -1.0
 x12 r4 -0.00390625
 x12 r6 0.0625
 x13 obj -1
 x14 obj -5
 x15 obj -8
 x16 obj -9
 x17 obj -5
 x18 obj -4
 x19 obj 0
 x19 r7 2.0
RHS
 rhs obj 23
 rhs r0 0.0625
 rhs r1 0.00390625
 rhs r2 0.0625
 rhs r3 -1.0
 rhs r4 -0.00390625
 rhs r5 -256.0
 rhs r6 0.0625
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 UP b x19 2
ENDATA
