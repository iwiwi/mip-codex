NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 L r4
COLUMNS
 x0 obj 6
 x1 obj 6
 x2 obj 4
 x3 obj 9
 x4 obj 3
 x5 obj 1
 x6 obj -8
 x6 r1 -16.0
 x6 r2 16.0
 x7 obj 1
 x8 obj 3
 x9 obj 6
 x10 obj 7
 x11 obj 1
 x12 obj -8
 x12 r0 0.00390625
 x12 r1 -16.0
 x12 r3 256.0
 x13 obj 7
 x14 obj -8
 x14 r0 0.00390625
 x14 r2 16.0
 x14 r3 256.0
 x14 r4 1.0
 x15 obj 2
 x16 obj 1
 x17 obj 5
 x18 obj 0
 x18 r4 2.0
RHS
 rhs obj -23
 rhs r0 0.00390625
 rhs r1 -16.0
 rhs r2 16.0
 rhs r3 256.0
 rhs r4 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 UP b x18 2
ENDATA
