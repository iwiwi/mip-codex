NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 G r3
 G r4
 L r5
 G r6
 L r7
 L r8
COLUMNS
 x0 obj 5
 x1 obj 5
 x2 obj 5
 x3 obj -7
 x3 r0 256.0
 x3 r1 -16.0
 x3 r3 -0.00390625
 x3 r4 -0.0625
 x3 r6 -16.0
 x3 r7 0.0625
 x4 obj 7
 x5 obj 2
 x6 obj 2
 x7 obj 9
 x8 obj 3
 x9 obj -7
 x9 r1 -16.0
 x9 r2 -16.0
 x9 r4 -0.0625
 x9 r5 16.0
 x9 r7 0.0625
 x10 obj 9
 x11 obj 3
 x12 obj 9
 x13 obj 8
 x14 obj 2
 x15 obj 5
 x16 obj 4
 x17 obj 2
 x18 obj 7
 x19 obj 4
 x20 obj 4
 x21 obj 7
 x22 obj 7
 x23 obj 8
 x24 obj 1
 x25 obj 4
 x26 obj 1
 x27 obj -7
 x27 r0 256.0
 x27 r2 -16.0
 x27 r3 -0.00390625
 x27 r5 16.0
 x27 r6 -16.0
 x27 r8 1.0
 x28 obj 4
 x29 obj 3
 x30 obj 2
 x31 obj 0
 x31 r8 2.0
RHS
 rhs obj -5
 rhs r0 256.0
 rhs r1 -16.0
 rhs r2 -16.0
 rhs r3 -0.00390625
 rhs r4 -0.0625
 rhs r5 16.0
 rhs r6 -16.0
 rhs r7 0.0625
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 1
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 2
 UP b x31 2
ENDATA
