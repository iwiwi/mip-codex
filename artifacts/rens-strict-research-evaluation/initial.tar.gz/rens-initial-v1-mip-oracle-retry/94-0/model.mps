NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj 7
 x1 obj 4
 x2 obj 6
 x3 obj 5
 x4 obj -4
 x4 r1 0.0625
 x4 r2 0.00390625
 x5 obj 4
 x6 obj 3
 x7 obj 1
 x8 obj 8
 x9 obj -4
 x9 r0 -0.0625
 x9 r2 0.00390625
 x9 r3 1.0
 x10 obj -4
 x10 r0 -0.0625
 x10 r1 0.0625
 x11 obj 7
 x12 obj 6
 x13 obj 4
 x14 obj 1
 x15 obj 8
 x16 obj 5
 x17 obj 1
 x18 obj 0
 x18 r3 2.0
RHS
 rhs obj -10
 rhs r0 -0.0625
 rhs r1 0.0625
 rhs r2 0.00390625
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 UP b x18 2
ENDATA
