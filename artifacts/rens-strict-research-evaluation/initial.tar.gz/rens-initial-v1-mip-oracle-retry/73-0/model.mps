NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 G r4
 L r5
 L r6
 G r7
 L r8
 G r9
 L r10
COLUMNS
 x0 obj 7
 x1 obj 9
 x2 obj 5
 x3 obj -5
 x3 r0 -0.00390625
 x3 r1 0.0625
 x3 r3 -1.0
 x3 r4 -256.0
 x3 r6 1.0
 x3 r7 -0.00390625
 x3 r9 -16.0
 x4 obj 4
 x5 obj 2
 x6 obj 8
 x7 obj 1
 x8 obj 3
 x9 obj 5
 x10 obj 2
 x11 obj 7
 x12 obj 9
 x13 obj 3
 x14 obj -5
 x14 r0 -0.00390625
 x14 r2 256.0
 x14 r3 -1.0
 x14 r5 0.0625
 x14 r6 1.0
 x14 r8 0.00390625
 x14 r9 -16.0
 x14 r10 1.0
 x15 obj 8
 x16 obj 2
 x17 obj 5
 x18 obj 7
 x19 obj 3
 x20 obj 5
 x21 obj 8
 x22 obj 5
 x23 obj 3
 x24 obj 9
 x25 obj 5
 x26 obj 6
 x27 obj 7
 x28 obj -5
 x28 r1 0.0625
 x28 r2 256.0
 x28 r4 -256.0
 x28 r5 0.0625
 x28 r7 -0.00390625
 x28 r8 0.00390625
 x29 obj 0
 x29 r10 2.0
RHS
 rhs obj 2
 rhs r0 -0.00390625
 rhs r1 0.0625
 rhs r2 256.0
 rhs r3 -1.0
 rhs r4 -256.0
 rhs r5 0.0625
 rhs r6 1.0
 rhs r7 -0.00390625
 rhs r8 0.00390625
 rhs r9 -16.0
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 1
 UP b x29 2
ENDATA
