NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
COLUMNS
 x0 obj -8
 x0 r1 -256.0
 x0 r2 -1.0
 x1 obj -8
 x1 r0 -256.0
 x1 r2 -1.0
 x1 r3 1.0
 x2 obj 1
 x3 obj 1
 x4 obj 1
 x5 obj 7
 x6 obj 5
 x7 obj 3
 x8 obj 1
 x9 obj 6
 x10 obj 8
 x11 obj 4
 x12 obj 8
 x13 obj 6
 x14 obj 6
 x15 obj -8
 x15 r0 -256.0
 x15 r1 -256.0
 x16 obj 6
 x17 obj 6
 x18 obj 8
 x19 obj 2
 x20 obj 6
 x21 obj 4
 x22 obj 4
 x23 obj 2
 x24 obj 7
 x25 obj 5
 x26 obj 1
 x27 obj 1
 x28 obj 1
 x29 obj 0
 x29 r3 2.0
RHS
 rhs obj -7
 rhs r0 -256.0
 rhs r1 -256.0
 rhs r2 -1.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 2
 UP b x29 2
ENDATA
