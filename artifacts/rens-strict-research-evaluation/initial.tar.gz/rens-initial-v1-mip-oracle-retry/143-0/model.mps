NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj 2
 x1 obj 1
 x2 obj 2
 x3 obj -9
 x3 r0 -0.00390625
 x3 r2 -256.0
 x3 r3 0.0625
 x3 r5 1.0
 x4 obj 1
 x5 obj -9
 x5 r0 -0.00390625
 x5 r1 -16.0
 x5 r3 0.0625
 x5 r4 256.0
 x6 obj 1
 x7 obj 8
 x8 obj 5
 x9 obj 8
 x10 obj 4
 x11 obj 3
 x12 obj 3
 x13 obj 5
 x14 obj 5
 x15 obj 1
 x16 obj 2
 x17 obj -9
 x17 r1 -16.0
 x17 r2 -256.0
 x17 r4 256.0
 x18 obj 3
 x19 obj 9
 x20 obj 3
 x21 obj 8
 x22 obj 6
 x23 obj 5
 x24 obj 1
 x25 obj 7
 x26 obj 0
 x26 r5 2.0
RHS
 rhs obj 8
 rhs r0 -0.00390625
 rhs r1 -16.0
 rhs r2 -256.0
 rhs r3 0.0625
 rhs r4 256.0
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 UP b x26 2
ENDATA
