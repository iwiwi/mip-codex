NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
 G r4
 G r5
 G r6
 G r7
 L r8
COLUMNS
 x0 obj 3
 x1 obj 6
 x2 obj 2
 x3 obj -7
 x3 r1 -0.0625
 x3 r2 -256.0
 x3 r4 -16.0
 x3 r5 -1.0
 x3 r7 -16.0
 x4 obj 9
 x5 obj 8
 x6 obj -7
 x6 r0 -16.0
 x6 r2 -256.0
 x6 r3 1.0
 x6 r5 -1.0
 x6 r6 -0.0625
 x6 r8 1.0
 x7 obj 1
 x8 obj 5
 x9 obj 2
 x10 obj 4
 x11 obj 9
 x12 obj -7
 x12 r0 -16.0
 x12 r1 -0.0625
 x12 r3 1.0
 x12 r4 -16.0
 x12 r6 -0.0625
 x12 r7 -16.0
 x13 obj 8
 x14 obj 3
 x15 obj 9
 x16 obj 8
 x17 obj 4
 x18 obj 8
 x19 obj 4
 x20 obj 3
 x21 obj 9
 x22 obj 8
 x23 obj 2
 x24 obj 7
 x25 obj 8
 x26 obj 7
 x27 obj 1
 x28 obj 5
 x29 obj 8
 x30 obj 0
 x30 r8 2.0
RHS
 rhs obj 24
 rhs r0 -16.0
 rhs r1 -0.0625
 rhs r2 -256.0
 rhs r3 1.0
 rhs r4 -16.0
 rhs r5 -1.0
 rhs r6 -0.0625
 rhs r7 -16.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 4
 UP b x30 2
ENDATA
