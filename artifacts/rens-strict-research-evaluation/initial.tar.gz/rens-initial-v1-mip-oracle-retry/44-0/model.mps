NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 L r4
 L r5
 L r6
COLUMNS
 x0 obj 7
 x1 obj 4
 x2 obj 7
 x3 obj 7
 x4 obj 5
 x5 obj 6
 x6 obj 3
 x7 obj 8
 x8 obj 8
 x9 obj -7
 x9 r0 -0.00390625
 x9 r2 -0.00390625
 x9 r3 -1.0
 x9 r5 16.0
 x9 r6 1.0
 x10 obj 3
 x11 obj 6
 x12 obj -7
 x12 r0 -0.00390625
 x12 r1 16.0
 x12 r3 -1.0
 x12 r4 0.00390625
 x13 obj 6
 x14 obj 8
 x15 obj 5
 x16 obj -7
 x16 r1 16.0
 x16 r2 -0.00390625
 x16 r4 0.00390625
 x16 r5 16.0
 x17 obj 6
 x18 obj 8
 x19 obj 3
 x20 obj 6
 x21 obj 6
 x22 obj 7
 x23 obj 0
 x23 r6 2.0
RHS
 rhs obj -30
 rhs r0 -0.00390625
 rhs r1 16.0
 rhs r2 -0.00390625
 rhs r3 -1.0
 rhs r4 0.00390625
 rhs r5 16.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 UP b x23 2
ENDATA
