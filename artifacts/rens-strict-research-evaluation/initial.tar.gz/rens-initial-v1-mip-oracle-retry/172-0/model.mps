NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 L r4
COLUMNS
 x0 obj 2
 x1 obj 4
 x2 obj 8
 x3 obj 9
 x4 obj -2
 x4 r1 -256.0
 x4 r2 0.00390625
 x5 obj 9
 x6 obj -2
 x6 r0 1.0
 x6 r1 -256.0
 x6 r3 -256.0
 x7 obj 1
 x8 obj 2
 x9 obj 3
 x10 obj 6
 x11 obj 3
 x12 obj 7
 x13 obj 9
 x14 obj 9
 x15 obj 6
 x16 obj 1
 x17 obj 9
 x18 obj 5
 x19 obj -2
 x19 r0 1.0
 x19 r2 0.00390625
 x19 r3 -256.0
 x19 r4 1.0
 x20 obj 5
 x21 obj 9
 x22 obj 9
 x23 obj 0
 x23 r4 2.0
RHS
 rhs obj -6
 rhs r0 1.0
 rhs r1 -256.0
 rhs r2 0.00390625
 rhs r3 -256.0
 rhs r4 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 UP b x23 2
ENDATA
