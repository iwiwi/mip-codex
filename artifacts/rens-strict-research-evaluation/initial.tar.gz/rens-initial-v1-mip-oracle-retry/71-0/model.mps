NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 L r4
 L r5
 L r6
 L r7
 G r8
 G r9
 L r10
COLUMNS
 x0 obj 7
 x1 obj 6
 x2 obj 8
 x3 obj 5
 x4 obj -7
 x4 r1 -1.0
 x4 r2 0.00390625
 x4 r4 16.0
 x4 r5 1.0
 x4 r7 1.0
 x4 r8 -0.00390625
 x5 obj 8
 x6 obj 9
 x7 obj 9
 x8 obj 3
 x9 obj 5
 x10 obj 8
 x11 obj 4
 x12 obj -7
 x12 r0 1.0
 x12 r2 0.00390625
 x12 r3 -256.0
 x12 r5 1.0
 x12 r6 256.0
 x12 r8 -0.00390625
 x12 r9 -0.00390625
 x12 r10 1.0
 x13 obj 9
 x14 obj 2
 x15 obj 9
 x16 obj 5
 x17 obj -7
 x17 r0 1.0
 x17 r1 -1.0
 x17 r3 -256.0
 x17 r4 16.0
 x17 r6 256.0
 x17 r7 1.0
 x17 r9 -0.00390625
 x18 obj 0
 x18 r10 2.0
RHS
 rhs obj 24
 rhs r0 1.0
 rhs r1 -1.0
 rhs r2 0.00390625
 rhs r3 -256.0
 rhs r4 16.0
 rhs r5 1.0
 rhs r6 256.0
 rhs r7 1.0
 rhs r8 -0.00390625
 rhs r9 -0.00390625
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 UP b x18 2
ENDATA
