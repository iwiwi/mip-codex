NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj 3
 x1 obj 2
 x2 obj 5
 x3 obj 9
 x4 obj 2
 x5 obj 7
 x6 obj 5
 x7 obj 4
 x8 obj 2
 x9 obj 6
 x10 obj 9
 x11 obj -8
 x11 r1 1.0
 x11 r2 0.0625
 x12 obj 2
 x13 obj 9
 x14 obj 7
 x15 obj 4
 x16 obj 3
 x17 obj 1
 x18 obj 7
 x19 obj 2
 x20 obj 4
 x21 obj 2
 x22 obj 8
 x23 obj 6
 x24 obj -8
 x24 r0 0.00390625
 x24 r1 1.0
 x25 obj 2
 x26 obj -8
 x26 r0 0.00390625
 x26 r2 0.0625
 x26 r3 1.0
 x27 obj 7
 x28 obj 0
 x28 r3 2.0
RHS
 rhs obj -23
 rhs r0 0.00390625
 rhs r1 1.0
 rhs r2 0.0625
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 1
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 1
 LI b x27 0
 UI b x27 4
 UP b x28 2
ENDATA
