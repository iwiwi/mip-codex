//! RENSの定義を参考に独立実装。外部ソルバー・既存コードへの最適化委譲なし。
//! Berthold, https://edocs.tib.eu/files/e01fn09/573699097l.pdf
//! https://www.scipopt.org/scip/doc/html/heur__rens_8h.php
use crate::model::Model;
use serde::Serialize;
use std::time::Instant;
#[derive(Clone,Default,Debug,Serialize)]pub struct Stats{pub attempts:usize,pub calls:usize,pub fixed:usize,pub eligible:usize,pub fractional:usize,pub nodes:usize,pub lp_solves:usize,pub candidates:usize,pub improvements:usize,pub seconds:f64,pub status:Option<String>}
pub struct Neighborhood{pub model:Model,pub fixed:usize,pub eligible:usize,pub fractional:usize}
pub fn neighborhood(model:&Model,point:&[f64],deadline:Instant)->Option<Neighborhood>{
 if model.variables.len()>1_000_000||point.len()!=model.variables.len()||point.iter().any(|v|!v.is_finite()||v.abs()>4503599627370496.)||Instant::now()>=deadline||model.check(point,false,1e-6).is_err(){return None;}
 let mut bounds=vec![];let mut fixed=0usize;let mut eligible=0usize;let mut fractional=0usize;
 for(j,v)in model.variables.iter().enumerate(){
  if j%1024==0&&Instant::now()>=deadline{return None;}if !v.integer{continue;}
  let original_lo=if v.lower.is_some(){Some(v.lower_enclosure?[1].ceil())}else{None};let original_up=if v.upper.is_some(){Some(v.upper_enclosure?[0].floor())}else{None};
  if original_lo.zip(original_up).is_some_and(|(l,u)|l>u){return None;}
  if original_lo.zip(original_up).is_some_and(|(l,u)|l==u){continue;}
  eligible+=1;let x=point[j];let near=(x-x.round()).abs()<=1e-6;let mut lo=if near{x.round()}else{x.floor()};let mut up=if near{x.round()}else{x.ceil()};if let Some(l)=original_lo{lo=lo.max(l);}if let Some(u)=original_up{up=up.min(u);}if lo>up{return None;}
  if lo==up{fixed+=1;}else{fractional+=1;}bounds.push((j,lo,up));
 }
 if fixed<2||fractional==0||fixed.saturating_mul(5)<eligible.saturating_mul(4)||Instant::now()>=deadline{return None;}
 let mut sub=model.clone();if Instant::now()>=deadline{return None;}
 for(j,lo,up)in bounds{let v=&mut sub.variables[j];v.lower=Some(lo);v.upper=Some(up);v.lower_enclosure=Some([lo;2]);v.upper_enclosure=Some([up;2]);}
 Some(Neighborhood{model:sub,fixed,eligible,fractional})
}
#[cfg(test)]mod tests{
 use super::*;
 fn triangle()->Model{let mut t=String::from("NAME rens\nROWS\n N c\n L r\n L s\n L t\nCOLUMNS\n x0 c -1 r 1\n x0 t 1\n x1 c -1 r 1\n x1 s 1\n x2 c -1 s 1\n x2 t 1\n");for j in 3..20{t+=&format!(" x{j} c 1\n");}t+="RHS\n rhs r 1 s 1\n rhs t 1\nBOUNDS\n";for j in 0..20{t+=&format!(" BV b x{j}\n");}t+="ENDATA\n";crate::mps::parse(std::io::Cursor::new(t)).unwrap()}
 #[test]fn fractional_lp_point_can_define_a_neighborhood_without_an_incumbent(){let m=triangle();let mut point=vec![0.;20];point[..3].fill(0.5);let n=neighborhood(&m,&point,Instant::now()+std::time::Duration::from_secs(1)).unwrap();assert_eq!((n.fixed,n.eligible,n.fractional),(17,20,3));assert_eq!(n.model.variables[3].upper,Some(0.));assert_eq!(m.variables[3].upper,Some(1.));assert_eq!(n.model.variables[0].lower,Some(0.));assert_eq!(n.model.variables[0].upper,Some(1.));assert!(neighborhood(&m,&point,Instant::now()).is_none());let mut bad=point.clone();bad[0]=2.;assert!(neighborhood(&m,&bad,Instant::now()+std::time::Duration::from_secs(1)).is_none());}
 #[test]fn rens_only_returns_an_original_valid_point(){use crate::solve::{solve,Limits};let m=triangle();let limits=Limits{seconds:2.,rens:true,primal_repair:false,box_primal:false,primal_probe:false,lp_diving:false,objective_lp_dive:false,feasibility_pump:false,rins:false,binary_graph:false,cover_cuts:false,mir_cuts:false,gomory_cuts:false,aggregate_cuts:false,clique_cuts:false,three_row_cuts:false,rounding_cuts:false,..Limits::default()};let r=solve(&m,&limits);let s=r.rens.as_ref().unwrap();assert_eq!(s.calls,1);assert_eq!(s.fixed,17);assert_eq!(s.improvements,1);assert_eq!(r.objective,Some(-1.));let x:Vec<_>=m.variables.iter().map(|v|r.values.as_ref().unwrap()[&v.name]).collect();assert!(m.check(&x,true,1e-7).is_ok());assert_eq!(m.variables[3].upper,Some(1.));}
}
