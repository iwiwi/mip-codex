from pathlib import Path
from fractions import Fraction as F
import json,sys,struct,os,time,resource
sys.path.insert(0,'scripts');from verify_cover_cuts import exact_model
from benchmark_common import atomic_json
r=Path.cwd();o=r/'artifacts/master-bound-diagnostic-v1';dest=r/'artifacts/master-bound-diagnostic-v1-exact-audit';dest.mkdir();os.sched_setaffinity(0,{35});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));manifest={m['name']:m for m in json.loads((r/'data/manifest.json').read_text())['instances']};records=[]
for name in sys.argv[1:]:
 m=manifest[name];assert m['split']=='development';data=o/name/'bound-calculations.jsonl'
 if not data.exists():continue
 proof=[json.loads(l)for l in data.read_text().splitlines()if json.loads(l).get('normalized_bound_bits')is not None]
 if not proof:continue
 start=time.monotonic();names,variables,rows,costs,constant=exact_model(r/m['path'],True);from verify_binary_graph import maximize_sense
 sign=-1 if maximize_sense(r/m['path'])else 1
 for index,p in enumerate(proof):
  reduced={n:sign*c for n,c in costs.items()if c};total=sign*constant;seen=set()
  for source,bits in p['multipliers']:
   assert isinstance(source,int)and 0<=source<len(rows)and source not in seen;seen.add(source);value=struct.unpack('>d',bytes.fromhex(bits))[0];assert value==value and abs(value)!=float('inf');y=F(value);assert y;row=rows[source];bound=row['lower']if y>0 else row['upper'];assert bound is not None;total+=y*bound
   for n,a in row['coefficients'].items():reduced[n]=reduced.get(n,F(0))-y*a
  finite=True
  for n,c in reduced.items():
   if not c:continue
   v=variables[n];bound=v['lower']if c>0 else v['upper']
   if bound is None:finite=False;break
   total+=c*bound
  claimed=F(struct.unpack('>d',bytes.fromhex(p['normalized_bound_bits']))[0]);valid=finite and claimed<=total;record=dict(name=name,master=p['master'],valid=valid,claimed=str(claimed),exact_lagrangian_bound=str(total)if finite else None,multipliers=len(seen),seconds=time.monotonic()-start);records.append(record);atomic_json(dest/f'{name}-{index}.json',record);atomic_json(dest/'summary.json',dict(checked=len(records),valid=sum(x['valid']for x in records)));assert valid,record
atomic_json(dest/'records.json',records);atomic_json(dest/'exit.json',dict(status='complete'));print(dict(checked=len(records),valid=sum(x['valid']for x in records)))
