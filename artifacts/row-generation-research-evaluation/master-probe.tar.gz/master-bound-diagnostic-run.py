from pathlib import Path
import os,json,subprocess,resource,shutil,hashlib,time,sys
r=Path('/home/ubuntu/mip-codex');w=Path('/home/ubuntu/mip-priced-repair');out=r/'artifacts/master-bound-diagnostic-v1';out.mkdir();(out/'bin').mkdir()
for name,src in [('mip-codex',w/'target/release/mip-codex'),('master_bound_diagnostic',w/'target/release/examples/master_bound_diagnostic')]:shutil.copy2(src,out/'bin'/name)
shutil.copy2(w/'examples/master_bound_diagnostic.rs',out/'example-source.rs');(out/'build-info.json').write_bytes(subprocess.check_output([str(out/'bin/mip-codex'),'build-info']));(out/'sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in(out/'bin').iterdir()},indent=2)+'\n');manifest={m['name']:m for m in json.loads((r/'data/manifest.json').read_text())['instances']};cpu=int(sys.argv[1]);names=sys.argv[2:];os.sched_setaffinity(0,{cpu});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3))
for name in names:
 m=manifest[name];assert m['split']=='development';model=r/m['path'];assert hashlib.sha256(model.read_bytes()).hexdigest()==m['sha256'];d=out/name;d.mkdir();dump=d/'masters';dump.mkdir();seconds=20;env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_ROW_GENERATION='1',MIP_ROW_GENERATION_CERTIFICATE_DUMP=str(dump),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');cmd=[str(out/'bin/mip-codex'),'solve',str(model),str(seconds)];(d/'job.json').write_text(json.dumps(dict(command=cmd,cpu=cpu,seconds=seconds,memory_bytes=16*1024**3,input_sha256=m['sha256'],environment={k:v for k,v in env.items()if k.startswith('MIP_')}),indent=2)+'\n');start=time.monotonic()
 with(d/'result.json').open('w')as f,(d/'stderr.log').open('w')as e:p=subprocess.run(cmd,stdout=f,stderr=e,env=env,timeout=seconds+60)
 (d/'execution.json').write_text(json.dumps(dict(exit_code=p.returncode,wall_seconds=time.monotonic()-start))+'\n');assert p.returncode==0
 cmd=[str(out/'bin/master_bound_diagnostic'),str(model),str(dump)];start=time.monotonic()
 with(d/'bound-calculations.jsonl').open('w')as f,(d/'bound-stderr.log').open('w')as e:p=subprocess.run(cmd,stdout=f,stderr=e,env=env,timeout=180)
 (d/'bound-execution.json').write_text(json.dumps(dict(exit_code=p.returncode,wall_seconds=time.monotonic()-start,command=cmd))+'\n');assert p.returncode==0;print(name,'masters',len(list(dump.glob('*.json'))),flush=True)
(out/f'exit-{cpu}.json').write_text(json.dumps(dict(status='complete'))+'\n')
