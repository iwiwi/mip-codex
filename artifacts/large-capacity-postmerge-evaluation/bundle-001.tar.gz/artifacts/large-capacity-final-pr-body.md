4096頂点を超える厳密なuniform-objective binary packingを、自作Rustグラフ探索へ渡せるようにします。頂点上限はu16の範囲内の65535。元の領域/整数係数/行判定、10Mペア作業、メモリ、期限のguardは保持し、新しい大規模グラフだけ深さ512で安全な `depth_limit` を返します。旧public APIの4096制限は保持、CLI `MIP_GRAPH_LARGE_CAPACITY=0/1` の既定はONです。

最終core1572f4382c/FPabc0956a38a27666で350 Rust成功/4ignored、1200小規模出力の全列挙・GMP・厳密証明/7410改変棄却、40大規模解析例の最適値一致・GMP・証明/160改変棄却、深さ制御4点GMP・証明/2改変棄却。単一5-cycle＋孤立点は2節点でoptimal、多数の5-cycleは512節点で安全な境界を保って中断します。

240問外z26、60秒・1thread・16GiB:

| solver | primal | dual bound |
|---|---:|---:|
| 本体 OFF | -7 | -1651 |
| 本体 最終ON | -1154 | -1578 |
| HiGHS1.16.0 | -1147 | -2114 |
| SCIP10.0.2 | -1013 | -1650.9375 |
| GLPK5.0 | 解なし | 境界なし |

本体主制御7点は元MPS GMPと独立root/prefix/Fraction証明valid。native2点もGMP valid、GLPK60.903269秒の超過を保持。nativeは新規60秒比較を同入力/driver/validator SHA照合して参照。外部解を自作探索へ渡していません。初期FPf293のz26 dual−1575と最終−1578を区別します。報告solver時間とCLI壁時計は別に保存しています。全体優位/新記録の主張はありません。

最終188問10秒比較はprimal185同じ/3悪化、dual173同じ/2悪化/13比較不可、finite175ずつ、両182time/2optimal/4numeric。全376新規proof/128点GMP＋公式valid、大容量新認識0。元の悪化は保存し、該当5件の同一凍結CLI・同コア3交互順ペア30点も全GMP/proof valid。追加15pairsはprimal2改善/1悪化/12同値、dual2改善/1悪化/12同値でした。非適用の時間打切り変動と整合するという推論であり、改善を本機能へ帰属したり、元の悪化を除外したりしません。

厳密領域拡張の正しさと新領域での本体改善を根拠に採用します。初期7222ファイル/5bundle、最終7437ファイル/7bundleは全payload SHA再照合、凍結ELFも保持・SHA照合済み。private原型と前PR126 postmerge検査も別archiveで保存しています。

開発のENOSPCに伴うbaseline管理停止は、719summaryと稼働GLPK identityを保持してcoordinatorだけ復旧。外部障害と実行/検査時刻が重なるGLPK1件の同一凍結版/資源での再測定を事前固定し、元720完了後に別tagで実行します。元結果/全失敗は保持、品質に関係なく再測定結果を用いる方針と証拠は `docs/BASELINE_DISK_RECOVERY_20261118.md`。自作final240は未起動、holdout個別成績は開発に使用していません。

AI資源量（ローカル各session最終累積を一度だけ集計）:
```json
{
  "sessions": 1,
  "totals": {
    "input_tokens": 1790802629,
    "cached_input_tokens": 1778172416,
    "output_tokens": 8862464,
    "reasoning_output_tokens": 5432325,
    "total_tokens": 1799665093
  },
  "note": "input_tokensはキャッシュ分を含む。reasoningはoutputの内数。ローカルログの最終記録まで。"
}
```
