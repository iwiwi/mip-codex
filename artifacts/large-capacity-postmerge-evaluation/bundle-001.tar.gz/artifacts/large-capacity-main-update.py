from pathlib import Path
import os,sys,json,subprocess,shutil
root=Path.cwd();assert root==Path('/home/ubuntu/mip-codex')
os.sched_setaffinity(0,set(range(56,64)))
sys.path.insert(0,'scripts')
from benchmark_common import sha256,atomic_json,require_solver_origin
for name in ['cargo','rustc']:
    assert subprocess.run(['pgrep','-x',name],capture_output=True).returncode==1
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='main'
subprocess.run(['git','fetch','origin','main'],check=True,capture_output=True,text=True)
new='b930e401a65b2cd55828905c242b10039f4c2359'
assert subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()==new
assert not subprocess.check_output(['git','diff','90b6e66b9db039af8a3d72858c63995657d2b02e',new,'--','src','scripts','tests','Cargo.toml','Cargo.lock','build.rs'])
old=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
tracked=set(subprocess.check_output(['git','ls-files','-z']).decode().split('\0'))
incoming=subprocess.check_output(['git','diff','--name-only','-z',old,new]).decode().split('\0')
backup=Path('/tmp/large-capacity-main127-untracked');moved=[]
for name in incoming:
    p=root/name
    if name and name not in tracked and p.is_file():
        content=subprocess.check_output(['git','show',new+':'+name])
        assert p.read_bytes()==content,name
        target=backup/name;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists()
        h=sha256(p);shutil.move(p,target);moved.append(dict(path=name,sha256=h,backup=str(target),bytes_equal_to_incoming_git_blob=True))
subprocess.run(['git','pull','--ff-only','origin','main'],check=True,capture_output=True,text=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==new
for r in moved:assert sha256(root/r['path'])==r['sha256']
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
with(root/'artifacts/large-capacity-main-build.log').open('w')as log:
    subprocess.run(['cargo','build','--release'],env=dict(os.environ,CARGO_INCREMENTAL='0'),stdout=log,stderr=subprocess.STDOUT,check=True)
info=require_solver_origin(root,root/'target/release/mip-codex')
assert info['source_fingerprint']=='abc0956a38a27666'
receipt=dict(old_main=old,new_main=new,source_fingerprint=info['source_fingerprint'],build_info=info,normal_cli_sha256=sha256(root/'target/release/mip-codex'),moved_verified_untracked_collisions=moved,tracked_clean=True,pr_head_source_scripts_tests_Cargo_build_diff_empty=True)
atomic_json(root/'artifacts/large-capacity-main-update.json',receipt)
print(json.dumps(receipt),flush=True)
