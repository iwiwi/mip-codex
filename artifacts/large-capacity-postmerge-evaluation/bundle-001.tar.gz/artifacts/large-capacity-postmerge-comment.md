mainへb930e401a65b2cd55828905c242b10039f4c2359として採用後、primaryで再ビルドし、CLI/library双方のsource directoryとFPabc0956a38a27666を確認しました。PR head90b6e66からsrc/scripts/tests/Cargo/build差分0。取り込むtrackedファイルと同じ内容の既存untracked証拠はGit blobとのbyte一致を確認して/tmpへ保持し、pull後もSHAを確認しています。

CPU47・1thread・16GiBのprimary再検査4件は全GMP/strict proof valid。cod105はoptimal−12/LB−12、0nodes/.020695114秒、独立root最適性true。生成5000pairはoptimal−2500/LB−2500、0nodes/.053164141秒、root最適性true。1020個C5はdepth_limit、best2040/upper3060、512nodes/.206185296秒。z26/60秒はtime_limit−1151/LB−1575、92,135nodes/60.038539414秒。候補branchの−1154/LB−1578とは値が異なるため同値再現とは主張せず、この再測定もそのまま保存。時間配分により主解とFraction被覆が変わるが、両出力の原点/安全境界検査は成功しています。

新create-only `large-capacity-final-20261118` configSHA2bbdcf0f551ab1012cc76dd631e87f8661e1355f79255ddaace09f5287bfa7d0を作成しました。mainb930/ABC、240件×3600秒・16GiB・1thread・cores8..15・swap0/pids512、113snapshotファイル/147libraries全SHA確認。旧E5 tag302bとは5ファイルだけ変更、追加/削除なし、libraries全同一。snapshot自身のcheckerでcod/5000pair/depth出力も再検証。新旧240cgroupsは空、全Rust最終jobは未起動。旧302bはOBSOLETEとして保持します。

元native720件（各solver240）が終端し、元cgroups/管理プロセスが空になった後、時刻重複で事前選択したGLPK1件の別tag再測定が07:30:23 UTCに開始しました（config3ea4c460…）。元720結果は不変で、品質に関係なく再測定結果を用い元失敗も提示する方針です。自作final240はこの再測定の終端と予約CPU解放も待ち、Nov19開始予定のままです。holdout個別成績は開発に参照していません。全体優位/新記録目標は未達で、次の構造依存heap候補を別枝で検証中です。

その時点のAI資源量:
```json
{
  "sessions": 1,
  "totals": {
    "input_tokens": 1794104883,
    "cached_input_tokens": 1781195136,
    "output_tokens": 8888062,
    "reasoning_output_tokens": 5450976,
    "total_tokens": 1802992945
  },
  "note": "input_tokensはキャッシュ分を含む。reasoningはoutputの内数。ローカルログの最終記録まで。"
}
```
