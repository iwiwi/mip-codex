from pathlib import Path
import os,sys,json,subprocess,collections
root=Path.cwd();assert root==Path('/home/ubuntu/mip-codex');os.sched_setaffinity(0,{43})
sys.path.insert(0,'scripts');from benchmark_common import sha256,atomic_json,require_solver_origin
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='b930e401a65b2cd55828905c242b10039f4c2359'
assert not subprocess.check_output(['git','diff','90b6e66b9db039af8a3d72858c63995657d2b02e','HEAD','--','src','scripts','tests','Cargo.toml','Cargo.lock','build.rs'])
info=require_solver_origin(root,root/'target/release/mip-codex');assert info['source_fingerprint']=='abc0956a38a27666'
assert json.load(open('artifacts/large-capacity-main-primary-audit/exit.json'))['gmp_valid']==4
snapshot=json.load(open('artifacts/large-capacity-final-snapshot-verification.json'));assert snapshot['config_sha256']=='2bbdcf0f551ab1012cc76dd631e87f8661e1355f79255ddaace09f5287bfa7d0'
base=root/'artifacts/runs/baseline-v2-20261115';b=(base/'results.jsonl').read_bytes();rs=[json.loads(s)for s in b.splitlines()];assert len(rs)==720
progress=dict(completed=720,solvers=dict(collections.Counter(r['solver']for r in rs)),results_sha256=sha256(base/'results.jsonl'),individual_results_used_for_tuning=False,external_disk_recovery_launched=json.load(open('artifacts/large-capacity-baseline-disk-recovery-launch.json')))
atomic_json(root/'artifacts/large-capacity-postmerge-baseline-progress.json',progress)
text='''mainへb930e401a65b2cd55828905c242b10039f4c2359として採用後、primaryで再ビルドし、CLI/library双方のsource directoryとFPabc0956a38a27666を確認しました。PR head90b6e66からsrc/scripts/tests/Cargo/build差分0。取り込むtrackedファイルと同じ内容の既存untracked証拠はGit blobとのbyte一致を確認して/tmpへ保持し、pull後もSHAを確認しています。

CPU47・1thread・16GiBのprimary再検査4件は全GMP/strict proof valid。cod105はoptimal−12/LB−12、0nodes/.020695114秒、独立root最適性true。生成5000pairはoptimal−2500/LB−2500、0nodes/.053164141秒、root最適性true。1020個C5はdepth_limit、best2040/upper3060、512nodes/.206185296秒。z26/60秒はtime_limit−1151/LB−1575、92,135nodes/60.038539414秒。候補branchの−1154/LB−1578とは値が異なるため同値再現とは主張せず、この再測定もそのまま保存。時間配分により主解とFraction被覆が変わるが、両出力の原点/安全境界検査は成功しています。

新create-only `large-capacity-final-20261118` configSHA2bbdcf0f551ab1012cc76dd631e87f8661e1355f79255ddaace09f5287bfa7d0を作成しました。mainb930/ABC、240件×3600秒・16GiB・1thread・cores8..15・swap0/pids512、113snapshotファイル/147libraries全SHA確認。旧E5 tag302bとは5ファイルだけ変更、追加/削除なし、libraries全同一。snapshot自身のcheckerでcod/5000pair/depth出力も再検証。新旧240cgroupsは空、全Rust最終jobは未起動。旧302bはOBSOLETEとして保持します。

元native720件（各solver240）が終端し、元cgroups/管理プロセスが空になった後、時刻重複で事前選択したGLPK1件の別tag再測定が07:30:23 UTCに開始しました（config3ea4c460…）。元720結果は不変で、品質に関係なく再測定結果を用い元失敗も提示する方針です。自作final240はこの再測定の終端と予約CPU解放も待ち、Nov19開始予定のままです。holdout個別成績は開発に参照していません。全体優位/新記録目標は未達で、次の構造依存heap候補を別枝で検証中です。
'''
usage=subprocess.check_output(['python3','scripts/ai_usage.py'],text=True)
Path('artifacts/large-capacity-postmerge-ai-usage.json').write_text(usage)
p=Path('artifacts/large-capacity-postmerge-comment.md');p.write_text(text+'\nその時点のAI資源量:\n```json\n'+usage+'```\n')
r=subprocess.run(['gh','pr','comment','127','--repo','iwiwi/mip-codex','--body-file',str(p)],capture_output=True,text=True);Path('artifacts/large-capacity-postmerge-comment.log').write_text(r.stdout+r.stderr);r.check_returncode();print(r.stdout)
