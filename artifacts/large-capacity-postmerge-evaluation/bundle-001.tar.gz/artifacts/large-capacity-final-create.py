from pathlib import Path
import sys,os,json,argparse,hashlib,subprocess,time
sys.path.insert(0,'scripts');import benchmark
root=Path.cwd()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='b930e401a65b2cd55828905c242b10039f4c2359'
deadline=time.monotonic()+1800
while not(root/'artifacts/large-capacity-main-primary-audit/exit.json').exists():
 assert time.monotonic()<deadline,'primary smoke not terminal'
 time.sleep(2)
assert json.load(open('artifacts/large-capacity-main-primary-audit/exit.json'))['gmp_valid']==4
oldpath=root/'artifacts/runs/spectral-bound-final-20261118/config.json'
assert hashlib.sha256(oldpath.read_bytes()).hexdigest()=='302b01a56a957515587b5aa4c7a19276a625f33c65bbee35f06fc6cf933b1e3e'
old=json.load(open(oldpath));destination=root/'artifacts/runs/large-capacity-final-20261118'
assert not destination.exists();solvers=sorted({j['solver']for j in old['jobs']});assert solvers==['rust']
original=benchmark.require_solver_origin
def pinned_origin(*a,**kw):
 os.sched_setaffinity(0,{43});info=original(*a,**kw)
 assert info['source_fingerprint']==info['library_source_fingerprint']=='abc0956a38a27666'
 return info
benchmark.require_solver_origin=pinned_origin
benchmark.create(argparse.Namespace(directory=str(destination),seconds=old['seconds'],cores=','.join(map(str,old['cores'])),solvers=','.join(solvers),manifest=str(root/'data/manifest.json'),names=None,allow_dirty=False))
