from pathlib import Path
import os,sys,json,subprocess,tarfile,hashlib,datetime
os.sched_setaffinity(0,{43})
root=Path.cwd();sys.path.insert(0,'scripts')
from benchmark_common import sha256,require_solver_origin,atomic_json
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert subprocess.check_output(['git','ls-remote','origin','refs/heads/graph-large-capacity'],text=True).split()[0]==head
assert not subprocess.check_output(['git','diff','1572f4382c303e12043ae92c74444d0e3c21b6f6','--','src','scripts','tests','Cargo.toml','Cargo.lock','build.rs'])
info=require_solver_origin(root,root/'artifacts/large-capacity-default-frozen/bin/mip-codex')
assert info['source_fingerprint']=='abc0956a38a27666'
assert json.load(open('artifacts/large-capacity-default-test-summary.json'))['passed']==350
assert json.load(open('artifacts/large-capacity-default-development-parallel-audit/summary.json'))['fresh']==376
assert json.load(open('artifacts/large-capacity-default-inactive-recheck/summary.json'))['gmp_valid']==30
for path in (root/'artifacts/large-capacity-default-development-screen/cases').glob('*/*/job.json'):
    r=json.load(open(path));expected='0'if path.parent.name=='before'else None
    assert r['environment'].get('MIP_GRAPH_LARGE_CAPACITY')==expected
checks=[]
for name,origin in [('large-capacity-evaluation',root),('large-capacity-default-evaluation',root),('large-cover-profile-evaluation',Path('/home/ubuntu/mip-large-packing-profile')),('large-cover-continuation-evaluation',Path('/home/ubuntu/mip-large-packing-profile')),('spectral-bound-postmerge-evaluation',Path('/home/ubuntu/mip-codex'))]:
    directory=root/'artifacts'/name
    rows=json.load(open(directory/'manifest.json'));lookup={r['path']:r for r in rows};assert len(lookup)==len(rows)
    seen=set()
    for bundle in sorted(directory.glob('bundle-*.tar.gz')):
        with tarfile.open(bundle)as t:
            for m in t:
                assert m.name not in seen
                seen.add(m.name);r=lookup[m.name];b=t.extractfile(m).read()
                assert len(b)==r['bytes']and hashlib.sha256(b).hexdigest()==r['sha256']
    assert seen==set(lookup)
    excluded=json.load(open(directory/'excluded-elf.json'))
    for r in excluded:
        p=origin/r['path'];assert p.stat().st_size==r['bytes']and sha256(p)==r['sha256']
    checks.append(dict(archive=name,files=len(rows),excluded_elf_verified=len(excluded),actual_origin=str(origin)))
atomic_json(root/'artifacts/large-capacity-adoption-preflight.json',dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,fingerprint=info['source_fingerprint'],source_unchanged_from_frozen_core=True,archives=checks,default_development_jobs_environment_verified=376,all_valid=True))
body='''4096頂点を超える厳密なuniform-objective binary packingを、自作Rustグラフ探索へ渡せるようにします。頂点上限はu16の範囲内の65535。元の領域/整数係数/行判定、10Mペア作業、メモリ、期限のguardは保持し、新しい大規模グラフだけ深さ512で安全な `depth_limit` を返します。旧public APIの4096制限は保持、CLI `MIP_GRAPH_LARGE_CAPACITY=0/1` の既定はONです。

最終core1572f4382c/FPabc0956a38a27666で350 Rust成功/4ignored、1200小規模出力の全列挙・GMP・厳密証明/7410改変棄却、40大規模解析例の最適値一致・GMP・証明/160改変棄却、深さ制御4点GMP・証明/2改変棄却。単一5-cycle＋孤立点は2節点でoptimal、多数の5-cycleは512節点で安全な境界を保って中断します。

240問外z26、60秒・1thread・16GiB:

| solver | primal | dual bound |
|---|---:|---:|
| 本体 OFF | -7 | -1651 |
| 本体 最終ON | -1154 | -1578 |
| HiGHS1.16.0 | -1147 | -2114 |
| SCIP10.0.2 | -1013 | -1650.9375 |
| GLPK5.0 | 解なし | 境界なし |

本体主制御7点は元MPS GMPと独立root/prefix/Fraction証明valid。native2点もGMP valid、GLPK60.903269秒の超過を保持。nativeは新規60秒比較を同入力/driver/validator SHA照合して参照。外部解を自作探索へ渡していません。初期FPf293のz26 dual−1575と最終−1578を区別します。報告solver時間とCLI壁時計は別に保存しています。全体優位/新記録の主張はありません。

最終188問10秒比較はprimal185同じ/3悪化、dual173同じ/2悪化/13比較不可、finite175ずつ、両182time/2optimal/4numeric。全376新規proof/128点GMP＋公式valid、大容量新認識0。元の悪化は保存し、該当5件の同一凍結CLI・同コア3交互順ペア30点も全GMP/proof valid。追加15pairsはprimal2改善/1悪化/12同値、dual2改善/1悪化/12同値でした。非適用の時間打切り変動と整合するという推論であり、改善を本機能へ帰属したり、元の悪化を除外したりしません。

厳密領域拡張の正しさと新領域での本体改善を根拠に採用します。初期7222ファイル/5bundle、最終7437ファイル/7bundleは全payload SHA再照合、凍結ELFも保持・SHA照合済み。private原型と前PR126 postmerge検査も別archiveで保存しています。

開発のENOSPCに伴うbaseline管理停止は、719summaryと稼働GLPK identityを保持してcoordinatorだけ復旧。外部障害と実行/検査時刻が重なるGLPK1件の同一凍結版/資源での再測定を事前固定し、元720完了後に別tagで実行します。元結果/全失敗は保持、品質に関係なく再測定結果を用いる方針と証拠は `docs/BASELINE_DISK_RECOVERY_20261118.md`。自作final240は未起動、holdout個別成績は開発に使用していません。
'''
usage=subprocess.check_output(['python3','scripts/ai_usage.py'],text=True)
Path('artifacts/large-capacity-final-body-ai-usage.json').write_text(usage)
p=Path('artifacts/large-capacity-final-pr-body.md');p.write_text(body+'\nAI資源量（ローカル各session最終累積を一度だけ集計）:\n```json\n'+usage+'```\n')
payload=root/'artifacts/large-capacity-pr-patch.json';atomic_json(payload,dict(body=p.read_text()))
r=subprocess.run(['gh','api','--method','PATCH','repos/iwiwi/mip-codex/pulls/127','--input',str(payload)],capture_output=True,text=True)
Path('artifacts/large-capacity-pr-patch-response.json').write_text(r.stdout);r.check_returncode()
comment='''採用前の再照合を完了しました。最終sourceは1572/ABCのまま、HEADに証拠だけを追加しています。元188での3primal/2dual悪化を全保持し、追加5件×3交互順pairsの30点は全GMP/proof valid、primal2改善/1悪化/12同値、dual2改善/1悪化/12同値、全graph Noneでした。map10は改善/同値/同値、neos911970は悪化/同値/改善、supportcase12は全同値、seymourはdual同値/改善/悪化、sp98arは同値/同値/改善。これを元188の代わりにしません。機能不適用の打切り変動と整合するという推論を明示し、厳密領域拡張・新領域z26本体−1154/LB−1578・全独立検査を根拠に採用します。

初期/最終/私的原型2件/前PRpostmergeの5archiveすべての全payload SHAと除外ELFを元の保持場所で再検証しました。既定ON188の全376 jobでbefore明示0/after未設定も確認済み。元720を残すnative外部ディスク障害1件の事前固定再測定方針を追加しました。最終Rust240は未起動で、新記録/全体優位は未達です。
'''
usage=subprocess.check_output(['python3','scripts/ai_usage.py'],text=True)
Path('artifacts/large-capacity-adoption-ai-usage.json').write_text(usage)
p=Path('artifacts/large-capacity-adoption-comment.md');p.write_text(comment+'\nその時点のAI資源量:\n```json\n'+usage+'```\n')
r=subprocess.run(['gh','pr','comment','127','--repo','iwiwi/mip-codex','--body-file',str(p)],capture_output=True,text=True)
Path('artifacts/large-capacity-adoption-comment.log').write_text(r.stdout+r.stderr);r.check_returncode()
view=json.loads(subprocess.check_output(['gh','pr','view','127','--repo','iwiwi/mip-codex','--json','headRefOid,isDraft,state'],text=True))
assert view['headRefOid']==head and view['state']=='OPEN'
if view['isDraft']:
    r=subprocess.run(['gh','pr','ready','127','--repo','iwiwi/mip-codex'],capture_output=True,text=True);Path('artifacts/large-capacity-pr-ready.log').write_text(r.stdout+r.stderr);r.check_returncode()
r=subprocess.run(['gh','pr','merge','127','--repo','iwiwi/mip-codex','--squash','--match-head-commit',head],capture_output=True,text=True)
Path('artifacts/large-capacity-pr-merge.log').write_text(r.stdout+r.stderr);r.check_returncode()
view=json.loads(subprocess.check_output(['gh','pr','view','127','--repo','iwiwi/mip-codex','--json','headRefOid,state,mergeCommit,mergedAt,url'],text=True));assert view['state']=='MERGED'and view['headRefOid']==head
atomic_json(root/'artifacts/large-capacity-pr-merge.json',view);print(json.dumps(view),flush=True)
