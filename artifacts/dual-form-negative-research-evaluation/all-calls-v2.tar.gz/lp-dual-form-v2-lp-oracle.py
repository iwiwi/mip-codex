from pathlib import Path
from fractions import Fraction as F
import os,json,random,subprocess,sys
import numpy as np,highspy
sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256
root=Path.cwd();out=root/'artifacts/lp-dual-form-v2-lp-oracle';out.mkdir();os.sched_setaffinity(0,{41});rng=random.Random(2026111710);cases=[]
for k in range(200):
 n=rng.randint(2,10);m=max(40,5*n);upper=[rng.randint(2,8)if rng.randrange(2)else None for _ in range(n)];plant=[rng.randint(0,u or 6)for u in upper];rows=[];rhs=[];eq=[];su=[]
 for i in range(m):
  scale=2.**rng.choice([-6,0,6]);row=[rng.randint(-3,3)*scale for _ in range(n)];equal=i==n and k%3==0
  if i<n:row=[float(j==i)for j in range(n)];b=float((upper[i]or 8));equal=False;slack=None
  else:
   b=sum(a*x for a,x in zip(row,plant))+(0 if equal else rng.randint(0,3)*scale);slack=0. if equal else (None if rng.randrange(2)else b-sum(a*x for a,x in zip(row,plant))+rng.randint(0,3)*scale)
  rows.append(row);rhs.append(b);eq.append(equal);su.append(slack)
 columns=[[(i,row[j])for i,row in enumerate(rows)if row[j]]for j in range(n)];costs=[rng.randint(-10,10)for _ in range(n)]
 for sign in [1,-1]:cases.append(dict(columns=columns,rhs=rhs,costs=[sign*c for c in costs],upper=upper,equality=eq,slack_upper=su))
atomic_json(out/'input.json',cases);binary=root/'artifacts/lp-dual-form-v2-diagnostic/bin/dual_lp';optima=[]
for p in cases:
 n=len(p['upper']);rows=[[]for _ in p['rhs']]
 for j,col in enumerate(p['columns']):
  for i,a in col:rows[i].append((j,a))
 h=highspy.Highs();h.setOptionValue('output_flag',False);h.setOptionValue('threads',1);h.addVars(n,np.zeros(n),np.array([u if u is not None else highspy.kHighsInf for u in p['upper']]));h.changeColsCost(n,np.arange(n,dtype=np.int32),np.array(p['costs'],dtype=float))
 for i,(row,b)in enumerate(zip(rows,p['rhs'])):h.addRow(b if p['equality'][i]else (b-p['slack_upper'][i]if p['slack_upper'][i]is not None else-highspy.kHighsInf),b,len(row),np.array([j for j,a in row],dtype=np.int32),np.array([a for j,a in row],dtype=float))
 h.run();assert h.getModelStatus()==highspy.HighsModelStatus.kOptimal;optima.append(h.getObjectiveValue())
records=[]
for flag in [0,1]:
 env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_LP_DUAL_FORM=str(flag),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');a=subprocess.run([str(binary)],input=json.dumps(cases),capture_output=True,text=True,env=env,timeout=300);(out/f'rust-{flag}.jsonl').write_text(a.stdout);(out/f'stderr-{flag}.log').write_text(a.stderr);assert a.returncode==0;data=[json.loads(s)for s in a.stdout.splitlines()];assert len(data)==len(cases)
 for r in data:
  p=cases[r['case']];assert r['status']=='optimal',(flag,r);x=list(map(lambda v:F(str(v)),r['x']));tol=F(1,1000000);assert all(v>=-tol and(u is None or v<=F(u)+tol)for v,u in zip(x,p['upper']));lhs=[F(0)]*len(p['rhs'])
  for j,col in enumerate(p['columns']):
   for i,a in col:lhs[i]+=F(a)*x[j]
  for i,(v,b)in enumerate(zip(lhs,p['rhs'])):
   assert v<=F(b)+tol and (not p['equality'][i]or abs(v-F(b))<=tol)and(p['slack_upper'][i]is None or v>=F(b)-F(p['slack_upper'][i])-tol),(flag,r,i,v,b)
  value=sum(F(c)*v for c,v in zip(p['costs'],x));assert abs(float(value)-optima[r['case']])<=1e-7*(1+abs(optima[r['case']]));assert r['dual']<=optima[r['case']]+1e-7*(1+abs(optima[r['case']]));records.append(dict(flag=flag,**r,valid=True))
assert sum(r['successes']for r in records)>0;atomic_json(out/'records.json',records);atomic_json(out/'summary.json',dict(outputs=len(records),valid=len(records),models=200,senses=2,successes=sum(r['successes']for r in records),fallbacks=sum(r['fallbacks']for r in records),pivots={str(f):sum(r['pivots']for r in records if r['flag']==f)for f in [0,1]}));atomic_json(out/'exit.json',dict(status='complete'));print(json.loads((out/'summary.json').read_text()))
