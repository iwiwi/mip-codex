from pathlib import Path
import json,os,subprocess,sys
sys.path.insert(0,'scripts');from benchmark_common import atomic_json
root=Path.cwd();out=root/'artifacts/lp-dual-form-v2-status-oracle';out.mkdir();os.sched_setaffinity(0,{42});cases=[];expected=[]
for mode in ['infeasible','unbounded','equality','ranged']:
 for sign in [1.,-1.]:
  rows=[[(0,sign)]]+[[]for _ in range(39)];rhs=[-1. if mode=='infeasible'else 1.]+[0.]*39;cost=[-1. if mode=='unbounded'else sign];eq=[mode=='equality']+[False]*39;su=[0. if mode=='equality'else 2. if mode=='ranged'else None]+[None]*39
  if mode=='unbounded':rows[0]=[]
  if mode=='infeasible':rows[0]=[]
  p=dict(columns=[[(i,a)for i,row in enumerate(rows)for j,a in row]],rhs=rhs,costs=cost,upper=[None],equality=eq,slack_upper=su);cases.append(p);expected.append('Infeasible'if mode=='infeasible'or(mode=='equality'and sign<0)else'Unbounded'if mode=='unbounded'else'optimal')
atomic_json(out/'input.json',cases);records=[]
for flag in [0,1]:
 env=os.environ.copy();env['MIP_LP_DUAL_FORM']=str(flag);a=subprocess.run([str(root/'artifacts/lp-dual-form-v2-diagnostic/bin/dual_lp')],input=json.dumps(cases),text=True,capture_output=True,env=env,timeout=60);(out/f'rust-{flag}.jsonl').write_text(a.stdout);(out/f'stderr-{flag}.log').write_text(a.stderr);assert a.returncode==0;data=[json.loads(s)for s in a.stdout.splitlines()];assert len(data)==len(cases)
 for r,e in zip(data,expected):assert r['status']==e,(flag,r,e);records.append(dict(flag=flag,expected=e,**r))
atomic_json(out/'records.json',records);atomic_json(out/'summary.json',dict(outputs=len(records),valid=len(records),fallbacks=sum(r['fallbacks']for r in records)));print('valid',len(records))
