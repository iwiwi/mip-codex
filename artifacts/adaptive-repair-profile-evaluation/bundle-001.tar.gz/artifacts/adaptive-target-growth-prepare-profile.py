from pathlib import Path
import re,hashlib,json
root=Path.cwd();source=(root/'src/adaptive_resource_repair.rs').read_text();s=source.replace('pub seconds:f64}','pub seconds:f64,pub index_seconds:f64,pub clone_seconds:f64,pub check_seconds:f64,pub search_seconds:f64,pub target_steps:Vec<f64>}')
a=' let original=Repair::new(model);if !original.candidate_check(point)||!original.objective_reliable(point,model.objective(point)){return None;}'
b=' let phase=Instant::now();let original=Repair::new(model);stats.index_seconds+=phase.elapsed().as_secs_f64();let phase=Instant::now();let valid=original.candidate_check(point)&&original.objective_reliable(point,model.objective(point));stats.check_seconds+=phase.elapsed().as_secs_f64();if !valid{return None;}'
assert a in s;s=s.replace(a,b);s=s.replace(' let step=model.variables',' let mut step=model.variables',1);s=s.replace(' let mut work=model.clone();work.decimal_source=None;',' let phase=Instant::now();let mut work=model.clone();stats.clone_seconds+=phase.elapsed().as_secs_f64();work.decimal_source=None;',1);s=s.replace(' for trial in 0..16{',' let base_step=step;let growth=std::env::var("MIP_DIAGNOSTIC_TARGET_GROWTH").is_ok_and(|v|v=="1");\n for trial in 0..16{',1);s=s.replace('  let target=(value-step','  stats.target_steps.push(step);let target=(value-step',1)
a='  let mut repair=Repair::new(&work);let candidate=if incremental{repair.search_adaptive_incremental(&best,lower,upper,deadline,budget.saturating_sub(stats.work),trial)}else{repair.search_adaptive(&best,lower,upper,deadline,budget.saturating_sub(stats.work),trial)};'
b='  let phase=Instant::now();let mut repair=Repair::new(&work);stats.index_seconds+=phase.elapsed().as_secs_f64();let phase=Instant::now();let candidate=if incremental{repair.search_adaptive_incremental(&best,lower,upper,deadline,budget.saturating_sub(stats.work),trial)}else{repair.search_adaptive(&best,lower,upper,deadline,budget.saturating_sub(stats.work),trial)};stats.search_seconds+=phase.elapsed().as_secs_f64();'
assert a in s;s=s.replace(a,b);s=s.replace('  let Some(x)=candidate else{break;};','  let Some(x)=candidate else{if growth&&step>base_step{step=(step*0.5).max(base_step);continue;}break;};',1)
a='  if !original.candidate_check(&x)||!original.objective_reliable(&x,model.objective(&x)){break;}'
b='  let phase=Instant::now();let valid=original.candidate_check(&x)&&original.objective_reliable(&x,model.objective(&x));stats.check_seconds+=phase.elapsed().as_secs_f64();if !valid{break;}'
assert a in s;s=s.replace(a,b);s=s.replace('  best=x;value=next;stats.improvements+=1;','  best=x;value=next;stats.improvements+=1;if growth{let doubled=step*2.;if doubled.is_finite(){step=doubled;}}',1)
path=root/'examples/support/profile_adaptive_resource_repair.rs';path.parent.mkdir(exist_ok=True);path.write_text(s)
# Compile an isolated copy of the crate modules so crate-private acceptance guards are unchanged.
head=(root/'src/lib.rs').read_text()
def module(m):
 name=m.group(2);target=Path('src')/(name+'.rs')
 if not target.exists():target=Path('src')/name/'mod.rs'
 assert target.exists(),target
 selected='support/profile_adaptive_resource_repair.rs'if name=='adaptive_resource_repair'else'../'+str(target)
 return f'#[path="{selected}"]\n{m.group(1)}mod {name};'
head=re.sub(r'(?m)^(pub(?:\(crate\))?\s+)?mod\s+(\w+);',lambda m:module(type('M',(),{'group':lambda self,i:(''if m.group(1)is None else m.group(1))if i==1 else m.group(2)})()),head)
main=r'''
fn main(){
 let a:Vec<_>=std::env::args().collect();assert_eq!(a.len(),5);let model=mps::read(&a[1]).unwrap();let seed:serde_json::Value=serde_json::from_slice(&std::fs::read(&a[2]).unwrap()).unwrap();let point:Vec<_>=model.variables.iter().map(|v|seed["values"][&v.name].as_f64().unwrap()).collect();assert!(heuristic::Repair::new(&model).candidate_check(&point));let seconds:f64=a[3].parse().unwrap();let lower:Vec<_>=model.variables.iter().map(|v|v.lower.map(|x|if v.integer{x.ceil()}else{x})).collect();let upper:Vec<_>=model.variables.iter().map(|v|v.upper.map(|x|if v.integer{x.floor()}else{x})).collect();let mut stats=adaptive_resource_repair::Stats::default();let start=std::time::Instant::now();let result=adaptive_resource_repair::search_incremental(&model,&point,&lower,&upper,start+std::time::Duration::from_secs_f64(seconds),512*1024*1024,&mut stats);let point=result.unwrap_or(point);let objective=model.objective(&point);let values:std::collections::BTreeMap<_,_>=model.variables.iter().zip(point).map(|(v,x)|(v.name.clone(),x)).collect();let value=serde_json::json!({"status":"primal_candidate","objective":objective,"dual_bound":null,"values":values,"diagnostic_stats":stats,"search_wall_seconds":start.elapsed().as_secs_f64(),"library_source_fingerprint":BUILD_SOURCE_FINGERPRINT,"purpose":"standalone continuation; parsing and seed validation outside search time; no bound/optimality claim"});std::fs::write(&a[4],serde_json::to_vec_pretty(&value).unwrap()).unwrap();println!("{}",serde_json::json!({"objective":objective,"stats":value["diagnostic_stats"]}));
}
'''
(root/'examples/adaptive_repair_profile.rs').write_text(head+main);(root/'artifacts/adaptive-target-growth-profile-source.json').write_text(json.dumps(dict(base_adaptive_source_sha256=hashlib.sha256(source.encode()).hexdigest(),profile_adaptive_source_sha256=hashlib.sha256(s.encode()).hexdigest(),example_sha256=hashlib.sha256((head+main).encode()).hexdigest(),production_source_unchanged=True),indent=2))
