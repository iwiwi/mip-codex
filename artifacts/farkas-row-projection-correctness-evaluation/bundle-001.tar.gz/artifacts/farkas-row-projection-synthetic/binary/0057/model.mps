NAME synthetic
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 E r2
 E r3
 L r4
 L r5
 L r6
 E r7
 G r8
 E r9
 E r10
 L r11
COLUMNS
 x0 obj 3
 x0 r0 -1
 x0 r1 -2
 x0 r2 3
 x0 r3 -4
 x0 r4 3
 x0 r5 2
 x0 r7 4
 x0 r8 -4
 x0 r9 -4
 x0 r10 -4
 x1 obj 4
 x1 r0 -3
 x1 r1 4
 x1 r2 -1
 x1 r3 -3
 x1 r4 2
 x1 r6 -4
 x1 r7 4
 x1 r9 -2
 x1 r10 -3
 x1 r11 -2
 x2 obj 5
 x2 r0 4
 x2 r1 -4
 x2 r3 3
 x2 r4 -3
 x2 r5 4
 x2 r6 -4
 x2 r7 4
 x2 r8 -4
 x2 r9 1
 x2 r10 -2
 x2 r11 -1
 x3 obj 0
 x3 r0 -1
 x3 r1 -1
 x3 r2 -4
 x3 r3 1
 x3 r4 1
 x3 r5 -1
 x3 r6 -4
 x3 r8 1
 x3 r9 4
 x3 r10 3
 x3 r11 -4
 x4 obj 1
 x4 r0 4
 x4 r1 -3
 x4 r2 4
 x4 r3 -2
 x4 r4 1
 x4 r5 3
 x4 r6 -4
 x4 r7 -4
 x4 r9 2
 x4 r10 -3
 x5 obj -4
 x5 r0 -1
 x5 r1 -1
 x5 r2 2
 x5 r3 3
 x5 r4 3
 x5 r6 3
 x5 r7 1
 x5 r8 4
 x5 r9 -3
 x5 r10 -3
 x5 r11 -3
 x6 obj -3
 x6 r0 2
 x6 r1 1
 x6 r2 4
 x6 r3 4
 x6 r4 -4
 x6 r5 -1
 x6 r6 -4
 x6 r7 1
 x6 r9 -2
 x6 r10 4
 x6 r11 3
 x7 obj 5
 x7 r0 -4
 x7 r1 2
 x7 r2 3
 x7 r4 3
 x7 r5 4
 x7 r6 -1
 x7 r7 -1
 x7 r8 4
 x7 r9 -4
 x7 r10 3
 x7 r11 -2
RHS
 rhs obj -3
 rhs r0 -3
 rhs r1 -6
 rhs r2 -3
 rhs r3 4
 rhs r4 4
 rhs r5 8
 rhs r6 -4
 rhs r7 9
 rhs r8 -3
 rhs r9 0
 rhs r10 -5
 rhs r11 -9
BOUNDS
 LI bounds x0 0
 UP bounds x0 1
 LI bounds x1 0
 UP bounds x1 1
 LI bounds x2 0
 UP bounds x2 1
 LI bounds x3 0
 UP bounds x3 1
 LI bounds x4 0
 UP bounds x4 1
 LI bounds x5 0
 UP bounds x5 1
 LI bounds x6 0
 UP bounds x6 1
 LI bounds x7 0
 UP bounds x7 1
ENDATA
