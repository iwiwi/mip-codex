NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 E r1
 E r2
 L r3
 G r4
 G r5
COLUMNS
 x0 obj -2
 x0 r0 -1
 x0 r1 -4
 x0 r2 -3
 x0 r3 -1
 x0 r4 4
 x0 r5 -2
 x1 obj -2
 x1 r0 3
 x1 r1 -3
 x1 r2 1
 x1 r3 1
 x1 r4 4
 x1 r5 -3
 x2 obj 5
 x2 r0 -1
 x2 r1 -1
 x2 r2 -3
 x2 r4 4
 x3 obj -4
 x3 r1 1
 x3 r2 2
 x3 r4 3
 x3 r5 3
 x4 obj 5
 x4 r2 1
 x4 r3 -4
 x4 r4 -1
 x4 r5 -2
RHS
 rhs obj -2
 rhs r0 1
 rhs r1 -8
 rhs r2 -4
 rhs r3 -3
 rhs r4 10
 rhs r5 -7
BOUNDS
 LI bounds x0 0
 UP bounds x0 1
 LI bounds x1 0
 UP bounds x1 1
 LI bounds x2 0
 UP bounds x2 1
 LI bounds x3 0
 UP bounds x3 1
 LI bounds x4 0
 UP bounds x4 1
ENDATA
