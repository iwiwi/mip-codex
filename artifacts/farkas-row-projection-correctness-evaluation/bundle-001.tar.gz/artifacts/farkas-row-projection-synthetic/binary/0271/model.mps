NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 E r1
 G r2
 E r3
 L r4
COLUMNS
 x0 obj -1
 x0 r0 -3
 x0 r1 -4
 x0 r2 -1
 x0 r3 -1
 x0 r4 -4
 x1 obj 5
 x1 r0 1
 x1 r1 3
 x1 r2 -3
 x1 r3 3
 x1 r4 3
 x2 obj -5
 x2 r0 1
 x2 r1 3
 x2 r2 -4
 x2 r3 -1
 x2 r4 -2
 x3 obj 4
 x3 r1 2
 x3 r2 2
 x3 r3 -3
 x3 r4 1
 x4 obj 1
 x4 r2 3
 x4 r3 -1
 x4 r4 4
RHS
 rhs obj -2
 rhs r0 -2
 rhs r1 0
 rhs r2 -2
 rhs r3 0
 rhs r4 0
BOUNDS
 LI bounds x0 0
 UP bounds x0 1
 LI bounds x1 0
 UP bounds x1 1
 LI bounds x2 0
 UP bounds x2 1
 LI bounds x3 0
 UP bounds x3 1
 LI bounds x4 0
 UP bounds x4 1
ENDATA
