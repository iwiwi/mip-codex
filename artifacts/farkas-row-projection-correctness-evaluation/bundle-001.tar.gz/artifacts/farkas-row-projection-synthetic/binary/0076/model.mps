NAME synthetic
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 E r1
 E r2
 G r3
 G r4
 G r5
COLUMNS
 x0 obj 1
 x0 r0 -4
 x0 r1 -2
 x0 r3 2
 x0 r4 -3
 x0 r5 -1
 x1 obj -3
 x1 r0 -2
 x1 r1 1
 x1 r2 -1
 x1 r3 1
 x1 r4 3
 x1 r5 -4
 x2 obj 1
 x2 r0 4
 x2 r1 1
 x2 r2 -4
 x2 r3 -2
 x2 r4 -2
 x2 r5 3
 x3 obj -5
 x3 r0 -3
 x3 r1 -3
 x3 r3 2
 x3 r4 3
 x4 obj 2
 x4 r0 4
 x4 r1 -4
 x4 r3 2
 x4 r4 -1
 x4 r5 4
RHS
 rhs obj -4
 rhs r0 8
 rhs r1 -3
 rhs r2 -4
 rhs r3 -5
 rhs r4 -7
 rhs r5 7
BOUNDS
 LI bounds x0 0
 UP bounds x0 1
 LI bounds x1 0
 UP bounds x1 1
 LI bounds x2 0
 UP bounds x2 1
 LI bounds x3 0
 UP bounds x3 1
 LI bounds x4 0
 UP bounds x4 1
ENDATA
