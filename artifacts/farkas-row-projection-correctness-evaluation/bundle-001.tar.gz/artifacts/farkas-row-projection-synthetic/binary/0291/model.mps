NAME synthetic
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 E r3
 E r4
COLUMNS
 x0 obj -3
 x0 r2 3
 x0 r3 1
 x0 r4 -4
 x1 obj 1
 x1 r0 1
 x1 r1 2
 x1 r2 -1
 x1 r3 4
 x1 r4 -1
 x2 obj 0
 x2 r0 2
 x2 r1 1
 x2 r2 -1
 x2 r3 -1
 x2 r4 4
 x3 obj 1
 x3 r1 3
 x3 r2 -1
 x3 r4 -2
 x4 obj 5
 x4 r0 -3
 x4 r1 -4
 x4 r2 -1
 x4 r3 4
 x4 r4 2
RHS
 rhs obj 4
 rhs r0 -5
 rhs r1 4
 rhs r2 0
 rhs r3 1
 rhs r4 -6
BOUNDS
 LI bounds x0 0
 UP bounds x0 1
 LI bounds x1 0
 UP bounds x1 1
 LI bounds x2 0
 UP bounds x2 1
 LI bounds x3 0
 UP bounds x3 1
 LI bounds x4 0
 UP bounds x4 1
ENDATA
