NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 E r1
 L r2
 E r3
 G r4
 E r5
 E r6
 E r7
COLUMNS
 x0 obj 1
 x0 r1 4
 x0 r3 1
 x0 r4 -2
 x0 r5 -2
 x0 r6 -4
 x1 obj -4
 x1 r0 3
 x1 r1 -1
 x1 r2 -3
 x1 r3 -1
 x1 r4 -3
 x1 r5 -1
 x1 r6 -3
 x1 r7 -1
 x2 obj 0
 x2 r0 1
 x2 r1 3
 x2 r2 2
 x2 r3 -3
 x2 r4 2
 x2 r5 -2
 x2 r6 -2
 x2 r7 1
 x3 obj 0
 x3 r0 1
 x3 r1 -1
 x3 r2 2
 x3 r3 4
 x3 r4 1
 x3 r5 -1
 x3 r6 3
 x4 obj -2
 x4 r0 -1
 x4 r1 -3
 x4 r2 -3
 x4 r3 2
 x4 r4 4
 x4 r5 1
 x4 r7 2
 x5 obj -4
 x5 r0 -4
 x5 r1 -3
 x5 r2 -3
 x5 r3 4
 x5 r4 -3
 x5 r5 2
 x5 r6 1
 x5 r7 -2
 x6 obj -4
 x6 r0 3
 x6 r1 -4
 x6 r2 -1
 x6 r3 -4
 x6 r4 -3
 x6 r5 -1
 x6 r6 2
 x6 r7 -2
RHS
 rhs obj 4
 rhs r0 5
 rhs r1 -4
 rhs r2 -1
 rhs r3 -3
 rhs r4 -4
 rhs r5 -1
 rhs r6 1
 rhs r7 -3
BOUNDS
 LI bounds x0 0
 UP bounds x0 1
 LI bounds x1 0
 UP bounds x1 1
 LI bounds x2 0
 UP bounds x2 1
 LI bounds x3 0
 UP bounds x3 1
 LI bounds x4 0
 UP bounds x4 1
 LI bounds x5 0
 UP bounds x5 1
 LI bounds x6 0
 UP bounds x6 1
ENDATA
