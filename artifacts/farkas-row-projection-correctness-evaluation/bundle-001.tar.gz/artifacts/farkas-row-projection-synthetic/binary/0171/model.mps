NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 L r1
 L r2
 E r3
 G r4
COLUMNS
 x0 obj 5
 x0 r0 -1
 x0 r2 3
 x0 r3 1
 x0 r4 -1
 x1 obj 3
 x1 r0 1
 x1 r1 -1
 x1 r2 1
 x1 r3 -4
 x1 r4 4
 x2 obj -2
 x2 r0 -4
 x2 r1 -2
 x2 r2 -4
 x2 r3 4
 x2 r4 3
 x3 obj 5
 x3 r2 -3
 x3 r3 4
 x4 obj 4
 x4 r0 -1
 x4 r1 2
 x4 r3 4
 x5 obj -3
 x5 r2 -2
 x5 r3 2
 x5 r4 4
RHS
 rhs obj 1
 rhs r0 1
 rhs r1 2
 rhs r2 4
 rhs r3 -2
 rhs r4 4
BOUNDS
 LI bounds x0 0
 UP bounds x0 1
 LI bounds x1 0
 UP bounds x1 1
 LI bounds x2 0
 UP bounds x2 1
 LI bounds x3 0
 UP bounds x3 1
 LI bounds x4 0
 UP bounds x4 1
 LI bounds x5 0
 UP bounds x5 1
ENDATA
