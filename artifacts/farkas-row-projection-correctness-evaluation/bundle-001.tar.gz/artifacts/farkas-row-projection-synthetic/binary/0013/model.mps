NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 L r1
 L r2
 E r3
 E r4
 G r5
 E r6
COLUMNS
 x0 obj 0
 x0 r0 -2
 x0 r1 3
 x0 r2 4
 x0 r4 2
 x0 r5 -4
 x0 r6 -1
 x1 obj 0
 x1 r0 -3
 x1 r1 -1
 x1 r2 -3
 x1 r3 -1
 x1 r4 3
 x1 r5 2
 x1 r6 1
 x2 obj -1
 x2 r1 4
 x2 r2 -4
 x2 r3 1
 x2 r5 1
 x2 r6 4
 x3 obj 3
 x3 r0 4
 x3 r2 -2
 x3 r3 -2
 x3 r4 4
 x3 r5 4
 x3 r6 -3
 x4 obj -5
 x4 r0 3
 x4 r1 4
 x4 r2 1
 x4 r4 -2
 x4 r5 -4
 x4 r6 -2
RHS
 rhs obj 1
 rhs r0 3
 rhs r1 11
 rhs r2 0
 rhs r3 1
 rhs r4 -2
 rhs r5 -6
 rhs r6 2
BOUNDS
 LI bounds x0 0
 UP bounds x0 1
 LI bounds x1 0
 UP bounds x1 1
 LI bounds x2 0
 UP bounds x2 1
 LI bounds x3 0
 UP bounds x3 1
 LI bounds x4 0
 UP bounds x4 1
ENDATA
