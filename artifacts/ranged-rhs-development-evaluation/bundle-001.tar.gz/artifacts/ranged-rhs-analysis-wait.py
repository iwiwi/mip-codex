from pathlib import Path
import json,time,subprocess
root=Path.cwd();end=time.monotonic()+600;audit=root/'artifacts/ranged-rhs-development-parallel-audit'
while not(audit/'summary.json').exists():
 for p in audit.glob('worker-*-exit.json'):assert json.load(open(p))['status']=='complete'
 assert time.monotonic()<end,'audit wait timeout';time.sleep(2)
with(root/'artifacts/ranged-rhs-development-analysis.log').open('w')as f:subprocess.run([str(root/'.venv/bin/python'),'artifacts/ranged-rhs-development-analysis.py'],stdout=f,stderr=subprocess.STDOUT,check=True)
