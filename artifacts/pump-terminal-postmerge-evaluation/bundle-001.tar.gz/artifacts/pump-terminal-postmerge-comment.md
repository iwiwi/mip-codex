PR131は2026-11-18 11:57:41 UTCにmain50491628c09e75f1043abdee1ed825e3ab797094へ統合しました。primaryでFP93bddc12fc843734、CLI SHAca54107fe92ceb56309e14be2cbfdb18f9e1cdce8cbf9cbb95fc64360d4524afを確認。head対mainのsrc/scripts/tests/Cargo/build差は空、tracked main cleanです。

primary CPU44/16GiB/1threadで7出力すべて元GMP/strict proof valid。cod105根最適−12、生成5000pairs根最適−2500、depth guard512nodesを維持。各10秒の新修復3問はdrayage645963.1709289545/LB11714.141979211226、graph20−7/LB−37、h8026428.164941/LB5470.509918076841となり、各terminal_repair_candidates=1の回収を確認しました。mcschedは従来の打切り丸めで315585.00000001054/LB193774.75370663218となり、候補の309595とは異なります。点の変動を残し、同値再現とは主張しません。

旧final1759は未起動、configを変えずmain131でsupersededとの別receiptを追加。長roundの1時間評価が終わってから次snapshotを作成します。正式240問は未起動、全体優位・新記録は未達です。

その時点のAI資源量:
```json
{
  "sessions": 1,
  "totals": {
    "input_tokens": 1898685793,
    "cached_input_tokens": 1885044608,
    "output_tokens": 9454479,
    "reasoning_output_tokens": 5804531,
    "total_tokens": 1908140272
  },
  "note": "input_tokensはキャッシュ分を含む。reasoningはoutputの内数。ローカルログの最終記録まで。"
}
```
