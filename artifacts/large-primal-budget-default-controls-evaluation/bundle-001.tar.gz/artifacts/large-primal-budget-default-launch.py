from pathlib import Path
import os,time,json,subprocess,sys
os.sched_setaffinity(0,{43});root=Path.cwd();end=time.monotonic()+1800
while True:
 p=Path('artifacts/large-primal-budget-default-build-execution.json');rs=json.load(open(p))if p.exists()else[]
 assert all(r['exit_code']==0 and not r['low_disk_stop']for r in rs),rs
 if len(rs)==2:break
 assert time.monotonic()<end;time.sleep(2)
subprocess.run([sys.executable,'artifacts/large-primal-budget-default-freeze.py'],check=True)
subprocess.run([sys.executable,'artifacts/large-primal-budget-default-launch-screen.py'],check=True)
workers=[]
for name,args,cpu in [('main-controls',[],44),('long-controls',[],45),('large-generated',[],49),('parallel-audit',['large-primal-budget-default'],43)]:
 p=Path('artifacts/large-primal-budget-default-'+name+'.log')
 with p.open('w')as log:
  child=subprocess.Popen([sys.executable,'artifacts/large-primal-budget-default-'+name+'.py',*args],stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,MIP_AUDIT_CPUS='36,37,42,48'))
 workers.append(dict(name=name,pid=child.pid,log=str(p)))
with Path('artifacts/large-primal-budget-default-enumeration.log').open('w')as log:
 child=subprocess.Popen(['taskset','-c','41',sys.executable,'scripts/check_binary_graph.py','200'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,MIP_ABSOLUTE_CHECKER='/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker-absolute',MIP_GRAPH_DIR='artifacts/large-primal-budget-default-enumeration'))
workers.append(dict(name='enumeration',pid=child.pid));Path('artifacts/large-primal-budget-default-workers.json').write_text(json.dumps(workers,indent=2));print(json.dumps(workers),flush=True)
