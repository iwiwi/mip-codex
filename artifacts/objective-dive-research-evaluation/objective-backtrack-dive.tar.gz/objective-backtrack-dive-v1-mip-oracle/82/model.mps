NAME gomory
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj -3
 x0 r0 1
 x0 r1 2
 x0 r2 -2
 x0 r3 -2
 x0 r4 -3
 x0 r5 5
 x1 obj -5
 x1 r0 -1
 x1 r1 -3
 x1 r2 2
 x1 r3 -2
 x1 r4 -5
 x1 r5 -1
 x2 obj 5
 x2 r0 -3
 x2 r1 -1
 x2 r2 -2
 x2 r3 -4
 x2 r4 4
 x2 r5 -4
 x3 obj -1
 x3 r0 2
 x3 r1 3
 x3 r2 2
 x3 r3 -4
 x3 r5 1
RHS
 rhs r0 -5
 rhs r1 -4
 rhs r2 3
 rhs r3 -1
 rhs r4 18
 rhs r5 -17
BOUNDS
 LI b x0 -3
 UI b x0 -2
 LO b x1 -3
 UP b x1 0
 LI b x2 1
 UI b x2 3
 LO b x3 0
 UP b x3 1
ENDATA
