NAME gomory
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj -1
 x0 r0 -2
 x0 r1 -2
 x0 r2 -1
 x0 r3 3
 x0 r4 -5
 x0 r5 2
 x1 obj 0
 x1 r0 5
 x1 r1 2
 x1 r3 -1
 x1 r4 1
 x1 r5 -1
 x2 obj 3
 x2 r0 4
 x2 r1 4
 x2 r2 1
 x2 r3 -2
 x2 r4 1
 x2 r5 -4
 x3 obj 5
 x3 r0 3
 x3 r1 -1
 x3 r2 4
 x3 r3 -5
 x3 r5 3
 x4 obj -3
 x4 r0 -1
 x4 r1 3
 x4 r3 5
 x4 r4 -5
 x4 r5 -4
RHS
 rhs r0 20
 rhs r1 17
 rhs r2 17
 rhs r3 -14
 rhs r4 10
 rhs r5 -8
BOUNDS
 LO b x0 -3
 UP b x0 -1
 LI b x1 -1
 UI b x1 0
 LO b x2 1
 UP b x2 2
 LI b x3 1
 UI b x3 3
 LI b x4 0
 UI b x4 2
ENDATA
