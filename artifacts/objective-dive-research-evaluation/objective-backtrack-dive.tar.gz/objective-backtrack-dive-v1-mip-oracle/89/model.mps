NAME gomory
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj 4
 x0 r0 3
 x0 r1 3
 x0 r2 1
 x0 r3 -3
 x1 obj 7
 x1 r0 -4
 x1 r1 1
 x1 r2 1
 x2 obj 3
 x2 r1 -5
 x2 r2 -2
 x3 obj 2
 x3 r0 -1
 x3 r1 -5
 x3 r2 3
 x3 r3 -5
 x4 obj -1
 x4 r0 5
 x4 r1 -4
 x4 r2 3
 x4 r3 1
RHS
 rhs r0 -7
 rhs r1 18
 rhs r2 -6
 rhs r3 4
BOUNDS
 LO b x0 -1
 UP b x0 0
 LI b x1 -1
 UI b x1 2
 LO b x2 -1
 UP b x2 1
 LI b x3 -2
 UI b x3 0
 LI b x4 -2
 UI b x4 0
ENDATA
