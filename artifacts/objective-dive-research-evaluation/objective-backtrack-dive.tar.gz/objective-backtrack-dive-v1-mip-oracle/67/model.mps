NAME gomory
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x0 obj -1
 x0 r0 3
 x0 r1 -2
 x1 obj 6
 x1 r0 3
 x1 r1 -3
 x2 obj 2
 x2 r0 1
 x2 r1 -3
 x3 obj -6
 x3 r0 -2
 x3 r1 1
RHS
 rhs r0 3
 rhs r1 5
BOUNDS
 LO b x0 1
 UP b x0 3
 LO b x1 0
 UP b x1 2
 LI b x2 -3
 UI b x2 0
 LI b x3 1
 UI b x3 2
ENDATA
