NAME gomory
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj -3
 x0 r1 -3
 x0 r2 3
 x0 r3 -5
 x0 r4 -5
 x0 r5 3
 x1 obj -5
 x1 r0 5
 x1 r1 -1
 x1 r2 5
 x1 r3 5
 x1 r4 3
 x1 r5 5
 x2 obj 0
 x2 r0 -2
 x2 r1 1
 x2 r2 -5
 x2 r3 2
 x2 r4 4
 x2 r5 1
 x3 obj -5
 x3 r0 2
 x3 r1 1
 x3 r2 3
 x3 r3 5
 x3 r4 5
 x3 r5 -4
 x4 obj -1
 x4 r0 2
 x4 r2 2
 x4 r4 2
 x4 r5 5
 x5 obj 7
 x5 r0 -2
 x5 r1 5
 x5 r2 -2
 x5 r3 5
 x5 r4 -1
 x5 r5 -5
RHS
 rhs r0 21
 rhs r1 -8
 rhs r2 19
 rhs r3 8
 rhs r4 16
 rhs r5 21
BOUNDS
 LI b x0 -3
 UI b x0 0
 LI b x1 1
 UI b x1 3
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 1
 LI b x4 1
 UI b x4 2
 LO b x5 -2
 UP b x5 0
ENDATA
