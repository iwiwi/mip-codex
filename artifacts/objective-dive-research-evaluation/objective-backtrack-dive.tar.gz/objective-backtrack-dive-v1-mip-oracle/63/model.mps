NAME gomory
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
COLUMNS
 x0 obj 5
 x0 r0 -4
 x0 r1 -4
 x0 r2 2
 x0 r3 1
 x0 r4 -2
 x0 r5 5
 x0 r6 -4
 x0 r7 -4
 x1 obj -7
 x1 r1 -4
 x1 r2 2
 x1 r3 2
 x1 r4 -1
 x1 r5 3
 x1 r6 2
 x1 r7 -2
RHS
 rhs r0 4
 rhs r1 0
 rhs r2 3
 rhs r3 1
 rhs r4 4
 rhs r5 1
 rhs r6 6
 rhs r7 2
BOUNDS
 LI b x0 -3
 UI b x0 -1
 LO b x1 -1
 UP b x1 2
ENDATA
