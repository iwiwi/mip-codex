NAME gomory
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
COLUMNS
 x0 obj -4
 x0 r0 3
 x0 r1 -4
 x0 r2 2
 x0 r3 -2
 x0 r4 1
 x0 r5 4
 x0 r6 -1
 x0 r7 1
 x1 obj -3
 x1 r0 2
 x1 r1 -4
 x1 r2 2
 x1 r3 -2
 x1 r4 -3
 x1 r5 5
 x1 r6 -5
 x1 r7 5
 x2 obj 4
 x2 r0 -1
 x2 r1 5
 x2 r2 1
 x2 r3 3
 x2 r4 -2
 x2 r5 2
 x2 r6 2
 x2 r7 -2
 x3 obj 4
 x3 r0 5
 x3 r1 1
 x3 r2 -1
 x3 r3 3
 x3 r4 -4
 x3 r5 -5
 x3 r6 -5
 x4 obj -2
 x4 r0 -2
 x4 r1 4
 x4 r2 1
 x4 r3 -1
 x4 r5 4
 x4 r6 -5
 x4 r7 5
 x5 obj -4
 x5 r0 -5
 x5 r1 -5
 x5 r2 -2
 x5 r3 5
 x5 r4 5
 x5 r6 -2
 x5 r7 -3
RHS
 rhs r0 3
 rhs r1 -13
 rhs r2 6
 rhs r3 1
 rhs r4 14
 rhs r5 18
 rhs r6 -26
 rhs r7 16
BOUNDS
 LI b x0 1
 UI b x0 4
 LO b x1 -1
 UP b x1 0
 LI b x2 -2
 UI b x2 -1
 LI b x3 1
 UI b x3 2
 LO b x4 1
 UP b x4 3
 LI b x5 -1
 UI b x5 2
ENDATA
