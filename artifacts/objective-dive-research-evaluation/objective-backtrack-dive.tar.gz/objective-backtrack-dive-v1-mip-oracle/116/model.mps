NAME gomory
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
COLUMNS
 x0 obj 4
 x0 r0 2
 x0 r1 -4
 x0 r2 5
 x0 r3 -1
 x0 r4 -5
 x0 r5 -5
 x0 r6 -4
 x0 r7 3
 x1 obj 5
 x1 r1 4
 x1 r2 1
 x1 r3 -5
 x1 r4 -1
 x1 r6 3
 x1 r7 -1
 x2 obj 6
 x2 r0 4
 x2 r1 -3
 x2 r2 -1
 x2 r3 2
 x2 r4 5
 x2 r5 1
 x2 r6 1
 x2 r7 -5
 x3 obj -3
 x3 r0 -4
 x3 r1 3
 x3 r2 1
 x3 r3 2
 x3 r4 -5
 x3 r6 -1
 x3 r7 3
 x4 obj 3
 x4 r0 2
 x4 r1 5
 x4 r2 3
 x4 r4 -5
 x4 r5 2
 x4 r6 -2
 x4 r7 2
 x5 obj 2
 x5 r0 2
 x5 r1 4
 x5 r2 2
 x5 r3 -3
 x5 r4 3
 x5 r5 -2
 x5 r6 -5
 x5 r7 -2
RHS
 rhs r0 -14
 rhs r1 -14
 rhs r2 4
 rhs r3 19
 rhs r4 -11
 rhs r5 -6
 rhs r6 -10
 rhs r7 18
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 -3
 UI b x1 -1
 LI b x2 -3
 UI b x2 0
 LO b x3 0
 UP b x3 3
 LI b x4 -3
 UI b x4 -2
 LI b x5 0
 UI b x5 1
ENDATA
