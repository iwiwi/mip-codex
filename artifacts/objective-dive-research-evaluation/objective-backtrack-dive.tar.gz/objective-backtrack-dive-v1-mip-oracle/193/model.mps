NAME gomory
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
COLUMNS
 x0 obj 3
 x0 r0 -1
 x0 r2 5
 x0 r3 4
 x0 r4 5
 x0 r5 -5
 x0 r6 -3
 x1 obj -7
 x1 r0 -2
 x1 r1 -1
 x1 r2 1
 x1 r4 -2
 x1 r5 5
 x1 r6 2
 x2 obj 6
 x2 r0 5
 x2 r1 -3
 x2 r2 2
 x2 r3 -4
 x2 r4 -4
 x2 r5 -2
 x2 r6 5
 x3 obj 6
 x3 r0 -3
 x3 r2 4
 x3 r3 1
 x3 r4 -5
 x3 r5 -5
 x3 r6 1
 x4 obj -6
 x4 r0 2
 x4 r1 -1
 x4 r2 3
 x4 r4 4
 x4 r5 -2
 x4 r6 -2
RHS
 rhs r0 10
 rhs r1 -13
 rhs r2 26
 rhs r3 -2
 rhs r4 -9
 rhs r5 0
 rhs r6 21
BOUNDS
 LI b x0 0
 UI b x0 3
 LO b x1 1
 UP b x1 4
 LO b x2 1
 UP b x2 4
 LI b x3 -1
 UI b x3 1
 LI b x4 -1
 UI b x4 2
ENDATA
