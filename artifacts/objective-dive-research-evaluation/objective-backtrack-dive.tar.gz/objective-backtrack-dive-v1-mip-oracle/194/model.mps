NAME gomory
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x0 obj -6
 x0 r0 3
 x0 r1 3
 x1 obj -5
 x1 r1 3
 x2 obj 6
 x2 r0 2
 x2 r1 -4
RHS
 rhs r0 5
 rhs r1 8
BOUNDS
 LO b x0 0
 UP b x0 2
 LI b x1 1
 UI b x1 4
 LI b x2 0
 UI b x2 2
ENDATA
