NAME gomory
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj -2
 x0 r1 1
 x0 r2 -1
 x0 r3 -2
 x0 r4 1
 x0 r5 -3
 x1 obj -2
 x1 r0 -3
 x1 r1 -4
 x1 r2 -3
 x1 r3 -4
 x1 r4 -2
 x1 r5 -3
RHS
 rhs r0 -2
 rhs r1 -5
 rhs r2 -5
 rhs r3 -7
 rhs r4 1
 rhs r5 -5
BOUNDS
 LO b x0 1
 UP b x0 4
 LI b x1 1
 UI b x1 2
ENDATA
