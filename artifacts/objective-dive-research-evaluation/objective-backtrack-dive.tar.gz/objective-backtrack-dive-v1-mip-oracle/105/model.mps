NAME gomory
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj -2
 x0 r0 -2
 x0 r1 -3
 x0 r2 2
 x0 r3 3
 x1 obj -3
 x1 r0 2
 x1 r1 -4
 x1 r2 -2
 x1 r3 3
 x2 obj -1
 x2 r0 3
 x2 r2 -3
 x2 r3 -1
RHS
 rhs r0 -2
 rhs r1 -7
 rhs r2 7
 rhs r3 12
BOUNDS
 LI b x0 0
 UI b x0 2
 LO b x1 0
 UP b x1 2
 LI b x2 -1
 UI b x2 2
ENDATA
