NAME gomory
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj -4
 x0 r0 5
 x0 r1 1
 x0 r2 5
 x0 r3 -4
 x1 obj -2
 x1 r0 -5
 x1 r1 1
 x1 r2 -1
 x1 r3 2
 x2 obj -6
 x2 r0 -3
 x2 r1 -1
 x2 r2 1
 x2 r3 5
 x3 obj 5
 x3 r0 1
 x3 r1 5
 x3 r3 -2
 x4 obj -4
 x4 r0 -3
 x4 r1 4
 x4 r3 -5
 x5 obj -2
 x5 r0 -4
 x5 r1 -5
 x5 r2 5
 x5 r3 -4
RHS
 rhs r0 -34
 rhs r1 8
 rhs r2 -3
 rhs r3 9
BOUNDS
 LI b x0 -3
 UI b x0 -2
 LO b x1 -2
 UP b x1 0
 LI b x2 1
 UI b x2 3
 LI b x3 -1
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LO b x5 -1
 UP b x5 2
ENDATA
