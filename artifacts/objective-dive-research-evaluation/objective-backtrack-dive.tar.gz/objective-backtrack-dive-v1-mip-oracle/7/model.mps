NAME gomory
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
COLUMNS
 x0 obj 6
 x0 r0 1
 x0 r1 5
 x0 r2 2
 x0 r3 5
 x0 r4 -2
 x1 obj -3
 x1 r0 -2
 x1 r1 5
 x1 r2 2
 x1 r3 2
 x1 r4 1
 x2 obj 1
 x2 r0 3
 x2 r1 -3
 x2 r2 1
 x2 r3 -3
 x2 r4 4
RHS
 rhs r0 0
 rhs r1 10
 rhs r2 -1
 rhs r3 13
 rhs r4 -7
BOUNDS
 LI b x0 0
 UI b x0 1
 LO b x1 -3
 UP b x1 0
 LI b x2 -2
 UI b x2 0
ENDATA
