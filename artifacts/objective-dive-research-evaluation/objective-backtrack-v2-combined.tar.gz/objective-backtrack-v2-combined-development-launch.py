from pathlib import Path
import json,subprocess,time,os
root=Path.cwd();os.sched_setaffinity(0,{45});started={};old=root/'artifacts/objective-backtrack-v1-combined-development-screen';out=root/'artifacts/objective-backtrack-v2-combined-development-screen'
while len(started)<5:
 for shard,cpu in enumerate(range(3,8)):
  if shard in started:continue
  p=old/f'worker-{shard}-exit.json'
  if not p.exists():continue
  assert json.loads(p.read_text())['status']=='complete';f=(out/f'worker-{shard}.log').open('w');run=subprocess.Popen(['python3','artifacts/objective-backtrack-v2-combined-development-screen.py',str(cpu),str(shard),'5'],stdout=f,stderr=subprocess.STDOUT,start_new_session=True);f.close();started[shard]=dict(cpu=cpu,pid=run.pid);(out/'workers.json').write_text(json.dumps(started,indent=2)+'\n')
 time.sleep(1)
(out/'launch-exit.json').write_text(json.dumps(dict(status='complete'))+'\n')
