import sys,runpy,resource
from pathlib import Path
r=Path('/home/ubuntu/mip-codex');resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));sys.path.insert(0,str(r/'artifacts/resource-primal-v1-diagnostic/scripts'));import verify_cover_cuts,verify_zero_dominance
sys.path.insert(0,str(r/'scripts'));runpy.run_path(str(r/'scripts/audit_smoke_solutions.py'),run_name='__main__')
