from pathlib import Path
import os,json,subprocess,resource,hashlib,time
r=Path.cwd();out=r/'artifacts/active-row-feasibility-empty-v1';out.mkdir();manifest={m['name']:m for m in json.loads((r/'data/manifest.json').read_text())['instances']};binary=r/'artifacts/active-row-feasibility-v1/bin/active_row_primal';os.sched_setaffinity(0,{44});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));names=['savsched1.mps.gz','map10.mps.gz','neos-5104907-jarama.mps.gz','neos-3402454-bohle.mps.gz']
for name in names:
 m=manifest[name];assert m['split']=='development';model=r/m['path'];assert hashlib.sha256(model.read_bytes()).hexdigest()==m['sha256'];d=out/name;d.mkdir();initial=d/'initial.json';initial.write_text(json.dumps(dict(indices=[]))+'\n');p=initial;cmd=['/usr/bin/time','-v','-o',str(d/'resource.log'),str(binary),str(model),str(initial),'20','1'];(d/'job.json').write_text(json.dumps(dict(command=cmd,cpu=44,seconds=20,threads=1,memory_bytes=16*1024**3,input_sha256=m['sha256'],binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),initial_source=str(p),initial_sha256=hashlib.sha256(initial.read_bytes()).hexdigest()),indent=2)+'\n');start=time.monotonic()
 with(d/'stdout.jsonl').open('w')as f,(d/'stderr.log').open('w')as e:q=subprocess.run(cmd,stdout=f,stderr=e,timeout=80)
 (d/'exit.json').write_text(json.dumps(dict(exit_code=q.returncode,wall_seconds=time.monotonic()-start))+'\n');print(name,q.returncode,flush=True)
(out/'exit.json').write_text(json.dumps(dict(status='complete'))+'\n')
