from pathlib import Path
from fractions import Fraction as F
import json,subprocess,sys,os,hashlib,shutil
r=Path.cwd();sys.path.insert(0,'scripts');from verify_cover_cuts import exact_model
out=r/'artifacts/active-row-primal-oracle';out.mkdir();binary=Path('/home/ubuntu/mip-phase-two/target/release/examples/active_row_primal');frozen=out/'bin/active_row_primal';frozen.parent.mkdir();shutil.copy2(binary,frozen);shutil.copy2('/home/ubuntu/mip-phase-two/examples/active_row_primal.rs',out/'source.rs');(out/'build-info.json').write_bytes(subprocess.check_output([str(frozen),'build-info']));(out/'sha256.json').write_text(json.dumps(dict(binary=hashlib.sha256(frozen.read_bytes()).hexdigest()))+'\n');os.sched_setaffinity(0,{41});(out/'initial.json').write_text(json.dumps(dict(indices=[0]))+'\n');records=[]
for case in range(4):
 for maximize in [0,1]:
  model=r/f'artifacts/master-bound-default-mip-oracle/{case}-{maximize}/model.mps';d=out/f'{case}-{maximize}';d.mkdir();p=subprocess.run([str(frozen),str(model),str(out/'initial.json'),'2'],capture_output=True,text=True,timeout=62);(d/'stdout.jsonl').write_text(p.stdout);(d/'stderr.log').write_text(p.stderr);assert p.returncode==0;data=[json.loads(l)for l in p.stdout.splitlines()];point=next((x for x in data if x['stage']=='original_candidate'),None);assert point is not None,(case,maximize,data);names,variables,rows,cost,offset=exact_model(model,True);x={n:F(str(point['values'][n]))for n in names};tol=F(1,1000000)
  for n,v in variables.items():assert(v['lower']is None or x[n]>=v['lower']-tol)and(v['upper']is None or x[n]<=v['upper']+tol)and(not v['integer']or abs(x[n]-round(x[n]))<=tol)
  for row in rows:
   lhs=sum(a*x[n]for n,a in row['coefficients'].items());assert(row['lower']is None or lhs>=row['lower']-tol)and(row['upper']is None or lhs<=row['upper']+tol)
  objective=offset+sum(c*x[n]for n,c in cost.items());assert abs(objective-F(str(point['objective'])))<=F(1,10**8)*(1+abs(objective));record=dict(case=case,maximize=maximize,valid=True,objective=point['objective'],rounds=sum(d['stage']=='subset'for d in data));records.append(record);(d/'validation.json').write_text(json.dumps(record)+'\n')
(out/'summary.json').write_text(json.dumps(dict(outputs=len(records),valid=len(records),independent_templates=4))+'\n');print(dict(outputs=len(records),valid=len(records)))
