from pathlib import Path
import subprocess,hashlib,json
root=Path.cwd();backup=Path('/tmp/rational-primal-main119-untracked');assert not backup.exists();backup.mkdir();names=subprocess.check_output(['git','diff','--name-only','--diff-filter=A','-z','HEAD..origin/main']).decode().split('\0');records=[]
for name in names:
 if not name:continue
 p=root/name
 if not p.is_file():continue
 tracked=subprocess.run(['git','ls-files','--error-unmatch','--',name],capture_output=True)
 if tracked.returncode==0:continue
 blob=subprocess.check_output(['git','show','origin/main:'+name]);assert hashlib.sha256(blob).digest()==hashlib.sha256(p.read_bytes()).digest(),name;q=backup/name;q.parent.mkdir(parents=True,exist_ok=True);p.rename(q);records.append(dict(path=name,sha256=hashlib.sha256(blob).hexdigest(),backup=str(q)))
Path('artifacts/rational-primal-witness-main-collision-recovery.json').write_text(json.dumps(dict(files=records,reason='pull stopped on byte-identical untracked archives; preserve copies then retry; old-source snapshot never launched'),indent=2))
subprocess.run(['git','pull','--ff-only'],check=True,stdout=Path('artifacts/rational-primal-witness-main-pull-v2.log').open('w'),stderr=subprocess.STDOUT)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='4f5daba80481da431f66c9868b8f7b1793390cc1';print('main updated; identical files moved',len(records))
