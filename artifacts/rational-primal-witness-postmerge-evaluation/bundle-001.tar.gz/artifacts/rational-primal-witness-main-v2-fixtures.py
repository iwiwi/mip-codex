from pathlib import Path
import json,subprocess,os,sys,copy
root=Path.cwd();frozen=root;sys.path.insert(0,str(frozen/'scripts'))
from verify_primal_witness import verify
from verify_cover_cuts import validate_cut_proofs
from benchmark_common import atomic_json,sha256
sys.path.insert(0,str(root/'scripts'));from validate_solution import validate
out=root/'artifacts/rational-primal-witness-main-v2-fixtures';out.mkdir();binary=root/'target/release/mip-codex';cases=[]
cases.append(('third','NAME third\nROWS\n N obj\n E r\nCOLUMNS\n y obj 1 r 3\nRHS\n rhs r 1\nENDATA\n',True))
cases.append(('fixed','NAME fixed\nROWS\n N obj\nCOLUMNS\n y obj 1\nRHS\n rhs obj 0\nBOUNDS\n FX b y .3\nENDATA\n',True))
cases.append(('decimal-integer','NAME decimal\nROWS\n N obj\n L cap\nCOLUMNS\n x obj -1 cap .1\nRHS\n rhs cap .3\nBOUNDS\n LI b x 0\n UI b x 3\nENDATA\n',True))
cases.append(('three-rows','NAME three\nROWS\n N obj\n L a\n L b\n L c\nCOLUMNS\n x obj -1 a 3\n z obj -1 c 3\n t a 2 b -1\n u b 3 c -6\nRHS\n rhs a 3 b 0\n rhs c 1\nBOUNDS\n BV bd x\n BV bd z\n FR bd t\n FR bd u\nENDATA\n',True))
for p in sorted((root/'artifacts/implied-boundary-final-pilot').glob('*/model.mps')):cases.append(('bad-'+p.parent.name,p.read_text(),False))
records=[];tampered=0
for name,text,good in cases:
 d=out/name;d.mkdir();m=d/'model.mps';m.write_text(text);env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};p=subprocess.run(['taskset','-c','42',str(binary),'solve',str(m),'2'],env=env,capture_output=True,text=True,timeout=62);(d/'result.json').write_text(p.stdout);(d/'stderr.log').write_text(p.stderr);assert p.returncode==0;r=json.loads(p.stdout);assert r['status']==('optimal'if good else'numerical_error'),(name,r['status'])
 if good and name!='three-rows':assert r.get('rational_primal_proof')is not None,(name,'missing proof')
 elif not good:assert r.get('rational_primal_proof')is None and r['dual_bound']is None and r['gap']is None
 proof=verify(m,r);atomic_json(d/'primal-proof-validation.json',proof);assert proof['valid']is True
 cut=validate_cut_proofs(m,r);atomic_json(d/'proof-validation.json',cut);assert cut['valid']is True,(name,cut)
 v=validate(m,r);atomic_json(d/'validation.json',v);assert v['valid']is True
 if good and r.get('rational_primal_proof',{}).get('values'):
  for edit in ['numerator','denominator','index','bool-index','duplicate','noncanonical','schema','empty','objective','dual','point','missing-variable']:
   bad=copy.deepcopy(r);entries=bad['rational_primal_proof']['values'];entry=entries[0]
   if edit=='numerator':entry['numerator']=str(int(entry['numerator'])+1)
   elif edit=='denominator':entry['denominator']='0'
   elif edit=='index':entry['variable']=-1
   elif edit=='bool-index':entry['variable']=False
   elif edit=='duplicate':entries.append(copy.deepcopy(entry))
   elif edit=='noncanonical':entry['numerator']='00'
   elif edit=='schema':entry['extra']=0
   elif edit=='empty':entries.clear()
   elif edit=='objective':bad['objective']+=.01
   elif edit=='dual':bad['dual_bound']+=.01
   elif edit=='point':bad['values'][next(iter(bad['values']))]+=.01
   else:bad['values'].pop(next(iter(bad['values'])))
   try:verify(m,bad)
   except (ValueError,AssertionError):tampered+=1
   else:raise AssertionError((name,'accepted tamper',edit))
 records.append(dict(name=name,status=r['status'],objective=r['objective'],primal_proof=proof,point_valid=True,result_sha256=sha256(d/'result.json')))
atomic_json(out/'summary.json',dict(outputs=len(records),points_valid=len(records),tampered_rejected=tampered,records=records));print({k:v for k,v in json.loads((out/'summary.json').read_text()).items()if k!='records'})
