from pathlib import Path
import hashlib,json,tarfile
root=Path.cwd();out=root/'artifacts/rational-primal-witness-postmerge-evaluation';assert not out.exists();out.mkdir();paths=set()
patterns=['rational-primal-witness-main-*','rational-primal-witness-final-create*','rational-primal-witness-final-snapshot-verification.json','rational-primal-witness-main-collision-recovery.json','rational-primal-witness-recover-main*','rational-primal-witness-postmerge-*','rational-primal-witness-pr-*','rational-primal-witness-final-pr-*','rational-primal-witness-final-ai-usage.json']
for pattern in patterns:
 for p in (root/'artifacts').glob(pattern):
  if p==out or p.name=='rational-primal-witness-postmerge-archive-run.log':continue
  if p.is_file():paths.add(p)
  elif p.is_dir():paths.update(q for q in p.rglob('*')if q.is_file())
for name in ['rational-primal-final-20261117','rational-primal-final-20261117-v2']:
 run=root/'artifacts/runs'/name;paths.add(run/'config.json');paths.update(p for p in (run/'snapshot').rglob('*')if p.is_file());p=run/'OBSOLETE.json'
 if p.exists():paths.add(p)
ledger=[];excluded=[]
for p in sorted(paths):
 assert not p.is_symlink();r=dict(path=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 with p.open('rb')as f:elf=f.read(4)==b'\x7fELF'
 (excluded if elf else ledger).append(r)
bundle=out/'bundle-001.tar.gz'
with tarfile.open(bundle,'w:gz',compresslevel=6)as t:
 for r in ledger:t.add(root/r['path'],arcname=r['path'],recursive=False)
with tarfile.open(bundle,'r:gz')as t:
 assert len(t.getmembers())==len(ledger)
 for m,r in zip(t.getmembers(),ledger):
  assert m.name==r['path'];data=t.extractfile(m).read();assert len(data)==r['bytes']and hashlib.sha256(data).hexdigest()==r['sha256']
(out/'manifest.json').write_text(json.dumps(ledger,indent=2));(out/'excluded-elf.json').write_text(json.dumps(excluded,indent=2));s=dict(files=len(ledger),raw_bytes=sum(r['bytes']for r in ledger),compressed_bytes=bundle.stat().st_size,excluded_elfs=len(excluded),all_payload_sha256_verified=True,bundle_sha256=hashlib.sha256(bundle.read_bytes()).hexdigest());(out/'summary.json').write_text(json.dumps(s,indent=2));print(s)
p=root/'experiments/rational-primal-snapshot-20261117.json';p.parent.mkdir(exist_ok=True);p.write_bytes((root/'artifacts/rational-primal-witness-final-snapshot-verification.json').read_bytes())
