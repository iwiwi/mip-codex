from pathlib import Path
import sys,os,json,argparse
sys.path.insert(0,'scripts');import benchmark
root=Path.cwd();old=json.loads((root/'artifacts/runs/integer-bound-safety-final-20261117/config.json').read_text());solvers=sorted({j['solver']for j in old['jobs']});assert len(solvers)==1
# future workersのCPU検査後、hash計算・copy・cgroup準備はCPU43だけで行う。
original=benchmark.require_solver_origin
def pinned_origin(*args,**kwargs):
 os.sched_setaffinity(0,{43});return original(*args,**kwargs)
benchmark.require_solver_origin=pinned_origin
args=argparse.Namespace(directory=str(root/'artifacts/runs/rational-primal-final-20261117'),seconds=old['seconds'],cores=','.join(map(str,old['cores'])),solvers=','.join(solvers),manifest=str(root/'data/manifest.json'),names=None,allow_dirty=False)
benchmark.create(args)
