NAME rational
OBJSENSE
 MIN
ROWS
 N obj
 E row
COLUMNS
 y obj 1e-20 row 3
RHS
 rhs row -3 obj -0.3
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
