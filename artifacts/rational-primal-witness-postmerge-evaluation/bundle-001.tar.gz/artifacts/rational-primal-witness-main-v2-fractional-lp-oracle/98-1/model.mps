NAME rational
OBJSENSE
 MAX
ROWS
 N obj
 E row
COLUMNS
 y obj -0.2 row 7
RHS
 rhs row -5 obj -0.3
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
