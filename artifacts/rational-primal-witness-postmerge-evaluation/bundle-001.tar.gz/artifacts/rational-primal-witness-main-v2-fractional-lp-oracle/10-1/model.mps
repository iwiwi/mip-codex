NAME rational
OBJSENSE
 MAX
ROWS
 N obj
 E row
COLUMNS
 y obj 0.1 row 3
RHS
 rhs row -6 obj -0
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
