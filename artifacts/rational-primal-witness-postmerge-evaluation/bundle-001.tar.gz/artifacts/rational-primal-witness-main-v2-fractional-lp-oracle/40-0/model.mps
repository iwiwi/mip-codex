NAME rational
OBJSENSE
 MIN
ROWS
 N obj
 E row
COLUMNS
 y obj 1.00000000000000000001 row 9
RHS
 rhs row -5 obj -0
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
