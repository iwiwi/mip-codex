NAME rational
OBJSENSE
 MIN
ROWS
 N obj
 E row
COLUMNS
 y obj -3 row 2
RHS
 rhs row -3 obj -0.3
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
