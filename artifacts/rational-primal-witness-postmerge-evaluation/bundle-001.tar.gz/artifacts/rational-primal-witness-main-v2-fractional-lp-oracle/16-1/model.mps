NAME rational
OBJSENSE
 MAX
ROWS
 N obj
 E row
COLUMNS
 y obj 1 row 5
RHS
 rhs row -2 obj -0.3
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
