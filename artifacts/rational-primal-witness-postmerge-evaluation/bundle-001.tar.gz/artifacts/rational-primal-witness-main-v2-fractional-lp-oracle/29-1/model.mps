NAME rational
OBJSENSE
 MAX
ROWS
 N obj
 E row
COLUMNS
 y obj 2 row 6
RHS
 rhs row 7 obj -0
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
