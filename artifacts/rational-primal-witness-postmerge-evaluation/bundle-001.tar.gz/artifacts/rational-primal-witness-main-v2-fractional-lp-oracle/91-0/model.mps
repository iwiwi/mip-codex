NAME rational
OBJSENSE
 MIN
ROWS
 N obj
 E row
COLUMNS
 y obj 1.00000000000000000001 row 1
RHS
 rhs row -7 obj 0.7
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
