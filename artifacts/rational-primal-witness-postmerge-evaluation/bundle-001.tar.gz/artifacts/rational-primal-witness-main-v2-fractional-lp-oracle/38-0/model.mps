NAME rational
OBJSENSE
 MIN
ROWS
 N obj
 E row
COLUMNS
 y obj 1 row 5
RHS
 rhs row -5 obj -1.00000000000000000001
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
