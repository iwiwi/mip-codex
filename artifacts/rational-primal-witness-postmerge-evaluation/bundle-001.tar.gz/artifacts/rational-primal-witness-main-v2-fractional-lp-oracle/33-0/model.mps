NAME rational
OBJSENSE
 MIN
ROWS
 N obj
 E row
COLUMNS
 y obj -1 row 1
RHS
 rhs row 0 obj -0
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
