NAME rational
OBJSENSE
 MAX
ROWS
 N obj
 E row
COLUMNS
 y obj -0.2 row 5
RHS
 rhs row -3 obj 0.7
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
