NAME rational
OBJSENSE
 MIN
ROWS
 N obj
 E row
COLUMNS
 y obj 1e-20 row 2
RHS
 rhs row 8 obj -0.3
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
