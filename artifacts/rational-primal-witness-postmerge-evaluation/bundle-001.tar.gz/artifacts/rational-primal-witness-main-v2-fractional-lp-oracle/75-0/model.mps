NAME rational
OBJSENSE
 MIN
ROWS
 N obj
 E row
COLUMNS
 y obj 1D-1 row 8
RHS
 rhs row -5 obj -0
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
