NAME rational
OBJSENSE
 MAX
ROWS
 N obj
 E row
COLUMNS
 y obj 1D-1 row 4
RHS
 rhs row -5 obj 0.7
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
