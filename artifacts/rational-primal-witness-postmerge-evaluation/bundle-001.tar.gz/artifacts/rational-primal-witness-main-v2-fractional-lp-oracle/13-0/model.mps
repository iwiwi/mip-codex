NAME rational
OBJSENSE
 MIN
ROWS
 N obj
 E row
COLUMNS
 y obj -0.2 row 6
RHS
 rhs row -6 obj -1.00000000000000000001
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
