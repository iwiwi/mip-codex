NAME rational
OBJSENSE
 MIN
ROWS
 N obj
 E row
COLUMNS
 y obj -1 row 9
RHS
 rhs row 4 obj 0.7
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
