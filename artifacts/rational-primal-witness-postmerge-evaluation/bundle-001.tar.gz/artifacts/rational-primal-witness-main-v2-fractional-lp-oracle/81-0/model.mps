NAME rational
OBJSENSE
 MIN
ROWS
 N obj
 E row
COLUMNS
 y obj -1 row 2
RHS
 rhs row 7 obj 0.7
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
