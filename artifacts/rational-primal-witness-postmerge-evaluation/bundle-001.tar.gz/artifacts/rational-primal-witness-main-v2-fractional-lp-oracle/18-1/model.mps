NAME rational
OBJSENSE
 MAX
ROWS
 N obj
 E row
COLUMNS
 y obj -0.2 row 8
RHS
 rhs row -1 obj -0
BOUNDS
 LO b y -10
 UP b y 10
ENDATA
