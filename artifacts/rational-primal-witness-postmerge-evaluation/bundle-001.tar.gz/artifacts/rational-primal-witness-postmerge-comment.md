main統合後確認: 4f5daba80481da431f66c9868b8f7b1793390cc1を主作業木で再buildし、通常/library FP7f49a5e2b0e69aedを確認しました。有理LP200例は172optimal/28numerical、厳密dual違反0、162証拠有効。固定9例とscaled/変数境界11例も期待通りで、合計218候補点が元MPSのGMP絶対検査に成功しました。

ローカルpullが同内容の未追跡アーカイブとの衝突で停止したのに、後続処理を止めず旧13db版を再buildした準備ミスがありました。指紋検査で発見し、衝突16ファイルとincoming Git blobの全SHA一致を確認して/tmpへ退避し、正しいmainへ更新して検証をやり直しました。最初のrational-primal-final-20261117は旧版・未起動でOBSOLETEを記録し、上書きせず保持しています。

正しい新create-only全240snapshotはrational-primal-final-20261117-v2。config SHA256 80ec62c19a08e28b843ffbe84001c5378d8c029d48629a95dc8bd4fb89e48c6c、109snapshotファイルと147共有libを全SHA照合済み。各3600秒・1thread・16GiB・CPU8..15、準備hash/copyはCPU43。worker未起動・cgroup空、共有libは前snapshotと全て同一で、実行中native比較を変更していません。最終Rustは11月19日UTC目安、期限11月22日14:59 UTCを維持。性能の総合優位/新記録はありません。

AI資源量（コメント直前累積、1 sessions）: total 1,540,239,544, input 1,532,739,554（cached 1,521,786,368を含む）, output 7,499,990（reasoning 4,601,035を含む）。内数二重加算なし。
