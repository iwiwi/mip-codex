NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 L r1
 G r2
 E r3
 E r4
COLUMNS
 x0 obj -4
 x0 r0 0.5
 x0 r1 -0.6
 x0 r2 0.2
 x0 r3 0.5
 x0 r4 0.8
 x1 obj 5
 x1 r0 0.1
 x1 r1 -0.5
 x1 r2 -0.7
 x1 r4 -0.5
 x2 obj -2
 x2 r0 0.2
 x2 r1 0.3
 x2 r2 -0.1
 x2 r3 0.5
 x2 r4 0.6
 x3 obj 3
 x3 r0 0.2
 x3 r1 0.4
 x3 r3 0.1
 x3 r4 -0.7
 x4 obj -4
 x4 r0 0.7
 x4 r1 0.7
 x4 r2 0.5
 x4 r3 -0.5
 x4 r4 0.2
 x5 obj 0
 x5 r0 -0.7
 x5 r1 -0.5
 x5 r2 -0.9
 x5 r3 0.6
 x5 r4 -0.6
 x6 obj -3
 x6 r0 0.9
 x6 r2 0.1
 x6 r4 0.4
 x7 obj -1
 x7 r0 0.7
 x7 r1 0.5
 x7 r2 0.6
 x7 r3 0.2
 x7 r4 0.9
RHS
 rhs obj 0
 rhs r0 0.29
 rhs r1 0.34
 rhs r2 -0.09
 rhs r3 0.5
 rhs r4 0.64
BOUNDS
 LI bounds x0 0
 UP bounds x0 1
 LI bounds x1 0
 UP bounds x1 1
 LI bounds x2 0
 UP bounds x2 1
 LI bounds x3 0
 UP bounds x3 1
 LI bounds x4 0
 UP bounds x4 1
 LI bounds x5 0
 UP bounds x5 1
 LO bounds x6 -0.2
 UP bounds x6 0.7
 LO bounds x7 -0.6
 UP bounds x7 1.3
ENDATA
