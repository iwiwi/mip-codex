from pathlib import Path
import sys,json,subprocess,os
root=Path.cwd();sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256
os.environ['MIP_ABSOLUTE_CHECKER']='/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker-absolute'
out=root/'artifacts/general-recovery-synthetic-followup';out.mkdir();main=Path('/home/ubuntu/mip-codex/artifacts/farkas-row-projection-main-primary-audit/bin/mip-codex');records=[]
for case in [43,171]:
 model=root/f'artifacts/general-recovery-synthetic/recovered/{case:04d}/model.mps';env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_PRIMAL_REPAIR='0',MIP_PRIMAL_PROBE='0',MIP_LP_DIVING='0',MIP_BOX_PRIMAL='0',MIP_OBJECTIVE_LP_DIVE='0')
 d=out/str(case)/'main';d.mkdir(parents=True);r=json.loads(subprocess.check_output([str(main),'solve',str(model),'10'],env=env));atomic_json(d/'result.json',r)
 for label,result in [('main',d/'result.json')]+[(k,root/f'artifacts/general-recovery-synthetic/{k}/{case:04d}/result.json')for k in ['baseline','recovered']]:
  audit=out/str(case)/label/'audit';audit.mkdir(parents=True)
  with(audit/'log').open('w')as f:subprocess.run([str(root/'.venv/bin/python'),'scripts/benchmark_validate.py',str(model),str(result),'/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker',str(audit)],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=600)
  v=json.load(open(result));validation={k:json.load(open(audit/f'{k}-validation.json'))['valid']for k in ['strict','official']};records.append(dict(case=case,label=label,status=v['status'],objective=v['objective'],dual=v['dual_bound'],validation=validation));atomic_json(out/'records.json',records)
atomic_json(out/'exit.json',dict(status='complete',main_sha256=sha256(main),records=records))
