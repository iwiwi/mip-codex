NAME synthetic
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 E r1
 E r2
 L r3
 E r4
 L r5
COLUMNS
 x0 obj 0
 x0 r1 -1
 x0 r2 3
 x0 r3 4
 x0 r4 -3
 x0 r5 4
 x1 obj 3
 x1 r0 4
 x1 r2 -2
 x1 r3 -4
 x1 r4 -1
 x1 r5 -3
 x2 obj 3
 x2 r0 -3
 x2 r1 -1
 x2 r2 2
 x2 r3 4
 x2 r4 -1
 x2 r5 2
 x3 obj 1
 x3 r0 -3
 x3 r1 -4
 x3 r2 4
 x3 r3 3
 x3 r4 -1
 x3 r5 -2
 x4 obj 3
 x4 r0 -2
 x4 r1 1
 x4 r2 3
 x4 r3 3
 x4 r5 3
 x5 obj 0
 x5 r0 3
 x5 r4 2
 x5 r5 -4
 x6 obj 3
 x6 r0 4
 x6 r1 -4
 x6 r2 3
 x6 r3 4
 x6 r4 3
 x6 r5 1
 x7 obj -5
 x7 r0 -1
 x7 r1 -3
 x7 r2 -1
 x7 r4 -1
 x7 r5 -3
RHS
 rhs obj -3
 rhs r0 3
 rhs r1 -7
 rhs r2 4
 rhs r3 5
 rhs r4 -5
 rhs r5 -9
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LI bounds x3 0
 UP bounds x3 3
 LI bounds x4 0
 UP bounds x4 3
 LI bounds x5 0
 UP bounds x5 3
 LO bounds x6 -2
 UP bounds x6 3
 LO bounds x7 -1
 UP bounds x7 2
ENDATA
