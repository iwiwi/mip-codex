NAME synthetic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 G r4
 L r5
COLUMNS
 x0 obj 3
 x0 r0 3
 x0 r1 -1
 x0 r2 2
 x0 r3 3
 x0 r4 -2
 x0 r5 -4
 x1 obj 4
 x1 r0 -3
 x1 r1 -3
 x1 r2 1
 x1 r3 -3
 x1 r4 -1
 x1 r5 -2
 x2 obj -4
 x2 r0 -4
 x2 r1 -4
 x2 r2 3
 x2 r3 -3
 x2 r4 2
 x2 r5 2
 x3 obj -1
 x3 r0 2
 x3 r1 1
 x3 r2 2
 x3 r3 4
 x3 r4 2
 x3 r5 -3
 x4 obj -4
 x4 r0 1
 x4 r1 -4
 x4 r2 -3
 x4 r3 1
 x4 r4 -1
 x4 r5 -3
RHS
 rhs obj 1
 rhs r0 0
 rhs r1 -13
 rhs r2 0
 rhs r3 1
 rhs r4 -5
 rhs r5 -17
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LO bounds x3 -2
 UP bounds x3 3
 LO bounds x4 -1
 UP bounds x4 2
ENDATA
