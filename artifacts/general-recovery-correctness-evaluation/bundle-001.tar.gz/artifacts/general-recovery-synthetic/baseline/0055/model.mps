NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 E r4
 L r5
 E r6
 L r7
COLUMNS
 x0 obj 0
 x0 r0 -4
 x0 r2 -1
 x0 r3 -2
 x0 r4 -2
 x0 r5 -1
 x0 r6 -3
 x1 obj -4
 x1 r0 -2
 x1 r1 1
 x1 r2 -1
 x1 r3 1
 x1 r4 3
 x1 r5 2
 x1 r6 -1
 x1 r7 -4
 x2 obj 4
 x2 r0 4
 x2 r1 1
 x2 r2 1
 x2 r3 3
 x2 r4 -2
 x2 r5 -4
 x2 r6 1
 x2 r7 4
 x3 obj 2
 x3 r0 -4
 x3 r1 4
 x3 r2 1
 x3 r3 4
 x3 r4 -1
 x3 r6 2
 x3 r7 2
 x4 obj 5
 x4 r0 2
 x4 r1 -4
 x4 r2 1
 x4 r3 3
 x4 r4 -3
 x4 r6 -1
 x4 r7 4
 x5 obj -5
 x5 r0 3
 x5 r1 4
 x5 r2 -2
 x5 r3 4
 x5 r4 4
 x5 r5 -2
 x5 r6 1
 x5 r7 3
 x6 obj 3
 x6 r1 4
 x6 r2 1
 x6 r3 1
 x6 r4 -1
 x6 r5 4
 x6 r6 3
 x6 r7 -2
RHS
 rhs obj -1
 rhs r0 -29
 rhs r1 7
 rhs r2 12
 rhs r3 13
 rhs r4 -21
 rhs r5 12
 rhs r6 -2
 rhs r7 0
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LI bounds x3 0
 UP bounds x3 3
 LI bounds x4 0
 UP bounds x4 3
 LO bounds x5 -2
 UP bounds x5 3
 LO bounds x6 -1
 UP bounds x6 2
ENDATA
