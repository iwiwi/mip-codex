NAME synthetic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 E r4
 E r5
 L r6
 L r7
 L r8
COLUMNS
 x0 obj 5
 x0 r1 -4
 x0 r2 -4
 x0 r3 -4
 x0 r5 1
 x0 r6 4
 x0 r8 3
 x1 obj -1
 x1 r0 4
 x1 r1 2
 x1 r2 -2
 x1 r3 1
 x1 r4 -4
 x1 r5 -1
 x1 r7 1
 x1 r8 -2
 x2 obj -2
 x2 r0 2
 x2 r1 1
 x2 r2 2
 x2 r3 2
 x2 r4 -1
 x2 r5 -2
 x2 r6 -2
 x2 r8 1
 x3 obj -1
 x3 r1 1
 x3 r2 3
 x3 r3 3
 x3 r4 -1
 x3 r5 -3
 x3 r6 -2
 x3 r7 4
 x4 obj 2
 x4 r0 4
 x4 r1 2
 x4 r2 4
 x4 r3 2
 x4 r4 2
 x4 r7 1
 x4 r8 4
RHS
 rhs obj -4
 rhs r0 19
 rhs r1 9
 rhs r2 13
 rhs r3 15
 rhs r4 -4
 rhs r5 -11
 rhs r6 -8
 rhs r7 11
 rhs r8 8
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LO bounds x3 -2
 UP bounds x3 3
 LO bounds x4 -1
 UP bounds x4 2
ENDATA
