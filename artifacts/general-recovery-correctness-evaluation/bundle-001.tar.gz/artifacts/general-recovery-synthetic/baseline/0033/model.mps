NAME synthetic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 E r1
 E r2
 L r3
 L r4
 E r5
 G r6
 L r7
 E r8
COLUMNS
 x0 obj -4
 x0 r0 1
 x0 r1 4
 x0 r3 -4
 x0 r4 4
 x0 r7 4
 x0 r8 1
 x1 obj -3
 x1 r0 -4
 x1 r1 4
 x1 r2 -1
 x1 r3 2
 x1 r4 2
 x1 r5 -1
 x1 r6 3
 x1 r7 1
 x1 r8 -4
 x2 obj -4
 x2 r0 1
 x2 r1 -2
 x2 r2 -3
 x2 r3 3
 x2 r4 2
 x2 r5 -4
 x2 r6 1
 x2 r7 3
 x2 r8 1
 x3 obj -1
 x3 r0 3
 x3 r1 1
 x3 r2 -1
 x3 r3 -1
 x3 r4 4
 x3 r5 1
 x3 r7 -4
 x3 r8 -4
 x4 obj 5
 x4 r0 1
 x4 r1 2
 x4 r2 3
 x4 r3 1
 x4 r4 1
 x4 r5 -2
 x4 r6 -2
 x4 r8 2
RHS
 rhs obj 3
 rhs r0 11
 rhs r1 1
 rhs r2 -7
 rhs r3 6
 rhs r4 17
 rhs r5 -7
 rhs r6 -1
 rhs r7 6
 rhs r8 -1
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LO bounds x3 -2
 UP bounds x3 3
 LO bounds x4 -1
 UP bounds x4 2
ENDATA
