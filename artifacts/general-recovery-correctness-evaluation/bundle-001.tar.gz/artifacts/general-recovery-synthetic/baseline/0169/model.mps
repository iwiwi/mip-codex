NAME synthetic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 E r1
 L r2
 G r3
 E r4
 L r5
 L r6
 L r7
 E r8
COLUMNS
 x0 obj -5
 x0 r0 4
 x0 r1 -2
 x0 r2 1
 x0 r3 4
 x0 r4 -1
 x0 r5 1
 x0 r6 -3
 x0 r7 4
 x0 r8 1
 x1 obj -5
 x1 r0 -1
 x1 r2 4
 x1 r3 1
 x1 r4 -2
 x1 r6 4
 x1 r7 2
 x1 r8 -2
 x2 obj 5
 x2 r0 -4
 x2 r1 3
 x2 r3 4
 x2 r4 -2
 x2 r5 -1
 x2 r7 3
 x2 r8 4
 x3 obj -3
 x3 r1 -3
 x3 r2 4
 x3 r3 3
 x3 r5 -3
 x3 r6 1
 x3 r7 2
 x3 r8 -4
 x4 obj -4
 x4 r0 2
 x4 r1 3
 x4 r2 -2
 x4 r3 -1
 x4 r4 -1
 x4 r5 1
 x4 r6 3
 x4 r7 3
 x5 obj -1
 x5 r0 2
 x5 r2 3
 x5 r3 4
 x5 r4 -4
 x5 r5 2
 x5 r6 1
 x5 r7 1
 x5 r8 3
 x6 obj -4
 x6 r1 3
 x6 r2 3
 x6 r3 -3
 x6 r5 -1
 x6 r6 -1
 x6 r7 -4
 x6 r8 2
 x7 obj -4
 x7 r0 2
 x7 r1 1
 x7 r2 -1
 x7 r3 -1
 x7 r4 2
 x7 r5 1
 x7 r6 1
 x7 r7 2
 x7 r8 -1
RHS
 rhs obj 3
 rhs r0 21
 rhs r1 -8
 rhs r2 27
 rhs r3 29
 rhs r4 -15
 rhs r5 0
 rhs r6 -3
 rhs r7 22
 rhs r8 5
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LI bounds x3 0
 UP bounds x3 3
 LI bounds x4 0
 UP bounds x4 3
 LI bounds x5 0
 UP bounds x5 3
 LO bounds x6 -2
 UP bounds x6 3
 LO bounds x7 -1
 UP bounds x7 2
ENDATA
