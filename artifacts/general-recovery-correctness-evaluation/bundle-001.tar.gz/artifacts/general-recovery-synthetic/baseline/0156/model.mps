NAME synthetic
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 E r1
 L r2
 G r3
 G r4
 E r5
 E r6
 L r7
 E r8
 E r9
 G r10
COLUMNS
 x0 obj 0
 x0 r0 1
 x0 r1 -3
 x0 r2 -3
 x0 r3 3
 x0 r4 3
 x0 r6 -3
 x0 r7 -3
 x0 r8 1
 x0 r9 -3
 x0 r10 -2
 x1 obj 3
 x1 r0 -3
 x1 r1 -2
 x1 r2 -3
 x1 r3 3
 x1 r4 -1
 x1 r5 -4
 x1 r6 4
 x1 r7 -3
 x1 r8 1
 x1 r9 1
 x1 r10 -2
 x2 obj 2
 x2 r1 -3
 x2 r2 2
 x2 r3 1
 x2 r4 4
 x2 r5 -2
 x2 r7 -4
 x2 r8 -4
 x2 r9 -1
 x2 r10 -2
 x3 obj -4
 x3 r1 2
 x3 r2 3
 x3 r4 -4
 x3 r5 -3
 x3 r6 1
 x3 r7 -1
 x3 r9 1
 x3 r10 3
 x4 obj 3
 x4 r0 3
 x4 r1 -1
 x4 r2 -3
 x4 r3 -1
 x4 r4 -1
 x4 r5 -2
 x4 r6 4
 x4 r7 -3
 x4 r8 4
RHS
 rhs obj 0
 rhs r0 -3
 rhs r1 -12
 rhs r2 -8
 rhs r3 6
 rhs r4 -2
 rhs r5 -23
 rhs r6 21
 rhs r7 -19
 rhs r8 3
 rhs r9 2
 rhs r10 -12
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LO bounds x3 -2
 UP bounds x3 3
 LO bounds x4 -1
 UP bounds x4 2
ENDATA
