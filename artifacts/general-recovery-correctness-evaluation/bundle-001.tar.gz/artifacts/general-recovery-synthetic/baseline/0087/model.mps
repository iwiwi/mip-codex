NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 L r4
 L r5
 G r6
 L r7
 L r8
 E r9
 L r10
COLUMNS
 x0 obj 1
 x0 r0 -1
 x0 r1 1
 x0 r2 2
 x0 r3 -4
 x0 r4 1
 x0 r5 -4
 x0 r6 -3
 x0 r7 3
 x0 r8 -2
 x0 r9 -3
 x0 r10 -2
 x1 obj -4
 x1 r0 -4
 x1 r1 -2
 x1 r3 -2
 x1 r4 2
 x1 r5 1
 x1 r6 -2
 x1 r7 -1
 x1 r8 3
 x1 r9 2
 x1 r10 1
 x2 obj -4
 x2 r0 2
 x2 r1 -3
 x2 r2 -1
 x2 r3 2
 x2 r4 -4
 x2 r5 1
 x2 r6 -3
 x2 r7 1
 x2 r8 -4
 x2 r9 -3
 x3 obj 5
 x3 r0 2
 x3 r4 1
 x3 r5 4
 x3 r6 -2
 x3 r7 -4
 x3 r8 4
 x3 r9 -4
 x3 r10 -1
 x4 obj 4
 x4 r2 2
 x4 r3 -3
 x4 r4 -2
 x4 r5 4
 x4 r6 -3
 x4 r7 -3
 x4 r8 4
 x4 r9 -4
 x4 r10 -4
 x5 obj 2
 x5 r0 -2
 x5 r1 -4
 x5 r2 4
 x5 r3 -2
 x5 r4 4
 x5 r5 -1
 x5 r6 -4
 x5 r7 3
 x5 r8 4
 x5 r9 -4
 x5 r10 2
RHS
 rhs obj 3
 rhs r0 -9
 rhs r1 -12
 rhs r2 9
 rhs r3 -21
 rhs r4 1
 rhs r5 14
 rhs r6 -43
 rhs r7 -2
 rhs r8 15
 rhs r9 -32
 rhs r10 -6
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LI bounds x3 0
 UP bounds x3 3
 LO bounds x4 -2
 UP bounds x4 3
 LO bounds x5 -1
 UP bounds x5 2
ENDATA
