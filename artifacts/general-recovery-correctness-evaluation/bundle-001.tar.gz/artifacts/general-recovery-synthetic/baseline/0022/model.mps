NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 E r1
 G r2
 G r3
 L r4
 L r5
 G r6
 L r7
 E r8
 G r9
 G r10
 L r11
COLUMNS
 x0 obj -4
 x0 r1 1
 x0 r2 -4
 x0 r3 4
 x0 r4 3
 x0 r5 4
 x0 r6 4
 x0 r7 1
 x0 r9 2
 x0 r10 4
 x0 r11 -3
 x1 obj 0
 x1 r0 3
 x1 r1 -2
 x1 r2 -2
 x1 r4 -2
 x1 r5 -3
 x1 r6 3
 x1 r7 2
 x1 r8 -4
 x1 r9 -2
 x1 r10 1
 x1 r11 3
 x2 obj -5
 x2 r0 3
 x2 r1 2
 x2 r2 2
 x2 r3 2
 x2 r5 -2
 x2 r7 -2
 x2 r9 -1
 x2 r11 4
 x3 obj 5
 x3 r0 1
 x3 r1 -4
 x3 r2 4
 x3 r3 -3
 x3 r4 2
 x3 r5 -4
 x3 r6 2
 x3 r7 2
 x3 r8 -4
 x3 r9 3
 x3 r10 4
 x3 r11 4
 x4 obj 2
 x4 r2 2
 x4 r3 2
 x4 r4 -2
 x4 r5 -4
 x4 r6 3
 x4 r7 -2
 x4 r8 1
 x4 r9 -4
 x4 r10 -2
 x4 r11 -1
RHS
 rhs obj 0
 rhs r0 13
 rhs r1 -5
 rhs r2 2
 rhs r3 6
 rhs r4 -2
 rhs r5 -13
 rhs r6 17
 rhs r7 4
 rhs r8 -10
 rhs r9 -8
 rhs r10 5
 rhs r11 14
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LO bounds x3 -2
 UP bounds x3 3
 LO bounds x4 -1
 UP bounds x4 2
ENDATA
