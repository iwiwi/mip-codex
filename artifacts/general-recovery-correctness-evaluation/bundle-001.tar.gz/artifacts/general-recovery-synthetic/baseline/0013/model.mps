NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 E r2
 L r3
 G r4
COLUMNS
 x0 obj 2
 x0 r0 2
 x0 r1 3
 x0 r2 -1
 x0 r3 4
 x0 r4 1
 x1 obj 5
 x1 r0 -1
 x1 r2 1
 x1 r3 -4
 x1 r4 1
 x2 obj -3
 x2 r0 -3
 x2 r1 1
 x2 r3 4
 x2 r4 -2
 x3 obj -2
 x3 r0 -4
 x3 r1 2
 x3 r2 2
 x3 r3 -3
 x3 r4 -4
 x4 obj -3
 x4 r0 -3
 x4 r1 -4
 x4 r2 -2
 x4 r3 1
 x4 r4 -4
RHS
 rhs obj 1
 rhs r0 -9
 rhs r1 13
 rhs r2 3
 rhs r3 13
 rhs r4 -11
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LO bounds x3 -2
 UP bounds x3 3
 LO bounds x4 -1
 UP bounds x4 2
ENDATA
