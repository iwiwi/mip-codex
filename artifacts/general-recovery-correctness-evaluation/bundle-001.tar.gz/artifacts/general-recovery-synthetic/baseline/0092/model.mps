NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 E r1
 L r2
 E r3
 G r4
COLUMNS
 x0 obj 1
 x0 r0 -4
 x0 r1 -2
 x0 r2 4
 x0 r3 -3
 x0 r4 -4
 x1 obj 0
 x1 r1 4
 x1 r2 3
 x1 r4 2
 x2 obj 1
 x2 r0 -2
 x2 r1 1
 x2 r2 1
 x2 r3 -1
 x3 obj -2
 x3 r1 4
 x3 r2 -4
 x3 r3 3
 x3 r4 4
 x4 obj 5
 x4 r2 -1
 x4 r3 1
 x4 r4 3
 x5 obj 5
 x5 r1 -2
 x5 r2 -2
 x5 r3 -3
 x5 r4 -2
RHS
 rhs obj -2
 rhs r0 -6
 rhs r1 -1
 rhs r2 -2
 rhs r3 -8
 rhs r4 -8
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LI bounds x3 0
 UP bounds x3 3
 LO bounds x4 -2
 UP bounds x4 3
 LO bounds x5 -1
 UP bounds x5 2
ENDATA
