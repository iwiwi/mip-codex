NAME synthetic
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 E r1
 L r2
 G r3
 E r4
 E r5
 E r6
 G r7
 L r8
 L r9
 G r10
COLUMNS
 x0 obj -3
 x0 r0 -3
 x0 r1 2
 x0 r2 3
 x0 r5 -3
 x0 r6 4
 x0 r8 2
 x0 r9 1
 x0 r10 -1
 x1 obj 0
 x1 r1 -2
 x1 r2 2
 x1 r3 3
 x1 r4 -3
 x1 r5 2
 x1 r6 -3
 x1 r7 -2
 x1 r9 -4
 x1 r10 -3
 x2 obj -2
 x2 r0 -1
 x2 r1 -4
 x2 r2 -1
 x2 r3 1
 x2 r4 3
 x2 r5 -4
 x2 r6 2
 x2 r7 4
 x2 r8 1
 x2 r9 4
 x2 r10 4
 x3 obj 1
 x3 r0 -4
 x3 r1 1
 x3 r3 4
 x3 r4 -2
 x3 r5 4
 x3 r6 2
 x3 r9 2
 x3 r10 -4
 x4 obj -3
 x4 r0 2
 x4 r1 2
 x4 r2 1
 x4 r3 -1
 x4 r4 -3
 x4 r5 2
 x4 r6 -1
 x4 r7 2
 x4 r8 4
 x4 r9 -3
 x4 r10 2
RHS
 rhs obj 0
 rhs r0 -17
 rhs r1 9
 rhs r2 19
 rhs r3 15
 rhs r4 -18
 rhs r5 11
 rhs r6 10
 rhs r7 -3
 rhs r8 15
 rhs r9 -1
 rhs r10 -20
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LO bounds x3 -2
 UP bounds x3 3
 LO bounds x4 -1
 UP bounds x4 2
ENDATA
