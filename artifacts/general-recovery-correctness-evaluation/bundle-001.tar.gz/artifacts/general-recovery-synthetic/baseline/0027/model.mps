NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 E r2
 L r3
 G r4
 L r5
 L r6
 L r7
 E r8
 E r9
COLUMNS
 x0 obj 4
 x0 r0 -4
 x0 r1 -4
 x0 r2 -4
 x0 r3 2
 x0 r4 -4
 x0 r5 4
 x0 r7 1
 x0 r8 4
 x0 r9 -4
 x1 obj 2
 x1 r0 -4
 x1 r1 4
 x1 r2 1
 x1 r3 3
 x1 r4 2
 x1 r5 4
 x1 r6 1
 x1 r7 -1
 x1 r8 -3
 x1 r9 3
 x2 obj 5
 x2 r0 4
 x2 r1 4
 x2 r3 -3
 x2 r4 -4
 x2 r5 4
 x2 r6 1
 x2 r7 -3
 x2 r8 1
 x2 r9 3
 x3 obj 0
 x3 r0 -1
 x3 r1 2
 x3 r2 -4
 x3 r3 2
 x3 r4 -1
 x3 r5 -3
 x3 r6 3
 x3 r7 4
 x3 r9 1
 x4 obj -2
 x4 r0 -1
 x4 r1 -2
 x4 r2 -1
 x4 r3 -1
 x4 r5 -3
 x4 r7 1
 x4 r8 2
 x4 r9 3
 x5 obj -5
 x5 r0 -2
 x5 r1 1
 x5 r3 -4
 x5 r4 -1
 x5 r5 -4
 x5 r6 -4
 x5 r7 -1
 x5 r9 1
 x6 obj 4
 x6 r0 2
 x6 r2 3
 x6 r3 -2
 x6 r4 -4
 x6 r5 2
 x6 r6 -1
 x6 r7 4
 x6 r8 3
 x6 r9 2
 x7 obj 4
 x7 r0 2
 x7 r1 4
 x7 r2 4
 x7 r3 -2
 x7 r4 4
 x7 r5 3
 x7 r6 -3
 x7 r7 4
 x7 r8 -2
 x7 r9 -3
 x8 obj 5
 x8 r0 2
 x8 r1 -3
 x8 r2 -3
 x8 r3 3
 x8 r4 -2
 x8 r5 -2
 x8 r7 4
 x8 r8 -3
 x8 r9 -4
RHS
 rhs obj 4
 rhs r0 3
 rhs r1 15
 rhs r2 12
 rhs r3 -9
 rhs r4 -13
 rhs r5 32
 rhs r6 -2
 rhs r7 26
 rhs r8 14
 rhs r9 3
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LI bounds x3 0
 UP bounds x3 3
 LI bounds x4 0
 UP bounds x4 3
 LI bounds x5 0
 UP bounds x5 3
 LI bounds x6 0
 UP bounds x6 3
 LO bounds x7 -2
 UP bounds x7 3
 LO bounds x8 -1
 UP bounds x8 2
ENDATA
