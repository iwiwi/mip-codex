NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 L r4
 G r5
 L r6
 E r7
 E r8
 E r9
 G r10
 G r11
COLUMNS
 x0 obj 4
 x0 r0 -2
 x0 r1 -3
 x0 r2 3
 x0 r3 -3
 x0 r4 -2
 x0 r5 4
 x0 r6 -1
 x0 r7 -1
 x0 r8 4
 x0 r9 -2
 x0 r10 2
 x0 r11 2
 x1 obj 2
 x1 r1 1
 x1 r2 2
 x1 r3 -2
 x1 r4 -3
 x1 r5 4
 x1 r6 -1
 x1 r7 3
 x1 r8 -3
 x1 r9 2
 x1 r10 -2
 x2 obj -1
 x2 r0 -3
 x2 r1 2
 x2 r2 -2
 x2 r3 -1
 x2 r4 -2
 x2 r5 -4
 x2 r6 -4
 x2 r7 2
 x2 r8 3
 x2 r9 -3
 x2 r10 3
 x2 r11 -1
 x3 obj 4
 x3 r0 3
 x3 r1 2
 x3 r2 -3
 x3 r3 -3
 x3 r4 -2
 x3 r5 -1
 x3 r7 1
 x3 r8 4
 x3 r9 -2
 x3 r10 3
 x3 r11 -4
 x4 obj -1
 x4 r0 2
 x4 r1 -3
 x4 r2 2
 x4 r3 4
 x4 r4 -4
 x4 r5 1
 x4 r6 -3
 x4 r8 -4
 x4 r9 -3
 x4 r11 -2
RHS
 rhs obj -2
 rhs r0 -4
 rhs r1 6
 rhs r2 1
 rhs r3 -21
 rhs r4 -22
 rhs r5 8
 rhs r6 -11
 rhs r7 10
 rhs r8 24
 rhs r9 -14
 rhs r10 12
 rhs r11 -12
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LO bounds x3 -2
 UP bounds x3 3
 LO bounds x4 -1
 UP bounds x4 2
ENDATA
