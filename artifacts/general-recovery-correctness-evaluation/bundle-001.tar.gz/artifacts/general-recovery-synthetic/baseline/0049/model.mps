NAME synthetic
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 L r1
 E r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj -2
 x0 r0 3
 x0 r1 -2
 x0 r3 -2
 x0 r4 4
 x0 r5 -1
 x1 obj 2
 x1 r0 -1
 x1 r1 -3
 x1 r2 1
 x1 r3 2
 x1 r4 -2
 x1 r5 -2
 x2 obj 0
 x2 r0 -2
 x2 r1 -3
 x2 r2 2
 x2 r3 2
 x2 r4 -2
 x2 r5 3
 x3 obj 5
 x3 r0 -4
 x3 r1 4
 x3 r2 -1
 x3 r3 3
 x3 r4 -2
 x3 r5 -3
 x4 obj 0
 x4 r1 2
 x4 r2 -1
 x4 r4 -3
 x5 obj -1
 x5 r0 -4
 x5 r1 -3
 x5 r2 1
 x5 r4 2
 x5 r5 1
RHS
 rhs obj -1
 rhs r0 -7
 rhs r1 9
 rhs r2 -3
 rhs r3 11
 rhs r4 -9
 rhs r5 -10
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LI bounds x3 0
 UP bounds x3 3
 LO bounds x4 -2
 UP bounds x4 3
 LO bounds x5 -1
 UP bounds x5 2
ENDATA
