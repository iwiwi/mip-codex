NAME synthetic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 E r4
 G r5
COLUMNS
 x0 obj -3
 x0 r0 3
 x0 r1 2
 x0 r2 4
 x0 r4 3
 x0 r5 1
 x1 obj 2
 x1 r0 -1
 x1 r1 3
 x1 r2 1
 x1 r3 4
 x1 r4 1
 x1 r5 -1
 x2 obj 3
 x2 r0 -2
 x2 r1 3
 x2 r3 -2
 x2 r4 2
 x2 r5 3
 x3 obj -2
 x3 r0 -3
 x3 r1 1
 x3 r2 -2
 x3 r3 -3
 x3 r5 -1
 x4 obj -2
 x4 r2 -3
 x4 r3 -4
 x4 r4 -2
RHS
 rhs obj -2
 rhs r0 10
 rhs r1 4
 rhs r2 10
 rhs r3 5
 rhs r4 6
 rhs r5 -3
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LO bounds x3 -2
 UP bounds x3 3
 LO bounds x4 -1
 UP bounds x4 2
ENDATA
