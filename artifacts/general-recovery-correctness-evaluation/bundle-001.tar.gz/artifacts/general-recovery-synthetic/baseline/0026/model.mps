NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
 E r2
 L r3
 E r4
 L r5
 G r6
 G r7
 E r8
 L r9
 L r10
COLUMNS
 x0 obj 4
 x0 r1 2
 x0 r2 4
 x0 r3 2
 x0 r4 4
 x0 r6 -4
 x0 r7 2
 x0 r8 2
 x0 r9 2
 x0 r10 -1
 x1 obj 1
 x1 r0 -1
 x1 r1 2
 x1 r2 2
 x1 r3 -3
 x1 r4 4
 x1 r5 1
 x1 r6 2
 x1 r7 3
 x1 r8 2
 x1 r9 1
 x1 r10 -2
 x2 obj -4
 x2 r1 3
 x2 r2 1
 x2 r3 1
 x2 r4 3
 x2 r5 1
 x2 r6 4
 x2 r9 4
 x2 r10 -4
 x3 obj 1
 x3 r0 2
 x3 r1 3
 x3 r2 -1
 x3 r3 -4
 x3 r4 2
 x3 r5 -1
 x3 r6 -3
 x3 r7 -4
 x3 r8 4
 x3 r9 1
 x4 obj -5
 x4 r1 -4
 x4 r3 -2
 x4 r4 -1
 x4 r5 1
 x4 r6 1
 x4 r8 2
 x4 r9 2
 x4 r10 -3
RHS
 rhs obj 1
 rhs r0 -2
 rhs r1 -5
 rhs r2 3
 rhs r3 5
 rhs r4 2
 rhs r5 6
 rhs r6 13
 rhs r7 0
 rhs r8 0
 rhs r9 12
 rhs r10 -11
BOUNDS
 LI bounds x0 0
 UP bounds x0 3
 LI bounds x1 0
 UP bounds x1 3
 LI bounds x2 0
 UP bounds x2 3
 LO bounds x3 -2
 UP bounds x3 3
 LO bounds x4 -1
 UP bounds x4 2
ENDATA
