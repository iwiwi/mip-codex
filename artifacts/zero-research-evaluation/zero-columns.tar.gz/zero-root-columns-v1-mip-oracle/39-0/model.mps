NAME dom
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 G r3
 L r4
 G r5
 L r6
 L r7
COLUMNS
 x0 obj -3
 x0 r0 3
 x0 r1 2
 x0 r3 2
 x0 r4 -2
 x0 r5 2
 x0 r7 3
 x1 obj 2
 x1 r0 1
 x1 r1 -3
 x1 r2 -2
 x1 r3 -2
 x1 r5 3
 x1 r6 -2
 x1 r7 -2
 x2 obj 7
 x2 r0 -3
 x2 r1 -1
 x2 r2 -3
 x2 r3 1
 x2 r4 3
 x2 r6 3
 x2 r7 1
 x3 obj 0
 x3 r3 3
 x3 r5 6
 x3 r7 -2
 x4 obj 0
 x4 r4 -2
 x4 r6 -4
 x4 r7 -2
RHS
 rhs obj 0
 rhs r0 2
 rhs r1 -6
 rhs r2 -10
 rhs r3 3
 rhs r4 1
 rhs r5 14
 rhs r6 0
 rhs r7 2
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
