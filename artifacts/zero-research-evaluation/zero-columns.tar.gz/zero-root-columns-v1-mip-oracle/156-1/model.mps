NAME dom
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 G r4
 L r5
 G r6
 L r7
COLUMNS
 x0 obj -1
 x0 r1 -1
 x0 r3 1
 x0 r4 3
 x0 r5 -2
 x0 r6 -3
 x0 r7 1
 x1 obj 9
 x1 r1 -3
 x1 r2 -1
 x1 r3 1
 x1 r4 -3
 x1 r5 -3
 x1 r6 -2
 x1 r7 -1
 x2 obj 1
 x2 r0 2
 x2 r1 3
 x2 r2 2
 x2 r3 3
 x2 r4 -3
 x2 r5 -2
 x2 r7 1
 x3 obj 0
 x3 r3 -1
 x3 r5 -2
 x3 r7 -2
 x4 obj 0
 x4 r4 3
 x4 r6 6
 x4 r7 -2
RHS
 rhs obj 0
 rhs r0 2
 rhs r1 -1
 rhs r2 2
 rhs r3 5
 rhs r4 -6
 rhs r5 -11
 rhs r6 1
 rhs r7 -6
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
