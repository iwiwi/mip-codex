from pathlib import Path
import os,subprocess,json,sys
sys.path.insert(0,'scripts');from benchmark_common import atomic_json
from validate_solution import validate
root=Path.cwd();out=root/'artifacts/integer-bound-safety-final-dense-fixtures';out.mkdir();binary=root/'artifacts/integer-bound-safety-final-diagnostic/bin/mip-codex';records=[]
for name in ['scaled-lp-0.mps','scaled-lp-8.mps']:
 model=root/'tests/fixtures'/name;d=out/name;d.mkdir();env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_LP_ENGINE='dense');env.update({k:'0'for k in ['MIP_BINARY_GRAPH','MIP_RINS','MIP_STRONG_BRANCHING','MIP_COVER_CUTS','MIP_MIR_CUTS','MIP_CLIQUE_CUTS','MIP_PRIMAL_REPAIR','MIP_FEASIBILITY_PUMP','MIP_PRIMAL_PROBE','MIP_LP_DIVING']});p=subprocess.run(['taskset','-c','42',str(binary),'solve',str(model),'2'],env=env,capture_output=True,text=True,timeout=62);(d/'result.json').write_text(p.stdout);(d/'stderr.log').write_text(p.stderr);assert p.returncode==0;r=json.loads(p.stdout);v=validate(model,r);atomic_json(d/'validation.json',v);records.append(dict(name=name,status=r['status'],objective=r['objective'],optimal_original_conflict=r['optimal_original_conflict'],valid=v['valid']));assert v['valid']is True,(name,v)
atomic_json(out/'summary.json',dict(outputs=2,points_valid=2,records=records));print(records)
