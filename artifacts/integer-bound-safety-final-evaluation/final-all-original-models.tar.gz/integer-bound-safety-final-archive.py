from pathlib import Path
import os,sys,json,hashlib,gzip,tarfile,io,subprocess
os.sched_setaffinity(0,{33});root=Path('/home/ubuntu/mip-codex');repo=Path('/home/ubuntu/mip-phase-two');kind='integer-bound-safety-final'
all_paths=sorted(p for p in (root/'artifacts').iterdir()if p.name.startswith('integer-bound-safety-'))
initial=[p.name for p in all_paths if not p.name.startswith('integer-bound-safety-final-')]
final=[p.name for p in all_paths if p.name.startswith('integer-bound-safety-final-')and p.name not in ['integer-bound-safety-final-archive.log']]
groups=[('initial-and-integer-guard',(),initial+['smoke-20261117-144609-0543rb3a']),('final-all-original-models',(),final+['smoke-20261117-150834-a5upadh1'])];documents=[]
for name in ['integer-bound-safety-development-audit','integer-bound-safety-guard-development-audit','integer-bound-safety-final-development-audit']:
 a=json.loads((root/'artifacts'/name/'summary.json').read_text());assert a['completed']==a['cut_valid']==376 and a['points']==a['strict_valid']==a['official_valid']==128 and a['cut_invalid']==a['strict_invalid']==0
out=repo/f'artifacts/{kind}-evaluation';assert not out.exists();out.mkdir();ledger=[];excluded=[];bundles=[]
for label,prefixes,extras in groups:
 paths=sorted(p for p in (root/'artifacts').iterdir()if prefixes and p.name.startswith(prefixes));paths.extend(root/'artifacts'/name for name in extras);bundle=out/(label+'.tar.gz');count=0
 with bundle.open('wb')as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6)as z,tarfile.open(fileobj=z,mode='w')as tar:
  for source in paths:
   for p in sorted(source.rglob('*'))if source.is_dir()else[source]:
    if not p.is_file():continue
    data=p.read_bytes();h=hashlib.sha256(data).hexdigest();name=str(p.relative_to(root/'artifacts'))
    if data[:4]==b'\x7fELF'or p.name=='model.glp':excluded.append(dict(source=str(p),sha256=h,bytes=len(data),reason='local executable/generated LP retained'));continue
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));ledger.append(dict(source=str(p),bundle=bundle.name,member=name,sha256=h,bytes=len(data)));count+=1
 assert bundle.stat().st_size<95*1024**2
 bundles.append(dict(path=bundle.name,sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),bytes=bundle.stat().st_size,files=count));print(bundles[-1],flush=True)
expected={(r['bundle'],r['member']):r for r in ledger};verified=0
for bundle in bundles:
 with tarfile.open(out/bundle['path'],'r:gz')as tar:
  for member in tar:
   r=expected[(bundle['path'],member.name)];data=tar.extractfile(member).read();assert len(data)==r['bytes']and hashlib.sha256(data).hexdigest()==r['sha256'];verified+=1
assert verified==len(ledger)
for branch,name in documents:(out/name).write_bytes(subprocess.check_output(['git','show',f'{branch}:docs/{name}'],cwd=repo))
(out/'relocation-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n');(out/'bundles.json').write_text(json.dumps(bundles,indent=2)+'\n');(out/'retained-local-files.json').write_text(json.dumps(excluded,indent=2)+'\n');s=dict(files=len(ledger),original_bytes=sum(r['bytes']for r in ledger),bundled_bytes=sum(b['bytes']for b in bundles),excluded=len(excluded),verified_payloads=verified);(out/'archive-summary.json').write_text(json.dumps(s,indent=2)+'\n');(out/'README.txt').write_text('完了済み開発試作の圧縮原記録。空の作業ディレクトリでtar.gzを展開すると元artifacts以下の相対パスが復元される。bundles.jsonで圧縮SHA、relocation-ledger.jsonで展開payloadのSHAを照合。作成時に全payloadの展開SHAを確認済み。元ファイルと除外したELF/生成LPはローカル保持。元十進数の整数境界安全性修正FPcdfc159e435d9194。最終800出力は213最適/586不能/1安全側撤回。全214点GMP有効、変換798証明/8928改竄拒否。途中の過剰なoracle assertや合成MPS形式/optional float readerの失敗も保持し、数値許容幅は変更していない。\n');print(s)
