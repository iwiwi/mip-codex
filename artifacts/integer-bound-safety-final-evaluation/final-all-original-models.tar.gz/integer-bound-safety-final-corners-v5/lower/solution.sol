=obj= 2.0
x 2.0
