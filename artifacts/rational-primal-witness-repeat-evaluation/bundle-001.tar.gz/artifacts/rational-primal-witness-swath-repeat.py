from pathlib import Path
import os,sys,json,subprocess,resource,signal,time
sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256
os.sched_setaffinity(0,{44});root=Path.cwd();name='swath1.mps.gz';m=next(r for r in json.loads((root/'data/manifest.json').read_text())['instances']if r['name']==name);assert m['split']=='development';model=root/m['path'];assert sha256(model)==m['sha256'];bins={v:root/'artifacts'/(p+'-diagnostic')/'bin/mip-codex'for v,p in [('before','implied-boundary-final'),('after','rational-primal-witness-v3')]};records=[]
def restrict():resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3))
try:
 for repeat in range(3):
  out=root/f'artifacts/rational-primal-witness-swath-repeat-{repeat}';out.mkdir();atomic_json(out/'experiment.json',dict(cpu=44,seconds=10,threads=1,memory_bytes=16*1024**3,split='development',purpose='repeat observed primal regression; two frozen binaries; no parameter tuning',binaries={v:dict(path=str(b),sha256=sha256(b))for v,b in bins.items()}))
  for v in (['before','after']if repeat%2==0 else['after','before']):
   d=out/name/v;d.mkdir(parents=True);env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_MIR_CUTS='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1');cmd=['/usr/bin/time','-v','-o',str(d/'resource.log'),str(bins[v]),'solve',str(model),'10'];atomic_json(d/'job.json',dict(command=cmd,input_sha256=m['sha256'],environment={k:env[k]for k in ['MIP_MIR_CUTS','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']}));start=time.monotonic()
   with (d/'stdout.log').open('w')as f,(d/'stderr.log').open('w')as e:
    p=subprocess.Popen(cmd,stdout=f,stderr=e,env=env,preexec_fn=restrict,start_new_session=True)
    try:p.wait(timeout=70)
    except BaseException:
     if p.poll()is None:os.killpg(p.pid,signal.SIGKILL);p.wait()
     raise
   assert p.returncode==0;r=json.loads((d/'stdout.log').read_text());atomic_json(d/'result.json',r);atomic_json(d/'execution.json',dict(exit_code=0,wall_seconds=time.monotonic()-start));record=dict(repeat=repeat,variant=v,status=r['status'],objective=r['objective'],dual_bound=r['dual_bound'],nodes=r['nodes'],rational_proof=r.get('rational_primal_proof')is not None);records.append(record);atomic_json(root/'artifacts/rational-primal-witness-swath-repeat-records.json',records);print(record,flush=True)
  atomic_json(out/'exit.json',dict(status='complete'))
except BaseException as error:atomic_json(root/'artifacts/rational-primal-witness-swath-repeat-exit.json',dict(status='failed',completed=len(records),error=str(error)));raise
atomic_json(root/'artifacts/rational-primal-witness-swath-repeat-exit.json',dict(status='complete',outputs=6))
