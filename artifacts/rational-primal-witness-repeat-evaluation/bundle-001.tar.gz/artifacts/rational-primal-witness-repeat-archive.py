from pathlib import Path
import hashlib,json,tarfile
root=Path.cwd();out=root/'artifacts/rational-primal-witness-repeat-evaluation';assert not out.exists();assert json.loads((root/'artifacts/rational-primal-witness-swath-repeat-audit/summary.json').read_text())['strict_valid']==6;out.mkdir();paths={Path(__file__).resolve(),root/'artifacts/rational-primal-witness-v3-development-memory.json'}
for pattern in ['rational-primal-witness-swath-repeat*','exact-binary-objective-bound-pilot','exact-binary-fixed-objective-pilot']:
 for p in (root/'artifacts').glob(pattern):
  if p.is_file():paths.add(p)
  elif p.is_dir():paths.update(q for q in p.rglob('*')if q.is_file())
ledger=[dict(path=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in sorted(paths)];bundle=out/'bundle-001.tar.gz'
with tarfile.open(bundle,'w:gz',compresslevel=6)as t:
 for r in ledger:t.add(root/r['path'],arcname=r['path'],recursive=False)
with tarfile.open(bundle,'r:gz')as t:
 assert len(t.getmembers())==len(ledger)
 for m,r in zip(t.getmembers(),ledger):assert m.name==r['path']and hashlib.sha256(t.extractfile(m).read()).hexdigest()==r['sha256']
(out/'manifest.json').write_text(json.dumps(ledger,indent=2));s=dict(files=len(ledger),raw_bytes=sum(r['bytes']for r in ledger),compressed_bytes=bundle.stat().st_size,bundle_sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),all_payload_sha256_verified=True);(out/'summary.json').write_text(json.dumps(s,indent=2));print(s)
