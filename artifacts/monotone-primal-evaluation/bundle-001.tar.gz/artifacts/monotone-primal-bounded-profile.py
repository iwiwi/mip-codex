from pathlib import Path
import highspy,json,os
os.sched_setaffinity(0,{43});h=highspy.Highs();h.setOptionValue('output_flag',False);h.readModel('data/raw/benchmark/rd-rplusc-21.mps.gz');h.ensureRowwise();lp=h.getLp();a=lp.a_matrix_;indices=list(a.index_);values=list(a.value_);starts=list(a.start_);lo=list(lp.row_lower_);up=list(lp.row_upper_);masks=[3]*lp.num_col_;counts=[0]*lp.num_col_
for i in range(lp.num_row_):
 terms=list(zip(indices[starts[i]:starts[i+1]],values[starts[i]:starts[i+1]]))
 if any(j==0 for j,c in terms):continue
 for j,c in terms:
  if not c:continue
  counts[j]+=1
  if abs(lo[i])<1e30:masks[j]&=1 if c>0 else 2
  if abs(up[i])<1e30:masks[j]&=2 if c>0 else 1
r=[dict(column=j,name=lp.col_names_[j],mask=masks[j],rows=counts[j],lower=str(lp.col_lower_[j]),upper=str(lp.col_upper_[j]),kind=str(lp.integrality_[j]))for j in range(lp.num_col_)if masks[j]and counts[j]];Path('artifacts/monotone-primal-bounded-profile.json').write_text(json.dumps(r,indent=2));print(r[:15],len(r))
