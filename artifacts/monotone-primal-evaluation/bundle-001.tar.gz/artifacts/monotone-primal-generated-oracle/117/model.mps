NAME lifting
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
COLUMNS
 z obj 1
 z r3 -3
 z r4 -3
 z r5 -2
 z r6 -1
 z r7 -1
 z r8 -2
 z r9 -1
 z r10 -3
 x0 obj 3
 x0 r0 -2
 x0 r1 1
 x0 r3 0.99999999999999999999
 x0 r4 0.1
 x0 r5 -1.25
 x0 r6 0.99999999999999999999
 x0 r7 -1.25
 x0 r8 -1.25
 x0 r9 2
 x0 r10 0.99999999999999999999
 x1 obj 1
 x1 r1 -1
 x1 r3 2
 x1 r4 -1.25
 x1 r5 -0.3
 x1 r6 -0.3
 x1 r7 -0.3
 x1 r8 2
 x1 r9 -1.25
 x1 r10 0.99999999999999999999
 x2 obj 3
 x2 r0 -2
 x2 r1 1
 x2 r2 -1
 x2 r3 2
 x2 r4 2
 x2 r5 -1.25
 x2 r6 0.99999999999999999999
 x2 r7 -0.3
 x2 r8 -0.3
 x2 r9 -0.3
 x2 r10 -0.3
 x3 obj 0
 x3 r0 -2
 x3 r1 -2
 x3 r2 -2
 x3 r3 -1.25
 x3 r4 -0.3
 x3 r5 -0.3
 x3 r6 0.99999999999999999999
 x3 r7 0.1
 x3 r8 -0.3
 x3 r9 -1.25
 x3 r10 -0.3
RHS
 rhs obj 0
 rhs r0 -3
 rhs r1 1
 rhs r2 0
 rhs r3 2.99999999999999999999
 rhs r4 -0.15
 rhs r5 5.2
 rhs r6 7.69999999999999999998
 rhs r7 -1.85
 rhs r8 7.45
 rhs r9 3.45
 rhs r10 1.69999999999999999998
BOUNDS
 FR b z
 FX b x0 1
 FX b x1 1
 FX b x2 1
 BV b x3
ENDATA
