NAME lifting
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
COLUMNS
 z obj 1
 z r3 3
 z r4 3
 z r5 3
 z r6 3
 z r7 1
 z r8 1
 z r9 3
 z r10 2
 x0 obj 1
 x0 r0 -2
 x0 r3 -0.3
 x0 r4 -0.3
 x0 r5 -0.3
 x0 r6 0.1
 x0 r7 -0.3
 x0 r8 0.99999999999999999999
 x0 r9 -0.3
 x0 r10 0.99999999999999999999
 x1 obj -2
 x1 r0 2
 x1 r1 1
 x1 r2 -1
 x1 r3 2
 x1 r4 2
 x1 r5 -0.3
 x1 r6 -1.25
 x1 r7 0.1
 x1 r8 -1.25
 x1 r9 -0.3
 x1 r10 -1.25
 x2 obj -3
 x2 r0 -1
 x2 r1 -2
 x2 r2 -1
 x2 r3 -1.25
 x2 r4 -0.3
 x2 r5 0.1
 x2 r6 0.1
 x2 r7 -0.3
 x2 r8 0.99999999999999999999
 x2 r9 0.1
 x2 r10 -0.3
 x3 obj 1
 x3 r0 -2
 x3 r1 -2
 x3 r2 2
 x3 r3 0.99999999999999999999
 x3 r4 0.99999999999999999999
 x3 r5 0.1
 x3 r6 0.1
 x3 r7 0.99999999999999999999
 x3 r8 0.1
 x3 r9 -0.3
 x3 r10 -1.25
 x4 obj -1
 x4 r0 -2
 x4 r1 2
 x4 r2 -2
 x4 r3 2
 x4 r4 -0.3
 x4 r5 -1.25
 x4 r6 -1.25
 x4 r7 -0.3
 x4 r8 -1.25
 x4 r9 -0.3
 x4 r10 2
 x5 obj -3
 x5 r1 2
 x5 r2 2
 x5 r3 0.1
 x5 r4 2
 x5 r5 -1.25
 x5 r6 -1.25
 x5 r7 -1.25
 x5 r8 2
 x5 r9 0.1
 x5 r10 0.99999999999999999999
RHS
 rhs obj 0
 rhs r0 -1
 rhs r1 4
 rhs r2 -2
 rhs r3 7.55
 rhs r4 2.1
 rhs r5 6
 rhs r6 3.45
 rhs r7 0.95
 rhs r8 -1.50000000000000000002
 rhs r9 4.3
 rhs r10 3.44999999999999999998
BOUNDS
 FR b z
 FX b x0 1
 FX b x1 1
 FX b x2 1
 BV b x3
 FX b x4 1
 FX b x5 1
ENDATA
