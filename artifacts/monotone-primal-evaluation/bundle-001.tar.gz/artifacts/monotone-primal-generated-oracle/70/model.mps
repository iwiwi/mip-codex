NAME lifting
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
COLUMNS
 z obj 1
 z r3 3
 z r4 1
 z r5 2
 z r6 2
 z r7 2
 z r8 3
 z r9 2
 z r10 1
 x0 obj -3
 x0 r0 -1
 x0 r1 -1
 x0 r2 1
 x0 r3 -0.3
 x0 r4 -0.3
 x0 r5 -1.25
 x0 r6 -0.3
 x0 r7 0.99999999999999999999
 x0 r8 -1.25
 x0 r9 2
 x0 r10 -0.3
 x1 obj 2
 x1 r0 1
 x1 r1 -2
 x1 r3 -1.25
 x1 r4 -0.3
 x1 r5 2
 x1 r6 0.99999999999999999999
 x1 r7 0.99999999999999999999
 x1 r8 -0.3
 x1 r9 2
 x1 r10 -1.25
RHS
 rhs obj 0
 rhs r0 1
 rhs r1 -2
 rhs r2 1
 rhs r3 3.45
 rhs r4 5.4
 rhs r5 1.75
 rhs r6 2.69999999999999999999
 rhs r7 4.99999999999999999998
 rhs r8 -4.55
 rhs r9 2
 rhs r10 2.45
BOUNDS
 FR b z
 FX b x0 1
 FX b x1 1
ENDATA
