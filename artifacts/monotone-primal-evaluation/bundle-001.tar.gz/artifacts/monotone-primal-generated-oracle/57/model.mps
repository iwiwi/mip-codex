NAME lifting
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
COLUMNS
 z obj 1
 z r3 -3
 z r4 -3
 z r5 -2
 z r6 -3
 z r7 -1
 z r8 -3
 z r9 -3
 z r10 -2
 x0 obj -1
 x0 r0 -2
 x0 r1 2
 x0 r2 1
 x0 r3 0.1
 x0 r4 0.1
 x0 r5 2
 x0 r6 -0.3
 x0 r7 2
 x0 r8 -1.25
 x0 r9 0.1
 x0 r10 0.1
 x1 obj 0
 x1 r0 -2
 x1 r1 2
 x1 r2 -1
 x1 r3 -1.25
 x1 r4 -1.25
 x1 r5 0.99999999999999999999
 x1 r6 0.1
 x1 r7 -1.25
 x1 r8 -0.3
 x1 r9 0.1
 x1 r10 -1.25
 x2 obj -2
 x2 r0 2
 x2 r1 1
 x2 r2 -1
 x2 r3 0.99999999999999999999
 x2 r4 -0.3
 x2 r5 -1.25
 x2 r6 -0.3
 x2 r7 -0.3
 x2 r8 -1.25
 x2 r9 0.99999999999999999999
 x2 r10 0.99999999999999999999
 x3 obj 0
 x3 r0 1
 x3 r1 1
 x3 r2 -1
 x3 r3 0.1
 x3 r4 0.99999999999999999999
 x3 r5 -0.3
 x3 r6 2
 x3 r7 0.1
 x3 r8 -1.25
 x3 r9 -0.3
 x3 r10 -1.25
RHS
 rhs obj 0
 rhs r0 -1
 rhs r1 5
 rhs r2 -1
 rhs r3 1.95
 rhs r4 -0.15000000000000000001
 rhs r5 -0.30000000000000000001
 rhs r6 7.8
 rhs r7 -0.15
 rhs r8 -3.8
 rhs r9 8.9
 rhs r10 3.6
BOUNDS
 FR b z
 FX b x0 1
 FX b x1 1
 BV b x2
 FX b x3 1
ENDATA
