NAME lifting
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
COLUMNS
 z obj 1
 z r3 -3
 z r4 -3
 z r5 -1
 z r6 -1
 z r7 -1
 z r8 -2
 z r9 -1
 z r10 -1
 x0 obj 0
 x0 r0 1
 x0 r1 -2
 x0 r3 2
 x0 r4 0.1
 x0 r5 2
 x0 r6 0.1
 x0 r7 -0.3
 x0 r8 0.99999999999999999999
 x0 r9 0.1
 x0 r10 2
 x1 obj 1
 x1 r1 1
 x1 r2 -1
 x1 r3 -0.3
 x1 r4 0.1
 x1 r5 2
 x1 r6 -1.25
 x1 r7 0.99999999999999999999
 x1 r8 2
 x1 r9 -1.25
 x1 r10 0.1
RHS
 rhs obj 0
 rhs r0 3
 rhs r1 -1
 rhs r2 1
 rhs r3 11
 rhs r4 6.1
 rhs r5 -1
 rhs r6 2.1
 rhs r7 4.7
 rhs r8 2.99999999999999999999
 rhs r9 2.1
 rhs r10 1
BOUNDS
 FR b z
 FX b x0 1
 BV b x1
ENDATA
