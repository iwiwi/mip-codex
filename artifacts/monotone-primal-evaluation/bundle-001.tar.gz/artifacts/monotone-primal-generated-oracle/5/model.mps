NAME lifting
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
COLUMNS
 z obj 1
 z r3 -1
 z r4 -1
 z r5 -1
 z r6 -2
 z r7 -1
 z r8 -1
 z r9 -3
 z r10 -2
 x0 obj 3
 x0 r0 -1
 x0 r2 -1
 x0 r3 2
 x0 r4 2
 x0 r5 0.99999999999999999999
 x0 r6 2
 x0 r7 -1.25
 x0 r8 2
 x0 r9 0.99999999999999999999
 x0 r10 -0.3
 x1 obj 0
 x1 r0 -1
 x1 r3 -1.25
 x1 r4 0.1
 x1 r5 0.1
 x1 r6 0.99999999999999999999
 x1 r7 2
 x1 r8 -1.25
 x1 r9 -1.25
 x1 r10 2
RHS
 rhs obj 0
 rhs r0 -1
 rhs r1 1
 rhs r2 0
 rhs r3 6.75
 rhs r4 2.1
 rhs r5 10.09999999999999999999
 rhs r6 6.99999999999999999999
 rhs r7 9.75
 rhs r8 1.75
 rhs r9 7.74999999999999999999
 rhs r10 8.7
BOUNDS
 FR b z
 FX b x0 1
 FX b x1 1
ENDATA
