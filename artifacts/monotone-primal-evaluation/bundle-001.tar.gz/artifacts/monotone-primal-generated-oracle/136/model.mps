NAME lifting
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
COLUMNS
 z obj 1
 z r3 2
 z r4 2
 z r5 2
 z r6 3
 z r7 1
 z r8 3
 z r9 2
 z r10 2
 x0 obj 2
 x0 r0 1
 x0 r1 -1
 x0 r2 2
 x0 r3 -0.3
 x0 r4 0.1
 x0 r5 -0.3
 x0 r6 -1.25
 x0 r7 -1.25
 x0 r8 0.1
 x0 r9 0.99999999999999999999
 x0 r10 -0.3
 x1 obj 0
 x1 r1 -2
 x1 r2 2
 x1 r3 2
 x1 r4 0.99999999999999999999
 x1 r5 -0.3
 x1 r6 0.99999999999999999999
 x1 r7 2
 x1 r8 -1.25
 x1 r9 0.99999999999999999999
 x1 r10 0.99999999999999999999
 x2 obj 1
 x2 r0 1
 x2 r1 1
 x2 r2 1
 x2 r3 2
 x2 r4 0.1
 x2 r5 0.1
 x2 r6 2
 x2 r7 -0.3
 x2 r8 2
 x2 r9 -1.25
 x2 r10 0.1
RHS
 rhs obj 0
 rhs r0 4
 rhs r1 0
 rhs r2 6
 rhs r3 9.7
 rhs r4 0.19999999999999999999
 rhs r5 -2.5
 rhs r6 9.74999999999999999999
 rhs r7 -2.55
 rhs r8 -2.15
 rhs r9 6.74999999999999999998
 rhs r10 7.79999999999999999999
BOUNDS
 FR b z
 FX b x0 1
 FX b x1 1
 FX b x2 1
ENDATA
