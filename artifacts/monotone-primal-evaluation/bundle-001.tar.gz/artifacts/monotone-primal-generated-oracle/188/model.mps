NAME lifting
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
COLUMNS
 z obj 1
 z r3 1
 z r4 2
 z r5 3
 z r6 3
 z r7 2
 z r8 3
 z r9 2
 z r10 3
 x0 obj 1
 x0 r0 -1
 x0 r1 -2
 x0 r3 2
 x0 r4 -0.3
 x0 r5 0.99999999999999999999
 x0 r6 -1.25
 x0 r7 -0.3
 x0 r8 -0.3
 x0 r9 -0.3
 x0 r10 0.99999999999999999999
 x1 obj 2
 x1 r2 2
 x1 r3 2
 x1 r4 -0.3
 x1 r5 -0.3
 x1 r6 0.1
 x1 r7 0.99999999999999999999
 x1 r8 0.99999999999999999999
 x1 r9 2
 x1 r10 -0.3
 x2 obj -1
 x2 r0 1
 x2 r3 -1.25
 x2 r4 0.1
 x2 r5 -0.3
 x2 r6 -0.3
 x2 r7 0.1
 x2 r8 0.1
 x2 r9 0.1
 x2 r10 0.99999999999999999999
 x3 obj 3
 x3 r0 -1
 x3 r1 1
 x3 r2 -1
 x3 r3 0.1
 x3 r4 0.1
 x3 r5 -1.25
 x3 r6 -1.25
 x3 r7 0.99999999999999999999
 x3 r8 -0.3
 x3 r9 2
 x3 r10 2
 x4 obj 3
 x4 r0 2
 x4 r1 2
 x4 r2 2
 x4 r3 0.99999999999999999999
 x4 r4 0.1
 x4 r5 0.99999999999999999999
 x4 r6 2
 x4 r7 0.99999999999999999999
 x4 r8 2
 x4 r9 -1.25
 x4 r10 0.99999999999999999999
RHS
 rhs obj 0
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 10.84999999999999999999
 rhs r4 -2.3
 rhs r5 -0.85000000000000000002
 rhs r6 7.3
 rhs r7 4.79999999999999999997
 rhs r8 7.49999999999999999999
 rhs r9 7.55
 rhs r10 1.69999999999999999997
BOUNDS
 FR b z
 FX b x0 1
 FX b x1 1
 FX b x2 1
 FX b x3 1
 FX b x4 1
ENDATA
