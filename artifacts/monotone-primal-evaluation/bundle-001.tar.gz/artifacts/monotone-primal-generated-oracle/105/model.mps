NAME lifting
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
COLUMNS
 z obj 1
 z r3 -2
 z r4 -3
 z r5 -2
 z r6 -2
 z r7 -2
 z r8 -1
 z r9 -3
 z r10 -3
 x0 obj 0
 x0 r2 2
 x0 r3 -0.3
 x0 r4 2
 x0 r5 -0.3
 x0 r6 -0.3
 x0 r7 -1.25
 x0 r8 -1.25
 x0 r9 -1.25
 x0 r10 -0.3
 x1 obj 2
 x1 r0 -1
 x1 r1 -1
 x1 r2 -2
 x1 r3 -1.25
 x1 r4 0.99999999999999999999
 x1 r5 2
 x1 r6 0.99999999999999999999
 x1 r7 2
 x1 r8 2
 x1 r9 2
 x1 r10 2
RHS
 rhs obj 0
 rhs r0 1
 rhs r1 2
 rhs r2 4
 rhs r3 -1.3
 rhs r4 10
 rhs r5 0.7
 rhs r6 2.7
 rhs r7 -1.25
 rhs r8 5.75
 rhs r9 3.75
 rhs r10 2.7
BOUNDS
 FR b z
 FX b x0 1
 BV b x1
ENDATA
