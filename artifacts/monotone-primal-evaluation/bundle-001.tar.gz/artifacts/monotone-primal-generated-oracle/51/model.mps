NAME lifting
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
COLUMNS
 z obj 1
 z r3 -2
 z r4 -1
 z r5 -1
 z r6 -1
 z r7 -1
 z r8 -2
 z r9 -1
 z r10 -1
 x0 obj 2
 x0 r1 -1
 x0 r3 0.1
 x0 r4 0.1
 x0 r5 0.1
 x0 r6 0.1
 x0 r7 0.99999999999999999999
 x0 r8 0.99999999999999999999
 x0 r9 -1.25
 x0 r10 -0.3
 x1 obj 2
 x1 r1 2
 x1 r2 -1
 x1 r3 -1.25
 x1 r4 -0.3
 x1 r5 -1.25
 x1 r6 0.99999999999999999999
 x1 r7 0.1
 x1 r8 2
 x1 r9 2
 x1 r10 -1.25
 x2 obj 0
 x2 r1 -2
 x2 r2 2
 x2 r3 -0.3
 x2 r4 -1.25
 x2 r5 -1.25
 x2 r6 -0.3
 x2 r7 0.1
 x2 r8 0.1
 x2 r9 0.99999999999999999999
 x2 r10 -1.25
RHS
 rhs obj 0
 rhs r0 2
 rhs r1 -3
 rhs r2 2
 rhs r3 -2.2
 rhs r4 6.85
 rhs r5 2.85
 rhs r6 7.8
 rhs r7 -0.90000000000000000001
 rhs r8 6.09999999999999999999
 rhs r9 7.74999999999999999999
 rhs r10 -2.55
BOUNDS
 FR b z
 FX b x0 1
 BV b x1
 FX b x2 1
ENDATA
