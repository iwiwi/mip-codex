NAME lifting
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
COLUMNS
 z obj 1
 z r3 3
 z r4 3
 z r5 1
 z r6 3
 z r7 2
 z r8 3
 z r9 1
 z r10 2
 x0 obj 3
 x0 r0 1
 x0 r3 0.99999999999999999999
 x0 r4 -1.25
 x0 r5 -0.3
 x0 r6 2
 x0 r7 0.1
 x0 r8 -0.3
 x0 r9 0.99999999999999999999
 x0 r10 -1.25
 x1 obj 1
 x1 r0 -2
 x1 r1 -2
 x1 r2 -2
 x1 r3 2
 x1 r4 0.99999999999999999999
 x1 r5 0.1
 x1 r6 -0.3
 x1 r7 0.99999999999999999999
 x1 r8 2
 x1 r9 0.99999999999999999999
 x1 r10 0.1
RHS
 rhs obj 0
 rhs r0 1
 rhs r1 0
 rhs r2 -2
 rhs r3 5.99999999999999999999
 rhs r4 -0.25000000000000000001
 rhs r5 0.8
 rhs r6 9.7
 rhs r7 5.09999999999999999999
 rhs r8 1.7
 rhs r9 6.99999999999999999998
 rhs r10 -2.15
BOUNDS
 FR b z
 FX b x0 1
 FX b x1 1
ENDATA
