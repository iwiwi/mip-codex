NAME lifting
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
COLUMNS
 z obj 1
 z r3 -3
 z r4 -2
 z r5 -1
 z r6 -2
 z r7 -1
 z r8 -2
 z r9 -1
 z r10 -2
 x0 obj 2
 x0 r0 2
 x0 r1 -1
 x0 r2 -2
 x0 r3 -1.25
 x0 r4 2
 x0 r5 0.1
 x0 r6 0.99999999999999999999
 x0 r7 2
 x0 r8 -0.3
 x0 r9 -0.3
 x0 r10 0.1
 x1 obj 3
 x1 r0 -2
 x1 r1 -2
 x1 r2 -2
 x1 r3 0.99999999999999999999
 x1 r4 2
 x1 r5 0.1
 x1 r6 2
 x1 r7 -1.25
 x1 r8 0.99999999999999999999
 x1 r9 0.1
 x1 r10 0.1
RHS
 rhs obj 0
 rhs r0 0
 rhs r1 -2
 rhs r2 -2
 rhs r3 0.74999999999999999999
 rhs r4 13
 rhs r5 0.2
 rhs r6 1.99999999999999999999
 rhs r7 8.75
 rhs r8 -2.30000000000000000001
 rhs r9 6.8
 rhs r10 5.2
BOUNDS
 FR b z
 FX b x0 1
 FX b x1 1
ENDATA
