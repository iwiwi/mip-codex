NAME dom
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 L r4
COLUMNS
 x0 obj 1
 x0 r0 2
 x0 r2 3
 x0 r3 -2
 x0 r4 2
 x1 obj -8
 x1 r1 -2
 x1 r3 -3
 x1 r4 1
 x2 obj 9
 x2 r0 1
 x2 r1 -2
 x2 r2 1
 x2 r3 -2
 x2 r4 -2
 x3 obj 0
 x3 r3 -3
 x4 obj 0
 x4 r4 -3
RHS
 rhs obj -6
 rhs r0 5
 rhs r1 -4
 rhs r2 7
 rhs r3 -11
 rhs r4 2
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
