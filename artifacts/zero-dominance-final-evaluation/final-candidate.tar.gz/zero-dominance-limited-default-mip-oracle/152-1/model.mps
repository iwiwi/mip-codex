NAME dom
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 G r4
COLUMNS
 x0 obj -8
 x0 r0 -2
 x0 r1 3
 x0 r2 -3
 x0 r3 -2
 x0 r4 3
 x1 obj 3
 x1 r0 -3
 x1 r1 1
 x1 r2 -1
 x1 r3 -3
 x1 r4 3
 x2 obj -4
 x2 r2 3
 x2 r3 -2
 x2 r4 2
 x3 obj 0
 x3 r3 1
 x4 obj 0
 x4 r4 -2
RHS
 rhs obj -2
 rhs r0 -6
 rhs r1 2
 rhs r2 2
 rhs r3 -10
 rhs r4 9
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
