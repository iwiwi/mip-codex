from pathlib import Path
import subprocess,time,sys,json,os
root=Path.cwd();prior=Path('/home/ubuntu/mip-graph-large-capacity/artifacts/large-capacity-default-development-screen');audit=Path('/home/ubuntu/mip-graph-large-capacity/artifacts/large-capacity-default-development-parallel-audit');deadline=time.monotonic()+1800
while len(list(prior.glob('worker-*-exit.json')))<5 or not(audit/'summary.json').exists():
    assert time.monotonic()<deadline,'prior development not terminal'
    time.sleep(2)
assert all(json.load(open(p))['status']=='complete'for p in prior.glob('worker-*-exit.json'))
assert json.load(open(audit/'summary.json'))['completed']==376
subprocess.run([sys.executable,'artifacts/cover-choice-heap-launch-screen.py'],check=True)
env=dict(os.environ,MIP_AUDIT_CPUS='36,37,42,48')
subprocess.run([sys.executable,'artifacts/cover-choice-heap-parallel-audit.py','cover-choice-heap'],env=env,check=True)
