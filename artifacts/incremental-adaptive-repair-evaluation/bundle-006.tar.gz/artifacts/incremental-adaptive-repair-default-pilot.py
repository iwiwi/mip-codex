from pathlib import Path
import os,sys,json,subprocess,resource,time
sys.path.insert(0,'scripts')
from benchmark_common import atomic_json,sha256,require_solver_origin
root=Path.cwd();out=root/'artifacts/incremental-adaptive-repair-default-pilot';out.mkdir(exist_ok=True);binary=root/'artifacts/incremental-adaptive-repair-default-diagnostic/bin/mip-codex';info=json.loads(subprocess.check_output([str(binary),'build-info']));os.sched_setaffinity(0,{45});manifest=json.loads((root/'data/manifest.json').read_text())['instances']
def restrict():resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3))
for name in ['map10','map16715-04','gmu-35-40','neos-1445765']:
 item=next(v for v in manifest if v['name'].split('.')[0]==name);assert item['split']=='development';model=root/item['path'];assert sha256(model)==item['sha256']
 for flag in [0,1]:
  d=out/name/str(flag);d.mkdir(parents=True);env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_ADAPTIVE_RESOURCE_REPAIR=str(flag),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');cmd=[str(binary),'solve',str(model),'10'];atomic_json(d/'job.json',dict(command=cmd,input_sha256=item['sha256'],cpu=45,seconds=10,memory_bytes=16*1024**3,environment={k:v for k,v in env.items()if k.startswith(('MIP_','OMP_','OPENBLAS_'))},build_info=info));start=time.monotonic();run=subprocess.run(cmd,capture_output=True,text=True,env=env,preexec_fn=restrict,timeout=70);(d/'result.json').write_text(run.stdout);(d/'stderr.log').write_text(run.stderr);atomic_json(d/'execution.json',dict(exit_code=run.returncode,wall_seconds=time.monotonic()-start));assert run.returncode==0;r=json.loads(run.stdout);print(json.dumps(dict(name=name,flag=flag,**{k:r.get(k)for k in ['status','objective','dual_bound','adaptive_resource_repair']})),flush=True)
atomic_json(out/'exit.json',dict(status='complete'))
