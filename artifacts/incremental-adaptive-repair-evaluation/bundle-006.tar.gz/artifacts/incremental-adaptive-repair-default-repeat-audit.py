from pathlib import Path
import json,os,sys,subprocess
sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256
from verify_cover_cuts import validate_cut_proofs
root=Path.cwd();out=root/'artifacts/incremental-adaptive-repair-default-repeat-audit';out.mkdir();os.sched_setaffinity(0,{40});os.environ['MIP_ABSOLUTE_CHECKER']='/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker-absolute';records=[]
for source in ['incremental-adaptive-repair-default-repeat-pairs','incremental-adaptive-repair-default-repeat-extra']:
 for p in sorted((root/'artifacts'/source).glob('*/*/result.json')):
  r=json.loads(p.read_text());job=json.loads((p.parent/'job.json').read_text());model=Path(job['command'][2]);assert sha256(model)==job['input_sha256'];d=out/source/p.parent.parent.name/p.parent.name;d.mkdir(parents=True);proof=validate_cut_proofs(model,r);atomic_json(d/'proof.json',proof);assert proof['valid'];record=dict(source=source,name=p.parent.parent.name,variant=p.parent.name,result_sha256=sha256(p),proof_valid=True,has_point=r.get('values')is not None)
  if record['has_point']:
   cmd=[str(root/'.venv/bin/python'),'/home/ubuntu/mip-codex/scripts/benchmark_validate.py',str(model),str(p),'/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker',str(d)]
   with(d/'audit.log').open('w')as stream:run=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,timeout=600)
   strict=json.loads((d/'strict-validation.json').read_text());official=json.loads((d/'official-validation.json').read_text());assert run.returncode==0 and strict['valid']and official['valid'];record.update(strict_valid=True,official_valid=True)
  records.append(record);atomic_json(out/'records.json',records)
assert len(records)==14,len(records)
atomic_json(out/'summary.json',dict(outputs=len(records),proof_valid=len(records),points=sum(r['has_point']for r in records),strict_valid=sum(r.get('strict_valid',False)for r in records),official_valid=sum(r.get('official_valid',False)for r in records)));print((out/'summary.json').read_text())
