from pathlib import Path
import os,json,hashlib,tarfile,subprocess,datetime,shutil
os.sched_setaffinity(0,{43});root=Path('/home/ubuntu/mip-adaptive-resource-repair');base=root/'artifacts/adaptive-resource-repair-evaluation';summary=json.loads((base/'summary.json').read_text());records=json.loads((base/'manifest.json').read_text());mapping={r['path']:r for r in records};where={}
for b in summary['bundles']:
 p=base/b['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==b['sha256']
 with tarfile.open(p,'r:gz')as t:
  for m in t:
   r=mapping[m.name];data=t.extractfile(m).read();assert len(data)==r['bytes']and hashlib.sha256(data).hexdigest()==r['sha256'];where[m.name]=b['path']
assert len(where)==len(records)
tracked=set(subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines());deleted=[];skipped=[]
for r in records:
 rel=r['path'];p=root/rel
 if not rel.startswith('artifacts/')or '-diagnostic/'in rel or rel.startswith('artifacts/runs/')or rel in tracked or not p.is_file()or p.is_symlink():continue
 data=p.read_bytes()
 if data[:4]==b'\x7fELF':continue
 if hashlib.sha256(data).hexdigest()!=r['sha256']:skipped.append(rel);continue
 p.unlink();deleted.append(dict(**r,archive=str(base),bundle=where[rel]))
s=dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),root=str(root),purpose='inactive intermediate only; full archive and loose SHA reverified; keep tracked files, bundles, ELF, diagnostic directories and run snapshots',all_archive_payload_sha256_verified=True,files=len(deleted),bytes=sum(r['bytes']for r in deleted),disk_free_bytes=shutil.disk_usage(root).free,skipped_changed_files=skipped,deleted=deleted);Path('artifacts/incremental-adaptive-repair-cleanup-intermediate.json').write_text(json.dumps(s,indent=2));print({k:v for k,v in s.items()if k!='deleted'})
