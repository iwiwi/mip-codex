from pathlib import Path
import json,hashlib,tarfile
root=Path.cwd();assert json.loads((root/'artifacts/incremental-adaptive-repair-default-development-audit/exit.json').read_text())['status']=='complete'
assert json.loads((root/'artifacts/incremental-adaptive-repair-development-audit/exit.json').read_text())['status']=='complete'
assert json.loads((root/'artifacts/incremental-adaptive-repair-default-repeat-audit/summary.json').read_text())['outputs']==14
out=root/'artifacts/incremental-adaptive-repair-evaluation';assert not out.exists();out.mkdir();paths=set()
for pattern in ['incremental-adaptive-repair*']:
 for p in (root/'artifacts').glob(pattern):
  if p==out or p.name in ['incremental-adaptive-repair-archive.log']:continue
  if p.is_file():paths.add(p)
  elif p.is_dir():paths.update(q for q in p.rglob('*')if q.is_file())
for name in ['INCREMENTAL_ADAPTIVE_REPAIR_RESULTS.md','INCREMENTAL_REPAIR_HYPOTHESIS.md']:paths.add(root/'docs'/name)
for name in ['smoke-20261117-212701-ubse6hyl','smoke-20261117-213404-v2rotb6f']:paths.update(p for p in (root/'artifacts'/name).rglob('*')if p.is_file())
ledger=[];excluded=[]
for p in sorted(paths):
 assert not p.is_symlink();data=p.read_bytes();r=dict(path=str(p.relative_to(root)),bytes=len(data),sha256=hashlib.sha256(data).hexdigest());(excluded if data[:4]==b'\x7fELF'else ledger).append(r)
groups=[];group=[];size=0
for r in ledger:
 if group and size+r['bytes']>75*1024**2:groups.append(group);group=[];size=0
 group.append(r);size+=r['bytes']
if group:groups.append(group)
bundles=[]
for i,group in enumerate(groups,1):
 p=out/f'bundle-{i:03d}.tar.gz'
 with tarfile.open(p,'w:gz',compresslevel=6)as t:
  for r in group:t.add(root/r['path'],arcname=r['path'],recursive=False)
 assert p.stat().st_size<95*1024**2
 with tarfile.open(p,'r:gz')as t:
  members=t.getmembers();assert len(members)==len(group)
  for m,r in zip(members,group):
   data=t.extractfile(m).read();assert m.name==r['path']and len(data)==r['bytes']and hashlib.sha256(data).hexdigest()==r['sha256']
 bundles.append(dict(path=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),files=len(group)))
(out/'manifest.json').write_text(json.dumps(ledger,indent=2));(out/'excluded-elf.json').write_text(json.dumps(excluded,indent=2));s=dict(files=len(ledger),raw_bytes=sum(r['bytes']for r in ledger),compressed_bytes=sum(r['bytes']for r in bundles),bundles=bundles,excluded_elfs=len(excluded),all_payload_sha256_verified=True);(out/'summary.json').write_text(json.dumps(s,indent=2));print(json.dumps(s))
