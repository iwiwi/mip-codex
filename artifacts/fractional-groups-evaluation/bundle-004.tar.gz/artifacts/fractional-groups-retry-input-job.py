from pathlib import Path
import json,os,shutil,subprocess,time,resource,sys
root=Path.cwd();os.sched_setaffinity(0,{45});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256
records=[]
for bad in json.load(open('artifacts/fractional-groups-input-link-failed-jobs.json')):
 d=root/bad['directory'];old=root/'artifacts/fractional-groups-development-screen/interrupted-input-link/failed-cases'/bad['name']/bad['variant'];old.parent.mkdir(parents=True,exist_ok=True);shutil.move(d,old);d.mkdir();job=json.load(open(old/'job.json'));job['cpu']=45;job['retry_of']=str(old);atomic_json(d/'job.json',job);cmd=job['command'];env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(job['environment']);model=Path(cmd[-2]);assert sha256(model)==job['input_sha256'];start=time.monotonic()
 with(d/'stdout.log').open('w')as out,(d/'stderr.log').open('w')as err:run=subprocess.run(cmd,env=env,stdout=out,stderr=err,timeout=70)
 execution=dict(exit_code=run.returncode,watchdog=False,wall_seconds=time.monotonic()-start);atomic_json(d/'execution.json',execution);assert run.returncode==0;r=json.load(open(d/'stdout.log'));atomic_json(d/'result.json',r);summary=dict(name=bad['name'],split='development',variant=bad['variant'],cpu=45,execution=execution,point_validation='pending independent audit',**{k:r[k]for k in ['status','objective','dual_bound','gap','nodes','seconds']});atomic_json(d/'summary.json',summary);records.append(summary)
atomic_json(root/'artifacts/fractional-groups-input-link-retry-exit.json',dict(status='complete',recovered=len(records),records=records))
