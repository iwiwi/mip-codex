根LPの資源制限後、既存主解から目的改善を試す修復探索で索引を再利用し、同じ時間・work予算で試行を続けます。適応重みは毎回初期化し、元問題の点・目的検査を維持します。追加メモリが収まらない場合は従来経路へ戻ります。

既定設定の開発188問題×10秒では主解2改善・0悪化（map10 −16→−25、supportcase12 −9→−12）。376出力と128点の独立検証、340 Rustテスト、生成直接400点、回帰1200点・厳密下界1028証明・改ざん8224件が合格しました。初期凍結での下界悪化とGLPK比較driver欠落errorも保存しています。HiGHS/SCIPの主解は依然優れ、総合優位・新記録は未達成です。

最終core961e1b624f/FP8a9ce2724eeea001。測定方法・native比較・限界はdocs/REUSABLE_ADAPTIVE_REPAIR_RESULTS.md、全証拠はartifacts/reusable-repair-evaluationとreusable-repair-default-evaluationに保存し全SHA256を照合しました。
