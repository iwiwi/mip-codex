//! Exact integer box implication, cached at the root to keep child row layouts stable.
use crate::model::{Model,Variable};
use serde::{Serialize,Deserialize};
use std::time::Instant;
#[derive(Clone,Debug,Serialize,Deserialize)]pub struct Proof{pub rows:Vec<usize>}
fn integer(x:f64)->Option<i128>{(x.is_finite()&&x.fract()==0.&&x.abs()<=4503599627370496.).then_some(x as i128)}
fn endpoint(v:&Variable,upper:bool)->Option<i128>{let(b,e)=if upper{(v.upper?,v.upper_enclosure?)}else{(v.lower?,v.lower_enclosure?)};if e!=[b,b]{return None;}integer(if v.integer{if upper{b.floor()}else{b.ceil()}}else{b})}
fn bound(b:Option<f64>,e:Option<[f64;2]>)->Option<i128>{let b=b?;(e==Some([b,b])).then_some(())?;integer(b)}
pub fn derive(model:&Model,fixes:Option<&crate::zero_dominance::Proof>,deadline:Instant)->Option<Proof>{
 if model.variables.len()>1_000_000||Instant::now()>=deadline{return None;}
 let mut bounds=Vec::with_capacity(model.variables.len());
 for(j,v)in model.variables.iter().enumerate(){if j%1024==0&&Instant::now()>=deadline{return None;}let b=[endpoint(v,false),endpoint(v,true)];if b[0].zip(b[1]).is_some_and(|(l,u)|l>u){return None;}bounds.push(b);}
 if let Some(p)=fixes{for(k,f)in p.fixes.iter().enumerate(){if k%1024==0&&Instant::now()>=deadline{return None;}let v=integer(f.value()?)?;*bounds.get_mut(f.variable)?=[Some(v);2];}}
 let mut rows=vec![];
 for(i,row)in model.rows.iter().enumerate(){
  if i%128==0&&Instant::now()>=deadline{break;}
  if !row.exact_coefficients{continue;}
  let mut activity=[Some(0i128);2];
  for(k,&(j,a))in row.coefficients.iter().enumerate(){if k%4096==0&&Instant::now()>=deadline{return (!rows.is_empty()).then_some(Proof{rows});}if a==0.{continue;}let Some(a)=integer(a)else{activity=[None;2];break;};for side in 0..2{let b=bounds[j][if a>=0{side}else{1-side}];activity[side]=activity[side].and_then(|s|s.checked_add(a.checked_mul(b?)?));}}
  let lower=row.lower.is_none()||bound(row.lower,row.lower_enclosure).zip(activity[0]).is_some_and(|(b,a)|a>=b);
  let upper=row.upper.is_none()||bound(row.upper,row.upper_enclosure).zip(activity[1]).is_some_and(|(b,a)|a<=b);
  if lower&&upper{rows.push(i);}
 }
 (!rows.is_empty()).then_some(Proof{rows})
}
#[cfg(test)]mod tests{
 use super::*;
 #[test]fn original_integer_rounding_and_unknown_continuous_endpoints_are_conservative(){
  let m=crate::mps::parse(std::io::Cursor::new("NAME boxrows\nROWS\n N c\n L r\n G s\n E t\nCOLUMNS\n x c 1 r 1\n x s 1 t 1\nRHS\n rhs r 2 s 1\n rhs t 1\nBOUNDS\n LI b x 0.5\n UI b x 2.5\nENDATA\n")).unwrap();let p=derive(&m,None,Instant::now()+std::time::Duration::from_secs(1)).unwrap();assert_eq!(p.rows,vec![0,1]);let mut continuous=m.clone();continuous.variables[0].integer=false;assert!(derive(&continuous,None,Instant::now()+std::time::Duration::from_secs(1)).is_none());assert!(derive(&m,None,Instant::now()).is_none());
 }
 #[test]fn zero_cost_dominance_can_make_a_row_redundant(){let m=crate::mps::parse(std::io::Cursor::new("NAME boxdom\nROWS\n N c\n L r\nCOLUMNS\n x c -1 r 1\n z c 0 r -1\nRHS\n rhs r 0\nBOUNDS\n BV b x\n LI b z 0\n UI b z 2\nENDATA\n")).unwrap();assert!(derive(&m,None,Instant::now()+std::time::Duration::from_secs(1)).is_none());let fixes=crate::zero_dominance::derive(&m,Instant::now()+std::time::Duration::from_secs(1)).unwrap();assert_eq!(derive(&m,Some(&fixes),Instant::now()+std::time::Duration::from_secs(1)).unwrap().rows,vec![0]);}
}
