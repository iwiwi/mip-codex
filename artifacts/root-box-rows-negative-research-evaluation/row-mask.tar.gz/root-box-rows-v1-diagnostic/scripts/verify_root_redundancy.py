"""Independently verify cached root row implications from original MPS Fractions."""
from fractions import Fraction
from pathlib import Path
import math,struct,hashlib

def verify(names,variables,rows,objective,result):
    proof=result.get('root_redundancy_proof')
    if proof is None:return None
    if not isinstance(proof,dict)or set(proof)!={'rows'}:raise ValueError('root redundancy schema')
    indices=proof['rows']
    if not isinstance(indices,list)or not indices or len(indices)>len(rows):raise ValueError('root redundancy row list')
    bounds={name:[v['lower'],v['upper']]for name,v in variables.items()}
    for name,v in variables.items():
        if v['integer']:
            if bounds[name][0]is not None:bounds[name][0]=Fraction(math.ceil(bounds[name][0]))
            if bounds[name][1]is not None:bounds[name][1]=Fraction(math.floor(bounds[name][1]))
        lo,hi=bounds[name]
        if lo is not None and hi is not None and lo>hi:raise ValueError('empty original integer box')
    zero=result.get('zero_dominance_proof')
    if zero is not None:
        from verify_zero_dominance import verify as verify_zero
        assert verify_zero(names,variables,rows,objective,result)['valid']is True
        for fix in zero['fixes']:
            value=Fraction.from_float(struct.unpack('>d',bytes.fromhex(fix['value_bits']))[0]);bounds[names[fix['variable']]]=[value,value]
    last=-1
    for index in indices:
        if type(index)is not int or not last<index<len(rows):raise ValueError('root redundancy row order/index')
        last=index;row=rows[index];activity=[Fraction(0),Fraction(0)]
        for name,a in row['coefficients'].items():
            if not a:continue
            for side in [0,1]:
                v=bounds[name][side if a>0 else 1-side]
                if v is None:activity[side]=None
                elif activity[side]is not None:activity[side]+=a*v
        if row['lower']is not None and(activity[0]is None or activity[0]<row['lower']):raise ValueError('root box does not imply lower row')
        if row['upper']is not None and(activity[1]is None or activity[1]>row['upper']):raise ValueError('root box does not imply upper row')
    return dict(valid=True,rows=len(indices),arithmetic='original MPS Fraction box implication after independently verified zero-cost fixes',checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
