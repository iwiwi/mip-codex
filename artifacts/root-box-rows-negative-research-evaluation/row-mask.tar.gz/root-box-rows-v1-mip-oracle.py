from pathlib import Path
from fractions import Fraction as F
import os,sys,json,subprocess,random,itertools,copy,struct,time,resource
root=Path.cwd();frozen=root/'artifacts/root-box-rows-v1-diagnostic';sys.path.insert(0,str(frozen/'scripts'));from verify_cover_cuts import exact_model,validate_cut_proofs
sys.path.insert(0,str(root/'scripts'));from benchmark_common import atomic_json,sha256
os.sched_setaffinity(0,{41});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));out=root/'artifacts/root-box-rows-v1-mip-oracle';out.mkdir();binary=frozen/'bin/mip-codex';rng=random.Random(2026111713);records=[];tampered=0
atomic_json(out/'experiment.json',dict(seed=2026111713,cpu=41,models=200,senses=['MIN','MAX'],flags=[0,1],seconds=2,memory_bytes=16*1024**3,binary_sha256=sha256(binary),build_info=json.loads(subprocess.check_output([str(binary),'build-info']))))
for case in range(200):
 costs=[rng.choice([i for i in range(-9,10)if i])for _ in range(3)]+[0,0];plant=[rng.randrange(3)for _ in costs];plant[0]=rng.randrange(2);rows=[];offset=rng.randint(-20,20)
 for i in range(5):
  a=[rng.randint(-3,3)for _ in range(3)]+[0,0]
  if i>=3:a[i]=rng.choice([-3,-2,-1,1,2,3])
  if not any(a):a[0]=1
  sense=rng.choice(['L','G']);rhs=sum(c*x for c,x in zip(a,plant))+(1 if sense=='L'else-1)*rng.randint(0,2);rows.append((a,sense,rhs))
 rows.extend([([3,2,-1,0,0],'L',10),([3,2,-1,0,0],'G',-2),([1,0,0,0,0],'L',1)])
 points=[x for x in itertools.product(range(3),repeat=5)if all((sum(c*v for c,v in zip(a,x))<=b if sense=='L'else sum(c*v for c,v in zip(a,x))>=b)for a,sense,b in rows)];assert points
 for maximize in [False,True]:
  d=out/f'{case}-{int(maximize)}';d.mkdir();model=d/'model.mps';text='NAME dom\nOBJSENSE\n '+('MAX'if maximize else'MIN')+'\nROWS\n N obj\n'+''.join(f' {s} r{i}\n'for i,(_,s,_)in enumerate(rows))+'COLUMNS\n'
  for j,c in enumerate(costs):text+=f' x{j} obj {c}\n'+''.join(f' x{j} r{i} {a[j]}\n'for i,(a,_,_)in enumerate(rows)if a[j])
  text+='RHS\n'+f' rhs obj {-offset}\n'+''.join(f' rhs r{i} {b}\n'for i,(_,_,b)in enumerate(rows))+'BOUNDS\n'+''.join(f' LI b x{j} 0\n UI b x{j} 2\n'for j in range(5))+'ENDATA\n';model.write_text(text);names,variables,parsed_rows,obj,constant=exact_model(model,True);assert constant==offset and all(obj.get(f'x{j}',F(0))==c for j,c in enumerate(costs));opt=(max if maximize else min)(offset+sum(c*v for c,v in zip(costs,x))for x in points)
  for label in (['before','after']if case%2==0 else['after','before']):
   dest=d/label;dest.mkdir();env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_ZERO_DOMINANCE='1',MIP_ROOT_BOX_ROWS='0'if label=='before'else'1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');cmd=[str(binary),'solve',str(model),'2'];atomic_json(dest/'job.json',dict(command=cmd,environment={k:v for k,v in env.items()if k.startswith(('MIP_','OMP_','OPENBLAS_'))},input_sha256=sha256(model)));start=time.monotonic();run=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=62);(dest/'result.json').write_text(run.stdout);(dest/'stderr.log').write_text(run.stderr);atomic_json(dest/'execution.json',dict(exit_code=run.returncode,wall_seconds=time.monotonic()-start));assert run.returncode==0;r=json.loads(run.stdout);check=validate_cut_proofs(model,r);atomic_json(dest/'proof-validation.json',check);assert check['valid']is True,(case,maximize,label,check);assert r['status']=='optimal',(case,maximize,label,r['status']);assert abs(F(str(r['objective']))-opt)<=F(1,1000000);x={name:F(str(r['values'][name]))for name in names};assert all(-F(1,1000000)<=v<=2+F(1,1000000)and abs(v-round(v))<=F(1,1000000)for v in x.values());assert all((row['lower']is None or sum(a*x[k]for k,a in row['coefficients'].items())>=row['lower']-F(1,1000000))and(row['upper']is None or sum(a*x[k]for k,a in row['coefficients'].items())<=row['upper']+F(1,1000000))for row in parsed_rows)
   if r['dual_bound']is not None:assert (-1 if maximize else 1)*F(str(r['dual_bound']))<=(-1 if maximize else 1)*opt+F(1,1000000)
   proof=r.get('root_redundancy_proof')
   assert check['zero_dominance']['valid']is True and check['zero_dominance']['fixed']==2
   if label=='after':
    assert proof is not None and {5,6}<=set(proof['rows'])and check['root_redundancy']['valid']is True,(case,check,proof)
    for variant in range(6):
     bad=copy.deepcopy(proof)
     if variant==0:bad['rows'].append(bad['rows'][-1])
     elif variant==1:bad['rows'].reverse()
     elif variant==2:bad['rows']=[7]
     elif variant==3:bad['rows']=[len(parsed_rows)]
     elif variant==4:bad['rows']=[]
     else:bad['extra']=True
     rejected=validate_cut_proofs(model,dict(r,root_redundancy_proof=bad));assert rejected['valid']is False,(variant,rejected);atomic_json(dest/f'tamper-{variant}.json',dict(proof=bad,validation=rejected));tampered+=1
   else:assert proof is None
   record=dict(case=case,maximize=maximize,label=label,objective=r['objective'],optimum=opt,status=r['status'],proof_valid=True,point_valid=True,removed_rows=0 if proof is None else len(proof['rows']));records.append(record);atomic_json(dest/'validation.json',record);atomic_json(out/'progress.json',dict(outputs=len(records),valid=len(records),tamper_rejected=tampered))
atomic_json(out/'records.json',records);atomic_json(out/'summary.json',dict(outputs=len(records),valid=len(records),tamper_rejected=tampered));atomic_json(out/'exit.json',dict(status='complete'));print(json.loads((out/'summary.json').read_text()))
