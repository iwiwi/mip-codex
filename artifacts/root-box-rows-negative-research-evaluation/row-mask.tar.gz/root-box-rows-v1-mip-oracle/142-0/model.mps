NAME dom
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 G r3
 G r4
 L r5
 G r6
 L r7
COLUMNS
 x0 obj -7
 x0 r0 -3
 x0 r1 -3
 x0 r2 -1
 x0 r4 2
 x0 r5 3
 x0 r6 3
 x0 r7 1
 x1 obj -3
 x1 r0 2
 x1 r1 -2
 x1 r3 -2
 x1 r4 -3
 x1 r5 2
 x1 r6 2
 x2 obj -3
 x2 r0 -3
 x2 r2 3
 x2 r3 -1
 x2 r5 -1
 x2 r6 -1
 x3 obj 0
 x3 r3 1
 x4 obj 0
 x4 r4 2
RHS
 rhs obj 9
 rhs r0 1
 rhs r1 -1
 rhs r2 -2
 rhs r3 -1
 rhs r4 -2
 rhs r5 10
 rhs r6 -2
 rhs r7 1
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
