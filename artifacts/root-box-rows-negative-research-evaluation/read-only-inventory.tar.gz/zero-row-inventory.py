from pathlib import Path
import json,subprocess,os,resource,sys
sys.path.insert(0,'scripts')
from benchmark_common import atomic_json,sha256
root=Path.cwd();out=root/'artifacts/zero-row-inventory';out.mkdir();os.sched_setaffinity(0,{31});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));binary=Path('/home/ubuntu/mip-dominance/target/release/examples/zero_row_inventory');source=Path('/home/ubuntu/mip-dominance/examples/zero_row_inventory.rs');(out/'helper.rs').write_bytes(source.read_bytes());atomic_json(out/'experiment.json',dict(purpose='read-only exact integer box redundant rows before/after certified zero-cost fixing; no solve or adoption',cpu=31,binary_sha256=sha256(binary),helper_source_sha256=sha256(source),library_reference='main PR108 plus zero dominance candidate FP3dec48b2a30f0b78'));records=[];manifest=[r for r in json.loads((root/'data/manifest.json').read_text())['instances']if r['split']=='development'];assert len(manifest)==188
try:
 for r in manifest:
  p=root/r['path'];assert sha256(p)==r['sha256'];d=out/r['name'];d.mkdir()
  with(d/'stdout.json').open('w')as stream,(d/'stderr.log').open('w')as error:proc=subprocess.run([str(binary),str(p)],stdout=stream,stderr=error,timeout=60)
  v=dict(name=r['name'],input_sha256=r['sha256'],exit_code=proc.returncode)
  if proc.returncode==0:v.update(json.loads((d/'stdout.json').read_text()))
  records.append(v);atomic_json(d/'record.json',v);atomic_json(out/'records.json',records)
 summary=dict(cases=len(records),success=sum(r['exit_code']==0 for r in records),additional_rows=sum(r.get('redundant_after',0)-r.get('redundant_before',0)for r in records),before_rows=sum(r.get('redundant_before',0)for r in records),after_rows=sum(r.get('redundant_after',0)for r in records));atomic_json(out/'summary.json',summary);atomic_json(out/'exit.json',dict(status='complete'));print(summary)
except BaseException as error:atomic_json(out/'exit.json',dict(status='failed',completed=len(records),error=str(error)));raise
