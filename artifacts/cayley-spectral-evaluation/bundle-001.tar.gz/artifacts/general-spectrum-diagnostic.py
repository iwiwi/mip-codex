from pathlib import Path
import os,sys,json,math,time
os.sched_setaffinity(0,{47});os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1');import numpy as np
sys.path.insert(0,'scripts');from verify_cayley_spectral import packing_graph;from benchmark_common import atomic_json,sha256
records=[]
for name,group in [('cod105.mps.gz','benchmark'),('sorrell3.mps.gz','benchmark'),('sorrell7.mps.gz','exploratory')]:
 p=Path('data/raw')/group/name;start=time.monotonic();names,conflict=packing_graph(p);n=len(names);matrix=np.zeros((n,n))
 for a,bits in enumerate(conflict):
  while bits:low=bits&-bits;bits-=low;matrix[a,low.bit_length()-1]=1.
 values=np.linalg.eigvalsh(matrix);degree=[v.bit_count()for v in conflict];regular=len(set(degree))==1;r=dict(name=name,input_sha256=sha256(p),vertices=n,degree_min=min(degree),degree_max=max(degree),regular=regular,approximate_minimum_eigenvalue=float(values[0]),approximate_maximum_eigenvalue=float(values[-1]),approximate_hoffman_upper=(n*(-float(values[0]))/(degree[0]-float(values[0])))if regular else None,seconds=time.monotonic()-start,certified=False,purpose='general linear algebra diagnostic only; cannot prune or declare optimality');records.append(r);atomic_json(Path('artifacts/general-spectrum-diagnostic.json'),records);print(json.dumps(r),flush=True)
