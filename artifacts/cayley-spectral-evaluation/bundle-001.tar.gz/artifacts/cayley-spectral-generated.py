from pathlib import Path
import os,sys,json,random,subprocess,copy,itertools,resource
os.sched_setaffinity(0,{41});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));root=Path.cwd();sys.path.insert(0,'scripts');from verify_cayley_spectral import verify,packing_graph;from benchmark_common import atomic_json,sha256
out=root/'artifacts/cayley-spectral-generated';out.mkdir();binary=root/'artifacts/cayley-spectral-v2-profile/profile';rng=random.Random(2026111802);records=[];atomic_json(out/'experiment.json',dict(models=200,weights=['positive','nonpositive-nonedges'],cpu=41,binary_sha256=sha256(binary),seed=2026111802,purpose='independent original-MPS proof plus exhaustive integer optimum; private bound-only profile'))
for case in range(200):
 bits=rng.randint(2,4);n=1<<bits;allowed=[False]+[bool(rng.getrandbits(1))for _ in range(bits)]
 if not any(allowed):allowed[rng.randint(1,bits)]=True
 mode=['binary','graded-lex','graded-colex'][case%3];labels=list(range(n))
 if mode=='graded-colex':labels.sort(key=lambda v:(v.bit_count(),v))
 if mode=='graded-lex':labels=[sum(1<<b for b in group)for weight in range(bits+1)for group in itertools.combinations(range(bits),weight)]
 edges=[(a,b)for a in range(n)for b in range(a+1,n)if allowed[(labels[a]^labels[b]).bit_count()]];adj=[0]*n
 for a,b in edges:adj[a]|=1<<b;adj[b]|=1<<a
 valid=bytearray(1<<n);valid[0]=1;opt=0
 for mask in range(1,1<<n):
  low=mask&-mask;v=low.bit_length()-1;rest=mask-low
  if valid[rest]and not adj[v]&rest:valid[mask]=1;opt=max(opt,mask.bit_count())
 maximize=case%2==1;negative=case%3==0;scale=rng.randint(1,4);weight=rng.randint(1,4);offset=rng.randint(-16,16)/8
 lines=['NAME spectral','OBJSENSE',' MAX'if maximize else' MIN','ROWS',' N obj',*[f' {"G"if negative else"L"} r{i}'for i in range(len(edges))],'COLUMNS']
 for v in range(n):
  lines.append(f' x{v} obj {weight if maximize else-weight}');lines.extend(f' x{v} r{i} {-scale if negative else scale}'for i,(a,b)in enumerate(edges)if v in[a,b])
 lines+=['RHS',f' rhs obj {-offset}',*[f' rhs r{i} {-scale if negative else scale}'for i in range(len(edges))],'BOUNDS',*[f' BV b x{v}'for v in range(n)],'ENDATA'];model=out/f'{case:04d}.mps';model.write_text('\n'.join(lines)+'\n');graph=packing_graph(model)
 for weights in ['positive','nonpositive-nonedges']:
  d=out/f'{case:04d}-{weights}';d.mkdir();run=subprocess.run([str(binary),str(model),'5',mode,weights,str(d/'result.json')],capture_output=True,text=True,timeout=15);(d/'stdout.log').write_text(run.stdout);(d/'stderr.log').write_text(run.stderr);assert run.returncode==0,run.stderr;c=json.load(open(d/'result.json'));assert c['recognized']is True,c;proof=verify(model,c,graph);assert opt<=c['upper'];atomic_json(d/'proof.json',proof);tamper=0
  for kind in ['degree','minimum','upper','labels','diagonal','float']:
   bad=copy.deepcopy(c)
   if kind=='degree':bad['degree']+=1
   elif kind=='minimum':bad['minimum_eigenvalue']-=1
   elif kind=='upper':bad['upper']-=1
   elif kind=='labels':bad['vertex_labels'][0]=bad['vertex_labels'][1]
   elif kind=='diagonal':bad['weights'][0]=1
   else:bad['weights'][1]=float(bad['weights'][1])
   try:verify(model,bad,graph)
   except(AssertionError,TypeError,ValueError,KeyError):tamper+=1
   else:raise AssertionError('accepted '+kind)
  records.append(dict(case=case,weights=weights,vertices=n,exact_optimum=opt,upper=c['upper'],valid=True,tamper_rejected=tamper));atomic_json(out/'records.json',records)
 atomic_json(out/'progress.json',dict(models=case+1,outputs=len(records)));print(case+1,len(records),flush=True)
atomic_json(out/'summary.json',dict(models=200,outputs=len(records),strict_valid=len(records),exhaustive_valid=len(records),tamper_rejected=sum(r['tamper_rejected']for r in records)));atomic_json(out/'exit.json',dict(status='complete'))
