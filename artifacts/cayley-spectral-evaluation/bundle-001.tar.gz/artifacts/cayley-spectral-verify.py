from pathlib import Path
import json,sys,copy,os
root=Path.cwd();os.sched_setaffinity(0,{41});sys.path.insert(0,'scripts');from verify_cayley_spectral import verify,packing_graph
records=[]
for directory in ['cayley-spectral-profile','cayley-spectral-v2-profile']:
 for p in(root/'artifacts'/directory).glob('*/*/result.json'):
  c=json.load(open(p))
  if not c['recognized']:continue
  model=root/'data/raw/benchmark'/p.parent.parent.name;graph=packing_graph(model);proof=verify(model,c,graph);tamper=0
  for kind in ['degree','minimum','upper','labels','diagonal','float','nonedge']:
   bad=copy.deepcopy(c)
   if kind=='degree':bad['degree']+=1
   elif kind=='minimum':bad['minimum_eigenvalue']-=1
   elif kind=='upper':bad['upper']-=1
   elif kind=='labels':bad['vertex_labels'][0]=bad['vertex_labels'][1]
   elif kind=='diagonal':bad['weights'][0]=1
   elif kind=='float':bad['weights'][1]=float(bad['weights'][1])
   else:
    names,conflict=graph;labels=bad['vertex_labels'];a,b=next((a,b)for a in range(len(names))for b in range(a+1,len(names))if not conflict[a]&(1<<b));bad['weights'][labels[a]^labels[b]]=1;w=bad['weights'];e=[sum(v*(-1 if(s&d).bit_count()%2 else 1)for d,v in enumerate(w))for s in range(len(w))];bad['degree']=sum(w);bad['minimum_eigenvalue']=min(e);bad['upper']=len(w)*(-min(e))//(sum(w)-min(e))
   try:verify(model,bad,graph)
   except(AssertionError,ValueError,TypeError,KeyError):tamper+=1
   else:raise AssertionError('accepted '+kind)
  record=dict(result=str(p.relative_to(root)),proof=proof,tamper_rejected=tamper);(p.parent/'strict-spectral-validation.json').write_text(json.dumps(record,indent=2));records.append(record);print(json.dumps(record),flush=True)
(root/'artifacts/cayley-spectral-proof-summary.json').write_text(json.dumps(dict(certificates=len(records),strict_valid=len(records),tamper_rejected=sum(r['tamper_rejected']for r in records)),indent=2))
