from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal
import random,subprocess,json,os,sys,hashlib
os.sched_setaffinity(0,{50});root=Path.cwd();sys.path.insert(0,str(root/'scripts'));from validate_solution import validate
out=root/'artifacts/lazy-coefficient-certifier-mixed-oracle';out.mkdir();binary=root/'artifacts/lazy-coefficient-certifier-after/bin/mip-codex';rng=random.Random(2026111727);records=[]
for case in range(200):
 a=F(rng.randint(1,5))+F(rng.choice([-1,1]),10**20);b=F(rng.randint(1,4))+F(rng.choice([-1,1]),10**20);rhs=F(rng.randint(1,15));cx=rng.choice([-7,-3,-1,1,3,7]);cy=rng.choice([-5,-2,-1,1,2,5]);maximize=bool(case%2);offset=rng.randint(-5,5)
 points=[]
 for x in range(4):
  upper=min(F(3),(rhs-a*x)/b)
  if upper>=0:
   for y in [F(0),upper]:points.append((offset+cx*x+cy*y,x,y))
 exact=(max if maximize else min)(p[0]for p in points)
 token=lambda v:format(Decimal(v.numerator)/Decimal(v.denominator),'f')
 d=out/f'{case:03d}';d.mkdir();m=d/'model.mps';m.write_text(f'NAME mixed\nOBJSENSE\n {"MAX" if maximize else "MIN"}\nROWS\n N c\n L r\nCOLUMNS\n x c {cx} r {token(a)}\n y c {cy} r {token(b)}\nRHS\n rhs c {-offset}\n rhs r {rhs}\nBOUNDS\n LI b x 0\n UI b x 3\n LO b y 0\n UP b y 3\nENDATA\n')
 run=subprocess.run([str(binary),'solve',str(m),'2'],capture_output=True,text=True,timeout=62);assert run.returncode==0;d.joinpath('result.json').write_text(run.stdout);d.joinpath('stderr.log').write_text(run.stderr);r=json.loads(run.stdout);dual=r.get('dual_bound');safe=dual is None or(min(F(dual),F(str(dual)))>=exact if maximize else max(F(dual),F(str(dual)))<=exact);assert safe,(case,exact,dual)
 if r['status']=='optimal':assert abs(F(str(r['objective']))-exact)<=F(1,10**8)*(1+abs(exact))
 assert r['status']!='infeasible'
 validation=None
 if r.get('values')is not None:validation=validate(m,{'objective':r['objective'],'values':r['values']});assert validation['valid'],(case,validation)
 record=dict(case=case,status=r['status'],exact_optimum=str(exact),dual=dual,conservative=safe,point=validation,mps_sha256=hashlib.sha256(m.read_bytes()).hexdigest());records.append(record);d.joinpath('validation.json').write_text(json.dumps(record,indent=2))
 if case%25==0:print(case,flush=True)
summary=dict(runs=len(records),bad_duals=0,optimal=sum(r['status']=='optimal'for r in records),points=sum(r['point']is not None for r in records));out.joinpath('records.json').write_text(json.dumps(records,indent=2));out.joinpath('summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
