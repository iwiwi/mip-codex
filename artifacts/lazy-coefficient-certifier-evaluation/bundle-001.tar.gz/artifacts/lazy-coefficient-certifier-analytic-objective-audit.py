from pathlib import Path
from fractions import Fraction as F
import json,hashlib
root=Path.cwd();records=[]
for name in ['lazy-coefficient-certifier-analytic-oracle','lazy-coefficient-certifier-dense-analytic-oracle']:
 source=root/'artifacts'/name
 for r in json.load(open(source/'records.json')):
  p=source/f"{r['case']:03d}"/(r['binary']+'.json');v=json.load(open(p));exact=F(r['exact_optimum']);gap=abs(F(str(v['objective']))-exact);limit=F(1,10**8)*(1+abs(exact));assert v['status']=='optimal'and gap<=limit
  records.append(dict(path=str(p.relative_to(root)),result_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),exact_optimum=str(exact),objective_error=str(gap),valid=True))
out=root/'artifacts/lazy-coefficient-certifier-analytic-objective-audit';out.mkdir();(out/'records.json').write_text(json.dumps(records,indent=2));(out/'summary.json').write_text(json.dumps(dict(outputs=len(records),valid=len(records),wrong_optimal_claims=0)));print(len(records),'valid')
