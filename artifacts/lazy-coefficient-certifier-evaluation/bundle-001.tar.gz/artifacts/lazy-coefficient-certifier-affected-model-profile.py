from pathlib import Path
import os,sys,json
os.sched_setaffinity(0,{45});root=Path.cwd();sys.path.insert(0,'scripts');from verify_cover_cuts import exact_model;from benchmark_common import sha256,atomic_json
manifest={r['name']:r for r in json.load(open('data/manifest.json'))['instances']};records=[]
for name in ['fast0507.mps.gz','seymour1.mps.gz','sp97ar.mps.gz','sp98ar.mps.gz']:
 m=manifest[name];assert m['split']=='development';p=root/m['path'];assert sha256(p)==m['sha256'];names,variables,rows=exact_model(p);n=sum(len(r['coefficients'])for r in rows);uncertain=sum(float(a).as_integer_ratio()!=(a.numerator,a.denominator)for r in rows for a in r['coefficients'].values());record=dict(name=name,input_sha256=m['sha256'],rows=len(rows),variables=len(names),nonzeros=n,nonbinary_exact_coefficients=uncertain,original_coefficient_certifier_needed=uncertain>0);records.append(record);print(json.dumps(record),flush=True)
atomic_json(root/'artifacts/lazy-coefficient-certifier-affected-model-profile.json',records)
