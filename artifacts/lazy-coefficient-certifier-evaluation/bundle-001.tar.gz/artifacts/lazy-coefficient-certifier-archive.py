from pathlib import Path
import json,hashlib,tarfile,re
root=Path.cwd();out=root/'artifacts/lazy-coefficient-certifier-evaluation';assert not out.exists();a=json.load(open('artifacts/lazy-coefficient-certifier-development-parallel-audit/summary.json'));assert a['completed']==a['cut_valid']==376 and a['points']==a['strict_valid']==a['official_valid']==128;assert json.load(open('artifacts/lazy-coefficient-certifier-development-parallel-audit/exit.json'))['status']=='complete';s=Path('artifacts/lazy-coefficient-certifier-full-tests.log').read_text();assert 'FAILED'not in s and sum(map(int,re.findall(r'test result: ok\. (\d+) passed',s)))==334
for kind,n in [('mip',800),('endpoint-mip',400)]:
 assert json.load(open(f'artifacts/lazy-coefficient-certifier-{kind}-oracle/exit.json'))['status']=='complete';a=json.load(open(f'artifacts/lazy-coefficient-certifier-{kind}-point-audit/summary.json'));assert a['points']==a['strict_valid']==n
roots=[p for p in(root/'artifacts').iterdir()if p.name.startswith('lazy-coefficient-certifier')and p!=out and p.name!='lazy-coefficient-certifier-archive.log'];files=sorted({f for p in roots for f in([p]if p.is_file()else p.rglob('*'))if f.is_file()});manifest=[];excluded=[];groups=[];group=[];size=0
for f in files:
 b=f.read_bytes();r=dict(path=str(f.relative_to(root)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 if b[:4]==b'\x7fELF':excluded.append(r);continue
 manifest.append(r)
 if group and size+len(b)>90*1024**2:groups.append(group);group=[];size=0
 group.append(f);size+=len(b)
if group:groups.append(group)
out.mkdir()
for i,group in enumerate(groups,1):
 p=out/f'bundle-{i:03d}.tar.gz'
 with tarfile.open(p,'w:gz',compresslevel=6)as t:
  for f in group:t.add(f,arcname=str(f.relative_to(root)),recursive=False)
 assert p.stat().st_size<95*1024**2
lookup={r['path']:r for r in manifest};seen=set()
for p in out.glob('bundle-*.tar.gz'):
 with tarfile.open(p)as t:
  for m in t:
   assert m.name not in seen;seen.add(m.name);b=t.extractfile(m).read();assert len(b)==lookup[m.name]['bytes']and hashlib.sha256(b).hexdigest()==lookup[m.name]['sha256']
assert seen==set(lookup);(out/'manifest.json').write_text(json.dumps(manifest,indent=2));(out/'excluded-elf.json').write_text(json.dumps(excluded,indent=2));s=dict(files=len(manifest),raw_bytes=sum(r['bytes']for r in manifest),bundles=len(groups),compressed_bytes=sum(p.stat().st_size for p in out.glob('bundle-*.tar.gz')),excluded_elf=len(excluded),all_payload_sha256_verified=True);(out/'summary.json').write_text(json.dumps(s,indent=2));print(json.dumps(s))
