from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal
import subprocess,json,os,hashlib,sys
os.sched_setaffinity(0,{51})
root=Path.cwd();out=root/'artifacts/lazy-coefficient-certifier-analytic-oracle';out.mkdir(exist_ok=True)
sys.path.insert(0,str(root/'scripts'));from validate_solution import validate
bins={'before':root/'artifacts/lazy-coefficient-certifier-before/bin/mip-codex','after':root/'artifacts/lazy-coefficient-certifier-after/bin/mip-codex'}
records=[]
for q in range(1,10):
 for delta in [-1,1]:
  a=F(q)+F(delta,10**20);token=format(Decimal(q)+Decimal(delta)/Decimal(10**20),'f')
  for maximize in [False,True]:
   for cost in [1,3,11]:
    for free in [False,True]:
     i=len(records)//2;d=out/f'{i:03d}';d.mkdir(exist_ok=True)
     m=d/'model.mps';m.write_text(f'NAME analytic\nOBJSENSE\n {"MAX" if maximize else "MIN"}\nROWS\n N c\n L r\nCOLUMNS\n x c {cost if maximize else -cost} r {token}\nRHS\n rhs r {q}\nBOUNDS\n'+(' FR b x\n' if free else ' LO b x 0\n UP b x 2\n')+'ENDATA\n')
     exact=F(cost*q)/a*(1 if maximize else -1)
     for label,binary in bins.items():
      run=subprocess.run([str(binary),'solve',str(m),'2'],capture_output=True,text=True,timeout=62);assert run.returncode==0,run.stderr
      r=json.loads(run.stdout);(d/f'{label}.json').write_text(run.stdout);(d/f'{label}.stderr').write_text(run.stderr)
      dual=r.get('dual_bound');good=dual is None or (min(F(str(dual)),F(dual))>=exact if maximize else max(F(str(dual)),F(dual))<=exact)
      point=None
      if r.get('values') is not None:
       point=validate(m,{'objective':r['objective'],'values':r['values']});assert point['valid'],point
      record=dict(case=i,binary=label,status=r['status'],dual=dual,exact_optimum=str(exact),conservative=good,point=point,mps_sha256=hashlib.sha256(m.read_bytes()).hexdigest());records.append(record)
      if label=='after':assert good,record
     if i%20==0:print(i,flush=True)
(out/'records.json').write_text(json.dumps(records,indent=2))
summary={label:dict(runs=sum(r['binary']==label for r in records),bad_duals=sum(r['binary']==label and not r['conservative'] for r in records),points=sum(r['binary']==label and r['point'] is not None for r in records))for label in bins}
(out/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
