from pathlib import Path
import os,sys,json,subprocess,shutil,copy,resource
from fractions import Fraction
root=Path.cwd();os.sched_setaffinity(0,{41});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));os.environ['MIP_ABSOLUTE_CHECKER']='/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker-absolute';sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256;from verify_cover_cuts import exact_model;from verify_binary_graph import verify;from verify_cayley_spectral import packing_graph;from validate_solution import validate
out=root/'artifacts/spectral-bound-default-generated';out.mkdir();source=Path('/home/ubuntu/mip-cayley-spectral-profile/artifacts/cayley-spectral-generated');assert json.load(open(source/'summary.json'))['outputs']==400;binary=root/'artifacts/spectral-bound-default-frozen/bin/mip-codex';atomic_json(out/'experiment.json',dict(source=str(source),models=200,limits=[0,3,100000],cpu=41,threads=1,memory_bytes=16*1024**3,binary_sha256=sha256(binary),purpose='fresh original-MPS exhaustive optimum, root spectrum, GMP, corrupted proof checks; no solver optima used as oracle'));records=[]
for case in range(200):
 model=out/f'{case:04d}.mps';shutil.copy2(source/model.name,model);exact=exact_model(model,True);names,conflict=packing_graph(model,exact);n=len(names);feasible=bytearray(1<<n);feasible[0]=1;opt=0
 for mask in range(1,1<<n):
  low=mask&-mask;v=low.bit_length()-1;rest=mask-low
  if feasible[rest]and not conflict[v]&rest:feasible[mask]=1;opt=max(opt,mask.bit_count())
 for limit in[0,3,100000]:
  d=out/f'{case:04d}-{limit}';d.mkdir();env={a:b for a,b in os.environ.items()if not a.startswith('MIP_')};env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');run=subprocess.run([str(binary),'solve',str(model),'5',str(limit)],env=env,capture_output=True,text=True,timeout=15);(d/'stdout.log').write_text(run.stdout);(d/'stderr.log').write_text(run.stderr);assert run.returncode==0,run.stderr;precise=json.loads(run.stdout,parse_float=Fraction);r=json.loads(run.stdout);g=r['binary_graph'];assert g and g['best']<=opt<=g['upper'];assert not g['complete']or g['best']==opt;proof=verify(model,precise,exact);atomic_json(d/'proof.json',proof);assert proof['valid'];point=validate(model,r);atomic_json(d/'point.json',point);assert point['valid'];c=(g.get('spectral_bound')or{}).get('certificate');tamper=0
  if c:
   for kind in['degree','minimum','upper','labels','diagonal','float']:
    bad=copy.deepcopy(precise);bc=bad['binary_graph']['spectral_bound']['certificate']
    if kind=='degree':bc['degree']+=1
    elif kind=='minimum':bc['minimum_eigenvalue']-=1
    elif kind=='upper':bc['upper']-=1
    elif kind=='labels':bc['vertex_labels'][0]=bc['vertex_labels'][1]
    elif kind=='diagonal':bc['weights'][0]=1
    else:bc['weights'][1]=float(bc['weights'][1])
    try:verify(model,bad,exact)
    except(AssertionError,ValueError,TypeError,KeyError):tamper+=1
    else:raise AssertionError('accepted spectral tamper '+kind)
  records.append(dict(case=case,limit=limit,input_sha256=sha256(model),optimum=opt,best=g['best'],upper=g['upper'],complete=g['complete'],spectral_certificate=c is not None,independent_optimality=proof['independent_optimality'],lp_solves=r['lp_solves'],valid=True,tamper_rejected=tamper));atomic_json(out/'records.json',records)
 atomic_json(out/'progress.json',dict(models=case+1,outputs=len(records)));print(case+1,len(records),flush=True)
atomic_json(out/'summary.json',dict(models=200,outputs=len(records),exhaustive_valid=len(records),proof_valid=len(records),gmp_valid=len(records),actual_spectral_certificates=sum(r['spectral_certificate']for r in records),independent_optimality=sum(r['independent_optimality']for r in records),tamper_rejected=sum(r['tamper_rejected']for r in records)));atomic_json(out/'exit.json',dict(status='complete'))
