from pathlib import Path
import os,json,sys,subprocess,random,itertools,copy,resource
from fractions import Fraction
root=Path.cwd();os.sched_setaffinity(0,{41});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));os.environ['MIP_ABSOLUTE_CHECKER']='/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker-absolute';sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256;from validate_solution import validate;from verify_cover_cuts import exact_model;from verify_binary_graph import verify
out=root/'artifacts/spectral-bound-default-cycles';out.mkdir();binary=root/'artifacts/spectral-bound-default-frozen/bin/mip-codex';rng=random.Random(2026111801);records=[];atomic_json(out/'experiment.json',dict(models=200,limits=[0,3,100000],cpu=41,threads=1,memory_bytes=16*1024**3,binary_sha256=sha256(binary),seed=2026111801,purpose='cyclic hyperedges,permutations,duplicate rows,MIN/MAX,dyadic offsets,negative/positive packing rows; exhaustive original constraints and strict Fraction cover/GMP'))
for case in range(200):
 n=rng.randint(7,12);k=rng.randint(3,min(5,n-1));permutation=list(range(n));rng.shuffle(permutation);groups=[sorted(permutation[(i+j)%n]for j in range(k))for i in range(n)];groups+=groups[:case%4];maximize=case%2==1;weight=rng.randint(1,4);offset=Fraction(rng.randint(-16,16),8);scale=rng.randint(1,3);negative=case%3==0
 lines=['NAME cyclic','OBJSENSE',' MAX'if maximize else' MIN','ROWS',' N obj',*[f' {"G"if negative else"L"} r{i}'for i in range(len(groups))],'COLUMNS']
 for v in range(n):
  lines.append(f' x{v} obj {weight if maximize else-weight}')
  lines.extend(f' x{v} r{i} {-scale if negative else scale}'for i,g in enumerate(groups)if v in g)
 lines+=['RHS',f' rhs obj {float(-offset)}',*[f' rhs r{i} {-scale if negative else scale}'for i in range(len(groups))],'BOUNDS',*[f' BV b x{v}'for v in range(n)],'ENDATA'];model=out/f'{case:04d}.mps';model.write_text('\n'.join(lines)+'\n');opt=max(sum(point)for point in itertools.product([0,1],repeat=n)if all(sum(point[v]for v in g)<=1 for g in groups));exact=exact_model(model,True)
 for limit in [0,3,100000]:
  d=out/f'{case:04d}-{limit}';d.mkdir();env={a:b for a,b in os.environ.items()if not a.startswith('MIP_')};env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');run=subprocess.run([str(binary),'solve',str(model),'5',str(limit)],env=env,capture_output=True,text=True,timeout=15);(d/'stdout.log').write_text(run.stdout);(d/'stderr.log').write_text(run.stderr);assert run.returncode==0;precise=json.loads(run.stdout,parse_float=Fraction);r=json.loads(run.stdout);g=r['binary_graph'];assert g is not None and g['best']<=opt<=g['upper'];assert not g['complete']or g['best']==opt;proof=verify(model,precise,exact);assert proof['valid'];atomic_json(d/'proof.json',proof);point=validate(model,r);assert point['valid'];atomic_json(d/'point.json',point);c=(g.get('fractional_cover')or{}).get('certificate');tamper=0
  if c:
   for kind in ['total','minimum','upper','zero','duplicate']:
    bad=copy.deepcopy(precise);bc=bad['binary_graph']['fractional_cover']['certificate']
    if kind=='total':bc['total']+=1
    elif kind=='minimum':bc['minimum']+=1
    elif kind=='upper':bc['upper']-=1
    elif kind=='zero':bc['counts'][0]=0
    else:bc['cliques'][0].append(bc['cliques'][0][0])
    try:verify(model,bad,exact)
    except(AssertionError,KeyError,ValueError,TypeError):tamper+=1
    else:raise AssertionError('accepted tamper '+kind)
  record=dict(case=case,limit=limit,valid=True,optimum_size=opt,best=g['best'],upper=g['upper'],complete=g['complete'],input_groups=((g.get('fractional_cover')or{}).get('stats')or{}).get('input_groups',0),input_upper=((g.get('fractional_cover')or{}).get('stats')or{}).get('input_upper'),certificate=c is not None,tamper_rejected=tamper);records.append(record);atomic_json(out/'records.json',records)
 atomic_json(out/'progress.json',dict(models=case+1,outputs=len(records)));print(case+1,len(records),flush=True)
summary=dict(models=200,outputs=len(records),exhaustive_valid=len(records),proof_valid=len(records),gmp_valid=len(records),actual_certificates=sum(r['certificate']for r in records),actual_input_covers=sum(r['input_upper']is not None for r in records),tamper_rejected=sum(r['tamper_rejected']for r in records));atomic_json(out/'summary.json',summary);atomic_json(out/'exit.json',dict(status='complete'));print(json.dumps(summary))
