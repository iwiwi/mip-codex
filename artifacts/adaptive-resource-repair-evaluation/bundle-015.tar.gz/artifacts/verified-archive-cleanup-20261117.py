from pathlib import Path
import os,json,hashlib,tarfile,subprocess,datetime
os.sched_setaffinity(0,{43});root=Path('/home/ubuntu/mip-codex');tracked=set(subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines());deleted=[];skipped=[];archives=[]
for name in ['rational-primal-witness-evaluation','zero-phase-one-evaluation']:
 base=root/'artifacts'/name;ledger=json.loads((base/'manifest.json').read_text());by_path={r['path']:r for r in ledger};bundles=json.loads((base/'bundles.json').read_text())
 for b in bundles:
  p=base/b['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==b['sha256']
  with tarfile.open(p,'r:gz')as t:
   for m in t:
    r=by_path[m.name];data=t.extractfile(m).read();assert len(data)==r['bytes']and hashlib.sha256(data).hexdigest()==r['sha256']
 archives.append(dict(path=str(base),files=len(ledger),all_payload_sha256_verified=True))
 for r in ledger:
  rel=r['path'];p=root/rel
  if not rel.startswith('artifacts/')or rel.startswith('artifacts/runs/')or '-diagnostic/'in rel or rel in tracked or not p.is_file()or p.is_symlink():continue
  if hashlib.sha256(p.read_bytes()).hexdigest()!=r['sha256']:skipped.append(dict(path=rel,reason='loose file SHA differs; retained'));continue
  with p.open('rb')as f:elf=f.read(4)==b'\x7fELF'
  if elf:continue
  p.unlink();deleted.append(dict(path=rel,bytes=r['bytes'],sha256=r['sha256'],archive=name,bundle=r['bundle']))
ledger=dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),purpose='remove only untracked inactive loose duplicates after full archive and loose-file SHA verification; keep archives, tracked files, frozen diagnostic directories, ELF, run snapshots and baseline untouched',archives=archives,deleted=deleted,skipped=skipped,deleted_bytes=sum(r['bytes']for r in deleted),disk_free_bytes=__import__('shutil').disk_usage(root).free)
p=Path('artifacts/verified-archive-cleanup-20261117.json');p.write_text(json.dumps(ledger,indent=2));(root/p).write_text(p.read_text());print({k:v for k,v in ledger.items()if k not in ['deleted','skipped']},'deleted_files',len(deleted),'skipped',len(skipped))
