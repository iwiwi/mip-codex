from pathlib import Path
import sys,os,json,subprocess,shutil,time,resource
sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256,require_solver_origin
root=Path.cwd();out=root/'artifacts/adaptive-resource-continue-prototype';out.mkdir();binary=root/'target/release/examples/adaptive_resource_continue';info=require_solver_origin(root,binary);shutil.copy2(binary,out/'adaptive_resource_continue');shutil.copy2(root/'examples/adaptive_resource_continue.rs',out/'source.rs');binary=out/'adaptive_resource_continue';os.sched_setaffinity(0,{45});manifest=json.loads((root/'data/manifest.json').read_text())['instances']
def restrict():resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3))
for name in ['map10','map16715-04']:
 r=next(v for v in manifest if v['name'].split('.')[0]==name);assert r['split']=='development';model=root/r['path'];parent=root/'artifacts/adaptive-resource-repair-pilot'/name/'0/result.json';d=out/name;d.mkdir();cmd=[str(binary),str(model),str(parent),'2',str(d/'candidate.json')];atomic_json(d/'job.json',dict(command=cmd,cpu=45,input_sha256=sha256(model),parent_sha256=sha256(parent),binary_sha256=sha256(binary),build_info=info));start=time.monotonic();run=subprocess.run(cmd,text=True,capture_output=True,preexec_fn=restrict,timeout=60);(d/'stdout.log').write_text(run.stdout);(d/'stderr.log').write_text(run.stderr);atomic_json(d/'execution.json',dict(exit_code=run.returncode,wall_seconds=time.monotonic()-start));assert run.returncode==0;print(name,run.stdout,flush=True)
atomic_json(out/'exit.json',dict(status='complete'))
