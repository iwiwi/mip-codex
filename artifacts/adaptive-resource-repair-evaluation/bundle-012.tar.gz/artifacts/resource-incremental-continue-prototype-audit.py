from pathlib import Path
import sys,os,json,subprocess
sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256
from verify_cover_cuts import validate_cut_proofs
root=Path.cwd();out=root/'artifacts/resource-incremental-continue-prototype-v2-audit';out.mkdir();records=[];os.sched_setaffinity(0,{40});os.environ['MIP_ABSOLUTE_CHECKER']='/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker-absolute'
for p in sorted((root/'artifacts/resource-incremental-continue-prototype-v2').glob('*/*/candidate.json')):
 r=json.loads(p.read_text());job=json.loads((p.parent/'job.json').read_text());model=Path(job['command'][1]);assert sha256(model)==job['input_sha256'];d=out/p.parent.parent.name/p.parent.name;d.mkdir(parents=True);proof=validate_cut_proofs(model,r);atomic_json(d/'proof.json',proof);assert proof['valid'];cmd=[str(root/'.venv/bin/python'),'/home/ubuntu/mip-codex/scripts/benchmark_validate.py',str(model),str(p),'/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker',str(d)]
 with (d/'audit.log').open('w')as stream:run=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,timeout=600)
 strict=json.loads((d/'strict-validation.json').read_text());official=json.loads((d/'official-validation.json').read_text());assert run.returncode==0 and strict['valid']and official['valid'];records.append(dict(result_sha256=sha256(p),proof_valid=True,strict_valid=True,official_valid=True))
assert len(records)==2,len(records)
atomic_json(out/'records.json',records);atomic_json(out/'summary.json',dict(outputs=len(records),proof_valid=len(records),strict_valid=len(records),official_valid=len(records)));print((out/'summary.json').read_text())
