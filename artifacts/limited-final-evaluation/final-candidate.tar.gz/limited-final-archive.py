from pathlib import Path
import gzip,tarfile,hashlib,json,io,os
os.sched_setaffinity(0,{41});root=Path('/home/ubuntu/mip-codex');repo=Path('/home/ubuntu/mip-phase-two');out=repo/'artifacts/limited-final-evaluation';assert not out.exists();out.mkdir();ledger=[];excluded=[]
for prefix,points in [('limited-primal-point-dive-default',123),('limited-primal-point-singleton',123)]:
 a=json.loads((root/f'artifacts/{prefix}-development-audit/summary.json').read_text());assert a['completed']==a['cut_valid']==376 and a['points']==a['strict_valid']==a['official_valid']==points
for prefix in ['limited-primal-point-dive-default','limited-primal-point-singleton']:
 a=json.loads((root/f'artifacts/{prefix}-lp-oracle/summary.json').read_text());assert a['outputs']==a['valid']==2400
paths=sorted(p for p in (root/'artifacts').iterdir()if p.name.startswith(('limited-primal-point-dive-default','limited-primal-point-singleton')));paths.extend([root/'artifacts/smoke-20261117-062341-caxelhvl',root/'artifacts/smoke-20261117-070822-5oi1x8ed',Path(__file__)])
bundle=out/'final-candidate.tar.gz'
with bundle.open('wb')as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6)as z,tarfile.open(fileobj=z,mode='w')as tar:
 for source in paths:
  for p in sorted(source.rglob('*'))if source.is_dir()else[source]:
   if not p.is_file():continue
   data=p.read_bytes();h=hashlib.sha256(data).hexdigest();name=str(p.relative_to(root/'artifacts'))
   if data[:4]==b'\x7fELF'or p.name=='model.glp':excluded.append(dict(source=str(p),sha256=h,bytes=len(data),reason='local executable/generated LP retained'));continue
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));ledger.append(dict(source=str(p),bundle=bundle.name,member=name,sha256=h,bytes=len(data)))
assert bundle.stat().st_size<95*1024**2
with tarfile.open(bundle,'r:gz')as tar:
 for r in ledger:assert hashlib.sha256(tar.extractfile(r['member']).read()).hexdigest()==r['sha256']
(out/'relocation-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n');(out/'retained-local-files.json').write_text(json.dumps(excluded,indent=2)+'\n');(out/'bundles.json').write_text(json.dumps([dict(path=bundle.name,sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),bytes=bundle.stat().st_size,files=len(ledger))],indent=2)+'\n');s=dict(files=len(ledger),original_bytes=sum(r['bytes']for r in ledger),bundled_bytes=bundle.stat().st_size,excluded=len(excluded),verified_payloads=len(ledger));(out/'archive-summary.json').write_text(json.dumps(s,indent=2)+'\n');(out/'review-summary.md').write_bytes((repo/'docs/LIMITED_PRIMAL_POINT_RESULTS.md').read_bytes());(out/'README.txt').write_text('final-candidate.tar.gzを空の作業ディレクトリで展開すると、元artifacts以下の相対パスが復元される。bundles.jsonで圧縮ファイル、relocation-ledger.jsonで展開後の各payloadのSHA256を照合する。全payloadを作成時に照合済み。元ファイルと除外ELF/生成LPはローカルに保持する。\n');print(s)
