from pathlib import Path
import json,random,subprocess,os,sys,hashlib
from fractions import Fraction as F
import numpy as np,highspy
sys.path.insert(0,'scripts')
from benchmark_common import atomic_json,sha256
root=Path.cwd();out=root/'artifacts/limited-primal-point-singleton-lp-oracle';out.mkdir();os.sched_setaffinity(0,{41});rng=random.Random(2026111706);cases=[]
for case in range(100):
 n=rng.randint(3,12);m=rng.randint(2,12);upper=[rng.randint(2,8)for _ in range(n)];plant=[rng.randint(0,u)for u in upper];matrix=[];rhs=[];equality=[]
 for i in range(m):
  scale=2.**rng.choice([-20,-10,0,10,20]);row=[rng.randint(-3,3)*scale for _ in range(n)];eq=rng.randrange(2)==0;matrix.append(row);rhs.append(sum(a*x for a,x in zip(row,plant))+(0 if eq else rng.randint(0,3)*scale));equality.append(eq)
 cases.append(dict(columns=[[(i,row[j])for i,row in enumerate(matrix)if row[j]]for j in range(n)],rhs=rhs,costs=[rng.randint(-10,10)for _ in range(n)],upper=upper,equality=equality,slack_upper=[None]*m,limits=[0,1,2,5,10,10000]))
atomic_json(out/'input.json',cases);binary=root/'artifacts/limited-primal-point-singleton-diagnostic/bin/limited_lp';atomic_json(out/'experiment.json',dict(seed=2026111706,cpu=41,binary_sha256=sha256(binary),build_info=json.loads(subprocess.check_output([str(binary),'build-info'])),models=100,limits_per_model=6,warm_states=2,flags=[0,1],highs_version=highspy.Highs().version()))
optima=[]
for p in cases:
 n=len(p['upper']);rows=[[]for _ in p['rhs']]
 for j,col in enumerate(p['columns']):
  for i,a in col:rows[i].append((j,a))
 h=highspy.Highs();h.setOptionValue('output_flag',False);h.setOptionValue('threads',1);h.addVars(n,np.zeros(n),np.array(p['upper'],dtype=float));h.changeColsCost(n,np.arange(n,dtype=np.int32),np.array(p['costs'],dtype=float))
 for row,b,eq in zip(rows,p['rhs'],p['equality']):h.addRow(b if eq else-highspy.kHighsInf,b,len(row),np.array([j for j,a in row],dtype=np.int32),np.array([a for j,a in row],dtype=float))
 h.run();assert h.getModelStatus()==highspy.HighsModelStatus.kOptimal;optima.append(h.getObjectiveValue())
records=[]
for flag in [0,1]:
 env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_LP_LIMIT_POINT=str(flag),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');run=subprocess.run([str(binary)],input=json.dumps(cases),text=True,capture_output=True,env=env,timeout=300);(out/f'rust-{flag}.jsonl').write_text(run.stdout);(out/f'stderr-{flag}.log').write_text(run.stderr);assert run.returncode==0;data=[json.loads(x)for x in run.stdout.splitlines()];assert len(data)==1200
 for r in data:
  p=cases[r['case']];x=r.get('point');assert r['status']in ['optimal','iteration_limit']
  if r['status']=='iteration_limit':assert r['dual']is None
  if x is not None:
   x=list(map(lambda v:F(str(v)),x));assert all(-F(1,1000000)<=v<=u+F(1,1000000)for v,u in zip(x,p['upper']));lhs=[F(0)]*len(p['rhs'])
   for j,col in enumerate(p['columns']):
    for i,a in col:lhs[i]+=F(a)*x[j]
   assert all(abs(v-F(b))<=F(1,1000000)if eq else v<=F(b)+F(1,1000000)for v,b,eq in zip(lhs,p['rhs'],p['equality'])),(flag,r)
   if r['status']=='optimal':assert abs(float(sum(F(c)*v for c,v in zip(p['costs'],x)))-optima[r['case']])<=1e-6*(1+abs(optima[r['case']]))
  if flag==0 and r['status']!='optimal':assert x is None
  records.append(dict(flag=flag,**{k:r[k]for k in ['case','limit','warm','status']},point=x is not None,valid=True))
atomic_json(out/'records.json',records);atomic_json(out/'summary.json',dict(outputs=len(records),valid=len(records),limited_points={str(flag):sum(r['flag']==flag and r['status']!='optimal'and r['point']for r in records)for flag in [0,1]}));atomic_json(out/'exit.json',dict(status='complete'));print(json.loads((out/'summary.json').read_text()))
