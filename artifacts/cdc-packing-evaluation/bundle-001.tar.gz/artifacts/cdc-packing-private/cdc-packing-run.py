from pathlib import Path
import os,sys,json,subprocess,time,resource,shutil
root=Path.cwd();os.sched_setaffinity(0,{40});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,)*2)
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MIP_ABSOLUTE_CHECKER='/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker-absolute');sys.path.insert(0,'scripts')
from benchmark_common import atomic_json,sha256
from validate_solution import validate
model=root/'data/raw/exploratory/cdc7-4-3-2.mps.gz';out=root/'artifacts/cdc-packing-v1';out.mkdir()
binary=root/'artifacts/cover-heap-fixed-work/heap-profile';spec=json.load(open('artifacts/cover-heap-fixed-work/experiment.json'))['binaries']['heap'];assert sha256(binary)==spec['sha256']
atomic_json(out/'experiment.json',dict(binary=spec,model_sha256=sha256(model),cpu=40,seconds=60,threads=1,memory_bytes=16*1024**3,seed=None,target=None,stop_value=None,outside_all_240=True,private_component=True))
records=[]
for mode in ['single','reseed']:
 d=out/mode;d.mkdir();env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_DIAGNOSTIC_COVER_INITIAL='100000000',MIP_DIAGNOSTIC_COVER_EXTENDED='100000000');cmd=[str(binary),str(model),'60',mode,str(d/'result.json')];atomic_json(d/'job.json',dict(command=cmd,environment={k:v for k,v in env.items()if k.startswith('MIP_')}));start=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=180);(d/'stdout.log').write_text(p.stdout);(d/'stderr.log').write_text(p.stderr);atomic_json(d/'execution.json',dict(exit_code=p.returncode,wall_seconds=time.monotonic()-start));assert p.returncode==0,p.stderr
 r=json.load(open(d/'result.json'));v=validate(model,r);atomic_json(d/'validation.json',v);assert v['valid'];records.append(dict(mode=mode,objective=r['objective'],seconds=r['component_seconds'],gmp_valid=True));atomic_json(out/'records.json',records);print(json.dumps(records[-1]),flush=True)
atomic_json(out/'exit.json',dict(status='complete',outputs=len(records),gmp_valid=len(records)))
