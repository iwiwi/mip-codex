from pathlib import Path
import json
root=Path.cwd();records=[]
for name in ['smoke-20261118-014738-8t9j9ycx','smoke-20261118-014919-pu14k5ce']:
 p=root/'artifacts'/name/'results.jsonl'
 for line in p.read_text().splitlines():
  r=json.loads(line);records.append(dict(run=name,**{k:r.get(k)for k in ['name','solver','status','objective','dual_bound','exit_code']},gmp_valid=r.get('validation',{}).get('valid'),proof_valid=r.get('cut_validation',{}).get('valid'),adaptive_stats=r.get('adaptive_resource_repair')))
(root/'artifacts/reusable-repair-native-summary.json').write_text(json.dumps(dict(records=records,initial_glpk_missing_driver_preserved=True,replacement_glpk_run='smoke-20261118-014919-pu14k5ce',superiority=False),indent=2));print(json.dumps(records))
