NAME repair
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj -1
 x0 r0 1
 x0 r2 2
 x0 r3 -1
 x1 obj 3
 x1 r0 2
 x1 r1 1
 x1 r2 -1
 x1 r4 2
 x1 r5 -2
 x2 obj 2
 x2 r0 1
 x2 r1 1
 x2 r2 1
 x2 r4 -1
 x2 r5 -2
 x3 obj 2
 x3 r0 -2
 x3 r1 1
 x3 r2 -1
 x3 r3 -1
 x3 r4 -2
 x3 r5 -2
 x4 obj -1
 x4 r0 1
 x4 r1 2
 x4 r2 -2
 x4 r3 -2
 x4 r5 -1
 x5 obj 3
 x5 r1 2
 x5 r2 1
 x5 r3 1
 x5 r4 1
 x5 r5 -2
 x6 obj 2
 x6 r0 2
 x6 r1 -2
 x6 r2 -2
 x6 r3 1
 x6 r4 -2
 x6 r5 -1
 x7 obj -3
 x7 r0 2
 x7 r1 -2
 x7 r2 2
 x7 r3 2
 x7 r4 1
 x7 r5 -1
RHS
 rhs obj -3
 rhs r0 1
 rhs r1 0
 rhs r2 3
 rhs r3 2
 rhs r4 2
 rhs r5 0
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
ENDATA
