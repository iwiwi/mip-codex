NAME repair
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj -1
 x0 r0 1
 x0 r1 -1
 x0 r3 2
 x0 r5 2
 x1 obj 2
 x1 r2 -2
 x1 r3 -1
 x1 r5 -2
 x2 obj -2
 x2 r0 -1
 x2 r1 -1
 x2 r2 -1
 x2 r3 1
 x2 r5 1
 x3 obj 2
 x3 r0 1
 x3 r1 1
 x3 r2 -2
 x3 r3 1
RHS
 rhs obj 5
 rhs r0 2
 rhs r1 0
 rhs r2 0
 rhs r3 2
 rhs r4 2
 rhs r5 0
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
ENDATA
