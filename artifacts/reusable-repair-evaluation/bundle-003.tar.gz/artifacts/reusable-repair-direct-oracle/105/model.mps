NAME repair
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj -1
 x0 r1 2
 x0 r2 1
 x0 r3 1
 x0 r4 -1
 x0 r5 1
 x1 obj 2
 x1 r0 1
 x1 r2 -1
 x1 r3 1
 x1 r4 -2
 x1 r5 -1
RHS
 rhs obj -6
 rhs r0 0
 rhs r1 3
 rhs r2 1
 rhs r3 2
 rhs r4 2
 rhs r5 0
BOUNDS
 BV b x0
 BV b x1
ENDATA
