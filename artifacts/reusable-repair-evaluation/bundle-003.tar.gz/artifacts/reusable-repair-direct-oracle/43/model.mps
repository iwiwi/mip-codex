NAME repair
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj -1
 x0 r0 -2
 x0 r1 -1
 x0 r2 1
 x0 r4 2
 x0 r5 2
 x1 obj -3
 x1 r0 2
 x1 r1 2
 x1 r2 2
 x1 r3 -1
 x1 r5 1
 x2 obj 1
 x2 r0 2
 x2 r1 2
 x2 r2 -1
 x2 r3 -2
 x2 r4 2
RHS
 rhs obj 9
 rhs r0 1
 rhs r1 3
 rhs r2 1
 rhs r3 0
 rhs r4 1
 rhs r5 1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
ENDATA
