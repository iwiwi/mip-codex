from pathlib import Path
import hashlib,json,tarfile
root=Path.cwd();out=root/'artifacts/implied-boundary-postmerge-evaluation';assert not out.exists();out.mkdir();paths=set();patterns=['implied-boundary-main-*','implied-boundary-final-create*','implied-boundary-final-snapshot-verification.json','implied-boundary-postmerge-*','implied-boundary-pr-*','implied-boundary-final-pr-*','implied-boundary-final-ai-usage.json']
for pattern in patterns:
 for p in (root/'artifacts').glob(pattern):
  if p==out or p.name=='implied-boundary-postmerge-archive-run.log':continue
  if p.is_file():paths.add(p)
  elif p.is_dir():paths.update(q for q in p.rglob('*')if q.is_file())
run=root/'artifacts/runs/implied-boundary-final-20261117';paths.add(run/'config.json');paths.update(p for p in (run/'snapshot').rglob('*')if p.is_file());ledger=[];excluded=[]
for p in sorted(paths):
 assert not p.is_symlink();record=dict(path=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 with p.open('rb')as f:elf=f.read(4)==b'\x7fELF'
 (excluded if elf else ledger).append(record)
bundle=out/'bundle-001.tar.gz'
with tarfile.open(bundle,'w:gz',compresslevel=6)as t:
 for r in ledger:t.add(root/r['path'],arcname=r['path'],recursive=False)
with tarfile.open(bundle,'r:gz')as t:
 assert len(t.getmembers())==len(ledger)
 for m,r in zip(t.getmembers(),ledger):
  assert m.name==r['path'];data=t.extractfile(m).read();assert len(data)==r['bytes']and hashlib.sha256(data).hexdigest()==r['sha256']
(out/'manifest.json').write_text(json.dumps(ledger,indent=2));(out/'excluded-elf.json').write_text(json.dumps(excluded,indent=2));s=dict(files=len(ledger),raw_bytes=sum(r['bytes']for r in ledger),compressed_bytes=bundle.stat().st_size,excluded_elfs=len(excluded),all_payload_sha256_verified=True,bundle_sha256=hashlib.sha256(bundle.read_bytes()).hexdigest());(out/'summary.json').write_text(json.dumps(s,indent=2));print(s)
receipt=root/'experiments/implied-boundary-snapshot-20261117.json';receipt.parent.mkdir(exist_ok=True);receipt.write_bytes((root/'artifacts/implied-boundary-final-snapshot-verification.json').read_bytes())
