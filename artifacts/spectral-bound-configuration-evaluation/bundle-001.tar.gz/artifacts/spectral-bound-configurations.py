from pathlib import Path
import os,json,sys,itertools,subprocess,shutil,resource
from fractions import Fraction
root=Path.cwd();os.sched_setaffinity(0,{41});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));os.environ['MIP_ABSOLUTE_CHECKER']='/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker-absolute';sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256;from verify_binary_graph import verify,maximize_sense;from verify_cayley_spectral import packing_graph;from verify_cover_cuts import exact_model;from validate_solution import validate
out=root/'artifacts/spectral-bound-configurations';out.mkdir();models=[];seen=set()
for r in json.load(open('artifacts/spectral-bound-default-generated/records.json')):
 if not r['spectral_certificate']:continue
 p=root/'artifacts/spectral-bound-default-generated'/f"{r['case']:04d}.mps";sense=maximize_sense(p)
 if sense not in seen:models.append(p);seen.add(sense)
 if len(models)==2:break
for r in json.load(open('artifacts/spectral-bound-default-cycles/records.json')):
 if r['input_upper']is None:continue
 p=root/'artifacts/spectral-bound-default-cycles'/f"{r['case']:04d}.mps"
 if len(exact_model(p)[0])==7:models.append(p);break
assert len(models)==3;binary=root/'artifacts/spectral-bound-default-frozen/bin/mip-codex';records=[]
for i,source in enumerate(models):
 model=out/f'{i}.mps';shutil.copy2(source,model);exact=exact_model(model,True);names=exact[0];n=len(names);index={name:j for j,name in enumerate(names)};conflict=[0]*n
 for row in exact[2]:
  vertices=[index[name]for name,a in row['coefficients'].items()if a]
  for a,b in itertools.combinations(vertices,2):conflict[a]|=1<<b;conflict[b]|=1<<a
 valid=bytearray(1<<n);valid[0]=1;opt=0
 for mask in range(1,1<<n):
  low=mask&-mask;v=low.bit_length()-1;rest=mask-low
  if valid[rest]and not conflict[v]&rest:valid[mask]=1;opt=max(opt,mask.bit_count())
 for flags in itertools.product([0,1],repeat=5):
  env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};keys=['MIP_GRAPH_ROOT_COLORING','MIP_GRAPH_ROOT_PREFIX','MIP_GRAPH_LOCAL_SEARCH','MIP_GRAPH_FRACTIONAL_COVER','MIP_GRAPH_SPECTRAL_BOUND'];env.update({k:str(v)for k,v in zip(keys,flags)});env['MIP_GRAPH_INPUT_COVER']='1';d=out/str(i)/''.join(map(str,flags));d.mkdir(parents=True);run=subprocess.run([str(binary),'solve',str(model),'5','0'],env=env,capture_output=True,text=True,timeout=15);(d/'stdout.log').write_text(run.stdout);(d/'stderr.log').write_text(run.stderr);assert run.returncode==0,run.stderr;precise=json.loads(run.stdout,parse_float=Fraction);r=json.loads(run.stdout);g=r['binary_graph'];assert g and g['best']<=opt<=g['upper'];assert not g['complete']or g['best']==opt;assert flags[0]or g['root_variants']==0;assert flags[2]or g['local']is None;assert flags[3]or g['fractional_cover']is None;assert flags[4]or g.get('spectral_bound')is None;proof=verify(model,precise,exact);assert proof['valid'];atomic_json(d/'proof.json',proof);point=validate(model,r);assert point['valid'];atomic_json(d/'point.json',point);records.append(dict(model=i,flags=dict(zip(keys,flags)),best=g['best'],upper=g['upper'],optimum=opt,spectral_certificate=bool((g.get('spectral_bound')or{}).get('certificate')),input_certificate=bool((g.get('fractional_cover')or{}).get('certificate')),valid=True));atomic_json(out/'records.json',records)
summary=dict(models=3,outputs=len(records),exhaustive_valid=len(records),proof_valid=len(records),gmp_valid=len(records),spectral_certificates=sum(r['spectral_certificate']for r in records),input_certificates=sum(r['input_certificate']for r in records),binary_sha256=sha256(binary));atomic_json(out/'summary.json',summary);atomic_json(out/'exit.json',dict(status='complete'));print(json.dumps(summary))
