//! RENSの定義を参考に独立実装。外部ソルバー・既存コードへの最適化委譲なし。
//! Berthold, https://edocs.tib.eu/files/e01fn09/573699097l.pdf
//! https://www.scipopt.org/scip/doc/html/heur__rens_8h.php
use crate::model::Model;
use serde::Serialize;
use std::time::Instant;
#[derive(Clone,Default,Debug,Serialize)]pub struct Stats{pub attempts:usize,pub calls:usize,pub fixed:usize,pub eligible:usize,pub fractional:usize,pub released:usize,pub expanded:usize,pub conflict_hints:usize,pub infeasible_neighborhoods:usize,pub nodes:usize,pub lp_solves:usize,pub candidates:usize,pub improvements:usize,pub seconds:f64,pub status:Option<String>}
pub struct Neighborhood{pub model:Model,pub fixed:usize,pub eligible:usize,pub fractional:usize,pub released:usize,pub expanded:usize}
pub fn neighborhood(model:&Model,point:&[f64],deadline:Instant)->Option<Neighborhood>{
 neighborhood_released(model,point,deadline,false)
}
pub fn neighborhood_released(model:&Model,point:&[f64],deadline:Instant,release:bool)->Option<Neighborhood>{
 neighborhood_with_hints(model,point,deadline,release,&[])
}
pub fn neighborhood_with_hints(model:&Model,point:&[f64],deadline:Instant,release:bool,hints:&[usize])->Option<Neighborhood>{
 neighborhood_expanded(model,point,deadline,release,hints,false)
}
pub fn neighborhood_expanded(model:&Model,point:&[f64],deadline:Instant,release:bool,hints:&[usize],expand:bool)->Option<Neighborhood>{
 if model.variables.len()>1_000_000||point.len()!=model.variables.len()||point.iter().any(|v|!v.is_finite()||v.abs()>4503599627370496.)||Instant::now()>=deadline||model.check(point,false,1e-6).is_err(){return None;}
 let mut bounds=vec![];let mut fixed=0usize;let mut eligible=0usize;let mut fractional=0usize;
 for(j,v)in model.variables.iter().enumerate(){
  if j%1024==0&&Instant::now()>=deadline{return None;}if !v.integer{continue;}
  let original_lo=if v.lower.is_some(){Some(v.lower_enclosure?[1].ceil())}else{None};let original_up=if v.upper.is_some(){Some(v.upper_enclosure?[0].floor())}else{None};
  if original_lo.zip(original_up).is_some_and(|(l,u)|l>u){return None;}
  if original_lo.zip(original_up).is_some_and(|(l,u)|l==u){continue;}
  eligible+=1;let x=point[j];let near=(x-x.round()).abs()<=1e-6;let mut lo=if near{x.round()}else{x.floor()};let mut up=if near{x.round()}else{x.ceil()};if let Some(l)=original_lo{lo=lo.max(l);}if let Some(u)=original_up{up=up.min(u);}if lo>up{return None;}
  if lo==up{fixed+=1;}else{fractional+=1;}bounds.push((j,lo,up));
 }
 if fixed<2||fractional==0||fixed.saturating_mul(5)<eligible.saturating_mul(4)||Instant::now()>=deadline{return None;}
 let mut released=0;
 if release {
  let mut fractional_mark=vec![false;model.variables.len()];let mut fixed_mark=vec![false;model.variables.len()];for &(j,l,u)in &bounds{if l==u{fixed_mark[j]=true;}else{fractional_mark[j]=true;}}
  let mut score=vec![0usize;model.variables.len()];
  for(i,row)in model.rows.iter().enumerate(){if i%128==0&&Instant::now()>=deadline{return None;}let mut touches=false;for(k,&(j,a))in row.coefficients.iter().enumerate(){if k%4096==0&&Instant::now()>=deadline{return None;}if a!=0.&&fractional_mark[j]{touches=true;break;}}if touches{for(k,&(j,a))in row.coefficients.iter().enumerate(){if k%4096==0&&Instant::now()>=deadline{return None;}if a!=0.&&fixed_mark[j]{score[j]=score[j].saturating_add(1);}}}}
  let mut rank=vec![0usize;model.variables.len()];for(k,&j)in hints.iter().enumerate(){if j<rank.len(){rank[j]=hints.len()-k;}}let mut candidates:Vec<_>=bounds.iter().filter_map(|&(j,l,u)|(l==u&&(score[j]>0||rank[j]>0)).then_some(j)).collect();candidates.sort_unstable_by_key(|&j|(std::cmp::Reverse(rank[j]),std::cmp::Reverse(score[j]),(j as u64).wrapping_mul(0x9e3779b97f4a7c15).rotate_left(17)));let hinted=candidates.iter().filter(|&&j|rank[j]>0).count();let limit=(fixed*5/100).max(1);candidates.truncate(if hinted>0{limit.min(hinted)}else{limit});if candidates.is_empty()&&!expand{return None;}let mut free=vec![false;model.variables.len()];for j in candidates{free[j]=true;released+=1;}bounds.retain(|&(j,_,_)|!free[j]);fixed-=released;
 }
 let expanded:Vec<_>=if expand{bounds.iter().filter_map(|&(j,l,u)|(l<u&&(model.variables[j].lower!=Some(l)||model.variables[j].upper!=Some(u))).then_some(j)).collect()}else{vec![]};if expand&&expanded.is_empty(){return None;}
 let mut sub=model.clone();if Instant::now()>=deadline{return None;}
 for(j,lo,up)in bounds{let v=&mut sub.variables[j];v.lower=Some(lo);v.upper=Some(up);v.lower_enclosure=Some([lo;2]);v.upper_enclosure=Some([up;2]);}
 let count=expanded.len();for j in expanded{sub.variables[j]=model.variables[j].clone();}
 Some(Neighborhood{model:sub,fixed,eligible,fractional,released,expanded:count})
}
#[cfg(test)]mod tests{
 use super::*;
 fn triangle()->Model{let mut t=String::from("NAME rens\nROWS\n N c\n L r\n L s\n L t\nCOLUMNS\n x0 c -1 r 1\n x0 t 1\n x1 c -1 r 1\n x1 s 1\n x2 c -1 s 1\n x2 t 1\n");for j in 3..20{t+=&format!(" x{j} c 1\n");}t+="RHS\n rhs r 1 s 1\n rhs t 1\nBOUNDS\n";for j in 0..20{t+=&format!(" BV b x{j}\n");}t+="ENDATA\n";crate::mps::parse(std::io::Cursor::new(t)).unwrap()}
 #[test]fn fractional_lp_point_can_define_a_neighborhood_without_an_incumbent(){let m=triangle();let mut point=vec![0.;20];point[..3].fill(0.5);let n=neighborhood(&m,&point,Instant::now()+std::time::Duration::from_secs(1)).unwrap();assert_eq!((n.fixed,n.eligible,n.fractional),(17,20,3));assert_eq!(n.model.variables[3].upper,Some(0.));assert_eq!(m.variables[3].upper,Some(1.));assert_eq!(n.model.variables[0].lower,Some(0.));assert_eq!(n.model.variables[0].upper,Some(1.));assert!(neighborhood(&m,&point,Instant::now()).is_none());let mut bad=point.clone();bad[0]=2.;assert!(neighborhood(&m,&bad,Instant::now()+std::time::Duration::from_secs(1)).is_none());}
 #[test]fn rens_only_returns_an_original_valid_point(){use crate::solve::{solve,Limits};let m=triangle();let limits=Limits{seconds:2.,rens:true,primal_repair:false,box_primal:false,primal_probe:false,lp_diving:false,objective_lp_dive:false,feasibility_pump:false,rins:false,binary_graph:false,cover_cuts:false,mir_cuts:false,gomory_cuts:false,aggregate_cuts:false,clique_cuts:false,three_row_cuts:false,rounding_cuts:false,..Limits::default()};let r=solve(&m,&limits);let s=r.rens.as_ref().unwrap();assert_eq!(s.calls,1);assert_eq!(s.fixed,17);assert_eq!(s.improvements,1);assert_eq!(r.objective,Some(-1.));let x:Vec<_>=m.variables.iter().map(|v|r.values.as_ref().unwrap()[&v.name]).collect();assert!(m.check(&x,true,1e-7).is_ok());assert_eq!(m.variables[3].upper,Some(1.));}
 #[test]fn releasing_a_coupled_integral_variable_can_escape_an_infeasible_rounding(){
  use crate::solve::{solve,Limits};let mut m=triangle();let extra=crate::mps::parse(std::io::Cursor::new("NAME need\nROWS\n N c\n G need\nCOLUMNS\n x0 c -1 need 1\n x1 c -1 need 1\n x2 c -1 need 1\n x3 c 1 need 1\nRHS\n rhs need 1.5\nBOUNDS\n BV b x0\n BV b x1\n BV b x2\n BV b x3\nENDATA\n")).unwrap();m.rows.push(extra.rows[0].clone());let limits=Limits{seconds:2.,rens:true,rens_release:true,primal_repair:false,box_primal:false,primal_probe:false,lp_diving:false,objective_lp_dive:false,feasibility_pump:false,rins:false,binary_graph:false,cover_cuts:false,mir_cuts:false,gomory_cuts:false,aggregate_cuts:false,clique_cuts:false,three_row_cuts:false,rounding_cuts:false,..Limits::default()};let r=solve(&m,&limits);let stats=r.rens.as_ref().unwrap();assert_eq!(stats.calls,2);assert!(stats.conflict_hints>0);assert_eq!(stats.infeasible_neighborhoods,1);assert_eq!(stats.released,1);assert_eq!(stats.improvements,1);assert_eq!(r.objective,Some(0.));let x:Vec<_>=m.variables.iter().map(|v|r.values.as_ref().unwrap()[&v.name]).collect();assert!(m.check(&x,true,1e-7).is_ok());assert_eq!(m.variables[3].upper,Some(1.));
 }

}

/// LP不能方向の固定列支持だけを近傍ヒントに使う。証明や枝刈りには使わない。
pub fn fixed_conflict_support(model:&Model,sources:&[(usize,f64)],witness:&[f64],deadline:Instant)->Vec<usize>{
 if sources.len()!=witness.len()||witness.iter().any(|v|!v.is_finite())||Instant::now()>=deadline{return vec![];}
 let fixed:Vec<_>=model.variables.iter().map(|v|v.integer&&v.lower.zip(v.upper).is_some_and(|(l,u)|l==u&&l.is_finite())).collect();let mut y=vec![0.;model.rows.len()];
 for(&(i,sign),&v)in sources.iter().zip(witness){if i>=y.len(){return vec![];}y[i]+=sign*v;if !y[i].is_finite(){return vec![];}}
 let mut coefficients=vec![0.;model.variables.len()];
 for(i,row)in model.rows.iter().enumerate(){if i%128==0&&Instant::now()>=deadline{return vec![];}if y[i]==0.{continue;}for(k,&(j,a))in row.coefficients.iter().enumerate(){if k%4096==0&&Instant::now()>=deadline{return vec![];}if fixed[j]{coefficients[j]+=a*y[i];}}}
 let largest=coefficients.iter().filter(|v|v.is_finite()).map(|v|v.abs()).fold(0.,f64::max);let mut ids:Vec<_>=coefficients.iter().enumerate().filter_map(|(j,&v)|(v.is_finite()&&v.abs()>largest*1e-9&&v!=0.).then_some(j)).collect();ids.sort_unstable_by(|&j,&k|coefficients[k].abs().total_cmp(&coefficients[j].abs()).then(j.cmp(&k)));ids.truncate(4096);ids
}
#[cfg(test)]mod conflict_tests{
 use super::*;
 #[test]fn a_zero_fixed_variable_can_appear_in_a_contradiction(){let m=crate::mps::parse(std::io::Cursor::new("NAME support\nROWS\n N c\n L r\n G s\nCOLUMNS\n z c 1 r 1\n x c 1 r 1\n x s 1\nRHS\n rhs r 0 s 1\nBOUNDS\n BV b z\n FX b z 0\nENDATA\n")).unwrap();assert_eq!(fixed_conflict_support(&m,&[(0,1.),(1,-1.)],&[1.,1.],Instant::now()+std::time::Duration::from_secs(1)),vec![0]);assert!(fixed_conflict_support(&m,&[],&[1.],Instant::now()+std::time::Duration::from_secs(1)).is_empty());}
}

#[cfg(test)]mod expanded_tests{
 #[test]fn general_integer_domains_can_require_more_than_floor_or_ceiling(){
  use crate::solve::{solve,Limits};let mut text=String::from("NAME lattice\nROWS\n N c\n E balance\n G need\nCOLUMNS\n x c 1 balance 2\n x need 1\n y c 1 balance -3\n");for j in 0..17{text+=&format!(" z{j} c 1\n");}text+="RHS\n rhs balance 0 need 0.5\nBOUNDS\n LI b x 0\n UI b x 3\n LI b y 0\n UI b y 2\n";for j in 0..17{text+=&format!(" BV b z{j}\n");}text+="ENDATA\n";let m=crate::mps::parse(std::io::Cursor::new(text)).unwrap();let limits=Limits{seconds:2.,rens:true,rens_release:true,rens_expand:true,primal_repair:false,box_primal:false,primal_probe:false,lp_diving:false,objective_lp_dive:false,feasibility_pump:false,rins:false,binary_graph:false,cover_cuts:false,mir_cuts:false,gomory_cuts:false,aggregate_cuts:false,clique_cuts:false,three_row_cuts:false,rounding_cuts:false,..Limits::default()};let r=solve(&m,&limits);let stats=r.rens.as_ref().unwrap();assert_eq!(stats.calls,2);assert_eq!(stats.expanded,2);assert_eq!(stats.released,0);assert_eq!(stats.improvements,1);assert_eq!(r.objective,Some(5.));let x:Vec<_>=m.variables.iter().map(|v|r.values.as_ref().unwrap()[&v.name]).collect();assert!(m.check(&x,true,1e-7).is_ok());assert_eq!(m.variables[0].upper,Some(3.));
 }
}
