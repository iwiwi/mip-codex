NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -5
 x1 obj -1
 x2 obj -6
 x2 r0 -3.0
 x3 obj -8
 x4 obj -4
 x5 obj -4
 x6 obj -4
 x7 obj -9
 x8 obj -7
 x9 obj -9
 x10 obj -7
 x11 obj -9
 x12 obj -4
 x13 obj -3
 x13 r0 2.0
 x13 r1 1.0
 x14 obj -8
 x15 obj -4
 x16 obj -5
 x17 obj -9
 x18 obj -1
RHS
 rhs obj -1
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 6
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 9
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
ENDATA
