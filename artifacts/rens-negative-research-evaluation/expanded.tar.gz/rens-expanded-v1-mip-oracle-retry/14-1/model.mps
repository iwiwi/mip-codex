NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -1
 x0 r0 -0.01171875
 x1 obj -1
 x2 obj -2
 x3 obj -9
 x4 obj -3
 x5 obj -4
 x6 obj -8
 x7 obj -7
 x8 obj -3
 x9 obj -9
 x10 obj -6
 x11 obj -4
 x12 obj -2
 x13 obj -6
 x14 obj -4
 x14 r0 0.0078125
 x14 r1 0.00390625
 x15 obj -8
 x16 obj -1
 x17 obj -9
 x18 obj -8
 x19 obj -4
 x20 obj -9
 x21 obj -7
 x22 obj -1
 x23 obj -9
 x24 obj -9
 x25 obj -1
RHS
 rhs obj 21
 rhs r0 0
 rhs r1 0.001953125
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 2
ENDATA
