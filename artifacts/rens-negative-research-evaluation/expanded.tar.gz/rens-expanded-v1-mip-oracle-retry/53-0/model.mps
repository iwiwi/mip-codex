NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 1
 x1 obj 1
 x2 obj 3
 x3 obj 5
 x4 obj 1
 x5 obj 2
 x6 obj 1
 x7 obj 3
 x8 obj 7
 x9 obj 7
 x10 obj 7
 x10 r0 -48.0
 x11 obj 1
 x12 obj 5
 x13 obj 1
 x13 r0 32.0
 x13 r1 16.0
 x14 obj 6
 x15 obj 7
 x16 obj 5
 x17 obj 2
 x18 obj 8
 x19 obj 7
RHS
 rhs obj 30
 rhs r0 0
 rhs r1 8.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 6
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 9
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
ENDATA
