NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -1
 x1 obj -8
 x2 obj -8
 x3 obj -2
 x4 obj -6
 x5 obj -6
 x6 obj -1
 x7 obj -1
 x8 obj -4
 x9 obj -7
 x10 obj -9
 x11 obj -2
 x12 obj -6
 x13 obj -7
 x14 obj -8
 x15 obj -3
 x16 obj -3
 x17 obj -4
 x17 r0 0.0078125
 x17 r1 0.00390625
 x18 obj -7
 x18 r0 -0.01171875
 x19 obj -9
 x20 obj -4
 x21 obj -6
 x22 obj -1
 x23 obj -4
 x24 obj -5
 x25 obj -7
 x26 obj -7
 x27 obj -8
 x28 obj -1
 x29 obj -7
 x30 obj -8
RHS
 rhs obj -4
 rhs r0 0
 rhs r1 0.001953125
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 9
 LI b x18 0
 UI b x18 6
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 2
ENDATA
