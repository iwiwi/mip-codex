NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -2
 x1 obj -5
 x2 obj -9
 x3 obj -3
 x4 obj -5
 x4 r0 0.0078125
 x4 r1 0.00390625
 x5 obj -1
 x6 obj -9
 x7 obj -6
 x8 obj -8
 x9 obj -2
 x10 obj -5
 x11 obj -2
 x12 obj -3
 x13 obj -5
 x14 obj -5
 x15 obj -3
 x16 obj -7
 x17 obj -9
 x18 obj -8
 x19 obj -6
 x20 obj -8
 x21 obj -5
 x22 obj -1
 x23 obj -6
 x24 obj -8
 x24 r0 -0.01171875
 x25 obj -3
 x26 obj -5
 x27 obj -5
RHS
 rhs obj 0
 rhs r0 0
 rhs r1 0.001953125
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 3
ENDATA
