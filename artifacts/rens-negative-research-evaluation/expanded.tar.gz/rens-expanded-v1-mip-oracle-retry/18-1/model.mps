NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -4
 x1 obj -8
 x2 obj -9
 x3 obj -8
 x4 obj -9
 x5 obj -3
 x6 obj -2
 x7 obj -8
 x8 obj -5
 x9 obj -4
 x9 r0 -3.0
 x10 obj -4
 x11 obj -6
 x12 obj -1
 x13 obj -3
 x14 obj -7
 x15 obj -1
 x16 obj -3
 x17 obj -9
 x17 r0 2.0
 x17 r1 1.0
 x18 obj -1
 x19 obj -5
 x20 obj -9
RHS
 rhs obj 20
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 6
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 9
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
ENDATA
