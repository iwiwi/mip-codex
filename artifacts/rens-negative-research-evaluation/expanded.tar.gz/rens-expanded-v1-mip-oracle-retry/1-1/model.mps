NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -9
 x1 obj -2
 x2 obj -2
 x3 obj -5
 x4 obj -4
 x5 obj -1
 x5 r0 512.0
 x5 r1 256.0
 x6 obj -6
 x7 obj -4
 x8 obj -3
 x9 obj -3
 x9 r0 -768.0
 x10 obj -6
 x11 obj -3
 x12 obj -9
 x13 obj -1
 x14 obj -9
 x15 obj -5
 x16 obj -3
 x17 obj -2
 x18 obj -7
RHS
 rhs obj 12
 rhs r0 0
 rhs r1 128.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 6
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
ENDATA
