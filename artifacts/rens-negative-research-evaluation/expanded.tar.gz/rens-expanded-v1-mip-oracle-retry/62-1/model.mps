NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -3
 x0 r0 2.0
 x0 r1 1.0
 x1 obj -9
 x2 obj -4
 x3 obj -9
 x4 obj -4
 x5 obj -6
 x6 obj -7
 x7 obj -6
 x8 obj -1
 x9 obj -8
 x10 obj -2
 x11 obj -4
 x11 r0 -3.0
 x12 obj -8
 x13 obj -7
 x14 obj -8
 x15 obj -8
 x16 obj -1
 x17 obj -8
 x18 obj -1
 x19 obj -4
 x20 obj -7
 x21 obj -7
 x22 obj -8
 x23 obj -6
 x24 obj -8
 x25 obj -7
 x26 obj -9
 x27 obj -1
 x28 obj -5
 x29 obj -9
RHS
 rhs obj -1
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 6
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 2
ENDATA
