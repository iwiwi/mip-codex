NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -3
 x1 obj -5
 x2 obj -1
 x3 obj -9
 x4 obj -1
 x5 obj -1
 x6 obj -1
 x6 r0 -0.1875
 x7 obj -6
 x8 obj -8
 x9 obj -7
 x10 obj -3
 x11 obj -7
 x12 obj -5
 x13 obj -9
 x14 obj -9
 x15 obj -4
 x16 obj -5
 x17 obj -7
 x18 obj -4
 x18 r0 0.125
 x18 r1 0.0625
 x19 obj -1
 x20 obj -1
 x21 obj -7
RHS
 rhs obj -2
 rhs r0 0
 rhs r1 0.03125
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 6
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
ENDATA
