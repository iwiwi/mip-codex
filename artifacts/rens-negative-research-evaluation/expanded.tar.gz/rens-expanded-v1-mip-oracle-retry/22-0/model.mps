NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 7
 x1 obj 6
 x2 obj 6
 x3 obj 8
 x4 obj 8
 x5 obj 2
 x6 obj 1
 x7 obj 5
 x8 obj 4
 x8 r0 -768.0
 x9 obj 3
 x10 obj 8
 x11 obj 5
 x12 obj 9
 x13 obj 8
 x14 obj 1
 x15 obj 7
 x16 obj 9
 x17 obj 8
 x17 r0 512.0
 x17 r1 256.0
 x18 obj 1
 x19 obj 5
 x20 obj 4
 x21 obj 3
 x22 obj 3
 x23 obj 6
 x24 obj 5
RHS
 rhs obj -15
 rhs r0 0
 rhs r1 128.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 6
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 9
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 3
ENDATA
