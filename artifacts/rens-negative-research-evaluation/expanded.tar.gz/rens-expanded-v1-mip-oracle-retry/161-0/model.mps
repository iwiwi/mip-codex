NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 3
 x1 obj 6
 x2 obj 5
 x3 obj 5
 x3 r0 -0.1875
 x4 obj 7
 x5 obj 6
 x6 obj 4
 x7 obj 7
 x8 obj 8
 x9 obj 1
 x10 obj 5
 x11 obj 3
 x12 obj 2
 x13 obj 4
 x14 obj 1
 x15 obj 1
 x16 obj 4
 x17 obj 9
 x18 obj 5
 x19 obj 6
 x20 obj 7
 x21 obj 3
 x22 obj 1
 x23 obj 3
 x24 obj 8
 x25 obj 8
 x25 r0 0.125
 x25 r1 0.0625
RHS
 rhs obj 27
 rhs r0 0
 rhs r1 0.03125
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 6
ENDATA
