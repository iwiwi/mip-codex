NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 9
 x1 obj 3
 x2 obj 5
 x3 obj 4
 x4 obj 3
 x4 r0 -0.1875
 x5 obj 1
 x6 obj 8
 x7 obj 1
 x8 obj 9
 x9 obj 6
 x10 obj 8
 x11 obj 7
 x12 obj 2
 x13 obj 5
 x14 obj 6
 x15 obj 5
 x15 r0 0.125
 x15 r1 0.0625
 x16 obj 7
 x17 obj 2
 x18 obj 2
 x19 obj 4
 x20 obj 4
 x21 obj 3
 x22 obj 2
 x23 obj 5
 x24 obj 5
 x25 obj 3
 x26 obj 8
 x27 obj 4
 x28 obj 9
RHS
 rhs obj 26
 rhs r0 0
 rhs r1 0.03125
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 4
ENDATA
