NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 4
 x0 r0 512.0
 x0 r1 256.0
 x1 obj 7
 x2 obj 8
 x3 obj 6
 x4 obj 6
 x5 obj 3
 x6 obj 3
 x7 obj 9
 x8 obj 3
 x9 obj 7
 x9 r0 -768.0
 x10 obj 1
 x11 obj 1
 x12 obj 3
 x13 obj 3
 x14 obj 2
 x15 obj 8
 x16 obj 3
 x17 obj 9
 x18 obj 3
 x19 obj 5
 x20 obj 8
 x21 obj 6
 x22 obj 6
 x23 obj 8
 x24 obj 8
RHS
 rhs obj -30
 rhs r0 0
 rhs r1 128.0
BOUNDS
 LI b x0 0
 UI b x0 6
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
ENDATA
