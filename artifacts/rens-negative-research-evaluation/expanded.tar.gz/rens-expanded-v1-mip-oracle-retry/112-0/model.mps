NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 3
 x1 obj 4
 x2 obj 1
 x3 obj 7
 x4 obj 1
 x5 obj 6
 x6 obj 6
 x7 obj 3
 x8 obj 4
 x9 obj 3
 x10 obj 1
 x11 obj 8
 x12 obj 9
 x13 obj 6
 x14 obj 4
 x15 obj 9
 x16 obj 4
 x17 obj 2
 x18 obj 9
 x19 obj 1
 x20 obj 6
 x21 obj 7
 x21 r0 512.0
 x21 r1 256.0
 x22 obj 2
 x23 obj 3
 x24 obj 3
 x25 obj 2
 x26 obj 5
 x27 obj 9
 x28 obj 8
 x29 obj 2
 x30 obj 5
 x30 r0 -768.0
 x31 obj 3
RHS
 rhs obj 10
 rhs r0 0
 rhs r1 128.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 9
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 6
 LI b x31 0
 UI b x31 2
ENDATA
