NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 7
 x0 r0 512.0
 x0 r1 256.0
 x1 obj 6
 x2 obj 2
 x3 obj 2
 x4 obj 7
 x5 obj 7
 x6 obj 8
 x7 obj 5
 x8 obj 8
 x9 obj 6
 x10 obj 1
 x11 obj 1
 x12 obj 8
 x13 obj 8
 x14 obj 5
 x15 obj 1
 x16 obj 2
 x17 obj 7
 x18 obj 1
 x18 r0 -768.0
 x19 obj 6
 x20 obj 7
 x21 obj 5
 x22 obj 7
 x23 obj 1
 x24 obj 5
 x25 obj 6
 x26 obj 4
RHS
 rhs obj -28
 rhs r0 0
 rhs r1 128.0
BOUNDS
 LI b x0 0
 UI b x0 6
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 4
ENDATA
