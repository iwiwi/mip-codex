NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -4
 x1 obj -6
 x1 r0 32.0
 x1 r1 16.0
 x2 obj -4
 x3 obj -4
 x4 obj -4
 x5 obj -2
 x6 obj -5
 x7 obj -2
 x8 obj -8
 x9 obj -4
 x10 obj -3
 x11 obj -9
 x12 obj -2
 x13 obj -9
 x14 obj -3
 x15 obj -1
 x16 obj -7
 x17 obj -1
 x18 obj -8
 x18 r0 -48.0
 x19 obj -1
 x20 obj -1
 x21 obj -9
 x22 obj -6
 x23 obj -5
RHS
 rhs obj 30
 rhs r0 0
 rhs r1 8.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 9
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 6
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
ENDATA
