NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 5
 x1 obj 2
 x2 obj 1
 x3 obj 6
 x4 obj 2
 x5 obj 5
 x6 obj 6
 x7 obj 4
 x7 r0 32.0
 x7 r1 16.0
 x8 obj 5
 x9 obj 9
 x10 obj 7
 x11 obj 6
 x12 obj 1
 x13 obj 5
 x14 obj 4
 x15 obj 4
 x16 obj 1
 x17 obj 5
 x18 obj 6
 x19 obj 6
 x20 obj 4
 x20 r0 -48.0
 x21 obj 4
 x22 obj 5
RHS
 rhs obj -29
 rhs r0 0
 rhs r1 8.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
ENDATA
