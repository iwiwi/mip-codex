NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -5
 x1 obj -3
 x1 r0 0.125
 x1 r1 0.0625
 x2 obj -4
 x3 obj -3
 x4 obj -2
 x5 obj -9
 x6 obj -1
 x7 obj -9
 x8 obj -2
 x9 obj -1
 x10 obj -7
 x11 obj -5
 x12 obj -5
 x13 obj -2
 x14 obj -3
 x15 obj -8
 x16 obj -7
 x16 r0 -0.1875
 x17 obj -5
 x18 obj -3
 x19 obj -5
 x20 obj -1
 x21 obj -8
 x22 obj -2
 x23 obj -4
 x24 obj -3
 x25 obj -7
RHS
 rhs obj -22
 rhs r0 0
 rhs r1 0.03125
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 9
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 6
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
ENDATA
