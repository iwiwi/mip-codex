NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 2
 x1 obj 4
 x2 obj 8
 x3 obj 9
 x4 obj 1
 x5 obj 3
 x6 obj 9
 x7 obj 4
 x8 obj 6
 x9 obj 8
 x10 obj 5
 x11 obj 5
 x12 obj 3
 x13 obj 3
 x14 obj 7
 x15 obj 7
 x16 obj 6
 x17 obj 8
 x18 obj 1
 x19 obj 5
 x20 obj 1
 x21 obj 2
 x22 obj 8
 x22 r0 -0.1875
 x23 obj 7
 x23 r0 0.125
 x23 r1 0.0625
 x24 obj 7
 x25 obj 8
 x26 obj 9
 x27 obj 7
RHS
 rhs obj 29
 rhs r0 0
 rhs r1 0.03125
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 6
 LI b x23 0
 UI b x23 9
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 4
ENDATA
