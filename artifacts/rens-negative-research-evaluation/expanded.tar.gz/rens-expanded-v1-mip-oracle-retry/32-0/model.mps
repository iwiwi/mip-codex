NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 5
 x1 obj 1
 x2 obj 8
 x3 obj 1
 x4 obj 4
 x5 obj 5
 x5 r0 2.0
 x5 r1 1.0
 x6 obj 6
 x7 obj 1
 x8 obj 2
 x9 obj 9
 x10 obj 1
 x11 obj 2
 x12 obj 7
 x13 obj 2
 x14 obj 9
 x15 obj 6
 x16 obj 9
 x17 obj 2
 x18 obj 4
 x19 obj 2
 x19 r0 -3.0
 x20 obj 7
 x21 obj 1
 x22 obj 9
 x23 obj 4
 x24 obj 4
 x25 obj 6
RHS
 rhs obj 17
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 3
ENDATA
