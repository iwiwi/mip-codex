NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -2
 x1 obj -9
 x2 obj -3
 x3 obj -2
 x4 obj -6
 x5 obj -3
 x6 obj -9
 x7 obj -2
 x8 obj -3
 x8 r0 0.125
 x8 r1 0.0625
 x9 obj -1
 x10 obj -6
 x11 obj -2
 x12 obj -1
 x13 obj -1
 x14 obj -5
 x15 obj -2
 x16 obj -9
 x16 r0 -0.1875
 x17 obj -8
 x18 obj -5
 x19 obj -4
 x20 obj -5
 x21 obj -6
 x22 obj -2
 x23 obj -4
RHS
 rhs obj 2
 rhs r0 0
 rhs r1 0.03125
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 9
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 6
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
ENDATA
