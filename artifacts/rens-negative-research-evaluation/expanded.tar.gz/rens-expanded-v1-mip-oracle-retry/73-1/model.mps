NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -8
 x1 obj -9
 x2 obj -4
 x3 obj -9
 x4 obj -7
 x5 obj -8
 x6 obj -4
 x7 obj -4
 x8 obj -5
 x8 r0 512.0
 x8 r1 256.0
 x9 obj -7
 x10 obj -4
 x11 obj -3
 x12 obj -8
 x13 obj -6
 x14 obj -6
 x15 obj -5
 x16 obj -8
 x17 obj -5
 x18 obj -2
 x19 obj -4
 x20 obj -8
 x21 obj -8
 x22 obj -8
 x23 obj -4
 x24 obj -9
 x24 r0 -768.0
RHS
 rhs obj -6
 rhs r0 0
 rhs r1 128.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 6
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 4
ENDATA
