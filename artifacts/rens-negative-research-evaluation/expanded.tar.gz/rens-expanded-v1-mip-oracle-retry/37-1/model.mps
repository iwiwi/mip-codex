NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -7
 x1 obj -9
 x2 obj -5
 x3 obj -9
 x3 r0 512.0
 x3 r1 256.0
 x4 obj -2
 x5 obj -9
 x6 obj -3
 x7 obj -4
 x8 obj -3
 x9 obj -9
 x10 obj -9
 x11 obj -9
 x12 obj -2
 x13 obj -2
 x14 obj -7
 x15 obj -2
 x16 obj -9
 x17 obj -2
 x18 obj -9
 x19 obj -3
 x19 r0 -768.0
 x20 obj -7
 x21 obj -6
RHS
 rhs obj -3
 rhs r0 0
 rhs r1 128.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
ENDATA
