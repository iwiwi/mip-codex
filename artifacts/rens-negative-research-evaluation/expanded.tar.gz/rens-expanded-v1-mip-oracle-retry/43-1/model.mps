NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -8
 x1 obj -5
 x2 obj -6
 x3 obj -1
 x4 obj -3
 x4 r0 512.0
 x4 r1 256.0
 x5 obj -8
 x6 obj -9
 x7 obj -5
 x8 obj -7
 x9 obj -3
 x10 obj -5
 x11 obj -5
 x12 obj -5
 x13 obj -5
 x14 obj -5
 x15 obj -6
 x16 obj -1
 x17 obj -3
 x18 obj -1
 x18 r0 -768.0
 x19 obj -3
RHS
 rhs obj 20
 rhs r0 0
 rhs r1 128.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
ENDATA
