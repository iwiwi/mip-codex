NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 8
 x1 obj 4
 x2 obj 1
 x3 obj 1
 x4 obj 4
 x5 obj 8
 x6 obj 9
 x7 obj 6
 x8 obj 4
 x9 obj 5
 x10 obj 2
 x11 obj 1
 x12 obj 4
 x13 obj 1
 x14 obj 1
 x15 obj 8
 x16 obj 8
 x17 obj 6
 x18 obj 9
 x19 obj 9
 x20 obj 6
 x20 r0 32.0
 x20 r1 16.0
 x21 obj 3
 x22 obj 6
 x23 obj 9
 x24 obj 3
 x25 obj 6
 x26 obj 4
 x27 obj 3
 x28 obj 6
 x29 obj 2
 x30 obj 5
 x31 obj 1
 x31 r0 -48.0
 x32 obj 8
RHS
 rhs obj -22
 rhs r0 0
 rhs r1 8.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 9
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 6
 LI b x32 0
 UI b x32 3
ENDATA
