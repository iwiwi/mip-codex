NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -6
 x1 obj -6
 x2 obj -2
 x3 obj -6
 x4 obj -7
 x5 obj -4
 x5 r0 -768.0
 x6 obj -8
 x7 obj -1
 x8 obj -4
 x9 obj -6
 x10 obj -6
 x11 obj -2
 x11 r0 512.0
 x11 r1 256.0
 x12 obj -5
 x13 obj -9
 x14 obj -6
 x15 obj -1
 x16 obj -6
 x17 obj -5
 x18 obj -4
 x19 obj -1
 x20 obj -7
 x21 obj -5
 x22 obj -7
 x23 obj -7
 x24 obj -5
 x25 obj -1
 x26 obj -5
 x27 obj -5
 x28 obj -1
 x29 obj -8
 x30 obj -2
 x31 obj -8
 x32 obj -3
 x33 obj -7
 x34 obj -2
RHS
 rhs obj -25
 rhs r0 0
 rhs r1 128.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 2
 LI b x32 0
 UI b x32 3
 LI b x33 0
 UI b x33 4
 LI b x34 0
 UI b x34 3
ENDATA
