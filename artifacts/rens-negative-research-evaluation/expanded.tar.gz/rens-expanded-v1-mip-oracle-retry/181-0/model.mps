NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 4
 x1 obj 9
 x2 obj 1
 x3 obj 2
 x4 obj 9
 x4 r0 512.0
 x4 r1 256.0
 x5 obj 2
 x6 obj 5
 x7 obj 1
 x8 obj 2
 x9 obj 2
 x10 obj 6
 x11 obj 4
 x12 obj 4
 x13 obj 8
 x13 r0 -768.0
 x14 obj 3
 x15 obj 3
 x16 obj 2
 x17 obj 5
 x18 obj 4
 x19 obj 4
 x20 obj 8
 x21 obj 4
 x22 obj 3
 x23 obj 5
 x24 obj 8
 x25 obj 2
 x26 obj 8
 x27 obj 6
 x28 obj 5
RHS
 rhs obj -22
 rhs r0 0
 rhs r1 128.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 9
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 6
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 2
ENDATA
