NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -6
 x1 obj -9
 x2 obj -6
 x3 obj -9
 x4 obj -8
 x5 obj -7
 x6 obj -2
 x6 r0 0.0078125
 x6 r1 0.00390625
 x7 obj -5
 x8 obj -9
 x9 obj -9
 x10 obj -2
 x11 obj -8
 x12 obj -3
 x13 obj -7
 x13 r0 -0.01171875
 x14 obj -8
 x15 obj -6
 x16 obj -6
 x17 obj -8
 x18 obj -9
 x19 obj -1
 x20 obj -2
 x21 obj -2
 x22 obj -2
 x23 obj -4
 x24 obj -7
 x25 obj -8
 x26 obj -9
 x27 obj -3
 x28 obj -9
 x29 obj -4
 x30 obj -8
RHS
 rhs obj 27
 rhs r0 0
 rhs r1 0.001953125
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 6
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 4
ENDATA
