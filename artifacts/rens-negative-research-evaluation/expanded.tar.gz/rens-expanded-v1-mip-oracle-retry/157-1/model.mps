NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -6
 x1 obj -7
 x2 obj -8
 x3 obj -5
 x4 obj -9
 x5 obj -7
 x6 obj -9
 x7 obj -6
 x8 obj -1
 x9 obj -4
 x10 obj -9
 x11 obj -2
 x12 obj -9
 x12 r0 -0.01171875
 x13 obj -1
 x14 obj -2
 x15 obj -7
 x16 obj -1
 x17 obj -4
 x18 obj -5
 x19 obj -5
 x20 obj -9
 x21 obj -2
 x22 obj -9
 x22 r0 0.0078125
 x22 r1 0.00390625
 x23 obj -4
 x24 obj -8
 x25 obj -5
 x26 obj -8
 x27 obj -4
 x28 obj -1
 x29 obj -2
 x30 obj -2
 x31 obj -1
RHS
 rhs obj -13
 rhs r0 0
 rhs r1 0.001953125
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 6
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 9
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 2
 LI b x31 0
 UI b x31 2
ENDATA
