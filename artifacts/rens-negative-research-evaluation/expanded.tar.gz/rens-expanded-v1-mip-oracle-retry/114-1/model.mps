NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -4
 x1 obj -2
 x2 obj -7
 x3 obj -3
 x4 obj -3
 x5 obj -2
 x6 obj -7
 x7 obj -3
 x8 obj -4
 x9 obj -7
 x10 obj -9
 x11 obj -6
 x12 obj -2
 x13 obj -3
 x14 obj -2
 x15 obj -1
 x15 r0 -3.0
 x16 obj -6
 x17 obj -9
 x17 r0 2.0
 x17 r1 1.0
 x18 obj -6
 x19 obj -2
 x20 obj -8
 x21 obj -9
RHS
 rhs obj 0
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 6
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 9
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
ENDATA
