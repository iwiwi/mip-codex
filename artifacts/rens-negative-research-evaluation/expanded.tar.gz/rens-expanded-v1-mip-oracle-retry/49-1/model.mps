NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -4
 x1 obj -2
 x2 obj -2
 x3 obj -4
 x4 obj -8
 x5 obj -8
 x6 obj -8
 x7 obj -7
 x8 obj -1
 x9 obj -9
 x10 obj -6
 x11 obj -8
 x12 obj -6
 x13 obj -5
 x14 obj -4
 x14 r0 0.125
 x14 r1 0.0625
 x15 obj -8
 x15 r0 -0.1875
 x16 obj -6
 x17 obj -3
 x18 obj -9
 x19 obj -4
 x20 obj -5
RHS
 rhs obj -14
 rhs r0 0
 rhs r1 0.03125
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 9
 LI b x15 0
 UI b x15 6
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
ENDATA
