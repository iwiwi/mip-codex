NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 8
 x1 obj 7
 x2 obj 5
 x3 obj 5
 x4 obj 6
 x5 obj 3
 x6 obj 2
 x7 obj 6
 x7 r0 -3.0
 x8 obj 9
 x8 r0 2.0
 x8 r1 1.0
 x9 obj 3
 x10 obj 5
 x11 obj 5
 x12 obj 7
 x13 obj 3
 x14 obj 5
 x15 obj 5
 x16 obj 6
 x17 obj 8
 x18 obj 5
 x19 obj 3
RHS
 rhs obj -17
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 6
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
ENDATA
