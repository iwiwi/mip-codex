NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 9
 x1 obj 9
 x2 obj 2
 x3 obj 1
 x4 obj 4
 x5 obj 9
 x6 obj 6
 x7 obj 4
 x8 obj 7
 x9 obj 9
 x10 obj 8
 x11 obj 8
 x12 obj 7
 x13 obj 5
 x13 r0 2.0
 x13 r1 1.0
 x14 obj 5
 x14 r0 -3.0
 x15 obj 3
 x16 obj 1
 x17 obj 6
 x18 obj 2
RHS
 rhs obj 6
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
ENDATA
