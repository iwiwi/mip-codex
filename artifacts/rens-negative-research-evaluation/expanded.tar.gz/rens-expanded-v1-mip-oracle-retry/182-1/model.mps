NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -7
 x1 obj -2
 x2 obj -7
 x3 obj -8
 x4 obj -8
 x5 obj -7
 x6 obj -8
 x7 obj -5
 x8 obj -7
 x9 obj -9
 x10 obj -7
 x11 obj -5
 x12 obj -3
 x12 r0 0.0078125
 x12 r1 0.00390625
 x13 obj -6
 x14 obj -7
 x14 r0 -0.01171875
 x15 obj -4
 x16 obj -2
 x17 obj -6
 x18 obj -2
 x19 obj -8
 x20 obj -9
RHS
 rhs obj 24
 rhs r0 0
 rhs r1 0.001953125
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
ENDATA
