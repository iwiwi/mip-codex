NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -1
 x1 obj -7
 x2 obj -5
 x3 obj -5
 x4 obj -8
 x5 obj -3
 x6 obj -8
 x6 r0 -3.0
 x7 obj -1
 x8 obj -3
 x9 obj -6
 x9 r0 2.0
 x9 r1 1.0
 x10 obj -6
 x11 obj -9
 x12 obj -4
 x13 obj -1
 x14 obj -6
 x15 obj -6
 x16 obj -4
 x17 obj -9
 x18 obj -7
RHS
 rhs obj 12
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 6
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
ENDATA
