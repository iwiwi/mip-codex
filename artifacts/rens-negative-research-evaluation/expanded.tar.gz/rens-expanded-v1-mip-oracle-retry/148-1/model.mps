NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -7
 x1 obj -4
 x2 obj -9
 x3 obj -5
 x4 obj -3
 x5 obj -7
 x6 obj -2
 x7 obj -7
 x8 obj -8
 x9 obj -2
 x9 r0 -0.1875
 x10 obj -7
 x11 obj -4
 x12 obj -6
 x13 obj -4
 x14 obj -5
 x15 obj -4
 x16 obj -8
 x17 obj -9
 x18 obj -8
 x19 obj -3
 x20 obj -7
 x21 obj -5
 x22 obj -5
 x23 obj -9
 x23 r0 0.125
 x23 r1 0.0625
 x24 obj -7
 x25 obj -8
 x26 obj -5
 x27 obj -9
 x28 obj -3
 x29 obj -3
RHS
 rhs obj -22
 rhs r0 0
 rhs r1 0.03125
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 2
ENDATA
