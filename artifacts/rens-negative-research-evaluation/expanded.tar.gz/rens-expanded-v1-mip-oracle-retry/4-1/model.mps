NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -1
 x1 obj -4
 x2 obj -3
 x3 obj -9
 x4 obj -9
 x5 obj -5
 x5 r0 -3.0
 x6 obj -7
 x7 obj -6
 x8 obj -1
 x9 obj -6
 x10 obj -5
 x11 obj -6
 x12 obj -2
 x13 obj -6
 x14 obj -6
 x15 obj -8
 x16 obj -7
 x17 obj -1
 x18 obj -2
 x19 obj -1
 x20 obj -2
 x21 obj -4
 x21 r0 2.0
 x21 r1 1.0
 x22 obj -9
 x23 obj -5
 x24 obj -1
 x25 obj -7
 x26 obj -8
 x27 obj -3
 x28 obj -1
RHS
 rhs obj -28
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 4
ENDATA
