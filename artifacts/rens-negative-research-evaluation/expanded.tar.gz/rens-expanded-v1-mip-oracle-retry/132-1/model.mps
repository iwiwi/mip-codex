NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -2
 x1 obj -7
 x2 obj -2
 x3 obj -8
 x4 obj -3
 x5 obj -3
 x6 obj -1
 x7 obj -9
 x8 obj -6
 x9 obj -6
 x10 obj -6
 x11 obj -7
 x12 obj -4
 x13 obj -9
 x14 obj -4
 x15 obj -9
 x16 obj -8
 x17 obj -6
 x18 obj -8
 x18 r0 -0.01171875
 x19 obj -2
 x20 obj -3
 x21 obj -6
 x22 obj -8
 x23 obj -3
 x24 obj -9
 x24 r0 0.0078125
 x24 r1 0.00390625
 x25 obj -7
 x26 obj -7
 x27 obj -3
 x28 obj -5
 x29 obj -6
 x30 obj -3
 x31 obj -3
 x32 obj -6
 x33 obj -4
 x34 obj -7
RHS
 rhs obj 18
 rhs r0 0
 rhs r1 0.001953125
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 6
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 9
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 4
 LI b x32 0
 UI b x32 3
 LI b x33 0
 UI b x33 3
 LI b x34 0
 UI b x34 2
ENDATA
