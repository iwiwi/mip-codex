NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -4
 x1 obj -8
 x2 obj -1
 x3 obj -6
 x4 obj -8
 x5 obj -2
 x6 obj -4
 x7 obj -3
 x7 r0 -0.01171875
 x8 obj -2
 x9 obj -5
 x10 obj -3
 x11 obj -5
 x12 obj -3
 x13 obj -2
 x14 obj -7
 x15 obj -9
 x15 r0 0.0078125
 x15 r1 0.00390625
 x16 obj -2
 x17 obj -5
 x18 obj -4
 x19 obj -6
 x20 obj -5
 x21 obj -9
 x22 obj -4
 x23 obj -9
 x24 obj -7
 x25 obj -8
 x26 obj -8
 x27 obj -5
 x28 obj -4
 x29 obj -3
 x30 obj -4
 x31 obj -1
RHS
 rhs obj 4
 rhs r0 0
 rhs r1 0.001953125
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 6
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 9
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 2
 LI b x31 0
 UI b x31 3
ENDATA
