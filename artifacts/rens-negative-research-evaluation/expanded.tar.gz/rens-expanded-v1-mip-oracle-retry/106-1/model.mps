NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -4
 x1 obj -7
 x2 obj -1
 x3 obj -6
 x4 obj -8
 x5 obj -7
 x6 obj -5
 x7 obj -3
 x8 obj -7
 x9 obj -8
 x10 obj -1
 x11 obj -1
 x12 obj -4
 x13 obj -7
 x13 r0 -48.0
 x14 obj -6
 x15 obj -9
 x16 obj -8
 x17 obj -9
 x18 obj -7
 x19 obj -2
 x20 obj -1
 x20 r0 32.0
 x20 r1 16.0
 x21 obj -7
 x22 obj -1
 x23 obj -6
 x24 obj -8
 x25 obj -1
RHS
 rhs obj -17
 rhs r0 0
 rhs r1 8.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 6
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 2
ENDATA
