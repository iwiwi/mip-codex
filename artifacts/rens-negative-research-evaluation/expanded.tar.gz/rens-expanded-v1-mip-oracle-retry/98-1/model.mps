NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -6
 x1 obj -8
 x1 r0 2.0
 x1 r1 1.0
 x2 obj -8
 x3 obj -2
 x4 obj -8
 x5 obj -8
 x6 obj -9
 x6 r0 -3.0
 x7 obj -3
 x8 obj -3
 x9 obj -4
 x10 obj -4
 x11 obj -4
 x12 obj -6
 x13 obj -9
 x14 obj -1
 x15 obj -8
 x16 obj -6
 x17 obj -3
 x18 obj -7
 x19 obj -7
 x20 obj -2
 x21 obj -8
 x22 obj -6
RHS
 rhs obj -21
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
ENDATA
