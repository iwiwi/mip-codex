NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 3
 x1 obj 9
 x2 obj 7
 x3 obj 5
 x4 obj 5
 x5 obj 7
 x6 obj 9
 x7 obj 1
 x8 obj 3
 x9 obj 3
 x10 obj 6
 x11 obj 6
 x12 obj 5
 x12 r0 -3.0
 x13 obj 7
 x14 obj 8
 x15 obj 9
 x16 obj 7
 x16 r0 2.0
 x16 r1 1.0
 x17 obj 6
 x18 obj 9
 x19 obj 4
 x20 obj 8
 x21 obj 5
RHS
 rhs obj -24
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
ENDATA
