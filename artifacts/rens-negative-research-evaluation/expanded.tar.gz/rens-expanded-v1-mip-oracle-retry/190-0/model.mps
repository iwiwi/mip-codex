NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 6
 x1 obj 9
 x2 obj 6
 x3 obj 3
 x4 obj 9
 x5 obj 5
 x6 obj 6
 x7 obj 2
 x8 obj 3
 x9 obj 9
 x10 obj 7
 x11 obj 2
 x12 obj 9
 x13 obj 7
 x14 obj 6
 x15 obj 6
 x16 obj 4
 x17 obj 9
 x18 obj 2
 x19 obj 5
 x20 obj 5
 x21 obj 1
 x22 obj 8
 x23 obj 5
 x24 obj 5
 x25 obj 5
 x26 obj 4
 x26 r0 -0.1875
 x27 obj 7
 x28 obj 2
 x29 obj 7
 x30 obj 3
 x30 r0 0.125
 x30 r1 0.0625
 x31 obj 1
RHS
 rhs obj 0
 rhs r0 0
 rhs r1 0.03125
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 3
ENDATA
