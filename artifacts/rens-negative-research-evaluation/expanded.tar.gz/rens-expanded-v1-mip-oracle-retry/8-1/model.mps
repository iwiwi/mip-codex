NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -6
 x1 obj -3
 x2 obj -1
 x3 obj -9
 x4 obj -9
 x5 obj -2
 x5 r0 -3.0
 x6 obj -7
 x7 obj -7
 x8 obj -2
 x9 obj -7
 x10 obj -2
 x11 obj -2
 x12 obj -4
 x13 obj -2
 x14 obj -8
 x15 obj -3
 x16 obj -5
 x17 obj -1
 x18 obj -4
 x18 r0 2.0
 x18 r1 1.0
 x19 obj -2
 x20 obj -1
 x21 obj -2
RHS
 rhs obj -10
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 6
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 9
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
ENDATA
