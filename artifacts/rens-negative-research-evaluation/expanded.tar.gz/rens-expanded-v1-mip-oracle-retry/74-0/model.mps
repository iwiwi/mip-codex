NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 9
 x1 obj 2
 x2 obj 3
 x3 obj 4
 x4 obj 6
 x5 obj 4
 x6 obj 7
 x7 obj 5
 x8 obj 2
 x9 obj 6
 x10 obj 2
 x11 obj 4
 x12 obj 9
 x13 obj 7
 x14 obj 1
 x15 obj 7
 x16 obj 1
 x16 r0 -3.0
 x17 obj 6
 x18 obj 8
 x19 obj 6
 x20 obj 8
 x21 obj 2
 x21 r0 2.0
 x21 r1 1.0
 x22 obj 6
 x23 obj 9
 x24 obj 4
RHS
 rhs obj 20
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
ENDATA
