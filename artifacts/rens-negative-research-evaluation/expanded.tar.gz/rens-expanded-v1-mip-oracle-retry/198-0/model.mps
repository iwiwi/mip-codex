NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 2
 x1 obj 7
 x2 obj 4
 x3 obj 4
 x4 obj 5
 x5 obj 1
 x6 obj 4
 x7 obj 6
 x7 r0 -0.1875
 x8 obj 7
 x9 obj 6
 x10 obj 4
 x11 obj 3
 x12 obj 4
 x13 obj 6
 x14 obj 8
 x14 r0 0.125
 x14 r1 0.0625
 x15 obj 7
 x16 obj 7
 x17 obj 8
 x18 obj 1
 x19 obj 5
 x20 obj 7
 x21 obj 4
 x22 obj 4
 x23 obj 7
 x24 obj 5
 x25 obj 4
 x26 obj 3
 x27 obj 6
 x28 obj 8
 x29 obj 5
 x30 obj 1
RHS
 rhs obj -26
 rhs r0 0
 rhs r1 0.03125
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 6
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 9
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 3
ENDATA
