NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 8
 x1 obj 2
 x2 obj 1
 x3 obj 3
 x4 obj 4
 x5 obj 9
 x6 obj 1
 x6 r0 -48.0
 x7 obj 8
 x8 obj 3
 x9 obj 1
 x10 obj 9
 x11 obj 3
 x12 obj 7
 x13 obj 2
 x14 obj 2
 x15 obj 5
 x16 obj 7
 x17 obj 6
 x18 obj 8
 x19 obj 8
 x19 r0 32.0
 x19 r1 16.0
 x20 obj 2
RHS
 rhs obj -28
 rhs r0 0
 rhs r1 8.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 6
 LI b x20 0
 UI b x20 4
ENDATA
