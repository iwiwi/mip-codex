NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 2
 x1 obj 6
 x2 obj 3
 x3 obj 3
 x4 obj 6
 x5 obj 3
 x6 obj 3
 x7 obj 1
 x8 obj 8
 x9 obj 7
 x10 obj 1
 x11 obj 8
 x12 obj 3
 x13 obj 2
 x14 obj 5
 x15 obj 9
 x16 obj 2
 x17 obj 1
 x18 obj 4
 x19 obj 6
 x20 obj 7
 x21 obj 1
 x21 r0 -3.0
 x22 obj 1
 x23 obj 2
 x24 obj 5
 x25 obj 7
 x26 obj 9
 x27 obj 3
 x27 r0 2.0
 x27 r1 1.0
 x28 obj 3
 x29 obj 2
 x30 obj 8
 x31 obj 7
 x32 obj 7
 x33 obj 6
 x34 obj 1
RHS
 rhs obj 19
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 6
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 2
 LI b x33 0
 UI b x33 2
 LI b x34 0
 UI b x34 4
ENDATA
