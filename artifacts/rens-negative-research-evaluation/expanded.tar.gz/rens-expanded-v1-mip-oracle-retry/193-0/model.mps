NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 1
 x1 obj 2
 x2 obj 5
 x3 obj 4
 x4 obj 8
 x5 obj 8
 x6 obj 8
 x7 obj 8
 x7 r0 -0.01171875
 x8 obj 4
 x9 obj 1
 x10 obj 3
 x11 obj 2
 x12 obj 6
 x13 obj 8
 x14 obj 6
 x15 obj 6
 x16 obj 8
 x17 obj 8
 x18 obj 9
 x18 r0 0.0078125
 x18 r1 0.00390625
 x19 obj 7
 x20 obj 6
 x21 obj 7
 x22 obj 4
 x23 obj 9
 x24 obj 5
 x25 obj 9
 x26 obj 6
 x27 obj 1
 x28 obj 7
 x29 obj 8
 x30 obj 8
 x31 obj 8
 x32 obj 8
RHS
 rhs obj 15
 rhs r0 0
 rhs r1 0.001953125
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 2
 LI b x32 0
 UI b x32 3
ENDATA
