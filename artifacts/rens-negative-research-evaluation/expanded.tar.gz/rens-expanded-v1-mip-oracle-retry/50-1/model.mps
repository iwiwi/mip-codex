NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -8
 x1 obj -7
 x2 obj -5
 x3 obj -4
 x4 obj -2
 x5 obj -2
 x6 obj -5
 x7 obj -8
 x8 obj -5
 x9 obj -9
 x10 obj -4
 x11 obj -9
 x12 obj -3
 x13 obj -4
 x14 obj -7
 x15 obj -6
 x16 obj -3
 x17 obj -9
 x18 obj -1
 x19 obj -6
 x19 r0 32.0
 x19 r1 16.0
 x20 obj -9
 x21 obj -5
 x22 obj -2
 x23 obj -9
 x24 obj -4
 x25 obj -4
 x25 r0 -48.0
 x26 obj -9
 x27 obj -1
 x28 obj -8
 x29 obj -3
 x30 obj -3
RHS
 rhs obj 22
 rhs r0 0
 rhs r1 8.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 2
ENDATA
