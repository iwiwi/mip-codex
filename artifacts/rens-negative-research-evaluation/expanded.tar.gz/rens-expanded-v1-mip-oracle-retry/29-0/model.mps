NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 8
 x1 obj 3
 x2 obj 1
 x3 obj 3
 x4 obj 7
 x5 obj 1
 x6 obj 8
 x7 obj 9
 x8 obj 3
 x9 obj 8
 x10 obj 9
 x11 obj 5
 x11 r0 -0.1875
 x12 obj 6
 x12 r0 0.125
 x12 r1 0.0625
 x13 obj 3
 x14 obj 8
 x15 obj 3
 x16 obj 9
 x17 obj 8
 x18 obj 1
 x19 obj 5
 x20 obj 8
 x21 obj 5
 x22 obj 6
RHS
 rhs obj 16
 rhs r0 0
 rhs r1 0.03125
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
ENDATA
