NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -6
 x1 obj -8
 x2 obj -4
 x3 obj -9
 x4 obj -2
 x4 r0 512.0
 x4 r1 256.0
 x5 obj -5
 x6 obj -1
 x7 obj -6
 x8 obj -6
 x9 obj -4
 x10 obj -7
 x10 r0 -768.0
 x11 obj -2
 x12 obj -5
 x13 obj -3
 x14 obj -2
 x15 obj -9
 x16 obj -6
 x17 obj -1
 x18 obj -4
 x19 obj -9
 x20 obj -7
 x21 obj -4
 x22 obj -7
 x23 obj -9
 x24 obj -3
 x25 obj -7
 x26 obj -9
 x27 obj -6
 x28 obj -8
 x29 obj -1
 x30 obj -2
 x31 obj -5
RHS
 rhs obj 0
 rhs r0 0
 rhs r1 128.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 6
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 4
ENDATA
