NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -1
 x1 obj -1
 x2 obj -5
 x2 r0 -48.0
 x3 obj -5
 x4 obj -9
 x5 obj -8
 x6 obj -5
 x7 obj -7
 x8 obj -8
 x9 obj -1
 x10 obj -6
 x11 obj -3
 x12 obj -5
 x13 obj -2
 x14 obj -5
 x15 obj -4
 x16 obj -2
 x17 obj -3
 x18 obj -7
 x19 obj -6
 x20 obj -5
 x21 obj -8
 x22 obj -1
 x23 obj -8
 x24 obj -3
 x25 obj -5
 x26 obj -9
 x26 r0 32.0
 x26 r1 16.0
 x27 obj -5
RHS
 rhs obj -29
 rhs r0 0
 rhs r1 8.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 6
 LI b x27 0
 UI b x27 2
ENDATA
