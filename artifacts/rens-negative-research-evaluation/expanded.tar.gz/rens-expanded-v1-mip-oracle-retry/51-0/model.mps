NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 9
 x1 obj 1
 x2 obj 2
 x3 obj 4
 x4 obj 6
 x5 obj 6
 x6 obj 4
 x7 obj 4
 x8 obj 3
 x9 obj 9
 x10 obj 4
 x11 obj 7
 x12 obj 7
 x13 obj 3
 x14 obj 1
 x15 obj 9
 x16 obj 8
 x17 obj 1
 x18 obj 2
 x19 obj 4
 x20 obj 7
 x21 obj 6
 x22 obj 7
 x22 r0 -768.0
 x23 obj 6
 x24 obj 1
 x24 r0 512.0
 x24 r1 256.0
RHS
 rhs obj -21
 rhs r0 0
 rhs r1 128.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 6
ENDATA
