NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -3
 x1 obj -1
 x2 obj -8
 x3 obj -5
 x4 obj -3
 x5 obj -1
 x6 obj -2
 x7 obj -7
 x8 obj -9
 x9 obj -9
 x10 obj -3
 x11 obj -6
 x12 obj -6
 x13 obj -2
 x13 r0 -768.0
 x14 obj -2
 x15 obj -3
 x15 r0 512.0
 x15 r1 256.0
 x16 obj -1
 x17 obj -1
 x18 obj -9
 x19 obj -8
 x20 obj -2
 x21 obj -6
 x22 obj -4
 x23 obj -9
 x24 obj -1
RHS
 rhs obj 4
 rhs r0 0
 rhs r1 128.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 6
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 9
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
ENDATA
