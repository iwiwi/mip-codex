NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -7
 x1 obj -3
 x2 obj -5
 x3 obj -3
 x3 r0 -3.0
 x4 obj -4
 x5 obj -4
 x6 obj -5
 x7 obj -1
 x8 obj -6
 x9 obj -6
 x10 obj -9
 x11 obj -9
 x12 obj -2
 x13 obj -9
 x14 obj -5
 x15 obj -3
 x16 obj -2
 x17 obj -7
 x18 obj -8
 x19 obj -5
 x20 obj -8
 x20 r0 2.0
 x20 r1 1.0
RHS
 rhs obj 26
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 6
ENDATA
