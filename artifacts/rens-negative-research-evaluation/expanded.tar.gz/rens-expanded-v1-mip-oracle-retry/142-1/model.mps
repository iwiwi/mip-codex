NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -4
 x1 obj -7
 x2 obj -8
 x3 obj -7
 x4 obj -9
 x5 obj -9
 x6 obj -5
 x7 obj -6
 x7 r0 2.0
 x7 r1 1.0
 x8 obj -5
 x9 obj -7
 x10 obj -6
 x11 obj -5
 x12 obj -9
 x13 obj -2
 x14 obj -6
 x15 obj -8
 x16 obj -3
 x17 obj -6
 x17 r0 -3.0
 x18 obj -2
 x19 obj -9
 x20 obj -5
 x21 obj -6
RHS
 rhs obj 8
 rhs r0 0
 rhs r1 0.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
ENDATA
