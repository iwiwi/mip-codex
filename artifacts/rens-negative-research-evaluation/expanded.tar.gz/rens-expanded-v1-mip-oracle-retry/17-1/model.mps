NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -4
 x1 obj -2
 x2 obj -9
 x3 obj -3
 x4 obj -8
 x5 obj -8
 x6 obj -8
 x7 obj -4
 x7 r0 -768.0
 x8 obj -6
 x9 obj -9
 x10 obj -4
 x11 obj -8
 x12 obj -8
 x13 obj -3
 x14 obj -2
 x15 obj -6
 x16 obj -1
 x17 obj -8
 x17 r0 512.0
 x17 r1 256.0
 x18 obj -7
 x19 obj -7
 x20 obj -4
 x21 obj -6
 x22 obj -8
 x23 obj -8
 x24 obj -2
RHS
 rhs obj 18
 rhs r0 0
 rhs r1 128.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 3
ENDATA
