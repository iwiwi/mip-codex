NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -3
 x1 obj -6
 x2 obj -5
 x3 obj -3
 x4 obj -1
 x5 obj -8
 x6 obj -7
 x7 obj -5
 x8 obj -2
 x9 obj -6
 x10 obj -6
 x11 obj -5
 x12 obj -5
 x13 obj -6
 x14 obj -7
 x15 obj -3
 x16 obj -8
 x16 r0 -48.0
 x17 obj -7
 x17 r0 32.0
 x17 r1 16.0
 x18 obj -4
 x19 obj -7
 x20 obj -6
 x21 obj -4
 x22 obj -9
 x23 obj -9
 x24 obj -1
 x25 obj -1
 x26 obj -7
RHS
 rhs obj 29
 rhs r0 0
 rhs r1 8.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 6
 LI b x17 0
 UI b x17 9
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 4
ENDATA
