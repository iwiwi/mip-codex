NAME lattice
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj 5
 x1 obj 1
 x2 obj 4
 x3 obj 2
 x3 r0 32.0
 x3 r1 16.0
 x4 obj 8
 x5 obj 8
 x6 obj 3
 x7 obj 9
 x8 obj 1
 x9 obj 3
 x10 obj 7
 x11 obj 8
 x12 obj 2
 x13 obj 1
 x14 obj 4
 x15 obj 9
 x16 obj 7
 x17 obj 5
 x18 obj 2
 x19 obj 9
 x19 r0 -48.0
 x20 obj 4
 x21 obj 4
 x22 obj 3
 x23 obj 6
 x24 obj 7
 x25 obj 2
 x26 obj 3
 x27 obj 8
 x28 obj 7
 x29 obj 7
 x30 obj 3
 x31 obj 9
 x32 obj 3
 x33 obj 7
 x34 obj 3
RHS
 rhs obj 25
 rhs r0 0
 rhs r1 8.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 6
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 2
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 4
 LI b x34 0
 UI b x34 2
ENDATA
