NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -1
 x1 obj -2
 x2 obj -5
 x3 obj -6
 x4 obj -8
 x5 obj -9
 x6 obj -7
 x6 r0 0.125
 x6 r1 0.0625
 x7 obj -2
 x8 obj -9
 x9 obj -3
 x10 obj -9
 x11 obj -7
 x12 obj -5
 x13 obj -5
 x14 obj -9
 x15 obj -3
 x16 obj -9
 x17 obj -1
 x18 obj -6
 x19 obj -4
 x20 obj -8
 x21 obj -7
 x22 obj -5
 x23 obj -2
 x24 obj -7
 x25 obj -4
 x26 obj -7
 x27 obj -6
 x28 obj -4
 x29 obj -1
 x30 obj -5
 x31 obj -5
 x32 obj -8
 x33 obj -4
 x33 r0 -0.1875
RHS
 rhs obj -20
 rhs r0 0
 rhs r1 0.03125
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 6
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 2
 LI b x32 0
 UI b x32 3
 LI b x33 0
 UI b x33 4
ENDATA
