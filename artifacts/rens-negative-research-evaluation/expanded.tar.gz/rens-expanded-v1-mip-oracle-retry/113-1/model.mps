NAME lattice
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
COLUMNS
 x0 obj -6
 x1 obj -8
 x2 obj -5
 x3 obj -4
 x3 r0 0.125
 x3 r1 0.0625
 x4 obj -5
 x5 obj -4
 x6 obj -8
 x7 obj -4
 x8 obj -3
 x9 obj -6
 x10 obj -1
 x11 obj -4
 x12 obj -8
 x13 obj -4
 x14 obj -3
 x15 obj -2
 x16 obj -1
 x17 obj -6
 x18 obj -5
 x19 obj -8
 x20 obj -3
 x20 r0 -0.1875
 x21 obj -9
RHS
 rhs obj -30
 rhs r0 0
 rhs r1 0.03125
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 6
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
ENDATA
