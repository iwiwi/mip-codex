from pathlib import Path
from fractions import Fraction as F
import os,json,random,subprocess,time,sys
root=Path.cwd();frozen=root/'artifacts/rens-released-v1-diagnostic';sys.path.insert(0,str(frozen/'scripts'));from verify_cover_cuts import exact_model,validate_cut_proofs
sys.path.insert(0,str(root/'scripts'));from benchmark_common import atomic_json,sha256
os.sched_setaffinity(0,{41});out=root/'artifacts/rens-released-v1-mip-oracle-retry';out.mkdir();rng=random.Random(2026111715);binary=frozen/'bin/mip-codex';records=[]
flags=['MIP_BINARY_GRAPH','MIP_BOX_PRIMAL','MIP_PRIMAL_REPAIR','MIP_PRIMAL_PROBE','MIP_LP_DIVING','MIP_OBJECTIVE_LP_DIVE','MIP_FEASIBILITY_PUMP','MIP_RINS','MIP_COVER_CUTS','MIP_MIR_CUTS','MIP_GOMORY_CUTS','MIP_AGGREGATE_CUTS','MIP_CLIQUE_CUTS','MIP_THREE_ROW_CUTS','MIP_ROUNDING_CUTS','MIP_STRONG_BRANCHING','MIP_OBJECTIVE_ROUNDING','MIP_PROPAGATION'];source=(frozen/'src/main.rs').read_text();assert all('"'+s+'"'in source for s in flags)
atomic_json(out/'experiment.json',dict(seed=2026111715,models=200,senses=2,settings=2,cpu=41,seconds=2,binary_sha256=sha256(binary),purpose='randomized triangle rounding templates with variable permutation/cost/offset/row scaling; explicitly disables other primal heuristics to exercise RENS'))
for case in range(200):
 n=rng.randrange(18,36);tri=rng.sample(range(n),3);c=rng.randint(1,9);offset=rng.randint(-30,30);upper=[1 if j in tri else rng.randint(2,4)for j in range(n)]+[2];rows=[]
 for i in range(rng.randint(3,10)):
  a,b=([tri[0],tri[1]],[tri[1],tri[2]],[tri[0],tri[2]])[i%3];scale=2.**rng.choice([-8,-4,0,4,8]);sense=rng.choice(['L','G']);sign=1 if sense=='L'else-1;rows.append(({a:sign*scale,b:sign*scale},sense,sign*scale))
 rows.append(({tri[0]:1.,n:2.},'L',5.));needs_release=case%2==1;z=rng.choice([j for j in range(n)if j not in tri])
 if needs_release:rows.append(({tri[0]:1.,tri[1]:1.,tri[2]:1.,z:1.},'G',1.5))
 for maximize in [False,True]:
  costs=[(-c if j in tri else rng.randint(1,9))*(-1 if maximize else 1)for j in range(n)]+[0];d=out/f'{case}-{int(maximize)}';d.mkdir();model=d/'model.mps';s='NAME rens\nOBJSENSE\n '+('MAX'if maximize else'MIN')+'\nROWS\n N obj\n'+''.join(f' {sense} r{i}\n'for i,(_,sense,_)in enumerate(rows))+'COLUMNS\n'
  for j,cost in enumerate(costs):s+=f' x{j} obj {cost}\n'+''.join(f' x{j} r{i} {a[j]}\n'for i,(a,_,_)in enumerate(rows)if j in a)
  s+='RHS\n'+f' rhs obj {-offset}\n'+''.join(f' rhs r{i} {b}\n'for i,(_,_,b)in enumerate(rows))+'BOUNDS\n'+''.join(f' LI b x{j} 0\n UI b x{j} {upper[j]}\n'for j in range(n))+f' UP b x{n} 2\nENDATA\n';model.write_text(s);names,variables,parsed_rows,obj,constant=exact_model(model,True);assert constant==offset;expected=offset+((c-abs(costs[z]) if maximize else abs(costs[z])-c)if needs_release else(c if maximize else-c))
  for label in (['before','after']if case%2==0 else['after','before']):
   dest=d/label;dest.mkdir();env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update({k:'0'for k in flags});env.update(MIP_RENS='1',MIP_RENS_RELEASE='0'if label=='before'else'1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');cmd=[str(binary),'solve',str(model),'2'];atomic_json(dest/'job.json',dict(command=cmd,input_sha256=sha256(model),environment={k:v for k,v in env.items()if k.startswith('MIP_')}));start=time.monotonic();a=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=62);(dest/'result.json').write_text(a.stdout);(dest/'stderr.log').write_text(a.stderr);atomic_json(dest/'execution.json',dict(exit_code=a.returncode,wall_seconds=time.monotonic()-start));assert a.returncode==0;r=json.loads(a.stdout);assert r['status']=='optimal',(case,maximize,label,r['status']);assert abs(F(str(r['objective']))-expected)<=F(1,1000000);x={name:F(str(r['values'][name]))for name in names};tol=F(1,1000000)
   assert all((v['lower']is None or x[name]>=v['lower']-tol)and(v['upper']is None or x[name]<=v['upper']+tol)and(not v['integer']or abs(x[name]-round(x[name]))<=tol)for name,v in variables.items())
   for row in parsed_rows:
    lhs=sum(a*x[name]for name,a in row['coefficients'].items());assert(row['lower']is None or lhs>=row['lower']-tol)and(row['upper']is None or lhs<=row['upper']+tol)
   proof=validate_cut_proofs(model,r);atomic_json(dest/'proof-validation.json',proof);assert proof['valid']is True;assert r['dual_bound']is None or (-1 if maximize else 1)*F(str(r['dual_bound']))<=(-1 if maximize else 1)*expected+tol
   active=needs_release and label=='after'
   assert r['rens']['calls']==(2 if active else 1)and r['rens']['released']==(1 if active else 0)and r['rens']['improvements']==(0 if needs_release and label=='before'else 1)and r['rens']['fixed']==n-3-(1 if active else 0),(case,label,r['rens'])
   record=dict(case=case,maximize=maximize,label=label,objective=r['objective'],expected=expected,valid=True,rens=r.get('rens'));records.append(record);atomic_json(dest/'validation.json',record);atomic_json(out/'progress.json',dict(outputs=len(records),valid=len(records)))
atomic_json(out/'records.json',records);atomic_json(out/'summary.json',dict(outputs=len(records),valid=len(records),models=200,rens_calls=sum((r['rens']or{}).get('calls',0)for r in records),rens_improvements=sum((r['rens']or{}).get('improvements',0)for r in records)));atomic_json(out/'exit.json',dict(status='complete'));print(json.loads((out/'summary.json').read_text()))
