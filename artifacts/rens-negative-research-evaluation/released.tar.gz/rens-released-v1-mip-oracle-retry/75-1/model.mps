NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 L r4
 G r5
COLUMNS
 x0 obj 1
 x0 r0 -0.00390625
 x0 r2 0.0625
 x0 r3 -0.0625
 x0 r4 1.0
 x0 r5 1.0
 x1 obj -3
 x2 obj -6
 x3 obj -9
 x4 obj -1
 x5 obj 1
 x5 r0 -0.00390625
 x5 r1 1.0
 x5 r3 -0.0625
 x5 r5 1.0
 x6 obj -2
 x7 obj -3
 x8 obj -4
 x9 obj -9
 x10 obj -5
 x11 obj -9
 x12 obj -8
 x13 obj -8
 x14 obj -2
 x15 obj -5
 x16 obj 1
 x16 r1 1.0
 x16 r2 0.0625
 x16 r5 1.0
 x17 obj -6
 x18 obj -5
 x19 obj -3
 x20 obj -5
 x21 obj -9
 x22 obj -2
 x22 r5 1.0
 x23 obj -3
 x24 obj -9
 x25 obj -9
 x26 obj 0
 x26 r4 2.0
RHS
 rhs obj 26
 rhs r0 -0.00390625
 rhs r1 1.0
 rhs r2 0.0625
 rhs r3 -0.0625
 rhs r4 5.0
 rhs r5 1.5
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 3
 UP b x26 2
ENDATA
