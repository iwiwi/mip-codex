NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 G r3
 L r4
 G r5
 G r6
 L r7
COLUMNS
 x0 obj 9
 x0 r0 -16.0
 x0 r1 -256.0
 x0 r3 -16.0
 x0 r4 1.0
 x0 r6 -1.0
 x1 obj -6
 x2 obj -9
 x3 obj -5
 x4 obj -2
 x5 obj 9
 x5 r1 -256.0
 x5 r2 0.00390625
 x5 r4 1.0
 x5 r5 -256.0
 x6 obj -6
 x7 obj -6
 x8 obj -2
 x9 obj -6
 x10 obj -5
 x11 obj -7
 x12 obj -3
 x13 obj -1
 x14 obj -4
 x15 obj -8
 x16 obj -1
 x17 obj 9
 x17 r0 -16.0
 x17 r2 0.00390625
 x17 r3 -16.0
 x17 r5 -256.0
 x17 r6 -1.0
 x17 r7 1.0
 x18 obj -9
 x19 obj -8
 x20 obj -2
 x21 obj -4
 x22 obj -1
 x23 obj -2
 x24 obj -5
 x25 obj -5
 x26 obj -2
 x27 obj 0
 x27 r7 2.0
RHS
 rhs obj 17
 rhs r0 -16.0
 rhs r1 -256.0
 rhs r2 0.00390625
 rhs r3 -16.0
 rhs r4 1.0
 rhs r5 -256.0
 rhs r6 -1.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 2
 UP b x27 2
ENDATA
