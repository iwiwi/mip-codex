NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 G r4
 L r5
 L r6
 G r7
COLUMNS
 x0 obj 6
 x1 obj 8
 x2 obj 4
 x3 obj 2
 x4 obj -4
 x4 r0 0.0625
 x4 r2 1.0
 x4 r3 1.0
 x4 r5 0.00390625
 x4 r6 1.0
 x4 r7 1.0
 x5 obj 5
 x6 obj 6
 x6 r7 1.0
 x7 obj 9
 x8 obj 5
 x9 obj 1
 x10 obj 1
 x11 obj 2
 x12 obj 9
 x13 obj -4
 x13 r0 0.0625
 x13 r1 -16.0
 x13 r3 1.0
 x13 r4 -256.0
 x13 r7 1.0
 x14 obj 4
 x15 obj -4
 x15 r1 -16.0
 x15 r2 1.0
 x15 r4 -256.0
 x15 r5 0.00390625
 x15 r7 1.0
 x16 obj 7
 x17 obj 4
 x18 obj 3
 x19 obj 1
 x20 obj 2
 x21 obj 9
 x22 obj 8
 x23 obj 1
 x24 obj 6
 x25 obj 1
 x26 obj 0
 x26 r6 2.0
RHS
 rhs obj -23
 rhs r0 0.0625
 rhs r1 -16.0
 rhs r2 1.0
 rhs r3 1.0
 rhs r4 -256.0
 rhs r5 0.00390625
 rhs r6 5.0
 rhs r7 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 UP b x26 2
ENDATA
