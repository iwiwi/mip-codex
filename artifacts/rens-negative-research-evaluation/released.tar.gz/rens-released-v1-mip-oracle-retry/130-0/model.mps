NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 L r7
 G r8
 G r9
 L r10
COLUMNS
 x0 obj 3
 x1 obj 5
 x2 obj 9
 x3 obj 4
 x4 obj 5
 x5 obj 9
 x6 obj 2
 x7 obj 7
 x8 obj -1
 x8 r0 256.0
 x8 r1 -1.0
 x8 r3 -0.00390625
 x8 r4 -0.0625
 x8 r6 -256.0
 x8 r7 16.0
 x8 r9 -256.0
 x9 obj 9
 x10 obj 3
 x11 obj -1
 x11 r1 -1.0
 x11 r2 -0.0625
 x11 r4 -0.0625
 x11 r5 -16.0
 x11 r7 16.0
 x11 r8 -256.0
 x12 obj -1
 x12 r0 256.0
 x12 r2 -0.0625
 x12 r3 -0.00390625
 x12 r5 -16.0
 x12 r6 -256.0
 x12 r8 -256.0
 x12 r9 -256.0
 x12 r10 1.0
 x13 obj 1
 x14 obj 4
 x15 obj 3
 x16 obj 4
 x17 obj 7
 x18 obj 2
 x19 obj 3
 x20 obj 9
 x21 obj 4
 x22 obj 4
 x23 obj 0
 x23 r10 2.0
RHS
 rhs obj -14
 rhs r0 256.0
 rhs r1 -1.0
 rhs r2 -0.0625
 rhs r3 -0.00390625
 rhs r4 -0.0625
 rhs r5 -16.0
 rhs r6 -256.0
 rhs r7 16.0
 rhs r8 -256.0
 rhs r9 -256.0
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 UP b x23 2
ENDATA
