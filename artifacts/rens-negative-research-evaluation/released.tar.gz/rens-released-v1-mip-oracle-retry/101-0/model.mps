NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 L r4
 L r5
 L r6
 G r7
 L r8
 G r9
COLUMNS
 x0 obj 8
 x1 obj 6
 x2 obj 6
 x3 obj 3
 x4 obj 9
 x5 obj 4
 x6 obj -4
 x6 r0 1.0
 x6 r2 256.0
 x6 r3 -0.0625
 x6 r5 256.0
 x6 r6 16.0
 x6 r8 1.0
 x6 r9 1.0
 x7 obj 2
 x8 obj 3
 x9 obj 1
 x10 obj -4
 x10 r1 -1.0
 x10 r2 256.0
 x10 r4 0.00390625
 x10 r5 256.0
 x10 r7 -1.0
 x10 r9 1.0
 x11 obj 5
 x11 r9 1.0
 x12 obj 6
 x13 obj 1
 x14 obj 8
 x15 obj 3
 x16 obj 2
 x17 obj 2
 x18 obj 3
 x19 obj 4
 x20 obj 7
 x21 obj -4
 x21 r0 1.0
 x21 r1 -1.0
 x21 r3 -0.0625
 x21 r4 0.00390625
 x21 r6 16.0
 x21 r7 -1.0
 x21 r9 1.0
 x22 obj 8
 x23 obj 1
 x24 obj 0
 x24 r8 2.0
RHS
 rhs obj 23
 rhs r0 1.0
 rhs r1 -1.0
 rhs r2 256.0
 rhs r3 -0.0625
 rhs r4 0.00390625
 rhs r5 256.0
 rhs r6 16.0
 rhs r7 -1.0
 rhs r8 5.0
 rhs r9 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 UP b x24 2
ENDATA
