NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 G r4
 L r5
 G r6
 L r7
 L r8
 G r9
 L r10
 G r11
COLUMNS
 x0 obj 1
 x1 obj 8
 x2 obj 9
 x3 obj 5
 x4 obj 1
 x5 obj 2
 x6 obj 3
 x7 obj 3
 x8 obj -7
 x8 r1 -0.0625
 x8 r2 16.0
 x8 r4 -16.0
 x8 r5 0.0625
 x8 r7 0.00390625
 x8 r8 256.0
 x8 r11 1.0
 x9 obj 7
 x10 obj 6
 x11 obj 5
 x12 obj 4
 x13 obj 8
 x14 obj 6
 x15 obj 2
 x16 obj 4
 x17 obj 7
 x18 obj 3
 x18 r11 1.0
 x19 obj 8
 x20 obj 2
 x21 obj 4
 x22 obj 3
 x23 obj 7
 x24 obj 2
 x25 obj -7
 x25 r0 0.00390625
 x25 r1 -0.0625
 x25 r3 16.0
 x25 r4 -16.0
 x25 r6 -0.00390625
 x25 r7 0.00390625
 x25 r9 -16.0
 x25 r11 1.0
 x26 obj 8
 x27 obj -7
 x27 r0 0.00390625
 x27 r2 16.0
 x27 r3 16.0
 x27 r5 0.0625
 x27 r6 -0.00390625
 x27 r8 256.0
 x27 r9 -16.0
 x27 r10 1.0
 x27 r11 1.0
 x28 obj 9
 x29 obj 2
 x30 obj 0
 x30 r10 2.0
RHS
 rhs obj -16
 rhs r0 0.00390625
 rhs r1 -0.0625
 rhs r2 16.0
 rhs r3 16.0
 rhs r4 -16.0
 rhs r5 0.0625
 rhs r6 -0.00390625
 rhs r7 0.00390625
 rhs r8 256.0
 rhs r9 -16.0
 rhs r10 5.0
 rhs r11 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 1
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 1
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 3
 UP b x30 2
ENDATA
