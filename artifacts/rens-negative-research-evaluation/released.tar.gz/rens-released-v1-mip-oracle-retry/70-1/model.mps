NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
COLUMNS
 x0 obj -2
 x1 obj -5
 x2 obj -6
 x3 obj -2
 x4 obj -9
 x5 obj -3
 x6 obj -8
 x7 obj -8
 x8 obj -1
 x9 obj -6
 x10 obj 2
 x10 r0 0.00390625
 x10 r2 256.0
 x10 r3 256.0
 x10 r5 0.0625
 x10 r6 1.0
 x10 r8 1.0
 x11 obj -4
 x12 obj -2
 x13 obj -4
 x14 obj -4
 x15 obj -6
 x16 obj -2
 x17 obj 2
 x17 r1 0.00390625
 x17 r2 256.0
 x17 r4 0.0625
 x17 r5 0.0625
 x17 r7 1.0
 x18 obj -7
 x19 obj 2
 x19 r0 0.00390625
 x19 r1 0.00390625
 x19 r3 256.0
 x19 r4 0.0625
 x19 r6 1.0
 x19 r7 1.0
 x20 obj -9
 x21 obj -3
 x22 obj -5
 x23 obj -3
 x24 obj -4
 x25 obj 0
 x25 r8 2.0
RHS
 rhs obj 20
 rhs r0 0.00390625
 rhs r1 0.00390625
 rhs r2 256.0
 rhs r3 256.0
 rhs r4 0.0625
 rhs r5 0.0625
 rhs r6 1.0
 rhs r7 1.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 UP b x25 2
ENDATA
