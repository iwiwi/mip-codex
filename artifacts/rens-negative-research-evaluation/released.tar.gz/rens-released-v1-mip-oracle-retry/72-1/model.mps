NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 G r3
 L r4
 G r5
 L r6
COLUMNS
 x0 obj -1
 x1 obj 7
 x1 r0 -0.0625
 x1 r1 -16.0
 x1 r3 -1.0
 x1 r4 0.0625
 x2 obj -8
 x3 obj -9
 x4 obj -5
 x5 obj -2
 x6 obj 7
 x6 r1 -16.0
 x6 r2 1.0
 x6 r4 0.0625
 x6 r5 -0.00390625
 x7 obj -2
 x8 obj -3
 x9 obj -8
 x10 obj -3
 x11 obj -1
 x12 obj -4
 x13 obj -5
 x14 obj -7
 x15 obj -8
 x16 obj 7
 x16 r0 -0.0625
 x16 r2 1.0
 x16 r3 -1.0
 x16 r5 -0.00390625
 x16 r6 1.0
 x17 obj -9
 x18 obj 0
 x18 r6 2.0
RHS
 rhs obj 15
 rhs r0 -0.0625
 rhs r1 -16.0
 rhs r2 1.0
 rhs r3 -1.0
 rhs r4 0.0625
 rhs r5 -0.00390625
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 4
 UP b x18 2
ENDATA
