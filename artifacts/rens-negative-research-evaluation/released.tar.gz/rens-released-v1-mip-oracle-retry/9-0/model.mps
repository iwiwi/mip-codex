NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 L r4
 G r5
COLUMNS
 x0 obj 6
 x0 r5 1.0
 x1 obj 2
 x2 obj -9
 x2 r0 1.0
 x2 r2 1.0
 x2 r3 -1.0
 x2 r4 1.0
 x2 r5 1.0
 x3 obj -9
 x3 r0 1.0
 x3 r1 16.0
 x3 r3 -1.0
 x3 r5 1.0
 x4 obj 3
 x5 obj 9
 x6 obj 1
 x7 obj 8
 x8 obj 6
 x9 obj 7
 x10 obj 3
 x11 obj 7
 x12 obj 4
 x13 obj 8
 x14 obj 9
 x15 obj 3
 x16 obj -9
 x16 r1 16.0
 x16 r2 1.0
 x16 r5 1.0
 x17 obj 1
 x18 obj 6
 x19 obj 1
 x20 obj 9
 x21 obj 0
 x21 r4 2.0
RHS
 rhs obj 27
 rhs r0 1.0
 rhs r1 16.0
 rhs r2 1.0
 rhs r3 -1.0
 rhs r4 5.0
 rhs r5 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 UP b x21 2
ENDATA
