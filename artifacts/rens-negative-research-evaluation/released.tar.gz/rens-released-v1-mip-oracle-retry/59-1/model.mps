NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 G r4
 G r5
 G r6
 L r7
 L r8
 L r9
 L r10
 G r11
COLUMNS
 x0 obj -5
 x1 obj -6
 x2 obj -1
 x3 obj -6
 x4 obj -9
 x5 obj -9
 x6 obj 8
 x6 r0 256.0
 x6 r1 256.0
 x6 r3 -0.0625
 x6 r4 -0.0625
 x6 r6 -1.0
 x6 r7 256.0
 x6 r9 0.0625
 x6 r11 1.0
 x7 obj -3
 x8 obj -7
 x8 r11 1.0
 x9 obj -7
 x10 obj -2
 x11 obj -1
 x12 obj -2
 x13 obj 8
 x13 r1 256.0
 x13 r2 -0.0625
 x13 r4 -0.0625
 x13 r5 -0.0625
 x13 r7 256.0
 x13 r8 1.0
 x13 r11 1.0
 x14 obj -4
 x15 obj -4
 x16 obj -4
 x17 obj -3
 x18 obj -7
 x19 obj 8
 x19 r0 256.0
 x19 r2 -0.0625
 x19 r3 -0.0625
 x19 r5 -0.0625
 x19 r6 -1.0
 x19 r8 1.0
 x19 r9 0.0625
 x19 r10 1.0
 x19 r11 1.0
 x20 obj -6
 x21 obj -1
 x22 obj -9
 x23 obj 0
 x23 r10 2.0
RHS
 rhs obj 22
 rhs r0 256.0
 rhs r1 256.0
 rhs r2 -0.0625
 rhs r3 -0.0625
 rhs r4 -0.0625
 rhs r5 -0.0625
 rhs r6 -1.0
 rhs r7 256.0
 rhs r8 1.0
 rhs r9 0.0625
 rhs r10 5.0
 rhs r11 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 UP b x23 2
ENDATA
