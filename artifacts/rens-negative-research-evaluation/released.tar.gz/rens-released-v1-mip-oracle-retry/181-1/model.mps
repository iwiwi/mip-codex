NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 L r5
 G r6
 L r7
 G r8
COLUMNS
 x0 obj -1
 x1 obj -6
 x2 obj 5
 x2 r0 -16.0
 x2 r1 -1.0
 x2 r3 -16.0
 x2 r4 -256.0
 x2 r6 -1.0
 x2 r8 1.0
 x3 obj -7
 x4 obj -2
 x5 obj -5
 x6 obj 5
 x6 r1 -1.0
 x6 r2 -0.0625
 x6 r4 -256.0
 x6 r5 256.0
 x6 r8 1.0
 x7 obj -3
 x8 obj -4
 x9 obj -5
 x10 obj -6
 x11 obj -2
 x12 obj -2
 x13 obj -4
 x14 obj -8
 x15 obj -9
 x16 obj -7
 x17 obj -8
 x18 obj -1
 x19 obj -4
 x20 obj -7
 x21 obj -2
 x22 obj -3
 x23 obj -9
 x24 obj -3
 x25 obj -3
 x25 r8 1.0
 x26 obj -3
 x27 obj -7
 x28 obj 5
 x28 r0 -16.0
 x28 r2 -0.0625
 x28 r3 -16.0
 x28 r5 256.0
 x28 r6 -1.0
 x28 r7 1.0
 x28 r8 1.0
 x29 obj -2
 x30 obj 0
 x30 r7 2.0
RHS
 rhs obj -1
 rhs r0 -16.0
 rhs r1 -1.0
 rhs r2 -0.0625
 rhs r3 -16.0
 rhs r4 -256.0
 rhs r5 256.0
 rhs r6 -1.0
 rhs r7 5.0
 rhs r8 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 1
 LI b x29 0
 UI b x29 4
 UP b x30 2
ENDATA
