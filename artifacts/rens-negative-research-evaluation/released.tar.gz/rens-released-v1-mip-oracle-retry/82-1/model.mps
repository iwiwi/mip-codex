NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
COLUMNS
 x0 obj -1
 x1 obj 8
 x1 r0 -0.00390625
 x1 r2 0.00390625
 x1 r3 256.0
 x1 r5 16.0
 x1 r6 0.00390625
 x1 r7 1.0
 x2 obj -6
 x3 obj -5
 x4 obj -9
 x5 obj -1
 x6 obj -6
 x7 obj -5
 x8 obj 8
 x8 r0 -0.00390625
 x8 r1 -256.0
 x8 r3 256.0
 x8 r4 16.0
 x8 r6 0.00390625
 x9 obj -8
 x10 obj -6
 x11 obj -5
 x12 obj -3
 x13 obj 8
 x13 r1 -256.0
 x13 r2 0.00390625
 x13 r4 16.0
 x13 r5 16.0
 x14 obj -1
 x15 obj -3
 x16 obj -8
 x17 obj -1
 x18 obj 0
 x18 r7 2.0
RHS
 rhs obj -14
 rhs r0 -0.00390625
 rhs r1 -256.0
 rhs r2 0.00390625
 rhs r3 256.0
 rhs r4 16.0
 rhs r5 16.0
 rhs r6 0.00390625
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 UP b x18 2
ENDATA
