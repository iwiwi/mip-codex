NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 G r3
 L r4
 G r5
COLUMNS
 x0 obj -9
 x1 obj -5
 x2 obj -3
 x3 obj -1
 x4 obj 8
 x4 r0 -256.0
 x4 r2 16.0
 x4 r3 -16.0
 x4 r4 1.0
 x4 r5 1.0
 x5 obj -3
 x6 obj -9
 x7 obj -1
 x8 obj -9
 x9 obj -5
 x10 obj -3
 x11 obj -7
 x12 obj -2
 x12 r5 1.0
 x13 obj 8
 x13 r1 -16.0
 x13 r2 16.0
 x13 r5 1.0
 x14 obj -1
 x15 obj -1
 x16 obj -4
 x17 obj 8
 x17 r0 -256.0
 x17 r1 -16.0
 x17 r3 -16.0
 x17 r5 1.0
 x18 obj -2
 x19 obj 0
 x19 r4 2.0
RHS
 rhs obj 26
 rhs r0 -256.0
 rhs r1 -16.0
 rhs r2 16.0
 rhs r3 -16.0
 rhs r4 5.0
 rhs r5 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 2
 UP b x19 2
ENDATA
