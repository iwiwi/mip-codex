NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 G r3
 L r4
 G r5
COLUMNS
 x0 obj 1
 x1 obj 3
 x2 obj 7
 x3 obj 4
 x4 obj 8
 x5 obj -7
 x5 r0 -256.0
 x5 r1 -0.00390625
 x5 r3 -16.0
 x5 r5 1.0
 x6 obj -7
 x6 r1 -0.00390625
 x6 r2 0.00390625
 x6 r5 1.0
 x7 obj 7
 x8 obj 5
 x9 obj 9
 x9 r5 1.0
 x10 obj 1
 x11 obj 8
 x12 obj 2
 x13 obj 9
 x14 obj -7
 x14 r0 -256.0
 x14 r2 0.00390625
 x14 r3 -16.0
 x14 r4 1.0
 x14 r5 1.0
 x15 obj 8
 x16 obj 1
 x17 obj 5
 x18 obj 5
 x19 obj 4
 x20 obj 6
 x21 obj 5
 x22 obj 1
 x23 obj 4
 x24 obj 8
 x25 obj 0
 x25 r4 2.0
RHS
 rhs obj -10
 rhs r0 -256.0
 rhs r1 -0.00390625
 rhs r2 0.00390625
 rhs r3 -16.0
 rhs r4 5.0
 rhs r5 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 UP b x25 2
ENDATA
