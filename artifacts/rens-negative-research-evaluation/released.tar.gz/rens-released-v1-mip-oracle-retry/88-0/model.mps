NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
COLUMNS
 x0 obj 7
 x1 obj 1
 x2 obj 7
 x3 obj 6
 x4 obj 6
 x5 obj 4
 x6 obj 4
 x7 obj 1
 x8 obj 3
 x9 obj 9
 x10 obj 3
 x11 obj -9
 x11 r1 -256.0
 x11 r2 -1.0
 x12 obj -9
 x12 r0 -256.0
 x12 r2 -1.0
 x12 r3 1.0
 x13 obj -9
 x13 r0 -256.0
 x13 r1 -256.0
 x14 obj 1
 x15 obj 3
 x16 obj 9
 x17 obj 5
 x18 obj 2
 x19 obj 4
 x20 obj 7
 x21 obj 7
 x22 obj 4
 x23 obj 0
 x23 r3 2.0
RHS
 rhs obj 20
 rhs r0 -256.0
 rhs r1 -256.0
 rhs r2 -1.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 UP b x23 2
ENDATA
