NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 L r4
 G r5
 L r6
 G r7
 L r8
 G r9
COLUMNS
 x0 obj 1
 x1 obj 6
 x2 obj 2
 x3 obj 3
 x4 obj 7
 x5 obj 6
 x6 obj 9
 x7 obj 4
 x8 obj 3
 x9 obj 4
 x10 obj 7
 x11 obj -2
 x11 r0 -16.0
 x11 r1 -16.0
 x11 r3 -0.0625
 x11 r4 0.0625
 x11 r6 256.0
 x11 r7 -0.0625
 x11 r9 1.0
 x12 obj 6
 x12 r9 1.0
 x13 obj 2
 x14 obj -2
 x14 r0 -16.0
 x14 r2 -0.0625
 x14 r3 -0.0625
 x14 r5 -0.00390625
 x14 r6 256.0
 x14 r8 1.0
 x14 r9 1.0
 x15 obj 1
 x16 obj 6
 x17 obj -2
 x17 r1 -16.0
 x17 r2 -0.0625
 x17 r4 0.0625
 x17 r5 -0.00390625
 x17 r7 -0.0625
 x17 r9 1.0
 x18 obj 5
 x19 obj 0
 x19 r8 2.0
RHS
 rhs obj 10
 rhs r0 -16.0
 rhs r1 -16.0
 rhs r2 -0.0625
 rhs r3 -0.0625
 rhs r4 0.0625
 rhs r5 -0.00390625
 rhs r6 256.0
 rhs r7 -0.0625
 rhs r8 5.0
 rhs r9 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 4
 UP b x19 2
ENDATA
