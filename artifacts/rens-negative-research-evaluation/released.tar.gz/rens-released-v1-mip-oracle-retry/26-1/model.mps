NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 G r4
 L r5
COLUMNS
 x0 obj -3
 x1 obj -2
 x2 obj -9
 x3 obj -1
 x4 obj -7
 x5 obj -1
 x6 obj -2
 x7 obj 6
 x7 r1 0.0625
 x7 r2 16.0
 x7 r4 -256.0
 x8 obj -6
 x9 obj -1
 x10 obj -2
 x11 obj -1
 x12 obj 6
 x12 r0 16.0
 x12 r1 0.0625
 x12 r3 0.0625
 x12 r4 -256.0
 x13 obj -8
 x14 obj -1
 x15 obj -9
 x16 obj -2
 x17 obj -9
 x18 obj -1
 x19 obj -6
 x20 obj -6
 x21 obj -6
 x22 obj -7
 x23 obj 6
 x23 r0 16.0
 x23 r2 16.0
 x23 r3 0.0625
 x23 r5 1.0
 x24 obj -1
 x25 obj -2
 x26 obj -3
 x27 obj -6
 x28 obj -6
 x29 obj 0
 x29 r5 2.0
RHS
 rhs obj 25
 rhs r0 16.0
 rhs r1 0.0625
 rhs r2 16.0
 rhs r3 0.0625
 rhs r4 -256.0
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 1
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 4
 UP b x29 2
ENDATA
