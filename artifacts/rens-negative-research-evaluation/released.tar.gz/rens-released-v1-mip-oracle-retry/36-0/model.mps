NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 G r4
 G r5
 G r6
 L r7
COLUMNS
 x0 obj 2
 x1 obj 7
 x2 obj 1
 x3 obj 4
 x4 obj 2
 x5 obj 1
 x6 obj 1
 x7 obj -8
 x7 r0 -16.0
 x7 r2 -16.0
 x7 r3 0.0625
 x7 r5 -1.0
 x7 r6 -1.0
 x7 r7 1.0
 x8 obj 8
 x9 obj 4
 x10 obj 5
 x11 obj 8
 x12 obj 9
 x13 obj 5
 x14 obj 6
 x15 obj 5
 x16 obj 3
 x17 obj 6
 x18 obj 9
 x19 obj 8
 x20 obj 5
 x21 obj -8
 x21 r0 -16.0
 x21 r1 16.0
 x21 r3 0.0625
 x21 r4 -0.0625
 x21 r6 -1.0
 x22 obj 5
 x23 obj 1
 x24 obj 3
 x25 obj -8
 x25 r1 16.0
 x25 r2 -16.0
 x25 r4 -0.0625
 x25 r5 -1.0
 x26 obj 2
 x27 obj 6
 x28 obj 8
 x29 obj 0
 x29 r7 2.0
RHS
 rhs obj 13
 rhs r0 -16.0
 rhs r1 16.0
 rhs r2 -16.0
 rhs r3 0.0625
 rhs r4 -0.0625
 rhs r5 -1.0
 rhs r6 -1.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 1
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 2
 UP b x29 2
ENDATA
