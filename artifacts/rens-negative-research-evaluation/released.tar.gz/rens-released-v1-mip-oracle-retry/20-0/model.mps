NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 G r4
 L r5
 L r6
 L r7
COLUMNS
 x0 obj 7
 x1 obj 2
 x2 obj 6
 x3 obj 4
 x4 obj 3
 x5 obj 3
 x6 obj 6
 x7 obj 4
 x8 obj 5
 x9 obj 1
 x10 obj 6
 x11 obj 1
 x12 obj 1
 x13 obj 2
 x14 obj 4
 x15 obj 8
 x16 obj 7
 x17 obj 2
 x18 obj 8
 x19 obj 8
 x20 obj -1
 x20 r0 16.0
 x20 r1 256.0
 x20 r3 0.00390625
 x20 r4 -0.0625
 x20 r6 16.0
 x21 obj 9
 x22 obj 9
 x23 obj 5
 x24 obj 8
 x25 obj 7
 x26 obj 2
 x27 obj 4
 x28 obj -1
 x28 r0 16.0
 x28 r2 -0.00390625
 x28 r3 0.00390625
 x28 r5 256.0
 x28 r6 16.0
 x28 r7 1.0
 x29 obj -1
 x29 r1 256.0
 x29 r2 -0.00390625
 x29 r4 -0.0625
 x29 r5 256.0
 x30 obj 0
 x30 r7 2.0
RHS
 rhs obj -12
 rhs r0 16.0
 rhs r1 256.0
 rhs r2 -0.00390625
 rhs r3 0.00390625
 rhs r4 -0.0625
 rhs r5 256.0
 rhs r6 16.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 1
 LI b x29 0
 UI b x29 1
 UP b x30 2
ENDATA
