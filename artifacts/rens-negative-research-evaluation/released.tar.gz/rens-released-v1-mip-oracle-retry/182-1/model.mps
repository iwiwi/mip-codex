NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 G r4
 G r5
 L r6
 L r7
 G r8
 L r9
COLUMNS
 x0 obj -2
 x1 obj -8
 x2 obj -1
 x3 obj -4
 x4 obj -7
 x5 obj -7
 x6 obj -5
 x7 obj -7
 x8 obj -3
 x9 obj -6
 x10 obj -8
 x11 obj -5
 x12 obj -4
 x13 obj 4
 x13 r0 -1.0
 x13 r1 16.0
 x13 r3 16.0
 x13 r4 -16.0
 x13 r6 256.0
 x13 r7 1.0
 x14 obj -9
 x15 obj 4
 x15 r1 16.0
 x15 r2 16.0
 x15 r4 -16.0
 x15 r5 -16.0
 x15 r7 1.0
 x15 r8 -16.0
 x16 obj -1
 x17 obj -8
 x18 obj -9
 x19 obj -6
 x20 obj -2
 x21 obj -1
 x22 obj -8
 x23 obj 4
 x23 r0 -1.0
 x23 r2 16.0
 x23 r3 16.0
 x23 r5 -16.0
 x23 r6 256.0
 x23 r8 -16.0
 x23 r9 1.0
 x24 obj -9
 x25 obj -2
 x26 obj -8
 x27 obj -5
 x28 obj -4
 x29 obj -5
 x30 obj -6
 x31 obj -9
 x32 obj -9
 x33 obj -5
 x34 obj -5
 x35 obj 0
 x35 r9 2.0
RHS
 rhs obj 11
 rhs r0 -1.0
 rhs r1 16.0
 rhs r2 16.0
 rhs r3 16.0
 rhs r4 -16.0
 rhs r5 -16.0
 rhs r6 256.0
 rhs r7 1.0
 rhs r8 -16.0
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 1
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 3
 LI b x33 0
 UI b x33 2
 LI b x34 0
 UI b x34 2
 UP b x35 2
ENDATA
