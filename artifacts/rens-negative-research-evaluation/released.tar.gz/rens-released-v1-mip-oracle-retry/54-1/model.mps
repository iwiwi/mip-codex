NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 G r4
 L r5
 G r6
 G r7
 L r8
 L r9
 L r10
COLUMNS
 x0 obj -9
 x1 obj -1
 x2 obj -6
 x3 obj -8
 x4 obj -5
 x5 obj -2
 x6 obj 7
 x6 r1 16.0
 x6 r2 -256.0
 x6 r4 -16.0
 x6 r5 256.0
 x6 r7 -1.0
 x6 r8 0.0625
 x7 obj -6
 x8 obj -9
 x9 obj -7
 x10 obj -9
 x11 obj -6
 x12 obj -4
 x13 obj -5
 x14 obj -5
 x15 obj -6
 x16 obj -8
 x17 obj -3
 x18 obj -8
 x19 obj -8
 x20 obj -8
 x21 obj -1
 x22 obj -5
 x23 obj -6
 x24 obj -4
 x25 obj -1
 x26 obj -8
 x27 obj -9
 x28 obj -4
 x29 obj -6
 x30 obj 7
 x30 r0 256.0
 x30 r1 16.0
 x30 r3 256.0
 x30 r4 -16.0
 x30 r6 -1.0
 x30 r7 -1.0
 x30 r9 16.0
 x31 obj -2
 x32 obj -7
 x33 obj 7
 x33 r0 256.0
 x33 r2 -256.0
 x33 r3 256.0
 x33 r5 256.0
 x33 r6 -1.0
 x33 r8 0.0625
 x33 r9 16.0
 x33 r10 1.0
 x34 obj -2
 x35 obj 0
 x35 r10 2.0
RHS
 rhs obj -22
 rhs r0 256.0
 rhs r1 16.0
 rhs r2 -256.0
 rhs r3 256.0
 rhs r4 -16.0
 rhs r5 256.0
 rhs r6 -1.0
 rhs r7 -1.0
 rhs r8 0.0625
 rhs r9 16.0
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 1
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 3
 LI b x33 0
 UI b x33 1
 LI b x34 0
 UI b x34 3
 UP b x35 2
ENDATA
