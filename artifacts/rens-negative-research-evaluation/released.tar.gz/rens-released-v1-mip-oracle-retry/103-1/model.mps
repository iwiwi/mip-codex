NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 L r5
 G r6
 L r7
 G r8
COLUMNS
 x0 obj -9
 x1 obj -4
 x1 r8 1.0
 x2 obj -2
 x3 obj -7
 x4 obj -7
 x5 obj -6
 x6 obj -9
 x7 obj -1
 x8 obj -8
 x9 obj -7
 x10 obj -1
 x11 obj -9
 x12 obj -4
 x13 obj -1
 x14 obj -3
 x15 obj -6
 x16 obj -5
 x17 obj 5
 x17 r0 1.0
 x17 r1 256.0
 x17 r3 -256.0
 x17 r4 -16.0
 x17 r6 -0.0625
 x17 r8 1.0
 x18 obj -8
 x19 obj -1
 x20 obj -5
 x21 obj -1
 x22 obj -1
 x23 obj -9
 x24 obj -7
 x25 obj -6
 x26 obj -3
 x27 obj -4
 x28 obj 5
 x28 r0 1.0
 x28 r2 256.0
 x28 r3 -256.0
 x28 r5 0.00390625
 x28 r6 -0.0625
 x28 r7 1.0
 x28 r8 1.0
 x29 obj -9
 x30 obj -9
 x31 obj -4
 x32 obj -2
 x33 obj 5
 x33 r1 256.0
 x33 r2 256.0
 x33 r4 -16.0
 x33 r5 0.00390625
 x33 r8 1.0
 x34 obj -7
 x35 obj 0
 x35 r7 2.0
RHS
 rhs obj -22
 rhs r0 1.0
 rhs r1 256.0
 rhs r2 256.0
 rhs r3 -256.0
 rhs r4 -16.0
 rhs r5 0.00390625
 rhs r6 -0.0625
 rhs r7 5.0
 rhs r8 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 1
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 2
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 2
 LI b x33 0
 UI b x33 1
 LI b x34 0
 UI b x34 4
 UP b x35 2
ENDATA
