NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 L r4
 L r5
 G r6
 G r7
 G r8
 L r9
 G r10
COLUMNS
 x0 obj 1
 x0 r0 -1.0
 x0 r2 -16.0
 x0 r3 -0.00390625
 x0 r5 0.0625
 x0 r6 -256.0
 x0 r8 -1.0
 x0 r9 1.0
 x0 r10 1.0
 x1 obj -4
 x2 obj 1
 x2 r0 -1.0
 x2 r1 -0.00390625
 x2 r3 -0.00390625
 x2 r4 16.0
 x2 r6 -256.0
 x2 r7 -0.00390625
 x2 r10 1.0
 x3 obj -5
 x4 obj -4
 x4 r10 1.0
 x5 obj -7
 x6 obj -7
 x7 obj -7
 x8 obj -9
 x9 obj -8
 x10 obj -8
 x11 obj 1
 x11 r1 -0.00390625
 x11 r2 -16.0
 x11 r4 16.0
 x11 r5 0.0625
 x11 r7 -0.00390625
 x11 r8 -1.0
 x11 r10 1.0
 x12 obj -2
 x13 obj -8
 x14 obj -6
 x15 obj -6
 x16 obj -3
 x17 obj -2
 x18 obj -9
 x19 obj -8
 x20 obj -9
 x21 obj -7
 x22 obj 0
 x22 r9 2.0
RHS
 rhs obj -3
 rhs r0 -1.0
 rhs r1 -0.00390625
 rhs r2 -16.0
 rhs r3 -0.00390625
 rhs r4 16.0
 rhs r5 0.0625
 rhs r6 -256.0
 rhs r7 -0.00390625
 rhs r8 -1.0
 rhs r9 5.0
 rhs r10 1.5
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 UP b x22 2
ENDATA
