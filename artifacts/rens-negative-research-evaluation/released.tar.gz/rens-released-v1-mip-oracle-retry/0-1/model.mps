NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 L r4
 G r5
 L r6
 L r7
 L r8
 L r9
COLUMNS
 x0 obj -9
 x1 obj -4
 x2 obj -4
 x3 obj -9
 x4 obj -1
 x5 obj 5
 x5 r0 -16.0
 x5 r2 -0.0625
 x5 r3 -256.0
 x5 r5 -0.00390625
 x5 r6 0.0625
 x5 r8 0.00390625
 x5 r9 1.0
 x6 obj -6
 x7 obj 5
 x7 r1 0.00390625
 x7 r2 -0.0625
 x7 r4 1.0
 x7 r5 -0.00390625
 x7 r7 16.0
 x7 r8 0.00390625
 x8 obj -2
 x9 obj -9
 x10 obj -3
 x11 obj -6
 x12 obj -2
 x13 obj -8
 x14 obj -8
 x15 obj -3
 x16 obj -9
 x17 obj -2
 x18 obj -9
 x19 obj -7
 x20 obj -8
 x21 obj -1
 x22 obj 5
 x22 r0 -16.0
 x22 r1 0.00390625
 x22 r3 -256.0
 x22 r4 1.0
 x22 r6 0.0625
 x22 r7 16.0
 x23 obj -1
 x24 obj -6
 x25 obj -9
 x26 obj -7
 x27 obj -7
 x28 obj -8
 x29 obj 0
 x29 r9 2.0
RHS
 rhs obj 2
 rhs r0 -16.0
 rhs r1 0.00390625
 rhs r2 -0.0625
 rhs r3 -256.0
 rhs r4 1.0
 rhs r5 -0.00390625
 rhs r6 0.0625
 rhs r7 16.0
 rhs r8 0.00390625
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 3
 UP b x29 2
ENDATA
