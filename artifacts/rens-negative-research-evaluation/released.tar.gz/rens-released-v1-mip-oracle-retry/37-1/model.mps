NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 L r4
 L r5
 G r6
 L r7
 L r8
 G r9
COLUMNS
 x0 obj -5
 x1 obj -6
 x2 obj -9
 x3 obj 3
 x3 r0 256.0
 x3 r2 -0.0625
 x3 r3 -16.0
 x3 r5 1.0
 x3 r6 -0.00390625
 x3 r8 1.0
 x3 r9 1.0
 x4 obj -2
 x5 obj 3
 x5 r0 256.0
 x5 r1 1.0
 x5 r3 -16.0
 x5 r4 0.0625
 x5 r6 -0.00390625
 x5 r7 0.0625
 x5 r9 1.0
 x6 obj -3
 x7 obj -2
 x8 obj -8
 x8 r9 1.0
 x9 obj -6
 x10 obj -6
 x11 obj -6
 x12 obj -5
 x13 obj -3
 x14 obj -6
 x15 obj -4
 x16 obj -7
 x17 obj -8
 x18 obj -7
 x19 obj -4
 x20 obj -1
 x21 obj 3
 x21 r1 1.0
 x21 r2 -0.0625
 x21 r4 0.0625
 x21 r5 1.0
 x21 r7 0.0625
 x21 r9 1.0
 x22 obj -3
 x23 obj 0
 x23 r8 2.0
RHS
 rhs obj 22
 rhs r0 256.0
 rhs r1 1.0
 rhs r2 -0.0625
 rhs r3 -16.0
 rhs r4 0.0625
 rhs r5 1.0
 rhs r6 -0.00390625
 rhs r7 0.0625
 rhs r8 5.0
 rhs r9 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 2
 UP b x23 2
ENDATA
