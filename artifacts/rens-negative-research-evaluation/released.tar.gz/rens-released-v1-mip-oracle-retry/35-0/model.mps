NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 L r4
 G r5
 L r6
 G r7
 G r8
 G r9
 L r10
 G r11
COLUMNS
 x0 obj 4
 x1 obj 5
 x2 obj 1
 x3 obj 1
 x4 obj 6
 x5 obj 7
 x6 obj 7
 x7 obj 4
 x8 obj 4
 x9 obj 6
 x10 obj 3
 x11 obj 7
 x11 r11 1.0
 x12 obj 4
 x13 obj 2
 x14 obj 8
 x15 obj 8
 x16 obj 9
 x17 obj 5
 x18 obj 2
 x19 obj 3
 x20 obj -4
 x20 r1 -16.0
 x20 r2 -16.0
 x20 r4 0.00390625
 x20 r5 -0.0625
 x20 r7 -256.0
 x20 r8 -256.0
 x20 r11 1.0
 x21 obj 4
 x22 obj -4
 x22 r0 0.0625
 x22 r2 -16.0
 x22 r3 16.0
 x22 r5 -0.0625
 x22 r6 0.00390625
 x22 r8 -256.0
 x22 r9 -0.00390625
 x22 r10 1.0
 x22 r11 1.0
 x23 obj 8
 x24 obj 2
 x25 obj 8
 x26 obj 4
 x27 obj 2
 x28 obj 6
 x29 obj -4
 x29 r0 0.0625
 x29 r1 -16.0
 x29 r3 16.0
 x29 r4 0.00390625
 x29 r6 0.00390625
 x29 r7 -256.0
 x29 r9 -0.00390625
 x29 r11 1.0
 x30 obj 0
 x30 r10 2.0
RHS
 rhs obj -22
 rhs r0 0.0625
 rhs r1 -16.0
 rhs r2 -16.0
 rhs r3 16.0
 rhs r4 0.00390625
 rhs r5 -0.0625
 rhs r6 0.00390625
 rhs r7 -256.0
 rhs r8 -256.0
 rhs r9 -0.00390625
 rhs r10 5.0
 rhs r11 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 1
 UP b x30 2
ENDATA
