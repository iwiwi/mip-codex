NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
 G r4
COLUMNS
 x0 obj 4
 x1 obj -9
 x1 r0 -256.0
 x1 r1 -0.00390625
 x1 r4 1.0
 x2 obj 7
 x3 obj 7
 x4 obj 7
 x5 obj 1
 x6 obj 4
 x7 obj 4
 x8 obj 1
 x9 obj 6
 x10 obj 3
 x11 obj 3
 x11 r4 1.0
 x12 obj 9
 x13 obj 2
 x14 obj 9
 x15 obj 1
 x16 obj 6
 x17 obj 2
 x18 obj 5
 x19 obj 1
 x20 obj 8
 x21 obj 7
 x22 obj -9
 x22 r0 -256.0
 x22 r2 0.0625
 x22 r3 1.0
 x22 r4 1.0
 x23 obj -9
 x23 r1 -0.00390625
 x23 r2 0.0625
 x23 r4 1.0
 x24 obj 4
 x25 obj 8
 x26 obj 0
 x26 r3 2.0
RHS
 rhs obj 24
 rhs r0 -256.0
 rhs r1 -0.00390625
 rhs r2 0.0625
 rhs r3 5.0
 rhs r4 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 1
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 UP b x26 2
ENDATA
