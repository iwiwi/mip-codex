NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 G r4
COLUMNS
 x0 obj 3
 x1 obj 4
 x2 obj -7
 x2 r1 1.0
 x2 r2 0.00390625
 x2 r4 1.0
 x3 obj 1
 x4 obj 6
 x4 r4 1.0
 x5 obj 6
 x6 obj 4
 x7 obj 8
 x8 obj 8
 x9 obj 6
 x10 obj 4
 x11 obj 4
 x12 obj 2
 x13 obj -7
 x13 r0 1.0
 x13 r1 1.0
 x13 r4 1.0
 x14 obj 4
 x15 obj -7
 x15 r0 1.0
 x15 r2 0.00390625
 x15 r3 1.0
 x15 r4 1.0
 x16 obj 2
 x17 obj 8
 x18 obj 0
 x18 r3 2.0
RHS
 rhs obj -7
 rhs r0 1.0
 rhs r1 1.0
 rhs r2 0.00390625
 rhs r3 5.0
 rhs r4 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 UP b x18 2
ENDATA
