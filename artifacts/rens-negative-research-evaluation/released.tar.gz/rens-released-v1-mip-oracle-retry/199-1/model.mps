NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 G r4
 G r5
 G r6
 L r7
 G r8
COLUMNS
 x0 obj 3
 x0 r0 -256.0
 x0 r2 256.0
 x0 r3 -0.00390625
 x0 r5 -0.00390625
 x0 r6 -0.0625
 x0 r7 1.0
 x0 r8 1.0
 x1 obj 3
 x1 r1 1.0
 x1 r2 256.0
 x1 r4 -1.0
 x1 r5 -0.00390625
 x1 r8 1.0
 x2 obj -9
 x3 obj -3
 x4 obj -9
 x5 obj -8
 x6 obj -8
 x7 obj -7
 x8 obj -6
 x9 obj -5
 x10 obj -5
 x11 obj -4
 x12 obj -9
 x13 obj -2
 x14 obj -6
 x15 obj -2
 x16 obj -9
 x17 obj -3
 x18 obj -4
 x19 obj -7
 x20 obj -8
 x21 obj -4
 x22 obj -5
 x23 obj -1
 x24 obj -1
 x25 obj -3
 x26 obj -8
 x27 obj -3
 x28 obj -6
 x29 obj -2
 x29 r8 1.0
 x30 obj 3
 x30 r0 -256.0
 x30 r1 1.0
 x30 r3 -0.00390625
 x30 r4 -1.0
 x30 r6 -0.0625
 x30 r8 1.0
 x31 obj 0
 x31 r7 2.0
RHS
 rhs obj 29
 rhs r0 -256.0
 rhs r1 1.0
 rhs r2 256.0
 rhs r3 -0.00390625
 rhs r4 -1.0
 rhs r5 -0.00390625
 rhs r6 -0.0625
 rhs r7 5.0
 rhs r8 1.5
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 1
 UP b x31 2
ENDATA
