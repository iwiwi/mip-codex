NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj -3
 x1 obj -3
 x2 obj -1
 x3 obj -7
 x4 obj -2
 x5 obj -2
 x6 obj -7
 x7 obj -5
 x8 obj -1
 x9 obj -1
 x10 obj 8
 x10 r0 256.0
 x10 r2 16.0
 x10 r3 1.0
 x11 obj -3
 x12 obj -3
 x13 obj -3
 x14 obj 8
 x14 r1 16.0
 x14 r2 16.0
 x15 obj -7
 x16 obj -5
 x17 obj -1
 x18 obj -2
 x19 obj 8
 x19 r0 256.0
 x19 r1 16.0
 x20 obj -3
 x21 obj -3
 x22 obj -4
 x23 obj -9
 x24 obj -1
 x25 obj -9
 x26 obj -6
 x27 obj 0
 x27 r3 2.0
RHS
 rhs obj 25
 rhs r0 256.0
 rhs r1 16.0
 rhs r2 16.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 3
 UP b x27 2
ENDATA
