NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 G r4
 L r5
 G r6
 L r7
 G r8
 G r9
 L r10
COLUMNS
 x0 obj -2
 x1 obj -7
 x2 obj -1
 x3 obj -6
 x4 obj 7
 x4 r0 16.0
 x4 r2 256.0
 x4 r3 0.00390625
 x4 r5 0.0625
 x4 r6 -1.0
 x4 r8 -0.00390625
 x4 r9 -0.0625
 x4 r10 1.0
 x5 obj -3
 x6 obj 7
 x6 r1 0.00390625
 x6 r2 256.0
 x6 r4 -1.0
 x6 r5 0.0625
 x6 r7 256.0
 x6 r8 -0.00390625
 x7 obj -5
 x8 obj -6
 x9 obj -4
 x10 obj -4
 x11 obj -4
 x12 obj -9
 x13 obj -5
 x14 obj -7
 x15 obj -1
 x16 obj 7
 x16 r0 16.0
 x16 r1 0.00390625
 x16 r3 0.00390625
 x16 r4 -1.0
 x16 r6 -1.0
 x16 r7 256.0
 x16 r9 -0.0625
 x17 obj -4
 x18 obj -5
 x19 obj 0
 x19 r10 2.0
RHS
 rhs obj 17
 rhs r0 16.0
 rhs r1 0.00390625
 rhs r2 256.0
 rhs r3 0.00390625
 rhs r4 -1.0
 rhs r5 0.0625
 rhs r6 -1.0
 rhs r7 256.0
 rhs r8 -0.00390625
 rhs r9 -0.0625
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 UP b x19 2
ENDATA
