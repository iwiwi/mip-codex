NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj -5
 x1 obj -4
 x2 obj -9
 x3 obj 7
 x3 r1 16.0
 x3 r2 1.0
 x4 obj -5
 x5 obj -1
 x6 obj -7
 x7 obj -9
 x8 obj -5
 x9 obj -7
 x10 obj -3
 x11 obj -5
 x12 obj -9
 x13 obj 7
 x13 r0 0.0625
 x13 r2 1.0
 x13 r3 1.0
 x14 obj -1
 x15 obj -2
 x16 obj -2
 x17 obj -7
 x18 obj -5
 x19 obj -6
 x20 obj -6
 x21 obj -3
 x22 obj -1
 x23 obj 7
 x23 r0 0.0625
 x23 r1 16.0
 x24 obj -1
 x25 obj -9
 x26 obj -7
 x27 obj -5
 x28 obj -7
 x29 obj 0
 x29 r3 2.0
RHS
 rhs obj -15
 rhs r0 0.0625
 rhs r1 16.0
 rhs r2 1.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 1
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 4
 UP b x29 2
ENDATA
