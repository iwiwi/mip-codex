NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj -1
 x1 obj -7
 x2 obj -7
 x3 obj -7
 x4 obj -6
 x5 obj 7
 x5 r0 -0.0625
 x5 r2 16.0
 x5 r3 1.0
 x6 obj -6
 x7 obj -1
 x8 obj -8
 x9 obj 7
 x9 r1 256.0
 x9 r2 16.0
 x10 obj -8
 x11 obj -9
 x12 obj -8
 x13 obj -6
 x14 obj -8
 x15 obj -8
 x16 obj -4
 x17 obj -8
 x18 obj -1
 x19 obj -4
 x20 obj -1
 x21 obj -8
 x22 obj -5
 x23 obj -4
 x24 obj -7
 x25 obj 7
 x25 r0 -0.0625
 x25 r1 256.0
 x26 obj -7
 x27 obj -3
 x28 obj -1
 x29 obj -5
 x30 obj 0
 x30 r3 2.0
RHS
 rhs obj 28
 rhs r0 -0.0625
 rhs r1 256.0
 rhs r2 16.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 1
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 2
 UP b x30 2
ENDATA
