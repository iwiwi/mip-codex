NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
 L r4
 L r5
 G r6
 G r7
 L r8
 L r9
 G r10
COLUMNS
 x0 obj 2
 x1 obj -7
 x1 r1 -256.0
 x1 r2 16.0
 x1 r4 0.00390625
 x1 r5 0.00390625
 x1 r7 -0.0625
 x1 r8 1.0
 x1 r10 1.0
 x2 obj 2
 x3 obj 4
 x4 obj 7
 x5 obj -7
 x5 r0 -16.0
 x5 r2 16.0
 x5 r3 0.0625
 x5 r5 0.00390625
 x5 r6 -0.0625
 x5 r8 1.0
 x5 r9 1.0
 x5 r10 1.0
 x6 obj 4
 x7 obj 4
 x8 obj 8
 x9 obj -7
 x9 r0 -16.0
 x9 r1 -256.0
 x9 r3 0.0625
 x9 r4 0.00390625
 x9 r6 -0.0625
 x9 r7 -0.0625
 x9 r10 1.0
 x10 obj 5
 x11 obj 6
 x12 obj 4
 x13 obj 7
 x13 r10 1.0
 x14 obj 4
 x15 obj 4
 x16 obj 5
 x17 obj 8
 x18 obj 0
 x18 r9 2.0
RHS
 rhs obj 9
 rhs r0 -16.0
 rhs r1 -256.0
 rhs r2 16.0
 rhs r3 0.0625
 rhs r4 0.00390625
 rhs r5 0.00390625
 rhs r6 -0.0625
 rhs r7 -0.0625
 rhs r8 1.0
 rhs r9 5.0
 rhs r10 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 UP b x18 2
ENDATA
