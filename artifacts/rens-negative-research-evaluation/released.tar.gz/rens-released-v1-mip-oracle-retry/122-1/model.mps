NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
COLUMNS
 x0 obj -6
 x1 obj -5
 x2 obj -4
 x3 obj -2
 x4 obj -2
 x5 obj -1
 x6 obj -3
 x7 obj -5
 x8 obj -6
 x9 obj -1
 x10 obj -1
 x11 obj -7
 x12 obj -6
 x13 obj -8
 x14 obj -9
 x15 obj -1
 x16 obj -9
 x17 obj -5
 x18 obj -4
 x19 obj -5
 x20 obj -3
 x21 obj -4
 x22 obj -5
 x23 obj 3
 x23 r1 -256.0
 x23 r2 16.0
 x24 obj 3
 x24 r0 -16.0
 x24 r2 16.0
 x24 r3 1.0
 x25 obj -8
 x26 obj -4
 x27 obj -9
 x28 obj -9
 x29 obj 3
 x29 r0 -16.0
 x29 r1 -256.0
 x30 obj -4
 x31 obj -8
 x32 obj -1
 x33 obj -3
 x34 obj 0
 x34 r3 2.0
RHS
 rhs obj 25
 rhs r0 -16.0
 rhs r1 -256.0
 rhs r2 16.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 1
 LI b x24 0
 UI b x24 1
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 1
 LI b x30 0
 UI b x30 2
 LI b x31 0
 UI b x31 2
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 2
 UP b x34 2
ENDATA
