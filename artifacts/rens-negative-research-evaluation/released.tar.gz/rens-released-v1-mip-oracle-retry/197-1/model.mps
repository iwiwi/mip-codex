NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 G r4
 G r5
 L r6
 G r7
 G r8
 L r9
 L r10
 G r11
COLUMNS
 x0 obj -9
 x1 obj -2
 x2 obj -3
 x3 obj -3
 x4 obj 5
 x4 r1 16.0
 x4 r2 -0.00390625
 x4 r4 -16.0
 x4 r5 -16.0
 x4 r7 -1.0
 x4 r8 -0.0625
 x4 r11 1.0
 x5 obj -6
 x6 obj -9
 x7 obj -8
 x8 obj -5
 x9 obj -9
 x10 obj -5
 x11 obj -4
 x12 obj -4
 x13 obj -1
 x14 obj -9
 x15 obj -8
 x16 obj -2
 x17 obj -1
 x17 r11 1.0
 x18 obj -2
 x19 obj 5
 x19 r0 0.00390625
 x19 r2 -0.00390625
 x19 r3 -16.0
 x19 r5 -16.0
 x19 r6 256.0
 x19 r8 -0.0625
 x19 r9 16.0
 x19 r10 1.0
 x19 r11 1.0
 x20 obj -7
 x21 obj -1
 x22 obj -5
 x23 obj 5
 x23 r0 0.00390625
 x23 r1 16.0
 x23 r3 -16.0
 x23 r4 -16.0
 x23 r6 256.0
 x23 r7 -1.0
 x23 r9 16.0
 x23 r11 1.0
 x24 obj -1
 x25 obj 0
 x25 r10 2.0
RHS
 rhs obj 4
 rhs r0 0.00390625
 rhs r1 16.0
 rhs r2 -0.00390625
 rhs r3 -16.0
 rhs r4 -16.0
 rhs r5 -16.0
 rhs r6 256.0
 rhs r7 -1.0
 rhs r8 -0.0625
 rhs r9 16.0
 rhs r10 5.0
 rhs r11 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 1
 LI b x24 0
 UI b x24 2
 UP b x25 2
ENDATA
