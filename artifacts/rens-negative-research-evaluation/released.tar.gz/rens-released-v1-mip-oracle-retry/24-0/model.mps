NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 G r4
 L r5
COLUMNS
 x0 obj 7
 x1 obj 1
 x2 obj 4
 x3 obj -6
 x3 r1 -16.0
 x3 r2 -1.0
 x3 r4 -0.00390625
 x4 obj 2
 x5 obj 2
 x6 obj -6
 x6 r0 256.0
 x6 r1 -16.0
 x6 r3 1.0
 x6 r4 -0.00390625
 x7 obj 5
 x8 obj 1
 x9 obj 9
 x10 obj 2
 x11 obj 6
 x12 obj 2
 x13 obj -6
 x13 r0 256.0
 x13 r2 -1.0
 x13 r3 1.0
 x13 r5 1.0
 x14 obj 1
 x15 obj 4
 x16 obj 9
 x17 obj 7
 x18 obj 5
 x19 obj 6
 x20 obj 3
 x21 obj 9
 x22 obj 0
 x22 r5 2.0
RHS
 rhs obj -20
 rhs r0 256.0
 rhs r1 -16.0
 rhs r2 -1.0
 rhs r3 1.0
 rhs r4 -0.00390625
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 UP b x22 2
ENDATA
