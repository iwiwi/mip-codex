NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 G r4
 G r5
 L r6
COLUMNS
 x0 obj -1
 x1 obj -8
 x2 obj -8
 x3 obj 4
 x3 r0 0.00390625
 x3 r2 -0.0625
 x3 r3 -16.0
 x3 r5 -16.0
 x3 r6 1.0
 x4 obj 4
 x4 r1 0.0625
 x4 r2 -0.0625
 x4 r4 -0.0625
 x4 r5 -16.0
 x5 obj -5
 x6 obj -2
 x7 obj -3
 x8 obj -3
 x9 obj -8
 x10 obj -2
 x11 obj 4
 x11 r0 0.00390625
 x11 r1 0.0625
 x11 r3 -16.0
 x11 r4 -0.0625
 x12 obj -7
 x13 obj -8
 x14 obj -9
 x15 obj -1
 x16 obj -1
 x17 obj -2
 x18 obj 0
 x18 r6 2.0
RHS
 rhs obj 28
 rhs r0 0.00390625
 rhs r1 0.0625
 rhs r2 -0.0625
 rhs r3 -16.0
 rhs r4 -0.0625
 rhs r5 -16.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 UP b x18 2
ENDATA
