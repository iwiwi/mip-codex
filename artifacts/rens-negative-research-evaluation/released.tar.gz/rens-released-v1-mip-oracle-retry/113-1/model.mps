NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 G r5
 L r6
 L r7
 L r8
 L r9
 G r10
COLUMNS
 x0 obj -4
 x0 r10 1.0
 x1 obj -9
 x2 obj -2
 x3 obj -8
 x4 obj -6
 x5 obj -6
 x6 obj -3
 x7 obj 5
 x7 r0 16.0
 x7 r2 256.0
 x7 r3 1.0
 x7 r5 -0.0625
 x7 r6 16.0
 x7 r8 1.0
 x7 r9 1.0
 x7 r10 1.0
 x8 obj -3
 x9 obj -6
 x10 obj -9
 x11 obj -3
 x12 obj -4
 x13 obj -8
 x14 obj -1
 x15 obj -3
 x16 obj 5
 x16 r0 16.0
 x16 r1 0.00390625
 x16 r3 1.0
 x16 r4 256.0
 x16 r6 16.0
 x16 r7 16.0
 x16 r10 1.0
 x17 obj -6
 x18 obj -2
 x19 obj -9
 x20 obj -8
 x21 obj -8
 x22 obj 5
 x22 r1 0.00390625
 x22 r2 256.0
 x22 r4 256.0
 x22 r5 -0.0625
 x22 r7 16.0
 x22 r8 1.0
 x22 r10 1.0
 x23 obj -7
 x24 obj -8
 x25 obj -9
 x26 obj -7
 x27 obj -7
 x28 obj -3
 x29 obj -3
 x30 obj -5
 x31 obj -9
 x32 obj -8
 x33 obj 0
 x33 r9 2.0
RHS
 rhs obj 26
 rhs r0 16.0
 rhs r1 0.00390625
 rhs r2 256.0
 rhs r3 1.0
 rhs r4 256.0
 rhs r5 -0.0625
 rhs r6 16.0
 rhs r7 16.0
 rhs r8 1.0
 rhs r9 5.0
 rhs r10 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 4
 LI b x32 0
 UI b x32 3
 UP b x33 2
ENDATA
