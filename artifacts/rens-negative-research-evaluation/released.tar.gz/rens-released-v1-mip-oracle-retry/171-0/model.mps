NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 G r4
 L r5
 G r6
 L r7
 L r8
 G r9
COLUMNS
 x0 obj 1
 x1 obj 7
 x2 obj 1
 x3 obj 7
 x4 obj -4
 x4 r0 0.00390625
 x4 r1 16.0
 x4 r3 1.0
 x4 r4 -256.0
 x4 r6 -16.0
 x4 r7 16.0
 x4 r9 1.0
 x5 obj 3
 x6 obj -4
 x6 r0 0.00390625
 x6 r2 -1.0
 x6 r3 1.0
 x6 r5 256.0
 x6 r6 -16.0
 x6 r8 1.0
 x6 r9 1.0
 x7 obj 4
 x8 obj 1
 x9 obj 7
 x10 obj 1
 x11 obj 9
 x12 obj 3
 x13 obj 9
 x14 obj 6
 x15 obj 4
 x16 obj 9
 x16 r9 1.0
 x17 obj -4
 x17 r1 16.0
 x17 r2 -1.0
 x17 r4 -256.0
 x17 r5 256.0
 x17 r7 16.0
 x17 r9 1.0
 x18 obj 0
 x18 r8 2.0
RHS
 rhs obj -8
 rhs r0 0.00390625
 rhs r1 16.0
 rhs r2 -1.0
 rhs r3 1.0
 rhs r4 -256.0
 rhs r5 256.0
 rhs r6 -16.0
 rhs r7 16.0
 rhs r8 5.0
 rhs r9 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 1
 UP b x18 2
ENDATA
