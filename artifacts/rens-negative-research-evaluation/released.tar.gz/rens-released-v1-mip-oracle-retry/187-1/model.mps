NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
 L r4
 L r5
 G r6
 L r7
 G r8
 L r9
 G r10
COLUMNS
 x0 obj 1
 x0 r1 -256.0
 x0 r2 0.0625
 x0 r4 0.00390625
 x0 r5 0.00390625
 x0 r7 16.0
 x0 r8 -0.00390625
 x0 r10 1.0
 x1 obj -1
 x2 obj -8
 x3 obj -9
 x3 r10 1.0
 x4 obj -1
 x5 obj -2
 x6 obj -1
 x7 obj -6
 x8 obj -6
 x9 obj -5
 x10 obj -7
 x11 obj -9
 x12 obj -3
 x13 obj -8
 x14 obj -1
 x15 obj -3
 x16 obj -5
 x17 obj -1
 x18 obj -7
 x19 obj -5
 x20 obj -9
 x21 obj 1
 x21 r0 -16.0
 x21 r2 0.0625
 x21 r3 16.0
 x21 r5 0.00390625
 x21 r6 -256.0
 x21 r8 -0.00390625
 x21 r9 1.0
 x21 r10 1.0
 x22 obj -3
 x23 obj 1
 x23 r0 -16.0
 x23 r1 -256.0
 x23 r3 16.0
 x23 r4 0.00390625
 x23 r6 -256.0
 x23 r7 16.0
 x23 r10 1.0
 x24 obj -1
 x25 obj -6
 x26 obj -2
 x27 obj -3
 x28 obj -9
 x29 obj -3
 x30 obj -6
 x31 obj -1
 x32 obj -9
 x33 obj 0
 x33 r9 2.0
RHS
 rhs obj -12
 rhs r0 -16.0
 rhs r1 -256.0
 rhs r2 0.0625
 rhs r3 16.0
 rhs r4 0.00390625
 rhs r5 0.00390625
 rhs r6 -256.0
 rhs r7 16.0
 rhs r8 -0.00390625
 rhs r9 5.0
 rhs r10 1.5
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 1
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 4
 LI b x32 0
 UI b x32 2
 UP b x33 2
ENDATA
