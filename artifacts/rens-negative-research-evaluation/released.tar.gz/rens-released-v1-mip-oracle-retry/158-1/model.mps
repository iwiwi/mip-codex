NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj -4
 x1 obj -4
 x2 obj -2
 x3 obj -7
 x4 obj -9
 x5 obj -2
 x6 obj -2
 x7 obj -4
 x8 obj -2
 x9 obj 2
 x9 r1 256.0
 x9 r2 16.0
 x10 obj -4
 x11 obj 2
 x11 r0 -16.0
 x11 r1 256.0
 x12 obj -3
 x13 obj -8
 x14 obj -2
 x15 obj -6
 x16 obj -3
 x17 obj 2
 x17 r0 -16.0
 x17 r2 16.0
 x17 r3 1.0
 x18 obj -8
 x19 obj 0
 x19 r3 2.0
RHS
 rhs obj 14
 rhs r0 -16.0
 rhs r1 256.0
 rhs r2 16.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 2
 UP b x19 2
ENDATA
