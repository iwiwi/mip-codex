NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 L r4
 G r5
 L r6
 L r7
 L r8
COLUMNS
 x0 obj -4
 x1 obj -9
 x2 obj -7
 x3 obj 5
 x3 r1 256.0
 x3 r2 0.0625
 x3 r4 1.0
 x3 r5 -1.0
 x3 r7 1.0
 x4 obj -6
 x5 obj -5
 x6 obj -6
 x7 obj -7
 x8 obj -8
 x9 obj -6
 x10 obj -2
 x11 obj -9
 x12 obj -2
 x13 obj -6
 x14 obj 5
 x14 r0 1.0
 x14 r2 0.0625
 x14 r3 -256.0
 x14 r5 -1.0
 x14 r6 256.0
 x14 r8 1.0
 x15 obj -5
 x16 obj -5
 x17 obj 5
 x17 r0 1.0
 x17 r1 256.0
 x17 r3 -256.0
 x17 r4 1.0
 x17 r6 256.0
 x17 r7 1.0
 x18 obj -6
 x19 obj -8
 x20 obj -5
 x21 obj -4
 x22 obj -1
 x23 obj -4
 x24 obj -9
 x25 obj 0
 x25 r8 2.0
RHS
 rhs obj -22
 rhs r0 1.0
 rhs r1 256.0
 rhs r2 0.0625
 rhs r3 -256.0
 rhs r4 1.0
 rhs r5 -1.0
 rhs r6 256.0
 rhs r7 1.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 3
 UP b x25 2
ENDATA
