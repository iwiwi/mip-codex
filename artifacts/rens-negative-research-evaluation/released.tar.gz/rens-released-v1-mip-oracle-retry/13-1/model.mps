NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 G r4
 G r5
 G r6
 G r7
 L r8
 G r9
COLUMNS
 x0 obj 5
 x0 r0 -16.0
 x0 r1 1.0
 x0 r3 16.0
 x0 r4 -16.0
 x0 r6 -0.0625
 x0 r7 -256.0
 x0 r9 1.0
 x1 obj -2
 x2 obj -5
 x3 obj -7
 x4 obj -7
 x5 obj -2
 x6 obj -3
 x7 obj -4
 x8 obj -2
 x9 obj -4
 x10 obj -9
 x11 obj -4
 x12 obj -4
 x13 obj -1
 x14 obj -9
 x15 obj -7
 x16 obj -6
 x17 obj -6
 x18 obj 5
 x18 r0 -16.0
 x18 r2 -1.0
 x18 r3 16.0
 x18 r5 -0.0625
 x18 r6 -0.0625
 x18 r8 1.0
 x18 r9 1.0
 x19 obj -9
 x20 obj -6
 x21 obj -5
 x22 obj 5
 x22 r1 1.0
 x22 r2 -1.0
 x22 r4 -16.0
 x22 r5 -0.0625
 x22 r7 -256.0
 x22 r9 1.0
 x23 obj -2
 x23 r9 1.0
 x24 obj 0
 x24 r8 2.0
RHS
 rhs obj 11
 rhs r0 -16.0
 rhs r1 1.0
 rhs r2 -1.0
 rhs r3 16.0
 rhs r4 -16.0
 rhs r5 -0.0625
 rhs r6 -0.0625
 rhs r7 -256.0
 rhs r8 5.0
 rhs r9 1.5
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 2
 UP b x24 2
ENDATA
