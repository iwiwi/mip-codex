NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
COLUMNS
 x0 obj 7
 x1 obj 7
 x2 obj 7
 x3 obj -3
 x3 r1 1.0
 x3 r2 -256.0
 x4 obj 5
 x5 obj 2
 x6 obj 7
 x7 obj 8
 x8 obj 8
 x9 obj 7
 x10 obj 1
 x11 obj 8
 x12 obj 8
 x13 obj 8
 x14 obj -3
 x14 r0 0.00390625
 x14 r1 1.0
 x15 obj 3
 x16 obj 2
 x17 obj 4
 x18 obj 1
 x19 obj 6
 x20 obj 4
 x21 obj -3
 x21 r0 0.00390625
 x21 r2 -256.0
 x21 r3 1.0
 x22 obj 8
 x23 obj 4
 x24 obj 0
 x24 r3 2.0
RHS
 rhs obj -27
 rhs r0 0.00390625
 rhs r1 1.0
 rhs r2 -256.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 UP b x24 2
ENDATA
