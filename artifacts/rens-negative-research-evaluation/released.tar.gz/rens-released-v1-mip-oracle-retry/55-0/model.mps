NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
 L r4
 L r5
 G r6
COLUMNS
 x0 obj 9
 x1 obj 5
 x2 obj 3
 x2 r6 1.0
 x3 obj 2
 x4 obj 1
 x5 obj -2
 x5 r1 -16.0
 x5 r2 -16.0
 x5 r4 0.00390625
 x5 r6 1.0
 x6 obj 7
 x7 obj 9
 x8 obj 5
 x9 obj 3
 x10 obj 8
 x11 obj 4
 x12 obj 1
 x13 obj 2
 x14 obj 4
 x15 obj 9
 x16 obj 7
 x17 obj 5
 x18 obj 9
 x19 obj 3
 x20 obj 3
 x21 obj 2
 x22 obj -2
 x22 r0 -0.0625
 x22 r2 -16.0
 x22 r3 16.0
 x22 r5 1.0
 x22 r6 1.0
 x23 obj 7
 x24 obj 4
 x25 obj 6
 x26 obj 9
 x27 obj -2
 x27 r0 -0.0625
 x27 r1 -16.0
 x27 r3 16.0
 x27 r4 0.00390625
 x27 r6 1.0
 x28 obj 3
 x29 obj 1
 x30 obj 6
 x31 obj 3
 x32 obj 9
 x33 obj 8
 x34 obj 4
 x35 obj 0
 x35 r5 2.0
RHS
 rhs obj 14
 rhs r0 -0.0625
 rhs r1 -16.0
 rhs r2 -16.0
 rhs r3 16.0
 rhs r4 0.00390625
 rhs r5 5.0
 rhs r6 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 1
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 2
 LI b x32 0
 UI b x32 3
 LI b x33 0
 UI b x33 3
 LI b x34 0
 UI b x34 2
 UP b x35 2
ENDATA
