NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 L r4
 L r5
 L r6
 G r7
 L r8
 L r9
 L r10
COLUMNS
 x0 obj 7
 x1 obj 6
 x2 obj 1
 x3 obj 7
 x4 obj 4
 x5 obj -1
 x5 r0 -256.0
 x5 r2 -0.00390625
 x5 r3 -16.0
 x5 r5 1.0
 x5 r6 256.0
 x5 r8 256.0
 x5 r9 16.0
 x5 r10 1.0
 x6 obj 2
 x7 obj 5
 x8 obj 5
 x9 obj 8
 x10 obj -1
 x10 r0 -256.0
 x10 r1 256.0
 x10 r3 -16.0
 x10 r4 16.0
 x10 r6 256.0
 x10 r7 -0.0625
 x10 r9 16.0
 x11 obj 6
 x12 obj 8
 x13 obj 1
 x14 obj 5
 x15 obj 4
 x16 obj -1
 x16 r1 256.0
 x16 r2 -0.00390625
 x16 r4 16.0
 x16 r5 1.0
 x16 r7 -0.0625
 x16 r8 256.0
 x17 obj 3
 x18 obj 4
 x19 obj 0
 x19 r10 2.0
RHS
 rhs obj -5
 rhs r0 -256.0
 rhs r1 256.0
 rhs r2 -0.00390625
 rhs r3 -16.0
 rhs r4 16.0
 rhs r5 1.0
 rhs r6 256.0
 rhs r7 -0.0625
 rhs r8 256.0
 rhs r9 16.0
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 UP b x19 2
ENDATA
