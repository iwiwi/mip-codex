NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 L r4
 L r5
 G r6
COLUMNS
 x0 obj -9
 x1 obj -8
 x2 obj 1
 x2 r0 0.0625
 x2 r1 16.0
 x2 r3 -256.0
 x2 r4 16.0
 x2 r6 1.0
 x3 obj 1
 x3 r0 0.0625
 x3 r2 -1.0
 x3 r3 -256.0
 x3 r5 1.0
 x3 r6 1.0
 x4 obj -3
 x5 obj -9
 x6 obj -1
 x6 r6 1.0
 x7 obj 1
 x7 r1 16.0
 x7 r2 -1.0
 x7 r4 16.0
 x7 r6 1.0
 x8 obj -2
 x9 obj -2
 x10 obj -5
 x11 obj -5
 x12 obj -9
 x13 obj -8
 x14 obj -7
 x15 obj -2
 x16 obj -7
 x17 obj -9
 x18 obj -2
 x19 obj -5
 x20 obj -1
 x21 obj -6
 x22 obj -2
 x23 obj -7
 x24 obj -8
 x25 obj -4
 x26 obj -6
 x27 obj -3
 x28 obj -7
 x29 obj -2
 x30 obj -6
 x31 obj -2
 x32 obj 0
 x32 r5 2.0
RHS
 rhs obj -20
 rhs r0 0.0625
 rhs r1 16.0
 rhs r2 -1.0
 rhs r3 -256.0
 rhs r4 16.0
 rhs r5 5.0
 rhs r6 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 2
 UP b x32 2
ENDATA
