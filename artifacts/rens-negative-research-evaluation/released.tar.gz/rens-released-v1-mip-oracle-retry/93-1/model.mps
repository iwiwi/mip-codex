NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 L r4
 G r5
 G r6
 L r7
 G r8
 L r9
 G r10
COLUMNS
 x0 obj -2
 x1 obj -2
 x2 obj -1
 x3 obj -1
 x4 obj -8
 x5 obj -7
 x6 obj -5
 x7 obj -4
 x8 obj -3
 x9 obj -2
 x10 obj 7
 x10 r0 -0.0625
 x10 r1 256.0
 x10 r3 -0.00390625
 x10 r4 0.00390625
 x10 r6 -0.0625
 x10 r7 256.0
 x10 r10 1.0
 x11 obj 7
 x11 r1 256.0
 x11 r2 0.0625
 x11 r4 0.00390625
 x11 r5 -1.0
 x11 r7 256.0
 x11 r8 -0.00390625
 x11 r10 1.0
 x12 obj -1
 x13 obj -3
 x14 obj -3
 x15 obj -2
 x16 obj -9
 x17 obj -2
 x18 obj -3
 x19 obj -3
 x20 obj -5
 x21 obj -9
 x22 obj -5
 x23 obj -1
 x24 obj 7
 x24 r0 -0.0625
 x24 r2 0.0625
 x24 r3 -0.00390625
 x24 r5 -1.0
 x24 r6 -0.0625
 x24 r8 -0.00390625
 x24 r9 1.0
 x24 r10 1.0
 x25 obj -3
 x26 obj -2
 x27 obj -6
 x28 obj -8
 x29 obj -9
 x30 obj -4
 x31 obj -9
 x31 r10 1.0
 x32 obj 0
 x32 r9 2.0
RHS
 rhs obj 17
 rhs r0 -0.0625
 rhs r1 256.0
 rhs r2 0.0625
 rhs r3 -0.00390625
 rhs r4 0.00390625
 rhs r5 -1.0
 rhs r6 -0.0625
 rhs r7 256.0
 rhs r8 -0.00390625
 rhs r9 5.0
 rhs r10 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 1
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 4
 UP b x32 2
ENDATA
