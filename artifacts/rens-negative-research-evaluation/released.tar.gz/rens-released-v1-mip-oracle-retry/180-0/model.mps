NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 L r5
 L r6
COLUMNS
 x0 obj 4
 x1 obj 4
 x2 obj 6
 x3 obj 4
 x4 obj 3
 x5 obj 4
 x6 obj 2
 x7 obj 2
 x8 obj 7
 x9 obj 3
 x10 obj 5
 x11 obj 3
 x12 obj 4
 x13 obj 6
 x14 obj 5
 x15 obj 5
 x16 obj -1
 x16 r0 -1.0
 x16 r2 -16.0
 x16 r3 -1.0
 x16 r5 16.0
 x16 r6 1.0
 x17 obj 3
 x18 obj 5
 x19 obj 5
 x20 obj -1
 x20 r1 -0.0625
 x20 r2 -16.0
 x20 r4 -0.00390625
 x20 r5 16.0
 x21 obj 4
 x22 obj 5
 x23 obj 4
 x24 obj 3
 x25 obj 4
 x26 obj 7
 x27 obj -1
 x27 r0 -1.0
 x27 r1 -0.0625
 x27 r3 -1.0
 x27 r4 -0.00390625
 x28 obj 9
 x29 obj 7
 x30 obj 1
 x31 obj 1
 x32 obj 0
 x32 r6 2.0
RHS
 rhs obj -27
 rhs r0 -1.0
 rhs r1 -0.0625
 rhs r2 -16.0
 rhs r3 -1.0
 rhs r4 -0.00390625
 rhs r5 16.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 1
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 2
 LI b x31 0
 UI b x31 3
 UP b x32 2
ENDATA
