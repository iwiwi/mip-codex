NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 G r4
 L r5
 L r6
 G r7
 L r8
 L r9
COLUMNS
 x0 obj 4
 x1 obj 6
 x2 obj 4
 x3 obj 5
 x4 obj 6
 x5 obj 8
 x6 obj 8
 x7 obj 4
 x8 obj 5
 x9 obj -6
 x9 r0 0.00390625
 x9 r2 16.0
 x9 r3 16.0
 x9 r5 16.0
 x9 r6 16.0
 x9 r8 0.0625
 x9 r9 1.0
 x10 obj 8
 x11 obj 4
 x12 obj 1
 x13 obj -6
 x13 r0 0.00390625
 x13 r1 -0.00390625
 x13 r3 16.0
 x13 r4 -256.0
 x13 r6 16.0
 x13 r7 -0.0625
 x14 obj 8
 x15 obj 7
 x16 obj 3
 x17 obj -6
 x17 r1 -0.00390625
 x17 r2 16.0
 x17 r4 -256.0
 x17 r5 16.0
 x17 r7 -0.0625
 x17 r8 0.0625
 x18 obj 7
 x19 obj 0
 x19 r9 2.0
RHS
 rhs obj 1
 rhs r0 0.00390625
 rhs r1 -0.00390625
 rhs r2 16.0
 rhs r3 16.0
 rhs r4 -256.0
 rhs r5 16.0
 rhs r6 16.0
 rhs r7 -0.0625
 rhs r8 0.0625
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 3
 UP b x19 2
ENDATA
