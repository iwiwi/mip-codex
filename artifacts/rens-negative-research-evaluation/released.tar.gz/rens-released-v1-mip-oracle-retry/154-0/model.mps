NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 L r6
COLUMNS
 x0 obj 8
 x1 obj 7
 x2 obj 2
 x3 obj 9
 x4 obj 2
 x5 obj 4
 x6 obj 2
 x7 obj 5
 x8 obj 3
 x9 obj 1
 x10 obj 5
 x11 obj 3
 x12 obj 3
 x13 obj -5
 x13 r0 -0.0625
 x13 r2 -256.0
 x13 r3 -1.0
 x13 r5 -0.0625
 x13 r6 1.0
 x14 obj 6
 x15 obj 3
 x16 obj 4
 x17 obj 4
 x18 obj -5
 x18 r1 -256.0
 x18 r2 -256.0
 x18 r4 -1.0
 x18 r5 -0.0625
 x19 obj -5
 x19 r0 -0.0625
 x19 r1 -256.0
 x19 r3 -1.0
 x19 r4 -1.0
 x20 obj 4
 x21 obj 2
 x22 obj 3
 x23 obj 2
 x24 obj 2
 x25 obj 4
 x26 obj 0
 x26 r6 2.0
RHS
 rhs obj -30
 rhs r0 -0.0625
 rhs r1 -256.0
 rhs r2 -256.0
 rhs r3 -1.0
 rhs r4 -1.0
 rhs r5 -0.0625
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 UP b x26 2
ENDATA
