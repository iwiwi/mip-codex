NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 L r4
 L r5
 L r6
 G r7
 L r8
COLUMNS
 x0 obj 1
 x1 obj 1
 x2 obj 5
 x3 obj 3
 x4 obj 7
 x5 obj 7
 x6 obj 8
 x7 obj 4
 x8 obj 7
 x9 obj 9
 x10 obj 4
 x11 obj 6
 x12 obj -2
 x12 r0 1.0
 x12 r1 0.00390625
 x12 r3 1.0
 x12 r4 0.0625
 x12 r6 0.0625
 x12 r7 -16.0
 x13 obj -2
 x13 r0 1.0
 x13 r2 -0.0625
 x13 r3 1.0
 x13 r5 256.0
 x13 r6 0.0625
 x13 r8 1.0
 x14 obj 6
 x15 obj 4
 x16 obj 4
 x17 obj 1
 x18 obj 2
 x19 obj 9
 x20 obj 7
 x21 obj -2
 x21 r1 0.00390625
 x21 r2 -0.0625
 x21 r4 0.0625
 x21 r5 256.0
 x21 r7 -16.0
 x22 obj 1
 x23 obj 6
 x24 obj 6
 x25 obj 5
 x26 obj 4
 x27 obj 5
 x28 obj 0
 x28 r8 2.0
RHS
 rhs obj -29
 rhs r0 1.0
 rhs r1 0.00390625
 rhs r2 -0.0625
 rhs r3 1.0
 rhs r4 0.0625
 rhs r5 256.0
 rhs r6 0.0625
 rhs r7 -16.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 UP b x28 2
ENDATA
