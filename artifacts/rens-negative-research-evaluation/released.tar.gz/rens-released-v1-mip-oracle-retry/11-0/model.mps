NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 L r5
 L r6
 L r7
 G r8
COLUMNS
 x0 obj 4
 x1 obj 2
 x1 r8 1.0
 x2 obj 2
 x3 obj 4
 x4 obj 2
 x5 obj -9
 x5 r1 -256.0
 x5 r2 -256.0
 x5 r4 -1.0
 x5 r5 0.00390625
 x5 r8 1.0
 x6 obj 2
 x7 obj 5
 x8 obj 5
 x9 obj -9
 x9 r0 -1.0
 x9 r1 -256.0
 x9 r3 -1.0
 x9 r4 -1.0
 x9 r6 0.0625
 x9 r8 1.0
 x10 obj 8
 x11 obj -9
 x11 r0 -1.0
 x11 r2 -256.0
 x11 r3 -1.0
 x11 r5 0.00390625
 x11 r6 0.0625
 x11 r7 1.0
 x11 r8 1.0
 x12 obj 5
 x13 obj 1
 x14 obj 1
 x15 obj 8
 x16 obj 2
 x17 obj 5
 x18 obj 0
 x18 r7 2.0
RHS
 rhs obj 5
 rhs r0 -1.0
 rhs r1 -256.0
 rhs r2 -256.0
 rhs r3 -1.0
 rhs r4 -1.0
 rhs r5 0.00390625
 rhs r6 0.0625
 rhs r7 5.0
 rhs r8 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 UP b x18 2
ENDATA
