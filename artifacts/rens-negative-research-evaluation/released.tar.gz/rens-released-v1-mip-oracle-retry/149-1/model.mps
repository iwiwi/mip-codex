NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 L r4
 L r5
 L r6
 L r7
 G r8
COLUMNS
 x0 obj -6
 x1 obj 7
 x1 r0 0.0625
 x1 r2 -0.00390625
 x1 r3 -256.0
 x1 r5 0.00390625
 x1 r6 0.0625
 x1 r7 1.0
 x1 r8 1.0
 x2 obj -5
 x3 obj -5
 x4 obj -6
 x5 obj -5
 x6 obj -9
 x7 obj -9
 x8 obj -4
 x9 obj -6
 x10 obj 7
 x10 r0 0.0625
 x10 r1 0.00390625
 x10 r3 -256.0
 x10 r4 1.0
 x10 r6 0.0625
 x10 r8 1.0
 x11 obj -4
 x12 obj -5
 x13 obj -3
 x14 obj -1
 x15 obj -4
 x16 obj -3
 x17 obj -5
 x18 obj -9
 x19 obj -3
 x20 obj -6
 x21 obj -2
 x22 obj -4
 x23 obj -9
 x24 obj -8
 x25 obj 7
 x25 r1 0.00390625
 x25 r2 -0.00390625
 x25 r4 1.0
 x25 r5 0.00390625
 x25 r8 1.0
 x26 obj -1
 x26 r8 1.0
 x27 obj -4
 x28 obj -2
 x29 obj -5
 x30 obj -5
 x31 obj -8
 x32 obj -1
 x33 obj -3
 x34 obj 0
 x34 r7 2.0
RHS
 rhs obj -9
 rhs r0 0.0625
 rhs r1 0.00390625
 rhs r2 -0.00390625
 rhs r3 -256.0
 rhs r4 1.0
 rhs r5 0.00390625
 rhs r6 0.0625
 rhs r7 5.0
 rhs r8 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 1
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 4
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 2
 UP b x34 2
ENDATA
