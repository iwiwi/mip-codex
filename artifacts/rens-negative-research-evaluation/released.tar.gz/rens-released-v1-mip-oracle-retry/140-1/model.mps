NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 G r4
 L r5
 G r6
 L r7
COLUMNS
 x0 obj -3
 x1 obj -6
 x2 obj -7
 x3 obj -6
 x4 obj -1
 x5 obj -4
 x6 obj 6
 x6 r1 1.0
 x6 r2 -1.0
 x6 r4 -256.0
 x6 r5 0.0625
 x7 obj -2
 x8 obj -5
 x9 obj -5
 x10 obj -4
 x11 obj -4
 x12 obj -2
 x13 obj -2
 x14 obj -4
 x15 obj -1
 x16 obj 6
 x16 r0 16.0
 x16 r2 -1.0
 x16 r3 256.0
 x16 r5 0.0625
 x16 r6 -256.0
 x16 r7 1.0
 x17 obj -8
 x18 obj -6
 x19 obj -5
 x20 obj 6
 x20 r0 16.0
 x20 r1 1.0
 x20 r3 256.0
 x20 r4 -256.0
 x20 r6 -256.0
 x21 obj -9
 x22 obj -1
 x23 obj -1
 x24 obj -8
 x25 obj -9
 x26 obj -3
 x27 obj -9
 x28 obj -3
 x29 obj -3
 x30 obj -1
 x31 obj -1
 x32 obj -9
 x33 obj 0
 x33 r7 2.0
RHS
 rhs obj 14
 rhs r0 16.0
 rhs r1 1.0
 rhs r2 -1.0
 rhs r3 256.0
 rhs r4 -256.0
 rhs r5 0.0625
 rhs r6 -256.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 4
 UP b x33 2
ENDATA
