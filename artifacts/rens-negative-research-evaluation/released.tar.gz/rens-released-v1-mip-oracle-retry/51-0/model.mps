NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 L r4
 G r5
 G r6
 G r7
 L r8
 G r9
COLUMNS
 x0 obj 2
 x1 obj 2
 x2 obj 1
 x2 r9 1.0
 x3 obj 2
 x4 obj 8
 x5 obj 1
 x6 obj 5
 x7 obj -9
 x7 r0 0.0625
 x7 r1 1.0
 x7 r3 0.0625
 x7 r4 16.0
 x7 r6 -0.00390625
 x7 r7 -16.0
 x7 r9 1.0
 x8 obj 3
 x9 obj 8
 x10 obj 7
 x11 obj 3
 x12 obj -9
 x12 r1 1.0
 x12 r2 -0.0625
 x12 r4 16.0
 x12 r5 -256.0
 x12 r7 -16.0
 x12 r9 1.0
 x13 obj 5
 x14 obj 2
 x15 obj 4
 x16 obj 8
 x17 obj 4
 x18 obj 8
 x19 obj -9
 x19 r0 0.0625
 x19 r2 -0.0625
 x19 r3 0.0625
 x19 r5 -256.0
 x19 r6 -0.00390625
 x19 r8 1.0
 x19 r9 1.0
 x20 obj 0
 x20 r8 2.0
RHS
 rhs obj -15
 rhs r0 0.0625
 rhs r1 1.0
 rhs r2 -0.0625
 rhs r3 0.0625
 rhs r4 16.0
 rhs r5 -256.0
 rhs r6 -0.00390625
 rhs r7 -16.0
 rhs r8 5.0
 rhs r9 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 1
 UP b x20 2
ENDATA
