NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 G r10
COLUMNS
 x0 obj 7
 x1 obj 8
 x2 obj 8
 x3 obj 3
 x4 obj -8
 x4 r1 256.0
 x4 r2 0.0625
 x4 r4 0.00390625
 x4 r5 16.0
 x4 r7 1.0
 x4 r8 0.0625
 x4 r10 1.0
 x5 obj 3
 x6 obj 5
 x7 obj 9
 x8 obj 8
 x9 obj 8
 x10 obj 5
 x11 obj 9
 x12 obj 6
 x13 obj 9
 x14 obj -8
 x14 r0 1.0
 x14 r2 0.0625
 x14 r3 0.0625
 x14 r5 16.0
 x14 r6 0.00390625
 x14 r8 0.0625
 x14 r9 1.0
 x14 r10 1.0
 x15 obj 4
 x16 obj 4
 x17 obj 3
 x18 obj 1
 x19 obj 8
 x20 obj 7
 x21 obj 7
 x22 obj 2
 x23 obj 4
 x24 obj 3
 x25 obj 9
 x26 obj 5
 x27 obj 3
 x27 r10 1.0
 x28 obj 9
 x29 obj 8
 x30 obj 2
 x31 obj 7
 x32 obj 7
 x33 obj -8
 x33 r0 1.0
 x33 r1 256.0
 x33 r3 0.0625
 x33 r4 0.00390625
 x33 r6 0.00390625
 x33 r7 1.0
 x33 r10 1.0
 x34 obj 8
 x35 obj 0
 x35 r9 2.0
RHS
 rhs obj -4
 rhs r0 1.0
 rhs r1 256.0
 rhs r2 0.0625
 rhs r3 0.0625
 rhs r4 0.00390625
 rhs r5 16.0
 rhs r6 0.00390625
 rhs r7 1.0
 rhs r8 0.0625
 rhs r9 5.0
 rhs r10 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 4
 LI b x32 0
 UI b x32 2
 LI b x33 0
 UI b x33 1
 LI b x34 0
 UI b x34 3
 UP b x35 2
ENDATA
