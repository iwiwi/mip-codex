NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
COLUMNS
 x0 obj 5
 x1 obj 2
 x2 obj 4
 x3 obj 4
 x4 obj 1
 x5 obj 5
 x6 obj 4
 x7 obj 5
 x8 obj -9
 x8 r0 -256.0
 x8 r1 -16.0
 x9 obj 5
 x10 obj 2
 x11 obj 8
 x12 obj 2
 x13 obj 8
 x14 obj -9
 x14 r1 -16.0
 x14 r2 0.0625
 x15 obj 1
 x16 obj 5
 x17 obj 7
 x18 obj 4
 x19 obj 4
 x20 obj 3
 x21 obj -9
 x21 r0 -256.0
 x21 r2 0.0625
 x21 r3 1.0
 x22 obj 3
 x23 obj 5
 x24 obj 1
 x25 obj 3
 x26 obj 0
 x26 r3 2.0
RHS
 rhs obj -20
 rhs r0 -256.0
 rhs r1 -16.0
 rhs r2 0.0625
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 4
 UP b x26 2
ENDATA
