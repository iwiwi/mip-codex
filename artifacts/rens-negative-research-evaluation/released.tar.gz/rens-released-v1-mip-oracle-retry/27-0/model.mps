NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 G r3
 G r4
 G r5
 L r6
 G r7
 L r8
 G r9
COLUMNS
 x0 obj 7
 x1 obj 4
 x2 obj 2
 x3 obj 6
 x4 obj 4
 x5 obj 8
 x6 obj 4
 x7 obj 5
 x8 obj 5
 x9 obj 6
 x10 obj 1
 x11 obj 3
 x12 obj -1
 x12 r1 -16.0
 x12 r2 -16.0
 x12 r4 -256.0
 x12 r5 -256.0
 x12 r7 -256.0
 x12 r9 1.0
 x13 obj 8
 x14 obj 4
 x15 obj 1
 x16 obj 2
 x16 r9 1.0
 x17 obj 1
 x18 obj 3
 x19 obj 1
 x20 obj -1
 x20 r0 1.0
 x20 r1 -16.0
 x20 r3 -0.00390625
 x20 r4 -256.0
 x20 r6 1.0
 x20 r7 -256.0
 x20 r9 1.0
 x21 obj 8
 x22 obj 9
 x23 obj 1
 x24 obj 7
 x25 obj 9
 x26 obj 7
 x27 obj -1
 x27 r0 1.0
 x27 r2 -16.0
 x27 r3 -0.00390625
 x27 r5 -256.0
 x27 r6 1.0
 x27 r8 1.0
 x27 r9 1.0
 x28 obj 0
 x28 r8 2.0
RHS
 rhs obj 18
 rhs r0 1.0
 rhs r1 -16.0
 rhs r2 -16.0
 rhs r3 -0.00390625
 rhs r4 -256.0
 rhs r5 -256.0
 rhs r6 1.0
 rhs r7 -256.0
 rhs r8 5.0
 rhs r9 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 1
 UP b x28 2
ENDATA
