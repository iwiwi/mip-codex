NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 G r9
COLUMNS
 x0 obj 7
 x0 r1 -16.0
 x0 r2 16.0
 x0 r4 16.0
 x0 r5 0.00390625
 x0 r7 16.0
 x0 r9 1.0
 x1 obj -3
 x2 obj -6
 x3 obj -2
 x4 obj -1
 x5 obj -6
 x6 obj -7
 x7 obj -2
 x8 obj -4
 x9 obj -2
 x10 obj -4
 x11 obj -9
 x12 obj -4
 x13 obj -4
 x13 r9 1.0
 x14 obj -5
 x15 obj -3
 x16 obj 7
 x16 r0 1.0
 x16 r1 -16.0
 x16 r3 1.0
 x16 r4 16.0
 x16 r6 256.0
 x16 r7 16.0
 x16 r9 1.0
 x17 obj -7
 x18 obj -4
 x19 obj -4
 x20 obj 7
 x20 r0 1.0
 x20 r2 16.0
 x20 r3 1.0
 x20 r5 0.00390625
 x20 r6 256.0
 x20 r8 1.0
 x20 r9 1.0
 x21 obj -5
 x22 obj -8
 x23 obj -6
 x24 obj -4
 x25 obj -2
 x26 obj -1
 x27 obj -6
 x28 obj -8
 x29 obj 0
 x29 r8 2.0
RHS
 rhs obj -29
 rhs r0 1.0
 rhs r1 -16.0
 rhs r2 16.0
 rhs r3 1.0
 rhs r4 16.0
 rhs r5 0.00390625
 rhs r6 256.0
 rhs r7 16.0
 rhs r8 5.0
 rhs r9 1.5
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 4
 UP b x29 2
ENDATA
