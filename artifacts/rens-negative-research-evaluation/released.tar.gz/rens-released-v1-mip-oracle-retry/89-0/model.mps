NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 G r4
COLUMNS
 x0 obj 8
 x1 obj -8
 x1 r0 -1.0
 x1 r1 1.0
 x1 r4 1.0
 x2 obj 8
 x3 obj 4
 x4 obj 1
 x5 obj -8
 x5 r0 -1.0
 x5 r2 -256.0
 x5 r3 1.0
 x5 r4 1.0
 x6 obj 2
 x7 obj 6
 x8 obj 6
 x9 obj 1
 x10 obj 1
 x10 r4 1.0
 x11 obj 2
 x12 obj 1
 x13 obj 3
 x14 obj 8
 x15 obj 6
 x16 obj 3
 x17 obj -8
 x17 r1 1.0
 x17 r2 -256.0
 x17 r4 1.0
 x18 obj 0
 x18 r3 2.0
RHS
 rhs obj 7
 rhs r0 -1.0
 rhs r1 1.0
 rhs r2 -256.0
 rhs r3 5.0
 rhs r4 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 1
 UP b x18 2
ENDATA
