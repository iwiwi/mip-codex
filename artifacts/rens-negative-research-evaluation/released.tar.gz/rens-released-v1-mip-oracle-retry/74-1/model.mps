NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
 G r4
 G r5
 L r6
 L r7
 G r8
 L r9
COLUMNS
 x0 obj -2
 x1 obj -7
 x2 obj -1
 x3 obj -9
 x4 obj -6
 x5 obj -1
 x6 obj -9
 x7 obj -9
 x8 obj -6
 x9 obj -5
 x10 obj -5
 x11 obj -9
 x12 obj -8
 x13 obj -5
 x14 obj -3
 x15 obj -8
 x16 obj -1
 x17 obj 2
 x17 r0 -16.0
 x17 r2 -1.0
 x17 r3 256.0
 x17 r5 -16.0
 x17 r6 0.00390625
 x17 r8 -256.0
 x17 r9 1.0
 x18 obj 2
 x18 r0 -16.0
 x18 r1 -256.0
 x18 r3 256.0
 x18 r4 -0.00390625
 x18 r6 0.00390625
 x18 r7 16.0
 x19 obj -9
 x20 obj -5
 x21 obj 2
 x21 r1 -256.0
 x21 r2 -1.0
 x21 r4 -0.00390625
 x21 r5 -16.0
 x21 r7 16.0
 x21 r8 -256.0
 x22 obj 0
 x22 r9 2.0
RHS
 rhs obj -6
 rhs r0 -16.0
 rhs r1 -256.0
 rhs r2 -1.0
 rhs r3 256.0
 rhs r4 -0.00390625
 rhs r5 -16.0
 rhs r6 0.00390625
 rhs r7 16.0
 rhs r8 -256.0
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 1
 UP b x22 2
ENDATA
