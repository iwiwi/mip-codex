NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 G r4
 L r5
 G r6
COLUMNS
 x0 obj 2
 x1 obj 1
 x2 obj 9
 x3 obj 5
 x4 obj 5
 x5 obj 1
 x6 obj 9
 x7 obj 2
 x8 obj -4
 x8 r0 0.00390625
 x8 r1 0.00390625
 x8 r3 256.0
 x8 r4 -256.0
 x8 r6 1.0
 x9 obj 7
 x10 obj 4
 x11 obj -4
 x11 r0 0.00390625
 x11 r2 -0.0625
 x11 r3 256.0
 x11 r5 1.0
 x11 r6 1.0
 x12 obj 1
 x13 obj 1
 x14 obj 4
 x15 obj 6
 x16 obj 4
 x17 obj 3
 x17 r6 1.0
 x18 obj 4
 x19 obj 4
 x20 obj -4
 x20 r1 0.00390625
 x20 r2 -0.0625
 x20 r4 -256.0
 x20 r6 1.0
 x21 obj 8
 x22 obj 2
 x23 obj 5
 x24 obj 8
 x25 obj 1
 x26 obj 0
 x26 r5 2.0
RHS
 rhs obj 14
 rhs r0 0.00390625
 rhs r1 0.00390625
 rhs r2 -0.0625
 rhs r3 256.0
 rhs r4 -256.0
 rhs r5 5.0
 rhs r6 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 2
 UP b x26 2
ENDATA
