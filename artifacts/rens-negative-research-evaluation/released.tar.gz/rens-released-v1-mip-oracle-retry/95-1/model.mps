NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 G r3
 L r4
 G r5
COLUMNS
 x0 obj -5
 x1 obj -7
 x2 obj -3
 x3 obj -1
 x4 obj -6
 x5 obj -9
 x6 obj 3
 x6 r1 -256.0
 x6 r2 256.0
 x6 r5 1.0
 x7 obj -8
 x8 obj -1
 x9 obj 3
 x9 r0 -0.00390625
 x9 r2 256.0
 x9 r3 -256.0
 x9 r4 1.0
 x9 r5 1.0
 x10 obj -7
 x11 obj -1
 x12 obj -3
 x13 obj -4
 x14 obj -4
 x15 obj 3
 x15 r0 -0.00390625
 x15 r1 -256.0
 x15 r3 -256.0
 x15 r5 1.0
 x16 obj -1
 x17 obj -8
 x18 obj -7
 x19 obj -8
 x19 r5 1.0
 x20 obj -6
 x21 obj -8
 x22 obj -9
 x23 obj -1
 x24 obj -6
 x25 obj -3
 x26 obj 0
 x26 r4 2.0
RHS
 rhs obj 21
 rhs r0 -0.00390625
 rhs r1 -256.0
 rhs r2 256.0
 rhs r3 -256.0
 rhs r4 5.0
 rhs r5 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 UP b x26 2
ENDATA
