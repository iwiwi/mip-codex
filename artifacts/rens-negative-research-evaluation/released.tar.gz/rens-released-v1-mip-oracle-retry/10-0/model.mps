NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 G r4
 G r5
 L r6
 G r7
 L r8
COLUMNS
 x0 obj 6
 x1 obj 6
 x2 obj 3
 x3 obj -8
 x3 r0 1.0
 x3 r2 -16.0
 x3 r3 1.0
 x3 r5 -0.00390625
 x3 r6 256.0
 x3 r8 1.0
 x4 obj 4
 x5 obj 3
 x6 obj 2
 x7 obj 1
 x8 obj 1
 x9 obj 8
 x10 obj 3
 x11 obj -8
 x11 r1 256.0
 x11 r2 -16.0
 x11 r4 -0.00390625
 x11 r5 -0.00390625
 x11 r7 -256.0
 x12 obj 7
 x13 obj 5
 x14 obj 8
 x15 obj 6
 x16 obj -8
 x16 r0 1.0
 x16 r1 256.0
 x16 r3 1.0
 x16 r4 -0.00390625
 x16 r6 256.0
 x16 r7 -256.0
 x17 obj 7
 x18 obj 9
 x19 obj 5
 x20 obj 3
 x21 obj 0
 x21 r8 2.0
RHS
 rhs obj -27
 rhs r0 1.0
 rhs r1 256.0
 rhs r2 -16.0
 rhs r3 1.0
 rhs r4 -0.00390625
 rhs r5 -0.00390625
 rhs r6 256.0
 rhs r7 -256.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 UP b x21 2
ENDATA
