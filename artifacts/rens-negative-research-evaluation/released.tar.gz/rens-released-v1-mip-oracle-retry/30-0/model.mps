NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
COLUMNS
 x0 obj 4
 x1 obj 2
 x2 obj 7
 x3 obj 9
 x4 obj 1
 x5 obj 2
 x6 obj 4
 x7 obj 2
 x8 obj 1
 x9 obj -3
 x9 r0 256.0
 x9 r1 0.0625
 x10 obj 9
 x11 obj 4
 x12 obj 2
 x13 obj 7
 x14 obj 9
 x15 obj 8
 x16 obj 9
 x17 obj 9
 x18 obj 9
 x19 obj 3
 x20 obj 1
 x21 obj 2
 x22 obj 5
 x23 obj -3
 x23 r1 0.0625
 x23 r2 -1.0
 x24 obj 6
 x25 obj 3
 x26 obj 4
 x27 obj -3
 x27 r0 256.0
 x27 r2 -1.0
 x27 r3 1.0
 x28 obj 2
 x29 obj 9
 x30 obj 5
 x31 obj 0
 x31 r3 2.0
RHS
 rhs obj -1
 rhs r0 256.0
 rhs r1 0.0625
 rhs r2 -1.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 1
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 1
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 2
 UP b x31 2
ENDATA
