NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 G r4
 L r5
 G r6
 L r7
COLUMNS
 x0 obj -6
 x1 obj -7
 x2 obj -1
 x3 obj -6
 x4 obj 9
 x4 r0 -0.0625
 x4 r1 0.0625
 x4 r3 -1.0
 x4 r4 -0.00390625
 x4 r6 -0.0625
 x5 obj -8
 x6 obj -4
 x7 obj -8
 x8 obj -4
 x9 obj -6
 x10 obj -3
 x11 obj -9
 x12 obj -4
 x13 obj -1
 x14 obj 9
 x14 r0 -0.0625
 x14 r2 -0.0625
 x14 r3 -1.0
 x14 r5 1.0
 x14 r6 -0.0625
 x14 r7 1.0
 x15 obj -4
 x16 obj -4
 x17 obj -5
 x18 obj -2
 x19 obj -4
 x20 obj -3
 x21 obj -8
 x22 obj 9
 x22 r1 0.0625
 x22 r2 -0.0625
 x22 r4 -0.00390625
 x22 r5 1.0
 x23 obj -2
 x24 obj -8
 x25 obj -6
 x26 obj -5
 x27 obj -5
 x28 obj -7
 x29 obj -2
 x30 obj -2
 x31 obj -3
 x32 obj -5
 x33 obj 0
 x33 r7 2.0
RHS
 rhs obj 14
 rhs r0 -0.0625
 rhs r1 0.0625
 rhs r2 -0.0625
 rhs r3 -1.0
 rhs r4 -0.00390625
 rhs r5 1.0
 rhs r6 -0.0625
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 2
 LI b x32 0
 UI b x32 3
 UP b x33 2
ENDATA
