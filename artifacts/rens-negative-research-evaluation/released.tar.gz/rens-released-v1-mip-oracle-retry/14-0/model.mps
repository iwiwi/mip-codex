NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 G r4
 L r5
 G r6
 L r7
COLUMNS
 x0 obj 7
 x1 obj 7
 x2 obj 4
 x3 obj 6
 x4 obj -2
 x4 r0 0.0625
 x4 r1 -16.0
 x4 r3 16.0
 x4 r4 -0.00390625
 x4 r6 -1.0
 x5 obj 1
 x6 obj 6
 x7 obj 5
 x8 obj 2
 x9 obj 1
 x10 obj 7
 x11 obj -2
 x11 r0 0.0625
 x11 r2 -0.00390625
 x11 r3 16.0
 x11 r5 256.0
 x11 r6 -1.0
 x11 r7 1.0
 x12 obj 4
 x13 obj 8
 x14 obj 9
 x15 obj 8
 x16 obj 8
 x17 obj 9
 x18 obj 1
 x19 obj 9
 x20 obj 3
 x21 obj 6
 x22 obj 8
 x23 obj 3
 x24 obj -2
 x24 r1 -16.0
 x24 r2 -0.00390625
 x24 r4 -0.00390625
 x24 r5 256.0
 x25 obj 5
 x26 obj 5
 x27 obj 0
 x27 r7 2.0
RHS
 rhs obj 29
 rhs r0 0.0625
 rhs r1 -16.0
 rhs r2 -0.00390625
 rhs r3 16.0
 rhs r4 -0.00390625
 rhs r5 256.0
 rhs r6 -1.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 1
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 UP b x27 2
ENDATA
