NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 L r5
 G r6
 L r7
 L r8
COLUMNS
 x0 obj 3
 x1 obj -6
 x1 r1 -256.0
 x1 r2 -0.00390625
 x1 r4 -16.0
 x1 r5 0.0625
 x1 r7 256.0
 x2 obj 9
 x3 obj 5
 x4 obj 2
 x5 obj 3
 x6 obj 6
 x7 obj 1
 x8 obj 8
 x9 obj 8
 x10 obj -6
 x10 r0 -256.0
 x10 r2 -0.00390625
 x10 r3 -0.0625
 x10 r5 0.0625
 x10 r6 -0.00390625
 x10 r8 1.0
 x11 obj 4
 x12 obj 1
 x13 obj 4
 x14 obj 9
 x15 obj 9
 x16 obj 1
 x17 obj -6
 x17 r0 -256.0
 x17 r1 -256.0
 x17 r3 -0.0625
 x17 r4 -16.0
 x17 r6 -0.00390625
 x17 r7 256.0
 x18 obj 5
 x19 obj 9
 x20 obj 7
 x21 obj 6
 x22 obj 9
 x23 obj 9
 x24 obj 0
 x24 r8 2.0
RHS
 rhs obj -3
 rhs r0 -256.0
 rhs r1 -256.0
 rhs r2 -0.00390625
 rhs r3 -0.0625
 rhs r4 -16.0
 rhs r5 0.0625
 rhs r6 -0.00390625
 rhs r7 256.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 UP b x24 2
ENDATA
