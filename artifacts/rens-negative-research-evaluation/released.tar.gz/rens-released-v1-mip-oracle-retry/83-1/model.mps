NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 G r4
 G r5
 L r6
 G r7
COLUMNS
 x0 obj -4
 x1 obj -8
 x2 obj -9
 x2 r7 1.0
 x3 obj -7
 x4 obj -9
 x5 obj -4
 x6 obj -5
 x7 obj -5
 x8 obj -1
 x9 obj -3
 x10 obj -9
 x11 obj 3
 x11 r0 0.0625
 x11 r1 256.0
 x11 r3 0.0625
 x11 r4 -1.0
 x11 r7 1.0
 x12 obj -7
 x13 obj -5
 x14 obj -4
 x15 obj -8
 x16 obj -4
 x17 obj -1
 x18 obj -5
 x19 obj -3
 x20 obj 3
 x20 r1 256.0
 x20 r2 256.0
 x20 r4 -1.0
 x20 r5 -256.0
 x20 r7 1.0
 x21 obj -4
 x22 obj -5
 x23 obj 3
 x23 r0 0.0625
 x23 r2 256.0
 x23 r3 0.0625
 x23 r5 -256.0
 x23 r6 1.0
 x23 r7 1.0
 x24 obj -3
 x25 obj -2
 x26 obj -5
 x27 obj -2
 x28 obj -2
 x29 obj -4
 x30 obj -6
 x31 obj -4
 x32 obj -1
 x33 obj -5
 x34 obj -2
 x35 obj 0
 x35 r6 2.0
RHS
 rhs obj 3
 rhs r0 0.0625
 rhs r1 256.0
 rhs r2 256.0
 rhs r3 0.0625
 rhs r4 -1.0
 rhs r5 -256.0
 rhs r6 5.0
 rhs r7 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 1
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 2
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 2
 LI b x34 0
 UI b x34 4
 UP b x35 2
ENDATA
