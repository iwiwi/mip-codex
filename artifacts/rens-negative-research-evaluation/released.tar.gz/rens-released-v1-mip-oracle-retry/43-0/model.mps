NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 G r3
 L r4
 G r5
COLUMNS
 x0 obj -1
 x0 r0 0.00390625
 x0 r1 -0.0625
 x0 r3 -256.0
 x0 r5 1.0
 x1 obj 6
 x2 obj 7
 x3 obj 3
 x4 obj 6
 x5 obj 8
 x6 obj 7
 x7 obj 3
 x8 obj 6
 x9 obj 6
 x10 obj -1
 x10 r1 -0.0625
 x10 r2 -1.0
 x10 r5 1.0
 x11 obj 4
 x12 obj 8
 x13 obj 9
 x14 obj 9
 x15 obj 3
 x16 obj 3
 x16 r5 1.0
 x17 obj 4
 x18 obj -1
 x18 r0 0.00390625
 x18 r2 -1.0
 x18 r3 -256.0
 x18 r4 1.0
 x18 r5 1.0
 x19 obj 9
 x20 obj 6
 x21 obj 1
 x22 obj 4
 x23 obj 3
 x24 obj 3
 x25 obj 2
 x26 obj 9
 x27 obj 6
 x28 obj 0
 x28 r4 2.0
RHS
 rhs obj 17
 rhs r0 0.00390625
 rhs r1 -0.0625
 rhs r2 -1.0
 rhs r3 -256.0
 rhs r4 5.0
 rhs r5 1.5
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 3
 UP b x28 2
ENDATA
