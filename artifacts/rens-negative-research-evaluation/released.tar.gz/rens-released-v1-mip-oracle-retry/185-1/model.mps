NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 L r4
 G r5
COLUMNS
 x0 obj 7
 x0 r0 -16.0
 x0 r2 256.0
 x0 r3 16.0
 x0 r4 1.0
 x0 r5 1.0
 x1 obj -5
 x2 obj -2
 x3 obj -8
 x3 r5 1.0
 x4 obj 7
 x4 r0 -16.0
 x4 r1 0.00390625
 x4 r3 16.0
 x4 r5 1.0
 x5 obj -2
 x6 obj -9
 x7 obj -1
 x8 obj -6
 x9 obj 7
 x9 r1 0.00390625
 x9 r2 256.0
 x9 r5 1.0
 x10 obj -4
 x11 obj -5
 x12 obj -5
 x13 obj -8
 x14 obj -2
 x15 obj -7
 x16 obj -3
 x17 obj -3
 x18 obj 0
 x18 r4 2.0
RHS
 rhs obj 1
 rhs r0 -16.0
 rhs r1 0.00390625
 rhs r2 256.0
 rhs r3 16.0
 rhs r4 5.0
 rhs r5 1.5
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 UP b x18 2
ENDATA
