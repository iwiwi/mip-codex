NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 G r4
COLUMNS
 x0 obj 2
 x0 r0 16.0
 x0 r1 16.0
 x0 r4 1.0
 x1 obj -5
 x2 obj -4
 x3 obj -8
 x4 obj -1
 x5 obj -2
 x6 obj -4
 x7 obj -8
 x8 obj -8
 x9 obj -9
 x10 obj 2
 x10 r1 16.0
 x10 r2 -16.0
 x10 r4 1.0
 x11 obj -2
 x12 obj -8
 x13 obj -3
 x14 obj -9
 x15 obj -2
 x16 obj -9
 x17 obj -6
 x18 obj -3
 x19 obj -9
 x20 obj -4
 x21 obj 2
 x21 r0 16.0
 x21 r2 -16.0
 x21 r3 1.0
 x21 r4 1.0
 x22 obj -7
 x23 obj -1
 x24 obj -8
 x25 obj -8
 x26 obj -3
 x26 r4 1.0
 x27 obj -5
 x28 obj -4
 x29 obj -2
 x30 obj 0
 x30 r3 2.0
RHS
 rhs obj 12
 rhs r0 16.0
 rhs r1 16.0
 rhs r2 -16.0
 rhs r3 5.0
 rhs r4 1.5
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 2
 UP b x30 2
ENDATA
