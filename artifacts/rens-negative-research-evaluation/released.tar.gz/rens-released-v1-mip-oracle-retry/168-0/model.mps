NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 G r3
 L r4
 G r5
 G r6
 L r7
COLUMNS
 x0 obj 1
 x1 obj 2
 x2 obj 7
 x3 obj 2
 x4 obj 8
 x5 obj 3
 x6 obj 4
 x7 obj 8
 x8 obj 9
 x9 obj 8
 x10 obj 4
 x11 obj -4
 x11 r0 0.00390625
 x11 r2 -256.0
 x11 r3 -16.0
 x11 r5 -16.0
 x11 r6 -16.0
 x11 r7 1.0
 x12 obj -4
 x12 r1 -0.00390625
 x12 r2 -256.0
 x12 r4 16.0
 x12 r5 -16.0
 x13 obj 6
 x14 obj 1
 x15 obj 8
 x16 obj 9
 x17 obj 1
 x18 obj 6
 x19 obj 1
 x20 obj -4
 x20 r0 0.00390625
 x20 r1 -0.00390625
 x20 r3 -16.0
 x20 r4 16.0
 x20 r6 -16.0
 x21 obj 9
 x22 obj 5
 x23 obj 3
 x24 obj 2
 x25 obj 9
 x26 obj 7
 x27 obj 7
 x28 obj 3
 x29 obj 4
 x30 obj 9
 x31 obj 1
 x32 obj 6
 x33 obj 2
 x34 obj 6
 x35 obj 0
 x35 r7 2.0
RHS
 rhs obj -9
 rhs r0 0.00390625
 rhs r1 -0.00390625
 rhs r2 -256.0
 rhs r3 -16.0
 rhs r4 16.0
 rhs r5 -16.0
 rhs r6 -16.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 2
 LI b x33 0
 UI b x33 3
 LI b x34 0
 UI b x34 2
 UP b x35 2
ENDATA
