NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 G r2
 G r3
 L r4
 L r5
 L r6
 G r7
 G r8
 L r9
COLUMNS
 x0 obj 7
 x0 r0 256.0
 x0 r1 -0.00390625
 x0 r3 -0.0625
 x0 r4 1.0
 x0 r6 0.0625
 x0 r7 -16.0
 x1 obj -8
 x2 obj -8
 x3 obj -7
 x4 obj -2
 x5 obj -8
 x6 obj -2
 x7 obj -7
 x8 obj 7
 x8 r0 256.0
 x8 r2 -256.0
 x8 r3 -0.0625
 x8 r5 16.0
 x8 r6 0.0625
 x8 r8 -0.0625
 x8 r9 1.0
 x9 obj -9
 x10 obj -8
 x11 obj -6
 x12 obj -2
 x13 obj -4
 x14 obj 7
 x14 r1 -0.00390625
 x14 r2 -256.0
 x14 r4 1.0
 x14 r5 16.0
 x14 r7 -16.0
 x14 r8 -0.0625
 x15 obj -7
 x16 obj -2
 x17 obj -5
 x18 obj -5
 x19 obj -2
 x20 obj -4
 x21 obj -1
 x22 obj -8
 x23 obj -6
 x24 obj -1
 x25 obj 0
 x25 r9 2.0
RHS
 rhs obj 17
 rhs r0 256.0
 rhs r1 -0.00390625
 rhs r2 -256.0
 rhs r3 -0.0625
 rhs r4 1.0
 rhs r5 16.0
 rhs r6 0.0625
 rhs r7 -16.0
 rhs r8 -0.0625
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 UP b x25 2
ENDATA
