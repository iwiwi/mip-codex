NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 G r4
COLUMNS
 x0 obj -2
 x1 obj -2
 x2 obj -2
 x3 obj -9
 x4 obj -5
 x5 obj -3
 x6 obj -2
 x7 obj -8
 x8 obj -5
 x9 obj -4
 x10 obj -1
 x11 obj -9
 x11 r4 1.0
 x12 obj -7
 x13 obj -6
 x14 obj -9
 x15 obj -7
 x16 obj -5
 x17 obj -9
 x18 obj -3
 x19 obj -6
 x20 obj 2
 x20 r0 -0.0625
 x20 r2 0.0625
 x20 r3 1.0
 x20 r4 1.0
 x21 obj -3
 x22 obj -8
 x23 obj -7
 x24 obj -9
 x25 obj -8
 x26 obj -2
 x27 obj -5
 x28 obj -9
 x29 obj -1
 x30 obj 2
 x30 r1 0.0625
 x30 r2 0.0625
 x30 r4 1.0
 x31 obj 2
 x31 r0 -0.0625
 x31 r1 0.0625
 x31 r4 1.0
 x32 obj 0
 x32 r3 2.0
RHS
 rhs obj -27
 rhs r0 -0.0625
 rhs r1 0.0625
 rhs r2 0.0625
 rhs r3 5.0
 rhs r4 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 1
 LI b x31 0
 UI b x31 1
 UP b x32 2
ENDATA
