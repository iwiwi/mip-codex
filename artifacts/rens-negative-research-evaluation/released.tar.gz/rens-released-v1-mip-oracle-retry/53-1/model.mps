NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 G r4
 G r5
 L r6
 L r7
 L r8
 G r9
COLUMNS
 x0 obj -3
 x1 obj -1
 x2 obj 7
 x2 r1 -256.0
 x2 r2 256.0
 x2 r4 -0.0625
 x2 r5 -1.0
 x2 r7 0.0625
 x2 r9 1.0
 x3 obj -1
 x4 obj -2
 x4 r9 1.0
 x5 obj -6
 x6 obj -8
 x7 obj -2
 x8 obj -2
 x9 obj 7
 x9 r0 0.0625
 x9 r1 -256.0
 x9 r3 1.0
 x9 r4 -0.0625
 x9 r6 0.00390625
 x9 r7 0.0625
 x9 r9 1.0
 x10 obj 7
 x10 r0 0.0625
 x10 r2 256.0
 x10 r3 1.0
 x10 r5 -1.0
 x10 r6 0.00390625
 x10 r8 1.0
 x10 r9 1.0
 x11 obj -1
 x12 obj -3
 x13 obj -2
 x14 obj -8
 x15 obj -7
 x16 obj -1
 x17 obj -1
 x18 obj -8
 x19 obj -9
 x20 obj 0
 x20 r8 2.0
RHS
 rhs obj 5
 rhs r0 0.0625
 rhs r1 -256.0
 rhs r2 256.0
 rhs r3 1.0
 rhs r4 -0.0625
 rhs r5 -1.0
 rhs r6 0.00390625
 rhs r7 0.0625
 rhs r8 5.0
 rhs r9 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 UP b x20 2
ENDATA
