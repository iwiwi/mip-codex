NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
 G r4
 L r5
 L r6
 G r7
COLUMNS
 x0 obj 5
 x1 obj 5
 x2 obj 6
 x3 obj 1
 x4 obj 8
 x5 obj 3
 x6 obj 4
 x7 obj 7
 x8 obj 5
 x9 obj 5
 x10 obj -8
 x10 r0 -256.0
 x10 r1 -256.0
 x10 r3 16.0
 x10 r4 -0.0625
 x10 r7 1.0
 x11 obj 7
 x12 obj 7
 x13 obj 6
 x14 obj 4
 x15 obj -8
 x15 r0 -256.0
 x15 r2 -0.0625
 x15 r3 16.0
 x15 r5 1.0
 x15 r6 1.0
 x15 r7 1.0
 x16 obj 7
 x17 obj 6
 x18 obj 5
 x19 obj 4
 x20 obj 8
 x21 obj 6
 x22 obj 6
 x22 r7 1.0
 x23 obj -8
 x23 r1 -256.0
 x23 r2 -0.0625
 x23 r4 -0.0625
 x23 r5 1.0
 x23 r7 1.0
 x24 obj 0
 x24 r6 2.0
RHS
 rhs obj 27
 rhs r0 -256.0
 rhs r1 -256.0
 rhs r2 -0.0625
 rhs r3 16.0
 rhs r4 -0.0625
 rhs r5 1.0
 rhs r6 5.0
 rhs r7 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 1
 UP b x24 2
ENDATA
