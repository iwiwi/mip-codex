NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 G r4
COLUMNS
 x0 obj -2
 x1 obj 9
 x1 r0 -0.00390625
 x1 r1 256.0
 x1 r4 1.0
 x2 obj -6
 x3 obj -4
 x4 obj -6
 x5 obj -6
 x6 obj -8
 x7 obj -3
 x8 obj -5
 x9 obj -5
 x10 obj -5
 x11 obj -3
 x12 obj -3
 x13 obj -8
 x14 obj -3
 x15 obj -6
 x16 obj -2
 x17 obj -8
 x18 obj -1
 x19 obj -4
 x20 obj -2
 x21 obj -5
 x22 obj -1
 x23 obj -3
 x24 obj -5
 x25 obj -9
 x26 obj -3
 x27 obj -4
 x28 obj -9
 x29 obj -4
 x30 obj 9
 x30 r0 -0.00390625
 x30 r2 16.0
 x30 r3 1.0
 x30 r4 1.0
 x31 obj -5
 x31 r4 1.0
 x32 obj 9
 x32 r1 256.0
 x32 r2 16.0
 x32 r4 1.0
 x33 obj 0
 x33 r3 2.0
RHS
 rhs obj 14
 rhs r0 -0.00390625
 rhs r1 256.0
 rhs r2 16.0
 rhs r3 5.0
 rhs r4 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 1
 LI b x31 0
 UI b x31 2
 LI b x32 0
 UI b x32 1
 UP b x33 2
ENDATA
