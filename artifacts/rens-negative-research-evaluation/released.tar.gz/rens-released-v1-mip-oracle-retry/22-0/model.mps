NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 G r4
 L r5
 G r6
 G r7
 L r8
COLUMNS
 x0 obj 4
 x1 obj 6
 x2 obj -9
 x2 r1 -16.0
 x2 r2 16.0
 x2 r4 -0.0625
 x2 r5 0.0625
 x2 r7 -0.0625
 x3 obj 4
 x4 obj 9
 x5 obj 7
 x6 obj 3
 x7 obj -9
 x7 r0 256.0
 x7 r2 16.0
 x7 r3 -0.00390625
 x7 r5 0.0625
 x7 r6 -1.0
 x7 r8 1.0
 x8 obj 4
 x9 obj 3
 x10 obj 4
 x11 obj 6
 x12 obj 9
 x13 obj 9
 x14 obj -9
 x14 r0 256.0
 x14 r1 -16.0
 x14 r3 -0.00390625
 x14 r4 -0.0625
 x14 r6 -1.0
 x14 r7 -0.0625
 x15 obj 4
 x16 obj 8
 x17 obj 9
 x18 obj 6
 x19 obj 3
 x20 obj 4
 x21 obj 1
 x22 obj 5
 x23 obj 3
 x24 obj 9
 x25 obj 5
 x26 obj 0
 x26 r8 2.0
RHS
 rhs obj 7
 rhs r0 256.0
 rhs r1 -16.0
 rhs r2 16.0
 rhs r3 -0.00390625
 rhs r4 -0.0625
 rhs r5 0.0625
 rhs r6 -1.0
 rhs r7 -0.0625
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 4
 UP b x26 2
ENDATA
