NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 L r4
 L r5
COLUMNS
 x0 obj -4
 x1 obj 4
 x1 r1 -0.00390625
 x1 r2 0.0625
 x1 r4 16.0
 x2 obj -6
 x3 obj -2
 x4 obj -9
 x5 obj -7
 x6 obj -8
 x7 obj -7
 x8 obj -6
 x9 obj -1
 x10 obj -2
 x11 obj -1
 x12 obj 4
 x12 r0 16.0
 x12 r1 -0.00390625
 x12 r3 -1.0
 x12 r4 16.0
 x13 obj -6
 x14 obj -1
 x15 obj -1
 x16 obj 4
 x16 r0 16.0
 x16 r2 0.0625
 x16 r3 -1.0
 x16 r5 1.0
 x17 obj -6
 x18 obj -2
 x19 obj 0
 x19 r5 2.0
RHS
 rhs obj -26
 rhs r0 16.0
 rhs r1 -0.00390625
 rhs r2 0.0625
 rhs r3 -1.0
 rhs r4 16.0
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 UP b x19 2
ENDATA
