NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj -6
 x1 obj 1
 x1 r1 -1.0
 x1 r2 -0.0625
 x1 r4 256.0
 x2 obj -4
 x3 obj -8
 x4 obj -1
 x5 obj -8
 x6 obj -8
 x7 obj -7
 x8 obj -8
 x9 obj 1
 x9 r0 -1.0
 x9 r2 -0.0625
 x9 r3 1.0
 x9 r5 1.0
 x10 obj -6
 x11 obj -8
 x12 obj -2
 x13 obj -4
 x14 obj -4
 x15 obj -8
 x16 obj -5
 x17 obj 1
 x17 r0 -1.0
 x17 r1 -1.0
 x17 r3 1.0
 x17 r4 256.0
 x18 obj -9
 x19 obj -7
 x20 obj 0
 x20 r5 2.0
RHS
 rhs obj -16
 rhs r0 -1.0
 rhs r1 -1.0
 rhs r2 -0.0625
 rhs r3 1.0
 rhs r4 256.0
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 UP b x20 2
ENDATA
