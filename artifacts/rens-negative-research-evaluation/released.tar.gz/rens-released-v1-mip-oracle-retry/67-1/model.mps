NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 L r5
 G r6
 G r7
 L r8
 G r9
 L r10
 G r11
COLUMNS
 x0 obj -1
 x1 obj -2
 x2 obj -1
 x3 obj -9
 x4 obj -1
 x5 obj -1
 x6 obj -2
 x7 obj -5
 x7 r11 1.0
 x8 obj -2
 x9 obj -1
 x10 obj -1
 x11 obj -8
 x12 obj -4
 x13 obj -4
 x14 obj -6
 x15 obj -5
 x16 obj -7
 x17 obj -2
 x18 obj -7
 x19 obj -2
 x20 obj 8
 x20 r1 0.0625
 x20 r2 16.0
 x20 r4 -16.0
 x20 r5 0.0625
 x20 r7 -0.00390625
 x20 r8 1.0
 x20 r11 1.0
 x21 obj -4
 x22 obj 8
 x22 r0 256.0
 x22 r1 0.0625
 x22 r3 -16.0
 x22 r4 -16.0
 x22 r6 -0.00390625
 x22 r7 -0.00390625
 x22 r9 -1.0
 x22 r11 1.0
 x23 obj -4
 x24 obj -9
 x25 obj -8
 x26 obj -9
 x27 obj -9
 x28 obj -6
 x29 obj -7
 x30 obj 8
 x30 r0 256.0
 x30 r2 16.0
 x30 r3 -16.0
 x30 r5 0.0625
 x30 r6 -0.00390625
 x30 r8 1.0
 x30 r9 -1.0
 x30 r10 1.0
 x30 r11 1.0
 x31 obj 0
 x31 r10 2.0
RHS
 rhs obj 30
 rhs r0 256.0
 rhs r1 0.0625
 rhs r2 16.0
 rhs r3 -16.0
 rhs r4 -16.0
 rhs r5 0.0625
 rhs r6 -0.00390625
 rhs r7 -0.00390625
 rhs r8 1.0
 rhs r9 -1.0
 rhs r10 5.0
 rhs r11 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 1
 UP b x31 2
ENDATA
