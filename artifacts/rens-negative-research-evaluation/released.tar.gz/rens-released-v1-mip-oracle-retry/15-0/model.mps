NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 G r4
 G r5
 L r6
 G r7
 G r8
 G r9
 L r10
 G r11
COLUMNS
 x0 obj 5
 x1 obj 7
 x2 obj 9
 x3 obj 6
 x4 obj 4
 x4 r11 1.0
 x5 obj 6
 x6 obj 9
 x7 obj 2
 x8 obj 7
 x9 obj 4
 x10 obj 3
 x11 obj 8
 x12 obj 6
 x13 obj -4
 x13 r0 16.0
 x13 r2 16.0
 x13 r3 1.0
 x13 r5 -256.0
 x13 r6 16.0
 x13 r8 -16.0
 x13 r9 -0.00390625
 x13 r10 1.0
 x13 r11 1.0
 x14 obj 2
 x15 obj -4
 x15 r0 16.0
 x15 r1 -0.00390625
 x15 r3 1.0
 x15 r4 -0.00390625
 x15 r6 16.0
 x15 r7 -1.0
 x15 r9 -0.00390625
 x15 r11 1.0
 x16 obj 4
 x17 obj 1
 x18 obj 8
 x19 obj -4
 x19 r1 -0.00390625
 x19 r2 16.0
 x19 r4 -0.00390625
 x19 r5 -256.0
 x19 r7 -1.0
 x19 r8 -16.0
 x19 r11 1.0
 x20 obj 3
 x21 obj 5
 x22 obj 8
 x23 obj 4
 x24 obj 8
 x25 obj 5
 x26 obj 3
 x27 obj 9
 x28 obj 5
 x29 obj 3
 x30 obj 3
 x31 obj 0
 x31 r10 2.0
RHS
 rhs obj 21
 rhs r0 16.0
 rhs r1 -0.00390625
 rhs r2 16.0
 rhs r3 1.0
 rhs r4 -0.00390625
 rhs r5 -256.0
 rhs r6 16.0
 rhs r7 -1.0
 rhs r8 -16.0
 rhs r9 -0.00390625
 rhs r10 5.0
 rhs r11 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 3
 UP b x31 2
ENDATA
