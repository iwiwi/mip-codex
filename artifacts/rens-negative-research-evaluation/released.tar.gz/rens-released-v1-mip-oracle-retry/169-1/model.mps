NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
 L r4
 L r5
 G r6
COLUMNS
 x0 obj -6
 x1 obj -9
 x2 obj -7
 x3 obj -7
 x4 obj -3
 x5 obj -6
 x6 obj -3
 x7 obj -8
 x8 obj -5
 x9 obj 6
 x9 r1 -1.0
 x9 r2 -16.0
 x9 r4 16.0
 x9 r6 1.0
 x10 obj 6
 x10 r0 -0.0625
 x10 r1 -1.0
 x10 r3 0.0625
 x10 r4 16.0
 x10 r6 1.0
 x11 obj -9
 x12 obj -4
 x13 obj -7
 x14 obj -7
 x15 obj -3
 x16 obj -1
 x17 obj -5
 x18 obj 6
 x18 r0 -0.0625
 x18 r2 -16.0
 x18 r3 0.0625
 x18 r5 1.0
 x18 r6 1.0
 x19 obj -7
 x20 obj -8
 x21 obj -1
 x22 obj -7
 x23 obj -9
 x24 obj -5
 x25 obj -5
 x26 obj -8
 x27 obj -8
 x28 obj -8
 x29 obj -3
 x30 obj -4
 x30 r6 1.0
 x31 obj -5
 x32 obj -6
 x33 obj -8
 x34 obj -1
 x35 obj 0
 x35 r5 2.0
RHS
 rhs obj 12
 rhs r0 -0.0625
 rhs r1 -1.0
 rhs r2 -16.0
 rhs r3 0.0625
 rhs r4 16.0
 rhs r5 5.0
 rhs r6 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 3
 LI b x34 0
 UI b x34 4
 UP b x35 2
ENDATA
