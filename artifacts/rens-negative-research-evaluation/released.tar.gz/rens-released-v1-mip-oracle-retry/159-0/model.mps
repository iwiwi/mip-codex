NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 G r4
 L r5
 G r6
 L r7
 L r8
 L r9
 G r10
COLUMNS
 x0 obj 7
 x1 obj 3
 x2 obj 4
 x3 obj 2
 x4 obj 7
 x4 r10 1.0
 x5 obj 5
 x6 obj 7
 x7 obj 7
 x8 obj 4
 x9 obj -7
 x9 r1 -256.0
 x9 r2 1.0
 x9 r4 -16.0
 x9 r5 256.0
 x9 r7 1.0
 x9 r8 16.0
 x9 r10 1.0
 x10 obj 7
 x11 obj 5
 x12 obj 2
 x13 obj 4
 x14 obj 3
 x15 obj 9
 x16 obj 6
 x17 obj 4
 x18 obj 3
 x19 obj -7
 x19 r0 0.00390625
 x19 r2 1.0
 x19 r3 -1.0
 x19 r5 256.0
 x19 r6 -0.0625
 x19 r8 16.0
 x19 r9 1.0
 x19 r10 1.0
 x20 obj 7
 x21 obj -7
 x21 r0 0.00390625
 x21 r1 -256.0
 x21 r3 -1.0
 x21 r4 -16.0
 x21 r6 -0.0625
 x21 r7 1.0
 x21 r10 1.0
 x22 obj 2
 x23 obj 8
 x24 obj 7
 x25 obj 6
 x26 obj 0
 x26 r9 2.0
RHS
 rhs obj 8
 rhs r0 0.00390625
 rhs r1 -256.0
 rhs r2 1.0
 rhs r3 -1.0
 rhs r4 -16.0
 rhs r5 256.0
 rhs r6 -0.0625
 rhs r7 1.0
 rhs r8 16.0
 rhs r9 5.0
 rhs r10 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 4
 UP b x26 2
ENDATA
