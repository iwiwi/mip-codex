NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 G r4
 L r5
COLUMNS
 x0 obj -6
 x0 r0 -0.00390625
 x0 r2 -0.0625
 x0 r3 1.0
 x0 r5 1.0
 x1 obj 3
 x2 obj 6
 x3 obj 8
 x4 obj 3
 x5 obj 4
 x6 obj 4
 x7 obj 4
 x8 obj 5
 x9 obj 8
 x10 obj 8
 x11 obj 8
 x12 obj -6
 x12 r0 -0.00390625
 x12 r1 0.0625
 x12 r3 1.0
 x12 r4 -256.0
 x13 obj 6
 x14 obj 3
 x15 obj 3
 x16 obj 8
 x17 obj 2
 x18 obj 2
 x19 obj -6
 x19 r1 0.0625
 x19 r2 -0.0625
 x19 r4 -256.0
 x20 obj 4
 x21 obj 6
 x22 obj 4
 x23 obj 8
 x24 obj 5
 x25 obj 2
 x26 obj 6
 x27 obj 5
 x28 obj 3
 x29 obj 5
 x30 obj 4
 x31 obj 8
 x32 obj 7
 x33 obj 0
 x33 r5 2.0
RHS
 rhs obj 15
 rhs r0 -0.00390625
 rhs r1 0.0625
 rhs r2 -0.0625
 rhs r3 1.0
 rhs r4 -256.0
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 3
 UP b x33 2
ENDATA
