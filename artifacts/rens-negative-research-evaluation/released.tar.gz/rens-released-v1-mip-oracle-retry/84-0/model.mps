NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 G r5
 G r6
 G r7
 L r8
COLUMNS
 x0 obj 8
 x1 obj 8
 x2 obj 2
 x3 obj 5
 x4 obj 2
 x5 obj 4
 x6 obj 6
 x7 obj 2
 x8 obj 4
 x9 obj 9
 x10 obj 4
 x11 obj 3
 x12 obj 3
 x13 obj 3
 x14 obj 8
 x15 obj 7
 x16 obj -2
 x16 r0 1.0
 x16 r2 0.0625
 x16 r3 -0.0625
 x16 r5 -0.0625
 x16 r6 -1.0
 x16 r8 1.0
 x17 obj 9
 x18 obj -2
 x18 r0 1.0
 x18 r1 256.0
 x18 r3 -0.0625
 x18 r4 -16.0
 x18 r6 -1.0
 x18 r7 -256.0
 x19 obj -2
 x19 r1 256.0
 x19 r2 0.0625
 x19 r4 -16.0
 x19 r5 -0.0625
 x19 r7 -256.0
 x20 obj 8
 x21 obj 3
 x22 obj 4
 x23 obj 3
 x24 obj 6
 x25 obj 9
 x26 obj 9
 x27 obj 2
 x28 obj 3
 x29 obj 2
 x30 obj 2
 x31 obj 1
 x32 obj 0
 x32 r8 2.0
RHS
 rhs obj -16
 rhs r0 1.0
 rhs r1 256.0
 rhs r2 0.0625
 rhs r3 -0.0625
 rhs r4 -16.0
 rhs r5 -0.0625
 rhs r6 -1.0
 rhs r7 -256.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 2
 LI b x31 0
 UI b x31 4
 UP b x32 2
ENDATA
