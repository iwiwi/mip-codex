NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 G r4
 L r5
 G r6
 L r7
COLUMNS
 x0 obj 3
 x1 obj -9
 x1 r0 0.00390625
 x1 r2 0.00390625
 x1 r3 0.00390625
 x1 r5 1.0
 x1 r6 -256.0
 x1 r7 1.0
 x2 obj 3
 x3 obj -9
 x3 r0 0.00390625
 x3 r1 16.0
 x3 r3 0.00390625
 x3 r4 -0.0625
 x3 r6 -256.0
 x4 obj 3
 x5 obj 9
 x6 obj 6
 x7 obj 8
 x8 obj 5
 x9 obj 5
 x10 obj 3
 x11 obj 6
 x12 obj 4
 x13 obj 8
 x14 obj 6
 x15 obj 6
 x16 obj 9
 x17 obj 9
 x18 obj 8
 x19 obj 3
 x20 obj -9
 x20 r1 16.0
 x20 r2 0.00390625
 x20 r4 -0.0625
 x20 r5 1.0
 x21 obj 9
 x22 obj 0
 x22 r7 2.0
RHS
 rhs obj -23
 rhs r0 0.00390625
 rhs r1 16.0
 rhs r2 0.00390625
 rhs r3 0.00390625
 rhs r4 -0.0625
 rhs r5 1.0
 rhs r6 -256.0
 rhs r7 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 3
 UP b x22 2
ENDATA
