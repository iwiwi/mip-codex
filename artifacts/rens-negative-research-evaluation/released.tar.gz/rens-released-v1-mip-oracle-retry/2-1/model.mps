NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
COLUMNS
 x0 obj -7
 x1 obj -5
 x2 obj -3
 x3 obj -8
 x4 obj -7
 x5 obj -1
 x6 obj -9
 x7 obj -7
 x8 obj -8
 x9 obj -1
 x10 obj 9
 x10 r0 1.0
 x10 r2 -0.0625
 x10 r3 1.0
 x11 obj 9
 x11 r1 256.0
 x11 r2 -0.0625
 x12 obj -9
 x13 obj -1
 x14 obj -9
 x15 obj -9
 x16 obj 9
 x16 r0 1.0
 x16 r1 256.0
 x17 obj -6
 x18 obj -5
 x19 obj -9
 x20 obj -5
 x21 obj -7
 x22 obj -6
 x23 obj -1
 x24 obj -8
 x25 obj -3
 x26 obj -8
 x27 obj -5
 x28 obj -6
 x29 obj -5
 x30 obj -3
 x31 obj 0
 x31 r3 2.0
RHS
 rhs obj -24
 rhs r0 1.0
 rhs r1 256.0
 rhs r2 -0.0625
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 2
 UP b x31 2
ENDATA
