NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 G r4
 G r5
 L r6
 L r7
 G r8
 L r9
 L r10
 G r11
COLUMNS
 x0 obj -1
 x1 obj -8
 x2 obj -2
 x3 obj -5
 x3 r11 1.0
 x4 obj -3
 x5 obj -6
 x6 obj 2
 x6 r0 1.0
 x6 r1 -256.0
 x6 r3 -256.0
 x6 r4 -0.00390625
 x6 r6 256.0
 x6 r7 256.0
 x6 r9 256.0
 x6 r11 1.0
 x7 obj -3
 x8 obj -6
 x9 obj -5
 x10 obj -3
 x11 obj 2
 x11 r1 -256.0
 x11 r2 0.00390625
 x11 r4 -0.00390625
 x11 r5 -1.0
 x11 r7 256.0
 x11 r8 -0.00390625
 x11 r11 1.0
 x12 obj -5
 x13 obj -1
 x14 obj -3
 x15 obj -4
 x16 obj -8
 x17 obj -6
 x18 obj -4
 x19 obj -6
 x20 obj -8
 x21 obj -9
 x22 obj -4
 x23 obj -3
 x24 obj -1
 x25 obj 2
 x25 r0 1.0
 x25 r2 0.00390625
 x25 r3 -256.0
 x25 r5 -1.0
 x25 r6 256.0
 x25 r8 -0.00390625
 x25 r9 256.0
 x25 r10 1.0
 x25 r11 1.0
 x26 obj -1
 x27 obj -5
 x28 obj -3
 x29 obj -2
 x30 obj 0
 x30 r10 2.0
RHS
 rhs obj 1
 rhs r0 1.0
 rhs r1 -256.0
 rhs r2 0.00390625
 rhs r3 -256.0
 rhs r4 -0.00390625
 rhs r5 -1.0
 rhs r6 256.0
 rhs r7 256.0
 rhs r8 -0.00390625
 rhs r9 256.0
 rhs r10 5.0
 rhs r11 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 1
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 2
 UP b x30 2
ENDATA
