NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 L r6
COLUMNS
 x0 obj -8
 x0 r0 -1.0
 x0 r2 -1.0
 x0 r3 -16.0
 x0 r5 -1.0
 x0 r6 1.0
 x1 obj 9
 x2 obj 4
 x3 obj 7
 x4 obj 6
 x5 obj 3
 x6 obj 3
 x7 obj 3
 x8 obj 3
 x9 obj 9
 x10 obj 3
 x11 obj 1
 x12 obj 3
 x13 obj 7
 x14 obj 5
 x15 obj 2
 x16 obj 1
 x17 obj -8
 x17 r1 -0.00390625
 x17 r2 -1.0
 x17 r4 -16.0
 x17 r5 -1.0
 x18 obj 6
 x19 obj 7
 x20 obj 6
 x21 obj 2
 x22 obj 2
 x23 obj 3
 x24 obj 5
 x25 obj 7
 x26 obj -8
 x26 r0 -1.0
 x26 r1 -0.00390625
 x26 r3 -16.0
 x26 r4 -16.0
 x27 obj 8
 x28 obj 8
 x29 obj 7
 x30 obj 3
 x31 obj 0
 x31 r6 2.0
RHS
 rhs obj -17
 rhs r0 -1.0
 rhs r1 -0.00390625
 rhs r2 -1.0
 rhs r3 -16.0
 rhs r4 -16.0
 rhs r5 -1.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 1
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 4
 UP b x31 2
ENDATA
