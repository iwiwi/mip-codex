NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 G r4
 G r5
 G r6
 L r7
 L r8
COLUMNS
 x0 obj -3
 x1 obj -8
 x2 obj -4
 x3 obj -9
 x4 obj -9
 x5 obj 1
 x5 r0 1.0
 x5 r2 -256.0
 x5 r3 16.0
 x5 r5 -16.0
 x5 r6 -16.0
 x5 r8 1.0
 x6 obj -9
 x7 obj -1
 x8 obj -7
 x9 obj -9
 x10 obj -9
 x11 obj 1
 x11 r1 -0.00390625
 x11 r2 -256.0
 x11 r4 -0.0625
 x11 r5 -16.0
 x11 r7 0.0625
 x12 obj -3
 x13 obj -3
 x14 obj -4
 x15 obj -2
 x16 obj -9
 x17 obj -7
 x18 obj -2
 x19 obj -5
 x20 obj -8
 x21 obj 1
 x21 r0 1.0
 x21 r1 -0.00390625
 x21 r3 16.0
 x21 r4 -0.0625
 x21 r6 -16.0
 x21 r7 0.0625
 x22 obj 0
 x22 r8 2.0
RHS
 rhs obj 1
 rhs r0 1.0
 rhs r1 -0.00390625
 rhs r2 -256.0
 rhs r3 16.0
 rhs r4 -0.0625
 rhs r5 -16.0
 rhs r6 -16.0
 rhs r7 0.0625
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 1
 UP b x22 2
ENDATA
