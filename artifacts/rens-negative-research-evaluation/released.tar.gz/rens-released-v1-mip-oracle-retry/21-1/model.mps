NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 G r4
COLUMNS
 x0 obj -5
 x1 obj 1
 x1 r0 256.0
 x1 r2 -1.0
 x1 r3 1.0
 x1 r4 1.0
 x2 obj -3
 x3 obj -3
 x4 obj -3
 x5 obj -3
 x6 obj -1
 x7 obj -2
 x8 obj -8
 x9 obj -5
 x10 obj -5
 x11 obj -9
 x12 obj -5
 x13 obj -3
 x14 obj -2
 x15 obj -6
 x16 obj -7
 x16 r4 1.0
 x17 obj -8
 x18 obj -3
 x19 obj -7
 x20 obj -4
 x21 obj -8
 x22 obj -8
 x23 obj -8
 x24 obj -3
 x25 obj -6
 x26 obj 1
 x26 r1 -1.0
 x26 r2 -1.0
 x26 r4 1.0
 x27 obj -5
 x28 obj 1
 x28 r0 256.0
 x28 r1 -1.0
 x28 r4 1.0
 x29 obj 0
 x29 r3 2.0
RHS
 rhs obj 23
 rhs r0 256.0
 rhs r1 -1.0
 rhs r2 -1.0
 rhs r3 5.0
 rhs r4 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 1
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 1
 UP b x29 2
ENDATA
