NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 L r4
 G r5
 G r6
 G r7
 G r8
 G r9
 L r10
 G r11
COLUMNS
 x0 obj 7
 x1 obj 3
 x2 obj 8
 x3 obj 9
 x4 obj 3
 x5 obj 2
 x6 obj -1
 x6 r0 -0.00390625
 x6 r2 -0.0625
 x6 r3 -0.0625
 x6 r5 -0.0625
 x6 r6 -16.0
 x6 r8 -1.0
 x6 r9 -16.0
 x6 r10 1.0
 x6 r11 1.0
 x7 obj 2
 x8 obj 7
 x9 obj 2
 x10 obj 4
 x10 r11 1.0
 x11 obj 4
 x12 obj 8
 x13 obj -1
 x13 r1 -256.0
 x13 r2 -0.0625
 x13 r4 16.0
 x13 r5 -0.0625
 x13 r7 -0.00390625
 x13 r8 -1.0
 x13 r11 1.0
 x14 obj 9
 x15 obj 6
 x16 obj 2
 x17 obj 1
 x18 obj 9
 x19 obj 7
 x20 obj 6
 x21 obj 1
 x22 obj 4
 x23 obj -1
 x23 r0 -0.00390625
 x23 r1 -256.0
 x23 r3 -0.0625
 x23 r4 16.0
 x23 r6 -16.0
 x23 r7 -0.00390625
 x23 r9 -16.0
 x23 r11 1.0
 x24 obj 0
 x24 r10 2.0
RHS
 rhs obj -4
 rhs r0 -0.00390625
 rhs r1 -256.0
 rhs r2 -0.0625
 rhs r3 -0.0625
 rhs r4 16.0
 rhs r5 -0.0625
 rhs r6 -16.0
 rhs r7 -0.00390625
 rhs r8 -1.0
 rhs r9 -16.0
 rhs r10 5.0
 rhs r11 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 1
 UP b x24 2
ENDATA
