NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 L r4
 G r5
 L r6
 L r7
 L r8
COLUMNS
 x0 obj -9
 x1 obj -4
 x2 obj -4
 x3 obj -8
 x4 obj -9
 x5 obj -7
 x6 obj -6
 x7 obj -6
 x8 obj -9
 x9 obj -4
 x10 obj -9
 x11 obj -1
 x12 obj -5
 x13 obj -1
 x14 obj -3
 x15 obj -7
 x16 obj -5
 x17 obj 4
 x17 r0 -16.0
 x17 r1 1.0
 x17 r3 -0.00390625
 x17 r4 0.0625
 x17 r6 0.00390625
 x17 r7 16.0
 x18 obj -1
 x19 obj -1
 x20 obj -6
 x21 obj -1
 x22 obj 4
 x22 r0 -16.0
 x22 r2 -16.0
 x22 r3 -0.00390625
 x22 r5 -0.0625
 x22 r6 0.00390625
 x22 r8 1.0
 x23 obj -9
 x24 obj -9
 x25 obj -3
 x26 obj -3
 x27 obj -6
 x28 obj -4
 x29 obj -2
 x30 obj -2
 x31 obj -5
 x32 obj 4
 x32 r1 1.0
 x32 r2 -16.0
 x32 r4 0.0625
 x32 r5 -0.0625
 x32 r7 16.0
 x33 obj -3
 x34 obj 0
 x34 r8 2.0
RHS
 rhs obj -26
 rhs r0 -16.0
 rhs r1 1.0
 rhs r2 -16.0
 rhs r3 -0.00390625
 rhs r4 0.0625
 rhs r5 -0.0625
 rhs r6 0.00390625
 rhs r7 16.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 2
 LI b x32 0
 UI b x32 1
 LI b x33 0
 UI b x33 2
 UP b x34 2
ENDATA
