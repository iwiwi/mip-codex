NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
 L r4
 L r5
 L r6
 G r7
 G r8
 G r9
 L r10
COLUMNS
 x0 obj -3
 x1 obj -5
 x2 obj -7
 x3 obj -8
 x4 obj -9
 x5 obj -8
 x6 obj -6
 x7 obj -3
 x8 obj -1
 x9 obj -7
 x10 obj -1
 x11 obj 4
 x11 r1 -256.0
 x11 r2 -0.00390625
 x11 r4 1.0
 x11 r5 256.0
 x11 r7 -0.0625
 x11 r8 -1.0
 x12 obj 4
 x12 r0 -256.0
 x12 r2 -0.00390625
 x12 r3 0.00390625
 x12 r5 256.0
 x12 r6 256.0
 x12 r8 -1.0
 x12 r9 -256.0
 x12 r10 1.0
 x13 obj -1
 x14 obj -8
 x15 obj -7
 x16 obj -7
 x17 obj -7
 x18 obj -7
 x19 obj -9
 x20 obj -3
 x21 obj -9
 x22 obj 4
 x22 r0 -256.0
 x22 r1 -256.0
 x22 r3 0.00390625
 x22 r4 1.0
 x22 r6 256.0
 x22 r7 -0.0625
 x22 r9 -256.0
 x23 obj -8
 x24 obj -3
 x25 obj -8
 x26 obj -5
 x27 obj 0
 x27 r10 2.0
RHS
 rhs obj 11
 rhs r0 -256.0
 rhs r1 -256.0
 rhs r2 -0.00390625
 rhs r3 0.00390625
 rhs r4 1.0
 rhs r5 256.0
 rhs r6 256.0
 rhs r7 -0.0625
 rhs r8 -1.0
 rhs r9 -256.0
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 3
 UP b x27 2
ENDATA
