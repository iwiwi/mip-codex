NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 G r3
 G r4
 L r5
 L r6
 L r7
 G r8
COLUMNS
 x0 obj -6
 x1 obj 2
 x1 r0 0.0625
 x1 r1 0.00390625
 x1 r3 -16.0
 x1 r4 -0.00390625
 x1 r6 16.0
 x1 r8 1.0
 x2 obj -9
 x3 obj -2
 x4 obj -4
 x5 obj -8
 x6 obj -3
 x7 obj -2
 x8 obj -6
 x9 obj -5
 x10 obj -6
 x11 obj -2
 x12 obj 2
 x12 r1 0.00390625
 x12 r2 16.0
 x12 r4 -0.00390625
 x12 r5 16.0
 x12 r8 1.0
 x13 obj -6
 x14 obj 2
 x14 r0 0.0625
 x14 r2 16.0
 x14 r3 -16.0
 x14 r5 16.0
 x14 r6 16.0
 x14 r7 1.0
 x14 r8 1.0
 x15 obj -9
 x16 obj -8
 x17 obj -7
 x17 r8 1.0
 x18 obj -3
 x19 obj -9
 x20 obj -2
 x21 obj -4
 x22 obj 0
 x22 r7 2.0
RHS
 rhs obj 22
 rhs r0 0.0625
 rhs r1 0.00390625
 rhs r2 16.0
 rhs r3 -16.0
 rhs r4 -0.00390625
 rhs r5 16.0
 rhs r6 16.0
 rhs r7 5.0
 rhs r8 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 UP b x22 2
ENDATA
