NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj -6
 x1 obj -3
 x2 obj -8
 x3 obj 7
 x3 r0 16.0
 x3 r2 1.0
 x3 r3 1.0
 x4 obj -9
 x5 obj -9
 x6 obj -2
 x7 obj -6
 x8 obj 7
 x8 r1 256.0
 x8 r2 1.0
 x9 obj -2
 x10 obj -7
 x11 obj -5
 x12 obj 7
 x12 r0 16.0
 x12 r1 256.0
 x13 obj -6
 x14 obj -4
 x15 obj -4
 x16 obj -9
 x17 obj -5
 x18 obj -1
 x19 obj -1
 x20 obj -4
 x21 obj -9
 x22 obj -5
 x23 obj -6
 x24 obj -3
 x25 obj -9
 x26 obj -7
 x27 obj 0
 x27 r3 2.0
RHS
 rhs obj 25
 rhs r0 16.0
 rhs r1 256.0
 rhs r2 1.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 UP b x27 2
ENDATA
