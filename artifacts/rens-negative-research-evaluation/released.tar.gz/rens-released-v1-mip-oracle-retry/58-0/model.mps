NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj 1
 x1 obj 1
 x2 obj -9
 x2 r0 0.00390625
 x2 r2 256.0
 x2 r3 1.0
 x3 obj 6
 x4 obj 2
 x5 obj 5
 x6 obj 9
 x7 obj 2
 x8 obj 7
 x9 obj 9
 x10 obj 5
 x11 obj 6
 x12 obj 6
 x13 obj 2
 x14 obj -9
 x14 r1 0.00390625
 x14 r2 256.0
 x15 obj -9
 x15 r0 0.00390625
 x15 r1 0.00390625
 x16 obj 2
 x17 obj 9
 x18 obj 9
 x19 obj 5
 x20 obj 9
 x21 obj 2
 x22 obj 7
 x23 obj 8
 x24 obj 2
 x25 obj 7
 x26 obj 8
 x27 obj 4
 x28 obj 5
 x29 obj 5
 x30 obj 7
 x31 obj 6
 x32 obj 9
 x33 obj 3
 x34 obj 0
 x34 r3 2.0
RHS
 rhs obj -10
 rhs r0 0.00390625
 rhs r1 0.00390625
 rhs r2 256.0
 rhs r3 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 1
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 2
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 2
 UP b x34 2
ENDATA
