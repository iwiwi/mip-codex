NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 G r4
 L r5
 G r6
 G r7
 L r8
 G r9
 L r10
COLUMNS
 x0 obj 6
 x1 obj 7
 x2 obj -4
 x2 r0 -0.0625
 x2 r2 -16.0
 x2 r3 -0.00390625
 x2 r5 1.0
 x2 r6 -1.0
 x2 r8 0.0625
 x2 r9 -1.0
 x2 r10 1.0
 x3 obj -4
 x3 r0 -0.0625
 x3 r1 0.00390625
 x3 r3 -0.00390625
 x3 r4 -1.0
 x3 r6 -1.0
 x3 r7 -1.0
 x3 r9 -1.0
 x4 obj 5
 x5 obj 9
 x6 obj 9
 x7 obj 9
 x8 obj 6
 x9 obj 8
 x10 obj 3
 x11 obj -4
 x11 r1 0.00390625
 x11 r2 -16.0
 x11 r4 -1.0
 x11 r5 1.0
 x11 r7 -1.0
 x11 r8 0.0625
 x12 obj 2
 x13 obj 2
 x14 obj 2
 x15 obj 5
 x16 obj 4
 x17 obj 7
 x18 obj 5
 x19 obj 3
 x20 obj 1
 x21 obj 8
 x22 obj 5
 x23 obj 5
 x24 obj 0
 x24 r10 2.0
RHS
 rhs obj 26
 rhs r0 -0.0625
 rhs r1 0.00390625
 rhs r2 -16.0
 rhs r3 -0.00390625
 rhs r4 -1.0
 rhs r5 1.0
 rhs r6 -1.0
 rhs r7 -1.0
 rhs r8 0.0625
 rhs r9 -1.0
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 UP b x24 2
ENDATA
