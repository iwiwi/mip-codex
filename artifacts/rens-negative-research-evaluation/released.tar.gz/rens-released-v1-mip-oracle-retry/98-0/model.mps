NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 L r4
COLUMNS
 x0 obj 2
 x1 obj -2
 x1 r0 0.00390625
 x1 r1 16.0
 x1 r3 0.00390625
 x2 obj -2
 x2 r1 16.0
 x2 r2 -0.0625
 x3 obj 8
 x4 obj 3
 x5 obj 4
 x6 obj 4
 x7 obj 5
 x8 obj 4
 x9 obj -2
 x9 r0 0.00390625
 x9 r2 -0.0625
 x9 r3 0.00390625
 x9 r4 1.0
 x10 obj 6
 x11 obj 8
 x12 obj 7
 x13 obj 6
 x14 obj 6
 x15 obj 8
 x16 obj 5
 x17 obj 4
 x18 obj 0
 x18 r4 2.0
RHS
 rhs obj 25
 rhs r0 0.00390625
 rhs r1 16.0
 rhs r2 -0.0625
 rhs r3 0.00390625
 rhs r4 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 UP b x18 2
ENDATA
