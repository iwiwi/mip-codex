NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 G r4
 G r5
 L r6
COLUMNS
 x0 obj -1
 x0 r0 -1.0
 x0 r1 0.0625
 x0 r3 16.0
 x0 r4 -0.00390625
 x1 obj 2
 x2 obj 2
 x3 obj 2
 x4 obj 2
 x5 obj 4
 x6 obj 6
 x7 obj 5
 x8 obj 2
 x9 obj 6
 x10 obj 5
 x11 obj 1
 x12 obj -1
 x12 r0 -1.0
 x12 r2 -0.0625
 x12 r3 16.0
 x12 r5 -16.0
 x12 r6 1.0
 x13 obj 9
 x14 obj 7
 x15 obj 9
 x16 obj 2
 x17 obj 8
 x18 obj -1
 x18 r1 0.0625
 x18 r2 -0.0625
 x18 r4 -0.00390625
 x18 r5 -16.0
 x19 obj 4
 x20 obj 1
 x21 obj 6
 x22 obj 7
 x23 obj 7
 x24 obj 9
 x25 obj 4
 x26 obj 1
 x27 obj 2
 x28 obj 6
 x29 obj 2
 x30 obj 9
 x31 obj 6
 x32 obj 4
 x33 obj 0
 x33 r6 2.0
RHS
 rhs obj -4
 rhs r0 -1.0
 rhs r1 0.0625
 rhs r2 -0.0625
 rhs r3 16.0
 rhs r4 -0.00390625
 rhs r5 -16.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 4
 LI b x32 0
 UI b x32 2
 UP b x33 2
ENDATA
