NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 G r4
 L r5
 G r6
 L r7
 L r8
 L r9
COLUMNS
 x0 obj 3
 x0 r0 256.0
 x0 r2 0.0625
 x0 r3 16.0
 x0 r5 1.0
 x0 r6 -256.0
 x0 r8 0.0625
 x0 r9 1.0
 x1 obj -4
 x2 obj -5
 x3 obj -8
 x4 obj -1
 x5 obj 3
 x5 r1 -1.0
 x5 r2 0.0625
 x5 r4 -0.0625
 x5 r5 1.0
 x5 r7 1.0
 x5 r8 0.0625
 x6 obj -5
 x7 obj -9
 x8 obj -8
 x9 obj -9
 x10 obj -7
 x11 obj -6
 x12 obj -3
 x13 obj -1
 x14 obj -4
 x15 obj -2
 x16 obj -9
 x17 obj -6
 x18 obj 3
 x18 r0 256.0
 x18 r1 -1.0
 x18 r3 16.0
 x18 r4 -0.0625
 x18 r6 -256.0
 x18 r7 1.0
 x19 obj -2
 x20 obj -4
 x21 obj -6
 x22 obj -9
 x23 obj -7
 x24 obj -5
 x25 obj -9
 x26 obj -4
 x27 obj -9
 x28 obj -2
 x29 obj -6
 x30 obj -3
 x31 obj -3
 x32 obj -7
 x33 obj -1
 x34 obj -5
 x35 obj 0
 x35 r9 2.0
RHS
 rhs obj -5
 rhs r0 256.0
 rhs r1 -1.0
 rhs r2 0.0625
 rhs r3 16.0
 rhs r4 -0.0625
 rhs r5 1.0
 rhs r6 -256.0
 rhs r7 1.0
 rhs r8 0.0625
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 1
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 4
 LI b x32 0
 UI b x32 3
 LI b x33 0
 UI b x33 3
 LI b x34 0
 UI b x34 4
 UP b x35 2
ENDATA
