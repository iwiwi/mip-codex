NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 L r4
COLUMNS
 x0 obj 8
 x1 obj 6
 x2 obj 8
 x3 obj 3
 x4 obj 2
 x5 obj 8
 x6 obj 3
 x7 obj 8
 x8 obj 3
 x9 obj 9
 x10 obj 7
 x11 obj -9
 x11 r1 0.00390625
 x11 r2 -0.0625
 x12 obj 8
 x13 obj 1
 x14 obj 2
 x15 obj 4
 x16 obj 2
 x17 obj 4
 x18 obj 5
 x19 obj -9
 x19 r0 256.0
 x19 r2 -0.0625
 x19 r3 1.0
 x19 r4 1.0
 x20 obj -9
 x20 r0 256.0
 x20 r1 0.00390625
 x20 r3 1.0
 x21 obj 1
 x22 obj 4
 x23 obj 4
 x24 obj 2
 x25 obj 3
 x26 obj 9
 x27 obj 8
 x28 obj 0
 x28 r4 2.0
RHS
 rhs obj 2
 rhs r0 256.0
 rhs r1 0.00390625
 rhs r2 -0.0625
 rhs r3 1.0
 rhs r4 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 2
 UP b x28 2
ENDATA
