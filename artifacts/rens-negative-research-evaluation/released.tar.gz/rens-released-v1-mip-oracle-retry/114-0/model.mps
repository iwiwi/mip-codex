NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 G r4
 G r5
 L r6
 G r7
 G r8
 L r9
COLUMNS
 x0 obj 3
 x1 obj 5
 x2 obj -6
 x2 r0 0.0625
 x2 r1 1.0
 x2 r3 0.00390625
 x2 r4 -16.0
 x2 r6 256.0
 x2 r7 -256.0
 x3 obj 7
 x4 obj 4
 x5 obj 3
 x6 obj 7
 x7 obj 4
 x8 obj -6
 x8 r0 0.0625
 x8 r2 -1.0
 x8 r3 0.00390625
 x8 r5 -256.0
 x8 r6 256.0
 x8 r8 -16.0
 x8 r9 1.0
 x9 obj 8
 x10 obj 4
 x11 obj 8
 x12 obj -6
 x12 r1 1.0
 x12 r2 -1.0
 x12 r4 -16.0
 x12 r5 -256.0
 x12 r7 -256.0
 x12 r8 -16.0
 x13 obj 2
 x14 obj 7
 x15 obj 7
 x16 obj 5
 x17 obj 8
 x18 obj 5
 x19 obj 5
 x20 obj 4
 x21 obj 0
 x21 r9 2.0
RHS
 rhs obj 26
 rhs r0 0.0625
 rhs r1 1.0
 rhs r2 -1.0
 rhs r3 0.00390625
 rhs r4 -16.0
 rhs r5 -256.0
 rhs r6 256.0
 rhs r7 -256.0
 rhs r8 -16.0
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 1
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 UP b x21 2
ENDATA
