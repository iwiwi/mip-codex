NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 G r4
 L r5
COLUMNS
 x0 obj 9
 x1 obj 7
 x2 obj 5
 x3 obj 5
 x4 obj 4
 x5 obj 1
 x6 obj 3
 x7 obj 5
 x8 obj 1
 x9 obj 7
 x10 obj 4
 x11 obj 3
 x12 obj 1
 x13 obj 5
 x14 obj 8
 x15 obj 3
 x16 obj 1
 x17 obj 2
 x18 obj -3
 x18 r0 -256.0
 x18 r1 1.0
 x18 r3 1.0
 x18 r4 -0.00390625
 x19 obj 9
 x20 obj 1
 x21 obj 5
 x22 obj 9
 x23 obj 1
 x24 obj 9
 x25 obj 1
 x26 obj 9
 x27 obj -3
 x27 r1 1.0
 x27 r2 1.0
 x27 r4 -0.00390625
 x28 obj -3
 x28 r0 -256.0
 x28 r2 1.0
 x28 r3 1.0
 x28 r5 1.0
 x29 obj 5
 x30 obj 5
 x31 obj 5
 x32 obj 9
 x33 obj 6
 x34 obj 9
 x35 obj 0
 x35 r5 2.0
RHS
 rhs obj 0
 rhs r0 -256.0
 rhs r1 1.0
 rhs r2 1.0
 rhs r3 1.0
 rhs r4 -0.00390625
 rhs r5 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 1
 LI b x28 0
 UI b x28 1
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 4
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 2
 LI b x34 0
 UI b x34 2
 UP b x35 2
ENDATA
