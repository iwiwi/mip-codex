NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 L r4
 L r5
 L r6
 G r7
 L r8
 G r9
COLUMNS
 x0 obj -2
 x1 obj -3
 x2 obj -3
 x3 obj -9
 x4 obj -3
 x5 obj -4
 x6 obj -5
 x7 obj -5
 x7 r9 1.0
 x8 obj -7
 x9 obj -1
 x10 obj -1
 x11 obj -8
 x12 obj -8
 x13 obj -1
 x14 obj -2
 x15 obj -3
 x16 obj -8
 x17 obj -1
 x18 obj -7
 x19 obj -2
 x20 obj -9
 x21 obj -1
 x22 obj 3
 x22 r0 -0.0625
 x22 r1 1.0
 x22 r3 -0.00390625
 x22 r4 256.0
 x22 r6 0.0625
 x22 r7 -256.0
 x22 r9 1.0
 x23 obj -3
 x24 obj 3
 x24 r0 -0.0625
 x24 r2 256.0
 x24 r3 -0.00390625
 x24 r5 1.0
 x24 r6 0.0625
 x24 r8 1.0
 x24 r9 1.0
 x25 obj -8
 x26 obj -6
 x27 obj -5
 x28 obj -1
 x29 obj -9
 x30 obj -1
 x31 obj -6
 x32 obj 3
 x32 r1 1.0
 x32 r2 256.0
 x32 r4 256.0
 x32 r5 1.0
 x32 r7 -256.0
 x32 r9 1.0
 x33 obj 0
 x33 r8 2.0
RHS
 rhs obj 9
 rhs r0 -0.0625
 rhs r1 1.0
 rhs r2 256.0
 rhs r3 -0.00390625
 rhs r4 256.0
 rhs r5 1.0
 rhs r6 0.0625
 rhs r7 -256.0
 rhs r8 5.0
 rhs r9 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 1
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 1
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 3
 LI b x32 0
 UI b x32 1
 UP b x33 2
ENDATA
