NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 G r4
 L r5
 G r6
 L r7
 L r8
 L r9
 G r10
COLUMNS
 x0 obj 8
 x1 obj 1
 x2 obj 2
 x3 obj 7
 x4 obj 3
 x5 obj 4
 x6 obj 6
 x7 obj 9
 x8 obj 4
 x9 obj 5
 x10 obj 3
 x11 obj 8
 x12 obj 4
 x13 obj 9
 x14 obj 4
 x15 obj -9
 x15 r0 0.00390625
 x15 r2 16.0
 x15 r3 1.0
 x15 r5 256.0
 x15 r6 -0.00390625
 x15 r8 16.0
 x15 r9 1.0
 x15 r10 1.0
 x16 obj -9
 x16 r0 0.00390625
 x16 r1 -256.0
 x16 r3 1.0
 x16 r4 -256.0
 x16 r6 -0.00390625
 x16 r7 0.00390625
 x16 r10 1.0
 x17 obj 5
 x18 obj 1
 x19 obj 3
 x20 obj 4
 x21 obj -9
 x21 r1 -256.0
 x21 r2 16.0
 x21 r4 -256.0
 x21 r5 256.0
 x21 r7 0.00390625
 x21 r8 16.0
 x21 r10 1.0
 x22 obj 8
 x23 obj 4
 x24 obj 7
 x25 obj 9
 x26 obj 1
 x27 obj 4
 x28 obj 6
 x28 r10 1.0
 x29 obj 0
 x29 r9 2.0
RHS
 rhs obj -4
 rhs r0 0.00390625
 rhs r1 -256.0
 rhs r2 16.0
 rhs r3 1.0
 rhs r4 -256.0
 rhs r5 256.0
 rhs r6 -0.00390625
 rhs r7 0.00390625
 rhs r8 16.0
 rhs r9 5.0
 rhs r10 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 4
 UP b x29 2
ENDATA
