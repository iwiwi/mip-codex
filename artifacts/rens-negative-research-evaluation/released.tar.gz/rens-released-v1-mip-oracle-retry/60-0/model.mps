NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 L r4
 G r5
 G r6
 L r7
 L r8
 G r9
 L r10
COLUMNS
 x0 obj 8
 x1 obj 8
 x2 obj 9
 x3 obj 5
 x4 obj 1
 x5 obj 4
 x6 obj 1
 x7 obj 1
 x8 obj 1
 x9 obj 3
 x10 obj -8
 x10 r0 -0.00390625
 x10 r2 -256.0
 x10 r3 -0.0625
 x10 r5 -0.00390625
 x10 r6 -16.0
 x10 r8 16.0
 x10 r9 -16.0
 x10 r10 1.0
 x11 obj 7
 x12 obj -8
 x12 r0 -0.00390625
 x12 r1 16.0
 x12 r3 -0.0625
 x12 r4 0.00390625
 x12 r6 -16.0
 x12 r7 256.0
 x12 r9 -16.0
 x13 obj 4
 x14 obj 5
 x15 obj -8
 x15 r1 16.0
 x15 r2 -256.0
 x15 r4 0.00390625
 x15 r5 -0.00390625
 x15 r7 256.0
 x15 r8 16.0
 x16 obj 5
 x17 obj 2
 x18 obj 6
 x19 obj 4
 x20 obj 9
 x21 obj 6
 x22 obj 7
 x23 obj 2
 x24 obj 5
 x25 obj 0
 x25 r10 2.0
RHS
 rhs obj 6
 rhs r0 -0.00390625
 rhs r1 16.0
 rhs r2 -256.0
 rhs r3 -0.0625
 rhs r4 0.00390625
 rhs r5 -0.00390625
 rhs r6 -16.0
 rhs r7 256.0
 rhs r8 16.0
 rhs r9 -16.0
 rhs r10 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 UP b x25 2
ENDATA
