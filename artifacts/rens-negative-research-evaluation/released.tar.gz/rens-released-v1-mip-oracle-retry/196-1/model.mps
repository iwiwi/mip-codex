NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 G r4
 G r5
 L r6
 G r7
 L r8
COLUMNS
 x0 obj -4
 x1 obj 5
 x1 r0 1.0
 x1 r2 -0.00390625
 x1 r3 -0.00390625
 x1 r5 -16.0
 x1 r6 0.00390625
 x1 r8 1.0
 x2 obj -7
 x3 obj -1
 x4 obj -6
 x5 obj -1
 x6 obj -4
 x7 obj -6
 x8 obj -5
 x9 obj -3
 x10 obj 5
 x10 r1 0.0625
 x10 r2 -0.00390625
 x10 r4 -1.0
 x10 r5 -16.0
 x10 r7 -256.0
 x11 obj -4
 x12 obj -4
 x13 obj -2
 x14 obj -2
 x15 obj -1
 x16 obj -3
 x17 obj -4
 x18 obj -3
 x19 obj -3
 x20 obj -6
 x21 obj -8
 x22 obj -2
 x23 obj -4
 x24 obj -7
 x25 obj -5
 x26 obj 5
 x26 r0 1.0
 x26 r1 0.0625
 x26 r3 -0.00390625
 x26 r4 -1.0
 x26 r6 0.00390625
 x26 r7 -256.0
 x27 obj -3
 x28 obj -8
 x29 obj 0
 x29 r8 2.0
RHS
 rhs obj -23
 rhs r0 1.0
 rhs r1 0.0625
 rhs r2 -0.00390625
 rhs r3 -0.00390625
 rhs r4 -1.0
 rhs r5 -16.0
 rhs r6 0.00390625
 rhs r7 -256.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 1
 LI b x27 0
 UI b x27 3
 LI b x28 0
 UI b x28 3
 UP b x29 2
ENDATA
