NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 L r4
 G r5
 L r6
 G r7
 L r8
 G r9
COLUMNS
 x0 obj -7
 x1 obj -2
 x2 obj -8
 x3 obj -2
 x4 obj -8
 x5 obj -8
 x6 obj -1
 x7 obj -3
 x8 obj -9
 x9 obj -4
 x10 obj -3
 x11 obj 7
 x11 r1 0.00390625
 x11 r2 1.0
 x11 r4 16.0
 x11 r5 -0.00390625
 x11 r7 -256.0
 x11 r9 1.0
 x12 obj -9
 x13 obj -1
 x14 obj -5
 x15 obj -1
 x15 r9 1.0
 x16 obj -6
 x17 obj -4
 x18 obj -2
 x19 obj -8
 x20 obj 7
 x20 r0 -256.0
 x20 r2 1.0
 x20 r3 -1.0
 x20 r5 -0.00390625
 x20 r6 0.00390625
 x20 r8 1.0
 x20 r9 1.0
 x21 obj -6
 x22 obj -5
 x23 obj -3
 x24 obj -7
 x25 obj -4
 x26 obj -5
 x27 obj -7
 x28 obj -5
 x29 obj -6
 x30 obj 7
 x30 r0 -256.0
 x30 r1 0.00390625
 x30 r3 -1.0
 x30 r4 16.0
 x30 r6 0.00390625
 x30 r7 -256.0
 x30 r9 1.0
 x31 obj -4
 x32 obj -1
 x33 obj -5
 x34 obj 0
 x34 r8 2.0
RHS
 rhs obj -6
 rhs r0 -256.0
 rhs r1 0.00390625
 rhs r2 1.0
 rhs r3 -1.0
 rhs r4 16.0
 rhs r5 -0.00390625
 rhs r6 0.00390625
 rhs r7 -256.0
 rhs r8 5.0
 rhs r9 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 1
 LI b x31 0
 UI b x31 4
 LI b x32 0
 UI b x32 2
 LI b x33 0
 UI b x33 3
 UP b x34 2
ENDATA
