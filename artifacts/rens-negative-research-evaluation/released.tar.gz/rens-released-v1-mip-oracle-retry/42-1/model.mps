NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 L r4
 L r5
 L r6
 L r7
 L r8
COLUMNS
 x0 obj -9
 x1 obj -1
 x2 obj -1
 x3 obj 6
 x3 r1 0.0625
 x3 r2 1.0
 x3 r4 1.0
 x3 r5 0.0625
 x3 r7 0.0625
 x4 obj 6
 x4 r0 -256.0
 x4 r1 0.0625
 x4 r3 -1.0
 x4 r4 1.0
 x4 r6 16.0
 x4 r7 0.0625
 x5 obj -8
 x6 obj -3
 x7 obj -2
 x8 obj -9
 x9 obj 6
 x9 r0 -256.0
 x9 r2 1.0
 x9 r3 -1.0
 x9 r5 0.0625
 x9 r6 16.0
 x9 r8 1.0
 x10 obj -3
 x11 obj -7
 x12 obj -3
 x13 obj -5
 x14 obj -1
 x15 obj -2
 x16 obj -3
 x17 obj -2
 x18 obj -8
 x19 obj -9
 x20 obj 0
 x20 r8 2.0
RHS
 rhs obj 0
 rhs r0 -256.0
 rhs r1 0.0625
 rhs r2 1.0
 rhs r3 -1.0
 rhs r4 1.0
 rhs r5 0.0625
 rhs r6 16.0
 rhs r7 0.0625
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 UP b x20 2
ENDATA
