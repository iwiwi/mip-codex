NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 G r3
 L r4
 G r5
 L r6
 L r7
 L r8
 L r9
 G r10
COLUMNS
 x0 obj 5
 x1 obj 4
 x2 obj 6
 x3 obj -5
 x3 r0 -1.0
 x3 r1 -1.0
 x3 r3 -16.0
 x3 r4 256.0
 x3 r6 16.0
 x3 r7 0.0625
 x3 r10 1.0
 x4 obj 3
 x5 obj 4
 x6 obj 4
 x7 obj 5
 x8 obj 8
 x9 obj 2
 x10 obj 4
 x11 obj 1
 x12 obj -5
 x12 r1 -1.0
 x12 r2 16.0
 x12 r4 256.0
 x12 r5 -1.0
 x12 r7 0.0625
 x12 r8 1.0
 x12 r10 1.0
 x13 obj 5
 x14 obj 6
 x15 obj 7
 x16 obj 3
 x17 obj 4
 x18 obj 6
 x19 obj -5
 x19 r0 -1.0
 x19 r2 16.0
 x19 r3 -16.0
 x19 r5 -1.0
 x19 r6 16.0
 x19 r8 1.0
 x19 r9 1.0
 x19 r10 1.0
 x20 obj 2
 x21 obj 6
 x22 obj 8
 x23 obj 2
 x24 obj 5
 x25 obj 1
 x25 r10 1.0
 x26 obj 0
 x26 r9 2.0
RHS
 rhs obj 17
 rhs r0 -1.0
 rhs r1 -1.0
 rhs r2 16.0
 rhs r3 -16.0
 rhs r4 256.0
 rhs r5 -1.0
 rhs r6 16.0
 rhs r7 0.0625
 rhs r8 1.0
 rhs r9 5.0
 rhs r10 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 4
 UP b x26 2
ENDATA
