NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 G r4
 G r5
 L r6
 G r7
 L r8
COLUMNS
 x0 obj 6
 x1 obj 8
 x2 obj 3
 x3 obj -1
 x3 r0 -256.0
 x3 r2 0.0625
 x3 r3 1.0
 x3 r5 -16.0
 x3 r6 0.00390625
 x3 r8 1.0
 x4 obj 2
 x5 obj 3
 x6 obj 8
 x7 obj 3
 x8 obj 8
 x9 obj 1
 x10 obj 1
 x11 obj -1
 x11 r1 16.0
 x11 r2 0.0625
 x11 r4 -16.0
 x11 r5 -16.0
 x11 r7 -1.0
 x12 obj 3
 x13 obj 9
 x14 obj 9
 x15 obj 1
 x16 obj -1
 x16 r0 -256.0
 x16 r1 16.0
 x16 r3 1.0
 x16 r4 -16.0
 x16 r6 0.00390625
 x16 r7 -1.0
 x17 obj 4
 x18 obj 8
 x19 obj 3
 x20 obj 9
 x21 obj 0
 x21 r8 2.0
RHS
 rhs obj 18
 rhs r0 -256.0
 rhs r1 16.0
 rhs r2 0.0625
 rhs r3 1.0
 rhs r4 -16.0
 rhs r5 -16.0
 rhs r6 0.00390625
 rhs r7 -1.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 UP b x21 2
ENDATA
