NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 G r3
 L r4
 G r5
COLUMNS
 x0 obj -8
 x1 obj -8
 x2 obj -8
 x2 r5 1.0
 x3 obj -8
 x4 obj 2
 x4 r1 -16.0
 x4 r2 0.00390625
 x4 r5 1.0
 x5 obj -7
 x6 obj -6
 x7 obj 2
 x7 r0 -16.0
 x7 r2 0.00390625
 x7 r3 -0.0625
 x7 r4 1.0
 x7 r5 1.0
 x8 obj -6
 x9 obj -1
 x10 obj -5
 x11 obj -7
 x12 obj -4
 x13 obj -1
 x14 obj -1
 x15 obj -8
 x16 obj -2
 x17 obj -7
 x18 obj -8
 x19 obj -6
 x20 obj -6
 x21 obj 2
 x21 r0 -16.0
 x21 r1 -16.0
 x21 r3 -0.0625
 x21 r5 1.0
 x22 obj -4
 x23 obj 0
 x23 r4 2.0
RHS
 rhs obj 26
 rhs r0 -16.0
 rhs r1 -16.0
 rhs r2 0.00390625
 rhs r3 -0.0625
 rhs r4 5.0
 rhs r5 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 4
 UP b x23 2
ENDATA
