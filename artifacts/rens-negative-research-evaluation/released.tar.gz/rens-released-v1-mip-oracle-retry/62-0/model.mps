NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
 G r4
 L r5
 G r6
 L r7
 L r8
 L r9
COLUMNS
 x0 obj 1
 x1 obj 8
 x2 obj 4
 x3 obj 4
 x4 obj 2
 x5 obj 1
 x6 obj 1
 x7 obj 6
 x8 obj 1
 x9 obj 4
 x10 obj 6
 x11 obj 7
 x12 obj 5
 x13 obj 1
 x14 obj 7
 x15 obj 1
 x16 obj 7
 x17 obj 1
 x18 obj 9
 x19 obj 8
 x20 obj 5
 x21 obj 5
 x22 obj 2
 x23 obj 4
 x24 obj 8
 x25 obj 6
 x26 obj -9
 x26 r0 -0.00390625
 x26 r2 -0.0625
 x26 r3 1.0
 x26 r5 0.0625
 x26 r6 -0.0625
 x26 r8 16.0
 x26 r9 1.0
 x27 obj -9
 x27 r1 -256.0
 x27 r2 -0.0625
 x27 r4 -16.0
 x27 r5 0.0625
 x27 r7 1.0
 x27 r8 16.0
 x28 obj 4
 x29 obj 5
 x30 obj -9
 x30 r0 -0.00390625
 x30 r1 -256.0
 x30 r3 1.0
 x30 r4 -16.0
 x30 r6 -0.0625
 x30 r7 1.0
 x31 obj 6
 x32 obj 6
 x33 obj 3
 x34 obj 2
 x35 obj 0
 x35 r9 2.0
RHS
 rhs obj 12
 rhs r0 -0.00390625
 rhs r1 -256.0
 rhs r2 -0.0625
 rhs r3 1.0
 rhs r4 -16.0
 rhs r5 0.0625
 rhs r6 -0.0625
 rhs r7 1.0
 rhs r8 16.0
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 3
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 1
 LI b x27 0
 UI b x27 1
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 2
 LI b x30 0
 UI b x30 1
 LI b x31 0
 UI b x31 2
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 3
 LI b x34 0
 UI b x34 2
 UP b x35 2
ENDATA
