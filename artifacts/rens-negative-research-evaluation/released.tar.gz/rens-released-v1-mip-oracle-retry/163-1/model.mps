NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 G r4
 L r5
 L r6
 G r7
 L r8
 G r9
COLUMNS
 x0 obj -9
 x1 obj -7
 x2 obj -8
 x3 obj -1
 x4 obj -5
 x5 obj -3
 x6 obj -7
 x7 obj -6
 x8 obj -1
 x8 r9 1.0
 x9 obj -3
 x10 obj -3
 x11 obj -4
 x12 obj -5
 x13 obj -7
 x14 obj -8
 x15 obj -6
 x16 obj -6
 x17 obj 1
 x17 r0 256.0
 x17 r2 -0.0625
 x17 r3 -0.00390625
 x17 r5 256.0
 x17 r6 0.0625
 x17 r8 1.0
 x17 r9 1.0
 x18 obj 1
 x18 r0 256.0
 x18 r1 0.00390625
 x18 r3 -0.00390625
 x18 r4 -1.0
 x18 r6 0.0625
 x18 r7 -0.00390625
 x18 r9 1.0
 x19 obj -1
 x20 obj -6
 x21 obj -4
 x22 obj -9
 x23 obj -6
 x24 obj -3
 x25 obj -1
 x26 obj -4
 x27 obj -4
 x28 obj -8
 x29 obj -3
 x30 obj 1
 x30 r1 0.00390625
 x30 r2 -0.0625
 x30 r4 -1.0
 x30 r5 256.0
 x30 r7 -0.00390625
 x30 r9 1.0
 x31 obj 0
 x31 r8 2.0
RHS
 rhs obj 0
 rhs r0 256.0
 rhs r1 0.00390625
 rhs r2 -0.0625
 rhs r3 -0.00390625
 rhs r4 -1.0
 rhs r5 256.0
 rhs r6 0.0625
 rhs r7 -0.00390625
 rhs r8 5.0
 rhs r9 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 3
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 1
 UP b x31 2
ENDATA
