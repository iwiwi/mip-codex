NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 G r4
 G r5
 L r6
 L r7
 L r8
COLUMNS
 x0 obj 9
 x1 obj -2
 x1 r0 1.0
 x1 r1 16.0
 x1 r3 0.0625
 x1 r4 -0.0625
 x1 r6 1.0
 x1 r7 16.0
 x2 obj 6
 x3 obj 9
 x4 obj 9
 x5 obj -2
 x5 r0 1.0
 x5 r2 1.0
 x5 r3 0.0625
 x5 r5 -256.0
 x5 r6 1.0
 x5 r8 1.0
 x6 obj 9
 x7 obj 8
 x8 obj 7
 x9 obj 7
 x10 obj 5
 x11 obj 1
 x12 obj 2
 x13 obj -2
 x13 r1 16.0
 x13 r2 1.0
 x13 r4 -0.0625
 x13 r5 -256.0
 x13 r7 16.0
 x14 obj 8
 x15 obj 3
 x16 obj 9
 x17 obj 7
 x18 obj 1
 x19 obj 3
 x20 obj 3
 x21 obj 8
 x22 obj 6
 x23 obj 6
 x24 obj 3
 x25 obj 9
 x26 obj 7
 x27 obj 7
 x28 obj 9
 x29 obj 2
 x30 obj 2
 x31 obj 3
 x32 obj 3
 x33 obj 2
 x34 obj 0
 x34 r8 2.0
RHS
 rhs obj -26
 rhs r0 1.0
 rhs r1 16.0
 rhs r2 1.0
 rhs r3 0.0625
 rhs r4 -0.0625
 rhs r5 -256.0
 rhs r6 1.0
 rhs r7 16.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 1
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 4
 LI b x32 0
 UI b x32 3
 LI b x33 0
 UI b x33 4
 UP b x34 2
ENDATA
