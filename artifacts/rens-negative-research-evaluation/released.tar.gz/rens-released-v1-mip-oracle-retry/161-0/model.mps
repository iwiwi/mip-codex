NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 L r4
 G r5
 L r6
 G r7
 L r8
 G r9
 L r10
 G r11
COLUMNS
 x0 obj 2
 x1 obj 2
 x2 obj 7
 x2 r11 1.0
 x3 obj 5
 x4 obj 5
 x5 obj 9
 x6 obj -8
 x6 r0 0.00390625
 x6 r1 -256.0
 x6 r3 1.0
 x6 r4 256.0
 x6 r6 0.0625
 x6 r7 -16.0
 x6 r9 -1.0
 x6 r11 1.0
 x7 obj 5
 x8 obj 2
 x9 obj 4
 x10 obj -8
 x10 r1 -256.0
 x10 r2 -16.0
 x10 r4 256.0
 x10 r5 -256.0
 x10 r7 -16.0
 x10 r8 0.00390625
 x10 r11 1.0
 x11 obj 5
 x12 obj -8
 x12 r0 0.00390625
 x12 r2 -16.0
 x12 r3 1.0
 x12 r5 -256.0
 x12 r6 0.0625
 x12 r8 0.00390625
 x12 r9 -1.0
 x12 r10 1.0
 x12 r11 1.0
 x13 obj 7
 x14 obj 8
 x15 obj 4
 x16 obj 2
 x17 obj 8
 x18 obj 7
 x19 obj 4
 x20 obj 5
 x21 obj 8
 x22 obj 1
 x23 obj 5
 x24 obj 1
 x25 obj 9
 x26 obj 0
 x26 r10 2.0
RHS
 rhs obj -12
 rhs r0 0.00390625
 rhs r1 -256.0
 rhs r2 -16.0
 rhs r3 1.0
 rhs r4 256.0
 rhs r5 -256.0
 rhs r6 0.0625
 rhs r7 -16.0
 rhs r8 0.00390625
 rhs r9 -1.0
 rhs r10 5.0
 rhs r11 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 2
 UP b x26 2
ENDATA
