NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
 G r4
COLUMNS
 x0 obj -2
 x1 obj -1
 x2 obj -8
 x3 obj -2
 x4 obj -9
 x5 obj -5
 x6 obj -3
 x7 obj -8
 x8 obj -2
 x9 obj -5
 x10 obj 3
 x10 r0 -0.0625
 x10 r2 -0.0625
 x10 r3 1.0
 x10 r4 1.0
 x11 obj -1
 x12 obj -7
 x13 obj -3
 x14 obj -1
 x15 obj 3
 x15 r1 -0.0625
 x15 r2 -0.0625
 x15 r4 1.0
 x16 obj -6
 x17 obj -4
 x18 obj -2
 x18 r4 1.0
 x19 obj -7
 x20 obj -7
 x21 obj -3
 x22 obj -3
 x23 obj -2
 x24 obj -5
 x25 obj -7
 x26 obj -6
 x27 obj -1
 x28 obj -2
 x29 obj 3
 x29 r0 -0.0625
 x29 r1 -0.0625
 x29 r4 1.0
 x30 obj 0
 x30 r3 2.0
RHS
 rhs obj 27
 rhs r0 -0.0625
 rhs r1 -0.0625
 rhs r2 -0.0625
 rhs r3 5.0
 rhs r4 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 4
 LI b x29 0
 UI b x29 1
 UP b x30 2
ENDATA
