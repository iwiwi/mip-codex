NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 G r2
 G r3
 G r4
 L r5
 G r6
COLUMNS
 x0 obj -7
 x1 obj -1
 x2 obj -8
 x2 r6 1.0
 x3 obj -4
 x4 obj -6
 x5 obj -7
 x6 obj -8
 x7 obj -7
 x8 obj -2
 x9 obj -4
 x10 obj -6
 x11 obj -2
 x12 obj -4
 x13 obj -2
 x14 obj -4
 x15 obj -6
 x16 obj -2
 x17 obj 7
 x17 r1 -0.0625
 x17 r2 -16.0
 x17 r4 -0.00390625
 x17 r6 1.0
 x18 obj -5
 x19 obj -5
 x20 obj -5
 x21 obj -9
 x22 obj -9
 x23 obj -8
 x24 obj -7
 x25 obj -6
 x26 obj -9
 x27 obj -9
 x28 obj -2
 x29 obj -7
 x30 obj -3
 x31 obj 7
 x31 r0 1.0
 x31 r2 -16.0
 x31 r3 -0.00390625
 x31 r5 1.0
 x31 r6 1.0
 x32 obj -8
 x33 obj 7
 x33 r0 1.0
 x33 r1 -0.0625
 x33 r3 -0.00390625
 x33 r4 -0.00390625
 x33 r6 1.0
 x34 obj 0
 x34 r5 2.0
RHS
 rhs obj -5
 rhs r0 1.0
 rhs r1 -0.0625
 rhs r2 -16.0
 rhs r3 -0.00390625
 rhs r4 -0.00390625
 rhs r5 5.0
 rhs r6 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 4
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 3
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 2
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 2
 LI b x31 0
 UI b x31 1
 LI b x32 0
 UI b x32 4
 LI b x33 0
 UI b x33 1
 UP b x34 2
ENDATA
