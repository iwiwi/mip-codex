NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
 G r4
COLUMNS
 x0 obj 3
 x1 obj 2
 x2 obj -4
 x2 r0 -256.0
 x2 r2 16.0
 x2 r3 1.0
 x2 r4 1.0
 x3 obj -4
 x3 r0 -256.0
 x3 r1 -0.0625
 x3 r4 1.0
 x4 obj 6
 x5 obj 9
 x6 obj 6
 x7 obj 7
 x8 obj 8
 x9 obj 1
 x10 obj 7
 x11 obj 8
 x12 obj -4
 x12 r1 -0.0625
 x12 r2 16.0
 x12 r4 1.0
 x13 obj 1
 x14 obj 8
 x15 obj 3
 x15 r4 1.0
 x16 obj 7
 x17 obj 7
 x18 obj 9
 x19 obj 2
 x20 obj 6
 x21 obj 1
 x22 obj 3
 x23 obj 2
 x24 obj 0
 x24 r3 2.0
RHS
 rhs obj 26
 rhs r0 -256.0
 rhs r1 -0.0625
 rhs r2 16.0
 rhs r3 5.0
 rhs r4 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 3
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 3
 UP b x24 2
ENDATA
