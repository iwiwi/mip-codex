NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 L r4
 L r5
 L r6
COLUMNS
 x0 obj -5
 x1 obj -9
 x2 obj -8
 x3 obj 6
 x3 r0 -0.0625
 x3 r1 0.0625
 x3 r3 256.0
 x3 r4 0.0625
 x4 obj 6
 x4 r0 -0.0625
 x4 r2 -1.0
 x4 r3 256.0
 x4 r5 1.0
 x4 r6 1.0
 x5 obj -9
 x6 obj -4
 x7 obj -1
 x8 obj -2
 x9 obj -4
 x10 obj -6
 x11 obj -8
 x12 obj -5
 x13 obj -4
 x14 obj -9
 x15 obj -5
 x16 obj -6
 x17 obj -4
 x18 obj -7
 x19 obj 6
 x19 r1 0.0625
 x19 r2 -1.0
 x19 r4 0.0625
 x19 r5 1.0
 x20 obj -7
 x21 obj -7
 x22 obj -6
 x23 obj -4
 x24 obj -3
 x25 obj -3
 x26 obj -7
 x27 obj -6
 x28 obj -8
 x29 obj -4
 x30 obj -1
 x31 obj -3
 x32 obj -2
 x33 obj -8
 x34 obj 0
 x34 r6 2.0
RHS
 rhs obj -26
 rhs r0 -0.0625
 rhs r1 0.0625
 rhs r2 -1.0
 rhs r3 256.0
 rhs r4 0.0625
 rhs r5 1.0
 rhs r6 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 1
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 2
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 3
 LI b x29 0
 UI b x29 4
 LI b x30 0
 UI b x30 3
 LI b x31 0
 UI b x31 4
 LI b x32 0
 UI b x32 2
 LI b x33 0
 UI b x33 4
 UP b x34 2
ENDATA
