NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 L r3
 G r4
 G r5
 G r6
 G r7
 L r8
COLUMNS
 x0 obj -1
 x1 obj -6
 x2 obj -1
 x3 obj -8
 x4 obj 9
 x4 r0 1.0
 x4 r1 -0.0625
 x4 r3 16.0
 x4 r4 -0.00390625
 x4 r6 -256.0
 x4 r7 -256.0
 x5 obj -7
 x6 obj -1
 x7 obj -6
 x8 obj -4
 x9 obj -5
 x10 obj -4
 x11 obj -3
 x12 obj -1
 x13 obj 9
 x13 r1 -0.0625
 x13 r2 0.00390625
 x13 r4 -0.00390625
 x13 r5 -16.0
 x13 r7 -256.0
 x14 obj -8
 x15 obj -6
 x16 obj -8
 x17 obj -5
 x18 obj -1
 x19 obj -9
 x20 obj -5
 x21 obj 9
 x21 r0 1.0
 x21 r2 0.00390625
 x21 r3 16.0
 x21 r5 -16.0
 x21 r6 -256.0
 x21 r8 1.0
 x22 obj 0
 x22 r8 2.0
RHS
 rhs obj 28
 rhs r0 1.0
 rhs r1 -0.0625
 rhs r2 0.00390625
 rhs r3 16.0
 rhs r4 -0.00390625
 rhs r5 -16.0
 rhs r6 -256.0
 rhs r7 -256.0
 rhs r8 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 3
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 1
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 1
 UP b x22 2
ENDATA
