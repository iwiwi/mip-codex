NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 L r4
 L r5
 G r6
 L r7
 L r8
 L r9
 G r10
COLUMNS
 x0 obj 3
 x1 obj 6
 x2 obj 2
 x3 obj 6
 x4 obj 5
 x5 obj 2
 x6 obj 5
 x7 obj 1
 x8 obj 4
 x9 obj 7
 x10 obj -8
 x10 r0 1.0
 x10 r2 -0.0625
 x10 r3 -256.0
 x10 r5 1.0
 x10 r6 -256.0
 x10 r8 16.0
 x10 r9 1.0
 x10 r10 1.0
 x11 obj 7
 x12 obj -8
 x12 r1 256.0
 x12 r2 -0.0625
 x12 r4 0.0625
 x12 r5 1.0
 x12 r7 0.00390625
 x12 r8 16.0
 x12 r10 1.0
 x13 obj 1
 x14 obj 4
 x15 obj 9
 x16 obj 2
 x17 obj 5
 x18 obj 3
 x19 obj 8
 x20 obj 3
 x21 obj -8
 x21 r0 1.0
 x21 r1 256.0
 x21 r3 -256.0
 x21 r4 0.0625
 x21 r6 -256.0
 x21 r7 0.00390625
 x21 r10 1.0
 x22 obj 3
 x22 r10 1.0
 x23 obj 0
 x23 r9 2.0
RHS
 rhs obj 30
 rhs r0 1.0
 rhs r1 256.0
 rhs r2 -0.0625
 rhs r3 -256.0
 rhs r4 0.0625
 rhs r5 1.0
 rhs r6 -256.0
 rhs r7 0.00390625
 rhs r8 16.0
 rhs r9 5.0
 rhs r10 1.5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 2
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 1
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 2
 UP b x23 2
ENDATA
