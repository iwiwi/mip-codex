NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 G r9
 L r10
 G r11
COLUMNS
 x0 obj 4
 x1 obj 6
 x2 obj 1
 x3 obj 8
 x4 obj 2
 x5 obj 5
 x6 obj -2
 x6 r1 -0.0625
 x6 r2 -0.0625
 x6 r4 1.0
 x6 r5 16.0
 x6 r7 256.0
 x6 r8 256.0
 x6 r11 1.0
 x7 obj 2
 x8 obj 8
 x9 obj 2
 x10 obj 7
 x11 obj 4
 x12 obj 4
 x13 obj 4
 x13 r11 1.0
 x14 obj 1
 x15 obj 8
 x16 obj 8
 x17 obj 9
 x18 obj 4
 x19 obj 9
 x20 obj 6
 x21 obj 1
 x22 obj 8
 x23 obj 8
 x24 obj 1
 x25 obj 5
 x26 obj 3
 x27 obj -2
 x27 r0 -1.0
 x27 r1 -0.0625
 x27 r3 256.0
 x27 r4 1.0
 x27 r6 256.0
 x27 r7 256.0
 x27 r9 -0.00390625
 x27 r11 1.0
 x28 obj 2
 x29 obj 3
 x30 obj -2
 x30 r0 -1.0
 x30 r2 -0.0625
 x30 r3 256.0
 x30 r5 16.0
 x30 r6 256.0
 x30 r8 256.0
 x30 r9 -0.00390625
 x30 r10 1.0
 x30 r11 1.0
 x31 obj 0
 x31 r10 2.0
RHS
 rhs obj 26
 rhs r0 -1.0
 rhs r1 -0.0625
 rhs r2 -0.0625
 rhs r3 256.0
 rhs r4 1.0
 rhs r5 16.0
 rhs r6 256.0
 rhs r7 256.0
 rhs r8 256.0
 rhs r9 -0.00390625
 rhs r10 5.0
 rhs r11 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 3
 LI b x25 0
 UI b x25 3
 LI b x26 0
 UI b x26 2
 LI b x27 0
 UI b x27 1
 LI b x28 0
 UI b x28 2
 LI b x29 0
 UI b x29 3
 LI b x30 0
 UI b x30 1
 UP b x31 2
ENDATA
