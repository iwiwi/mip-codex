NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 G r3
 G r4
 L r5
 G r6
COLUMNS
 x0 obj 3
 x1 obj 7
 x2 obj 9
 x2 r6 1.0
 x3 obj 7
 x4 obj 7
 x5 obj 5
 x6 obj 1
 x7 obj 3
 x8 obj 3
 x9 obj 7
 x10 obj 2
 x11 obj 3
 x12 obj 4
 x13 obj 3
 x14 obj 6
 x15 obj 2
 x16 obj 6
 x17 obj 7
 x18 obj 2
 x19 obj -2
 x19 r0 1.0
 x19 r2 -0.0625
 x19 r3 -16.0
 x19 r5 1.0
 x19 r6 1.0
 x20 obj 6
 x21 obj -2
 x21 r0 1.0
 x21 r1 -16.0
 x21 r3 -16.0
 x21 r4 -0.0625
 x21 r6 1.0
 x22 obj 4
 x23 obj 6
 x24 obj 7
 x25 obj -2
 x25 r1 -16.0
 x25 r2 -0.0625
 x25 r4 -0.0625
 x25 r6 1.0
 x26 obj 0
 x26 r5 2.0
RHS
 rhs obj 20
 rhs r0 1.0
 rhs r1 -16.0
 rhs r2 -0.0625
 rhs r3 -16.0
 rhs r4 -0.0625
 rhs r5 5.0
 rhs r6 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 1
 LI b x20 0
 UI b x20 4
 LI b x21 0
 UI b x21 1
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 4
 LI b x25 0
 UI b x25 1
 UP b x26 2
ENDATA
