NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 G r4
 G r5
 L r6
 L r7
 L r8
 L r9
 G r10
COLUMNS
 x0 obj 6
 x1 obj 1
 x2 obj 1
 x3 obj 1
 x3 r10 1.0
 x4 obj 2
 x5 obj 2
 x6 obj 8
 x7 obj 7
 x8 obj 8
 x9 obj 9
 x10 obj 7
 x11 obj -4
 x11 r0 1.0
 x11 r1 16.0
 x11 r3 1.0
 x11 r4 -0.00390625
 x11 r6 0.00390625
 x11 r7 16.0
 x11 r10 1.0
 x12 obj 7
 x13 obj 1
 x14 obj 2
 x15 obj -4
 x15 r1 16.0
 x15 r2 -0.0625
 x15 r4 -0.00390625
 x15 r5 -256.0
 x15 r7 16.0
 x15 r8 0.00390625
 x15 r10 1.0
 x16 obj 4
 x17 obj 9
 x18 obj -4
 x18 r0 1.0
 x18 r2 -0.0625
 x18 r3 1.0
 x18 r5 -256.0
 x18 r6 0.00390625
 x18 r8 0.00390625
 x18 r9 1.0
 x18 r10 1.0
 x19 obj 4
 x20 obj 9
 x21 obj 0
 x21 r9 2.0
RHS
 rhs obj -27
 rhs r0 1.0
 rhs r1 16.0
 rhs r2 -0.0625
 rhs r3 1.0
 rhs r4 -0.00390625
 rhs r5 -256.0
 rhs r6 0.00390625
 rhs r7 16.0
 rhs r8 0.00390625
 rhs r9 5.0
 rhs r10 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 3
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 3
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 1
 LI b x12 0
 UI b x12 2
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 2
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 1
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 4
 UP b x21 2
ENDATA
