NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 G r4
 G r5
 L r6
 L r7
 G r8
COLUMNS
 x0 obj -3
 x1 obj -3
 x2 obj -9
 x3 obj -9
 x4 obj -8
 x5 obj -9
 x6 obj 3
 x6 r1 1.0
 x6 r2 0.00390625
 x6 r4 -0.0625
 x6 r5 -0.00390625
 x6 r8 1.0
 x7 obj -7
 x8 obj -5
 x9 obj -5
 x10 obj -5
 x11 obj -3
 x12 obj 3
 x12 r0 -256.0
 x12 r2 0.00390625
 x12 r3 0.0625
 x12 r5 -0.00390625
 x12 r6 0.0625
 x12 r7 1.0
 x12 r8 1.0
 x13 obj -6
 x14 obj -6
 x15 obj -7
 x16 obj -9
 x17 obj -1
 x18 obj -1
 x19 obj -2
 x20 obj -4
 x21 obj -3
 x22 obj -7
 x23 obj -3
 x24 obj 3
 x24 r0 -256.0
 x24 r1 1.0
 x24 r3 0.0625
 x24 r4 -0.0625
 x24 r6 0.0625
 x24 r8 1.0
 x25 obj -2
 x25 r8 1.0
 x26 obj -3
 x27 obj -8
 x28 obj -7
 x29 obj 0
 x29 r7 2.0
RHS
 rhs obj -7
 rhs r0 -256.0
 rhs r1 1.0
 rhs r2 0.00390625
 rhs r3 0.0625
 rhs r4 -0.0625
 rhs r5 -0.00390625
 rhs r6 0.0625
 rhs r7 5.0
 rhs r8 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 4
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 1
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 2
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 2
 LI b x22 0
 UI b x22 4
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 1
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 4
 LI b x27 0
 UI b x27 4
 LI b x28 0
 UI b x28 3
 UP b x29 2
ENDATA
