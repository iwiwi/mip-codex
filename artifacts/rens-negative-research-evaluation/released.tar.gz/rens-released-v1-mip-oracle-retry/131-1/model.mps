NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 G r4
COLUMNS
 x0 obj -6
 x1 obj -6
 x2 obj -9
 x3 obj -4
 x4 obj 4
 x4 r1 256.0
 x4 r2 -256.0
 x4 r4 1.0
 x5 obj -8
 x6 obj -7
 x7 obj -3
 x8 obj -3
 x9 obj 4
 x9 r0 1.0
 x9 r1 256.0
 x9 r4 1.0
 x10 obj -2
 x11 obj -8
 x12 obj -2
 x13 obj -2
 x14 obj -7
 x15 obj -7
 x16 obj -8
 x17 obj -4
 x18 obj -3
 x19 obj -8
 x20 obj 4
 x20 r0 1.0
 x20 r2 -256.0
 x20 r3 1.0
 x20 r4 1.0
 x21 obj -6
 x22 obj -9
 x23 obj -6
 x24 obj -6
 x25 obj -6
 x26 obj -8
 x27 obj -3
 x27 r4 1.0
 x28 obj 0
 x28 r3 2.0
RHS
 rhs obj -27
 rhs r0 1.0
 rhs r1 256.0
 rhs r2 -256.0
 rhs r3 5.0
 rhs r4 1.5
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 1
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 2
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 4
 LI b x13 0
 UI b x13 4
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 3
 LI b x16 0
 UI b x16 2
 LI b x17 0
 UI b x17 2
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 2
 LI b x20 0
 UI b x20 1
 LI b x21 0
 UI b x21 4
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 4
 LI b x26 0
 UI b x26 3
 LI b x27 0
 UI b x27 4
 UP b x28 2
ENDATA
