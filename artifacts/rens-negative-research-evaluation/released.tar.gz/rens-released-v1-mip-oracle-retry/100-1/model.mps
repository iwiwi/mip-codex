NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 L r4
COLUMNS
 x0 obj -5
 x1 obj -4
 x2 obj -4
 x3 obj -8
 x4 obj -2
 x5 obj -8
 x6 obj -3
 x7 obj -5
 x8 obj -9
 x9 obj 5
 x9 r1 -0.00390625
 x9 r2 -256.0
 x10 obj -3
 x11 obj -9
 x12 obj -2
 x13 obj -7
 x14 obj -6
 x15 obj 5
 x15 r0 16.0
 x15 r1 -0.00390625
 x15 r3 1.0
 x16 obj 5
 x16 r0 16.0
 x16 r2 -256.0
 x16 r3 1.0
 x16 r4 1.0
 x17 obj -9
 x18 obj -2
 x19 obj -1
 x20 obj -2
 x21 obj -6
 x22 obj -9
 x23 obj -5
 x24 obj -1
 x25 obj 0
 x25 r4 2.0
RHS
 rhs obj -4
 rhs r0 16.0
 rhs r1 -0.00390625
 rhs r2 -256.0
 rhs r3 1.0
 rhs r4 5.0
BOUNDS
 LI b x0 0
 UI b x0 3
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 3
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
 LI b x5 0
 UI b x5 2
 LI b x6 0
 UI b x6 3
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 3
 LI b x11 0
 UI b x11 3
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 1
 LI b x16 0
 UI b x16 1
 LI b x17 0
 UI b x17 4
 LI b x18 0
 UI b x18 2
 LI b x19 0
 UI b x19 3
 LI b x20 0
 UI b x20 3
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 4
 LI b x24 0
 UI b x24 3
 UP b x25 2
ENDATA
