NAME rens
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
 G r2
 G r3
 L r4
 G r5
 L r6
 L r7
 G r8
 L r9
COLUMNS
 x0 obj 2
 x1 obj 1
 x2 obj 8
 x3 obj 1
 x4 obj 6
 x5 obj -2
 x5 r1 -16.0
 x5 r2 -256.0
 x5 r4 256.0
 x5 r5 -1.0
 x5 r7 256.0
 x5 r8 -256.0
 x6 obj 1
 x7 obj 5
 x8 obj 8
 x9 obj -2
 x9 r0 1.0
 x9 r2 -256.0
 x9 r3 -16.0
 x9 r5 -1.0
 x9 r6 1.0
 x9 r8 -256.0
 x9 r9 1.0
 x10 obj 2
 x11 obj 5
 x12 obj 2
 x13 obj 9
 x14 obj 2
 x15 obj 3
 x16 obj 8
 x17 obj -2
 x17 r0 1.0
 x17 r1 -16.0
 x17 r3 -16.0
 x17 r4 256.0
 x17 r6 1.0
 x17 r7 256.0
 x18 obj 9
 x19 obj 6
 x20 obj 2
 x21 obj 1
 x22 obj 4
 x23 obj 2
 x24 obj 4
 x25 obj 4
 x26 obj 0
 x26 r9 2.0
RHS
 rhs obj 2
 rhs r0 1.0
 rhs r1 -16.0
 rhs r2 -256.0
 rhs r3 -16.0
 rhs r4 256.0
 rhs r5 -1.0
 rhs r6 1.0
 rhs r7 256.0
 rhs r8 -256.0
 rhs r9 5.0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 3
 LI b x5 0
 UI b x5 1
 LI b x6 0
 UI b x6 4
 LI b x7 0
 UI b x7 4
 LI b x8 0
 UI b x8 3
 LI b x9 0
 UI b x9 1
 LI b x10 0
 UI b x10 2
 LI b x11 0
 UI b x11 4
 LI b x12 0
 UI b x12 3
 LI b x13 0
 UI b x13 2
 LI b x14 0
 UI b x14 3
 LI b x15 0
 UI b x15 2
 LI b x16 0
 UI b x16 4
 LI b x17 0
 UI b x17 1
 LI b x18 0
 UI b x18 4
 LI b x19 0
 UI b x19 4
 LI b x20 0
 UI b x20 2
 LI b x21 0
 UI b x21 3
 LI b x22 0
 UI b x22 2
 LI b x23 0
 UI b x23 2
 LI b x24 0
 UI b x24 2
 LI b x25 0
 UI b x25 4
 UP b x26 2
ENDATA
