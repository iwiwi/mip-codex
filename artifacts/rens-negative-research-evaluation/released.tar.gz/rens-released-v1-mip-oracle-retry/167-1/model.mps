NAME rens
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 L r4
 G r5
COLUMNS
 x0 obj -4
 x0 r5 1.0
 x1 obj -8
 x2 obj 1
 x2 r0 -256.0
 x2 r1 0.00390625
 x2 r3 16.0
 x2 r5 1.0
 x3 obj -3
 x4 obj -9
 x5 obj -1
 x6 obj -9
 x7 obj 1
 x7 r1 0.00390625
 x7 r2 0.0625
 x7 r5 1.0
 x8 obj -9
 x9 obj -4
 x10 obj -8
 x11 obj -1
 x12 obj 1
 x12 r0 -256.0
 x12 r2 0.0625
 x12 r3 16.0
 x12 r4 1.0
 x12 r5 1.0
 x13 obj -4
 x14 obj -1
 x15 obj -8
 x16 obj -1
 x17 obj -1
 x18 obj 0
 x18 r4 2.0
RHS
 rhs obj -30
 rhs r0 -256.0
 rhs r1 0.00390625
 rhs r2 0.0625
 rhs r3 16.0
 rhs r4 5.0
 rhs r5 1.5
BOUNDS
 LI b x0 0
 UI b x0 4
 LI b x1 0
 UI b x1 3
 LI b x2 0
 UI b x2 1
 LI b x3 0
 UI b x3 4
 LI b x4 0
 UI b x4 4
 LI b x5 0
 UI b x5 4
 LI b x6 0
 UI b x6 2
 LI b x7 0
 UI b x7 1
 LI b x8 0
 UI b x8 4
 LI b x9 0
 UI b x9 4
 LI b x10 0
 UI b x10 4
 LI b x11 0
 UI b x11 2
 LI b x12 0
 UI b x12 1
 LI b x13 0
 UI b x13 3
 LI b x14 0
 UI b x14 4
 LI b x15 0
 UI b x15 4
 LI b x16 0
 UI b x16 3
 LI b x17 0
 UI b x17 3
 UP b x18 2
ENDATA
