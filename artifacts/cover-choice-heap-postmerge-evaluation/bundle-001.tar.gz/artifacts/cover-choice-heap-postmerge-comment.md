main128を1feca2b74520a835e9f50a42b0caef4dd884b5bbとして統合後、primary専用targetで再ビルド。CLI/library双方のsource directoryとFP9c9eb50415d5914cを確認し、PR headからsrc/scripts/tests/Cargo/build差分0。既存untracked証拠とincoming Git blobのbyte一致を確認して退避し、pull後SHAも照合しました。

primary CPU47/1thread/16GiBの4出力すべて元MPS GMP/strict proof valid。cod105 optimal−12/−12（0nodes）、5000pair optimal−2500/−2500（0nodes）、深さ試験depth_limit−6113/LB−9173（512nodes）。z26/60秒は−1151/LB−1575、94,311nodes、60.038916996秒。候補測定−1154等との差もそのまま保持し、同値再現とはしません。システムPythonでの最初の検査起動はhighspy欠落で探索前に失敗し、ログを保持して既存.venvで全件成功しました。

新しい最終評価snapshotはcreate-onlyで全240問×3600秒・16GiB・1thread・cores8..15・swap0/pids512。全snapshot/library SHA照合、旧main127から変更は実行ファイルとheap関連4Rustファイルだけ。snapshot自身のcheckerで3生成/既知最適出力を再検証し、新旧cgroups空・全Rust最終job未起動。旧snapshotはOBSOLETEとして保持。開始予定はNov19です。最初のsnapshot照合スクリプトはweighted_coverの期待パスを一階層誤記して停止し、初版と失敗ログを残してパスだけ修正しました。ソルバー/測定結果の変更はありません。

native原720件と、時刻重複で事前選択した外的disk障害再測定1件はすべて終了済み。holdout個別成績は改善判断に参照していません。全体優位・新記録は未達で、探索を継続します。

snapshot receipt:
```json
{
  "run": "artifacts/runs/cover-choice-heap-final-20261118",
  "config_sha256": "9e5fc98a69b2d1d849d30446c5ccb9cb39b04a3167647e319c2558b50158e846",
  "source_fingerprint": "9c9eb50415d5914c",
  "source_git_sha": "1feca2b74520a835e9f50a42b0caef4dd884b5bb",
  "seconds": 3600,
  "threads": 1,
  "memory_bytes": 17179869184,
  "instances": 240,
  "jobs": 240,
  "status": "create-only; neverlaunched",
  "cores": [
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15
  ],
  "snapshot_files_verified": 113,
  "changed_snapshot_files": [
    "bin/mip-codex",
    "src/binary_graph.rs",
    "src/binary_graph/weighted_cover.rs",
    "src/main.rs",
    "src/solve.rs"
  ],
  "snapshot_spectral_large_depth_checker_valid": true,
  "libraries_verified": 147,
  "libraries_unchanged_from_previous_snapshot": true,
  "creation_hash_copy_cpu": 43,
  "verification_cpu": 43,
  "cgroups_empty": 240,
  "old_cgroups_empty": 240,
  "native_disk_recovery_required_before_launch": {
    "tag": "baseline-v2-disk-recovery-20261118",
    "config_sha256": "3ea4c4602e024a579282019d43c55f3d668e4054147610b1a509d0472c2cab4a",
    "jobs": 1
  },
  "own_final_jobs_launched": false
}
```

その時点のAI資源量:
```json
{
  "sessions": 1,
  "totals": {
    "input_tokens": 1814432785,
    "cached_input_tokens": 1801444736,
    "output_tokens": 9036864,
    "reasoning_output_tokens": 5554438,
    "total_tokens": 1823469649
  },
  "note": "input_tokensはキャッシュ分を含む。reasoningはoutputの内数。ローカルログの最終記録まで。"
}
```
