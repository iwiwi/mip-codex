from pathlib import Path
import os,sys,json,subprocess,shutil,time,resource
root=Path.cwd();assert root==Path('/home/ubuntu/mip-codex')
os.sched_setaffinity(0,{47})
resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,)*2)
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MIP_ABSOLUTE_CHECKER=str(root/'third_party/miplib-checker/bin/solchecker-absolute'))
sys.path.insert(0,'scripts')
from benchmark_common import atomic_json,sha256,require_solver_origin
from validate_solution import validate
from verify_cover_cuts import validate_cut_proofs
binary=root/'target/release/mip-codex'
info=require_solver_origin(root,binary)
assert info['source_fingerprint']=='9c9eb50415d5914c'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='1feca2b74520a835e9f50a42b0caef4dd884b5bb'
out=root/'artifacts/cover-choice-heap-main-primary-audit'
out.mkdir();(out/'bin').mkdir();shutil.copy2(binary,out/'bin/mip-codex');binary=out/'bin/mip-codex'
atomic_json(out/'experiment.json',dict(main='1feca2b74520a835e9f50a42b0caef4dd884b5bb',build_info=info,binary_sha256=sha256(binary),cpu=47,threads=1,memory_bytes=16*1024**3,purpose='primary postmerge defaults; generated pair/root spectral/depth guard and original z26 GMP/proofs'))
models=[('cod105',root/'data/raw/benchmark/cod105.mps.gz',10,{}),('pairs5000',Path('/home/ubuntu/mip-large-packing-profile/artifacts/large-cover-profile-v1/pairs5000.mps'),10,{}),('depth-cycles',Path('/home/ubuntu/mip-graph-large-capacity/artifacts/large-capacity-depth-controls/many-cycles-0/model.mps'),30,{f'MIP_GRAPH_{n}':'0'for n in ['LOCAL_SEARCH','ROOT_COLORING','ROOT_PREFIX','FRACTIONAL_COVER','INPUT_COVER','SPECTRAL_BOUND']}),('z26',root/'data/raw/exploratory/z26.mps.gz',60,{})]
records=[]
for label,model,seconds,flags in models:
    d=out/label;d.mkdir()
    env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(flags)
    cmd=[str(binary),'solve',str(model),str(seconds)]
    atomic_json(d/'job.json',dict(command=cmd,input_sha256=sha256(model),environment={k:v for k,v in env.items()if k.startswith('MIP_')}))
    start=time.monotonic();run=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=seconds+90)
    (d/'stdout.log').write_text(run.stdout);(d/'stderr.log').write_text(run.stderr)
    atomic_json(d/'execution.json',dict(exit_code=run.returncode,wall_seconds=time.monotonic()-start));assert run.returncode==0,run.stderr
    r=json.loads(run.stdout);atomic_json(d/'result.json',r);assert r['binary_graph']is not None
    v=validate(model,r);atomic_json(d/'point-validation.json',v);assert v['valid']
    p=validate_cut_proofs(model,r);atomic_json(d/'proof-validation.json',p);assert p['valid']
    if label=='cod105':assert r['status']=='optimal'and r['objective']==r['dual_bound']==-12
    if label=='pairs5000':assert r['status']=='optimal'and r['objective']==r['dual_bound']==-2500
    if label=='depth-cycles':assert r['status']=='depth_limit'and r['binary_graph']['depth_limit_hit']and r['nodes']==512
    if label=='z26':assert r['binary_graph']['vertices']==17937
    records.append(dict(label=label,status=r['status'],objective=r['objective'],dual_bound=r['dual_bound'],nodes=r['nodes'],seconds=r['seconds'],gmp_valid=True,proof_valid=True,independent_root_optimality=p['binary_graph']['independent_optimality']))
    atomic_json(out/'records.json',records);print(json.dumps(records[-1]),flush=True)
atomic_json(out/'exit.json',dict(status='complete',outputs=len(records),gmp_valid=len(records),proof_valid=len(records)))
