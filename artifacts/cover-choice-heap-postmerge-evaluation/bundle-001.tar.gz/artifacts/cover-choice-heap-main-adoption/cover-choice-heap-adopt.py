from pathlib import Path
import os,sys,json,subprocess,tarfile,hashlib,datetime
root=Path.cwd();os.sched_setaffinity(0,{43});sys.path.insert(0,'scripts')
from benchmark_common import sha256,require_solver_origin,atomic_json
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert subprocess.check_output(['git','ls-remote','origin','refs/heads/graph-cover-choice-heap'],text=True).split()[0]==head
assert not subprocess.check_output(['git','diff','a6c196e155026ae693e351147295386f294b885e','--','src','scripts','tests','Cargo.toml','Cargo.lock','build.rs'])
info=require_solver_origin(root,root/'artifacts/cover-choice-heap-default-frozen/bin/mip-codex');assert info['source_fingerprint']=='9c9eb50415d5914c'
for prefix in ['cover-choice-heap','cover-choice-heap-default']:
 assert json.load(open('artifacts/'+prefix+'-test-summary.json'))['passed']==353
 assert json.load(open('artifacts/'+prefix+'-development-parallel-audit/summary.json'))['fresh']==376
 assert json.load(open('artifacts/'+prefix+'-enumeration/summary.json'))['failures']==0
 assert json.load(open('artifacts/'+prefix+'-large-generated/summary.json'))['gmp_valid']==12
 assert json.load(open('artifacts/'+prefix+'-main-controls/exit.json'))['gmp_valid']==7
 assert json.load(open('artifacts/'+prefix+'-main-long-controls/exit.json'))['gmp_valid']==2
assert json.load(open('artifacts/cover-choice-heap-default-inactive-recheck/summary.json'))['gmp_valid']==6
for p in (root/'artifacts/cover-choice-heap-default-development-screen/cases').glob('*/*/job.json'):
 r=json.load(open(p));assert r['environment'].get('MIP_GRAPH_COVER_HEAP')==('0'if p.parent.name=='before'else None)
for p in (root/'artifacts/cover-choice-heap-default-large-generated').glob('*/job.json'):
 r=json.load(open(p));assert r['environment'].get('MIP_GRAPH_COVER_HEAP')==('0'if p.parent.name.endswith('-0')else None)
assert json.load(open('artifacts/cover-choice-heap-native300-controls/exit.json'))['all_cases_accounted_for']
assert json.load(open('artifacts/cover-choice-heap-native300-controls/glpk/late-validation.json'))['valid']is True
checks=[]
for name,origin in [('cover-choice-heap-evaluation',root),('cover-choice-heap-default-evaluation',root),('cover-choice-heap-native300-evaluation',root),('cover-heap-fixed-work-evaluation',Path('/home/ubuntu/mip-cover-choice-heap')),('cover-heap-primal-evaluation',Path('/home/ubuntu/mip-cover-choice-heap')),('large-capacity-postmerge-evaluation',Path('/home/ubuntu/mip-codex'))]:
 d=root/'artifacts'/name;rows=json.load(open(d/'manifest.json'));lookup={r['path']:r for r in rows};assert len(lookup)==len(rows);seen=set()
 for b in sorted(d.glob('bundle-*.tar.gz')):
  with tarfile.open(b)as t:
   for m in t:
    assert m.name not in seen;seen.add(m.name);r=lookup[m.name];data=t.extractfile(m).read();assert len(data)==r['bytes']and hashlib.sha256(data).hexdigest()==r['sha256']
 assert seen==set(lookup)
 excluded=json.load(open(d/'excluded-elf.json'))
 for r in excluded:assert (origin/r['path']).stat().st_size==r['bytes']and sha256(origin/r['path'])==r['sha256']
 checks.append(dict(archive=name,files=len(rows),excluded_elf_verified=len(excluded),origin=str(origin)))
atomic_json(root/'artifacts/cover-choice-heap-adoption-preflight.json',dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,fingerprint=info['source_fingerprint'],source_unchanged_since_frozen_core=True,archives=checks,default_jobs_verified=376,large_jobs_verified=12,all_valid=True))
body='''大規模で疎なpackingのweighted-cover探索の全頂点走査を、同じscore降順・age昇順・id昇順を保つindexed heapへ替えます。n>4096、8Eceil(log2 n)<=n²、144n+32E<=memoryの構造/追加メモリ条件を満たす場合だけ適用。外れる場合はscanを使いheap配列を確保しません。CLI `MIP_GRAPH_COVER_HEAP=0/1` の既定はON、旧public APIはscanのwrapperを保持。認識・予算・反復上限・再始動・乱数・境界計算は変えません。

初期a45/BDDと最終a6/9c9を別凍結し、main127へのrebaseはsource/tests/scripts/Cargo/build全byte同一。各353 Rust成功/4ignored、各1200smallの全列挙/GMP/strict proofと7410改変棄却、各12largeのcomponent oracle/GMP/proof（実heap6）を検査。約60000更新でheap先頭と全走査の選択、全position/親子順/scoreを再計算照合しています。

私的100k固定work×4モデル×3pairsは24点GMP、同values/同weighted counters。疎pair約16x、z26約3.6x、S7約1.13x、密cod105で5x遅化したため一律適用を棄却し、構造gateを付けました。これらのprivate成果や1197点を本体成績/新記録へ帰属しません。

z26/300秒・1thread・16GiBの新規比較:

| solver | primal | dual bound | outcome |
|---|---:|---:|---|
| 本体scan | -1163 | -1575 | 300.041秒 |
| 本体heap | -1182 | -1578 | 300.038秒 |
| HiGHS1.16.0 | -1147 | -2114 | 300.049秒 |
| SCIP10.0.2 | -1013 | -1539.949499925362 | 300.143秒 |
| GLPK5.0 | 時間内点なし | 時間内結果なし | 外側watchdog420秒 |

本体2点とnative時間内2点は元MPS GMP valid、本体はstrict root/prefix/Fraction証明もvalid。主解は改善し、SCIPのdualはより強い値です。GLPKの研究wrapperがタイムアウト後、C childは441.545秒で自然終端し、遅延点−460/LB−1651をdirect API sidecarから再構成して元GMP validを確認しました。300秒の結果には含めずwatchdog失敗とlate別枠を保持。初回late検査のchecker相対パス不在validNoneも保存し、絶対パスで検査だけ再実行しました。native最適化の再実行はありません。

60秒の本体は両primal−1154、dual−1575/−1578を保存。初期300秒−1160/−1578→−1178/−1575と最終を区別し、初期/最終それぞれ主制御7+長制御2を全GMP/strict proof検査。cod105は両opt−12/LP1/13pivots、S3は両opt−16/6042153nodes、最終19.381/19.321秒。

最終188問はprimal187同じ/1悪化、dual173同じ/2改善/13比較不可、finite175ずつ、両182time/2optimal/4numeric。全376fresh proof/128点GMP＋公式valid。実heap適用0であり、改善は本機能へ帰属しません。neos911970悪化を保持し、同じ最終9c9/CPU46の3交互順pairs6点は全両140.59/LB23.26、GMP/proof valid。初期188のprimal186同じ/1改善/1悪化も保存。因果は断定しません。

同順位選択の正しさと追加メモリguard、大規模生成例、本体の同時間主解改善を根拠に採用します。初期/最終4bundleずつ、native300、private原型2件、前PRpostmergeの6archiveすべての全payload/除外ELF SHAを再検証済み。正式自作240は未起動、元native720＋事前固定disk再測定1は終端・cgroups空、全結果を保持。holdout個別成績は開発へ使っていません。全体優位/新記録は未達です。
'''
usage=subprocess.check_output(['python3','scripts/ai_usage.py'],text=True);Path('artifacts/cover-choice-heap-final-body-ai-usage.json').write_text(usage);p=Path('artifacts/cover-choice-heap-final-pr-body.md');p.write_text(body+'\nAI資源量:\n```json\n'+usage+'```\n');payload=root/'artifacts/cover-choice-heap-pr-patch.json';atomic_json(payload,dict(body=p.read_text()))
r=subprocess.run(['gh','api','--method','PATCH','repos/iwiwi/mip-codex/pulls/128','--input',str(payload)],capture_output=True,text=True);Path('artifacts/cover-choice-heap-pr-patch-response.json').write_text(r.stdout);r.check_returncode()
text='''採用前の最終再照合を完了しました。a6/9c9からコード変更なし、既定ON開発376jobとlarge12jobでbefore明示0/after未設定を確認、6archiveすべてのpayload/除外ELF SHAを元保持位置で再検証済みです。初期/最終各353Rust/1200small/7410tampers/12large/376fresh proof128GMP公式/9主制御を保持しています。

新規native300秒はHS−1147/−2114、SCIP−1013/−1539.9495（2点GMP valid）、本体heap−1182/−1578（GMP/strict proof valid）。SCIPのdualが強いことも明示します。GLPKは研究wrapper420秒watchdog、遅延C出力441.545秒の−460/−1651だけを別枠GMP確認し、300秒へ混ぜません。初回late検査のchecker不在も記録して検査だけやり直しました。研究driverのtimeout失敗と子の自然終端を保存し、正式cgroup harnessの結果とは区別しています。

最終188の非適用neos悪化を残し、同一9c9の3pairs6点は両140.59/LB23.26で全GMP/proof valid。これを元screenの代わりにせず、機能不適用の変動について因果を断定しません。同順位の処理を構造gateで選び、固定時間の反復と大規模packing主解を改善したため採用します。元正式native720+disk回復1は全終端・全cgroups空。正式Rust240は未起動、全体優位/新記録は未達です。
'''
usage=subprocess.check_output(['python3','scripts/ai_usage.py'],text=True);Path('artifacts/cover-choice-heap-adoption-ai-usage.json').write_text(usage);p=Path('artifacts/cover-choice-heap-adoption-comment.md');p.write_text(text+'\nその時点のAI資源量:\n```json\n'+usage+'```\n')
r=subprocess.run(['gh','pr','comment','128','--repo','iwiwi/mip-codex','--body-file',str(p)],capture_output=True,text=True);Path('artifacts/cover-choice-heap-adoption-comment.log').write_text(r.stdout+r.stderr);r.check_returncode()
view=json.loads(subprocess.check_output(['gh','pr','view','128','--repo','iwiwi/mip-codex','--json','headRefOid,isDraft,state'],text=True));assert view['headRefOid']==head and view['state']=='OPEN'
if view['isDraft']:
 r=subprocess.run(['gh','pr','ready','128','--repo','iwiwi/mip-codex'],capture_output=True,text=True);Path('artifacts/cover-choice-heap-pr-ready.log').write_text(r.stdout+r.stderr);r.check_returncode()
r=subprocess.run(['gh','pr','merge','128','--repo','iwiwi/mip-codex','--squash','--match-head-commit',head],capture_output=True,text=True);Path('artifacts/cover-choice-heap-pr-merge.log').write_text(r.stdout+r.stderr);r.check_returncode()
view=json.loads(subprocess.check_output(['gh','pr','view','128','--repo','iwiwi/mip-codex','--json','headRefOid,state,mergeCommit,mergedAt,url'],text=True));assert view['state']=='MERGED'and view['headRefOid']==head;atomic_json(root/'artifacts/cover-choice-heap-pr-merge.json',view);print(json.dumps(view),flush=True)
