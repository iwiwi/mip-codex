大規模で疎なpackingのweighted-cover探索の全頂点走査を、同じscore降順・age昇順・id昇順を保つindexed heapへ替えます。n>4096、8Eceil(log2 n)<=n²、144n+32E<=memoryの構造/追加メモリ条件を満たす場合だけ適用。外れる場合はscanを使いheap配列を確保しません。CLI `MIP_GRAPH_COVER_HEAP=0/1` の既定はON、旧public APIはscanのwrapperを保持。認識・予算・反復上限・再始動・乱数・境界計算は変えません。

初期a45/BDDと最終a6/9c9を別凍結し、main127へのrebaseはsource/tests/scripts/Cargo/build全byte同一。各353 Rust成功/4ignored、各1200smallの全列挙/GMP/strict proofと7410改変棄却、各12largeのcomponent oracle/GMP/proof（実heap6）を検査。約60000更新でheap先頭と全走査の選択、全position/親子順/scoreを再計算照合しています。

私的100k固定work×4モデル×3pairsは24点GMP、同values/同weighted counters。疎pair約16x、z26約3.6x、S7約1.13x、密cod105で5x遅化したため一律適用を棄却し、構造gateを付けました。これらのprivate成果や1197点を本体成績/新記録へ帰属しません。

z26/300秒・1thread・16GiBの新規比較:

| solver | primal | dual bound | outcome |
|---|---:|---:|---|
| 本体scan | -1163 | -1575 | 300.041秒 |
| 本体heap | -1182 | -1578 | 300.038秒 |
| HiGHS1.16.0 | -1147 | -2114 | 300.049秒 |
| SCIP10.0.2 | -1013 | -1539.949499925362 | 300.143秒 |
| GLPK5.0 | 時間内点なし | 時間内結果なし | 外側watchdog420秒 |

本体2点とnative時間内2点は元MPS GMP valid、本体はstrict root/prefix/Fraction証明もvalid。主解は改善し、SCIPのdualはより強い値です。GLPKの研究wrapperがタイムアウト後、C childは441.545秒で自然終端し、遅延点−460/LB−1651をdirect API sidecarから再構成して元GMP validを確認しました。300秒の結果には含めずwatchdog失敗とlate別枠を保持。初回late検査のchecker相対パス不在validNoneも保存し、絶対パスで検査だけ再実行しました。native最適化の再実行はありません。

60秒の本体は両primal−1154、dual−1575/−1578を保存。初期300秒−1160/−1578→−1178/−1575と最終を区別し、初期/最終それぞれ主制御7+長制御2を全GMP/strict proof検査。cod105は両opt−12/LP1/13pivots、S3は両opt−16/6042153nodes、最終19.381/19.321秒。

最終188問はprimal187同じ/1悪化、dual173同じ/2改善/13比較不可、finite175ずつ、両182time/2optimal/4numeric。全376fresh proof/128点GMP＋公式valid。実heap適用0であり、改善は本機能へ帰属しません。neos911970悪化を保持し、同じ最終9c9/CPU46の3交互順pairs6点は全両140.59/LB23.26、GMP/proof valid。初期188のprimal186同じ/1改善/1悪化も保存。因果は断定しません。

同順位選択の正しさと追加メモリguard、大規模生成例、本体の同時間主解改善を根拠に採用します。初期/最終4bundleずつ、native300、private原型2件、前PRpostmergeの6archiveすべての全payload/除外ELF SHAを再検証済み。正式自作240は未起動、元native720＋事前固定disk再測定1は終端・cgroups空、全結果を保持。holdout個別成績は開発へ使っていません。全体優位/新記録は未達です。

AI資源量:
```json
{
  "sessions": 1,
  "totals": {
    "input_tokens": 1812859755,
    "cached_input_tokens": 1799927808,
    "output_tokens": 9029898,
    "reasoning_output_tokens": 5554023,
    "total_tokens": 1821889653
  },
  "note": "input_tokensはキャッシュ分を含む。reasoningはoutputの内数。ローカルログの最終記録まで。"
}
```
