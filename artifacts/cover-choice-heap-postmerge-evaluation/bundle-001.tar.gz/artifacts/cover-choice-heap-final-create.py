from pathlib import Path
import sys,os,json,argparse,hashlib,subprocess,time
sys.path.insert(0,'scripts');import benchmark
root=Path.cwd()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='1feca2b74520a835e9f50a42b0caef4dd884b5bb'
deadline=time.monotonic()+1800
while not(root/'artifacts/cover-choice-heap-main-primary-audit/exit.json').exists():
 assert time.monotonic()<deadline,'primary smoke not terminal'
 time.sleep(2)
assert json.load(open('artifacts/cover-choice-heap-main-primary-audit/exit.json'))['gmp_valid']==4
oldpath=root/'artifacts/runs/large-capacity-final-20261118/config.json'
assert hashlib.sha256(oldpath.read_bytes()).hexdigest()=='2bbdcf0f551ab1012cc76dd631e87f8661e1355f79255ddaace09f5287bfa7d0'
old=json.load(open(oldpath));destination=root/'artifacts/runs/cover-choice-heap-final-20261118'
assert not destination.exists();solvers=sorted({j['solver']for j in old['jobs']});assert solvers==['rust']
original=benchmark.require_solver_origin
def pinned_origin(*a,**kw):
 os.sched_setaffinity(0,{43});info=original(*a,**kw)
 assert info['source_fingerprint']==info['library_source_fingerprint']=='9c9eb50415d5914c'
 return info
benchmark.require_solver_origin=pinned_origin
benchmark.create(argparse.Namespace(directory=str(destination),seconds=old['seconds'],cores=','.join(map(str,old['cores'])),solvers=','.join(solvers),manifest=str(root/'data/manifest.json'),names=None,allow_dirty=False))
