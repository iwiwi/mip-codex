from pathlib import Path
import os,json,subprocess,sys
os.sched_setaffinity(0,{43});sys.path.insert(0,'scripts')
from benchmark_common import require_solver_origin,sha256
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='1feca2b74520a835e9f50a42b0caef4dd884b5bb'
assert not subprocess.check_output(['git','diff','5a0e2e037dd24e329cfe476e8df6c5a4befc3e28','HEAD','--','src','scripts','tests','Cargo.toml','Cargo.lock','build.rs'])
info=require_solver_origin(Path.cwd(),Path.cwd()/'target/release/mip-codex');assert info['source_fingerprint']=='9c9eb50415d5914c'
r=json.load(open('artifacts/cover-choice-heap-main-primary-audit/records.json'));assert len(r)==4 and all(x['gmp_valid']and x['proof_valid']for x in r)
s=json.load(open('artifacts/cover-choice-heap-final-snapshot-verification.json'));assert s['own_final_jobs_launched']is False
text='''main128を1feca2b74520a835e9f50a42b0caef4dd884b5bbとして統合後、primary専用targetで再ビルド。CLI/library双方のsource directoryとFP9c9eb50415d5914cを確認し、PR headからsrc/scripts/tests/Cargo/build差分0。既存untracked証拠とincoming Git blobのbyte一致を確認して退避し、pull後SHAも照合しました。

primary CPU47/1thread/16GiBの4出力すべて元MPS GMP/strict proof valid。cod105 optimal−12/−12（0nodes）、5000pair optimal−2500/−2500（0nodes）、深さ試験depth_limit−6113/LB−9173（512nodes）。z26/60秒は−1151/LB−1575、94,311nodes、60.038916996秒。候補測定−1154等との差もそのまま保持し、同値再現とはしません。システムPythonでの最初の検査起動はhighspy欠落で探索前に失敗し、ログを保持して既存.venvで全件成功しました。

新しい最終評価snapshotはcreate-onlyで全240問×3600秒・16GiB・1thread・cores8..15・swap0/pids512。全snapshot/library SHA照合、旧main127から変更は実行ファイルとheap関連4Rustファイルだけ。snapshot自身のcheckerで3生成/既知最適出力を再検証し、新旧cgroups空・全Rust最終job未起動。旧snapshotはOBSOLETEとして保持。開始予定はNov19です。最初のsnapshot照合スクリプトはweighted_coverの期待パスを一階層誤記して停止し、初版と失敗ログを残してパスだけ修正しました。ソルバー/測定結果の変更はありません。

native原720件と、時刻重複で事前選択した外的disk障害再測定1件はすべて終了済み。holdout個別成績は改善判断に参照していません。全体優位・新記録は未達で、探索を継続します。

snapshot receipt:
```json
'''+json.dumps(s,ensure_ascii=False,indent=2)+'\n```\n'
usage=subprocess.check_output(['python3','scripts/ai_usage.py'],text=True)
Path('artifacts/cover-choice-heap-postmerge-ai-usage.json').write_text(usage)
p=Path('artifacts/cover-choice-heap-postmerge-comment.md');p.write_text(text+'\nその時点のAI資源量:\n```json\n'+usage+'```\n')
pres=subprocess.run(['gh','pr','comment','128','--repo','iwiwi/mip-codex','--body-file',str(p)],capture_output=True,text=True);Path('artifacts/cover-choice-heap-postmerge-comment.log').write_text(pres.stdout+pres.stderr);pres.check_returncode();print(pres.stdout)
