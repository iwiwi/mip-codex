from pathlib import Path
import tarfile,hashlib,json,subprocess,os,datetime
os.sched_setaffinity(0,{43});root=Path('/home/ubuntu/mip-lazy-coefficient-certifier');archive=root/'artifacts/lazy-coefficient-certifier-evaluation';manifest=json.load(open(archive/'manifest.json'));lookup={r['path']:r for r in manifest};seen=set()
for p in archive.glob('bundle-*.tar.gz'):
 with tarfile.open(p)as t:
  for m in t:
   b=t.extractfile(m).read();r=lookup[m.name];assert m.name not in seen and len(b)==r['bytes']and hashlib.sha256(b).hexdigest()==r['sha256'];seen.add(m.name)
assert seen==set(lookup)
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  cwd=(p/'cwd').resolve()
  if cwd==root or root in cwd.parents:active.append(int(p.name))
 except (OSError,RuntimeError):pass
assert not active,active
tracked=set(subprocess.check_output(['git','-C',str(root),'ls-files'],text=True).splitlines());removed=[];kept=[]
for r in manifest:
 name=r['path'];p=root/name
 if name in tracked or not name.startswith('artifacts/lazy-coefficient-certifier-')or len(Path(name).parts)<4 or 'frozen'in name or not p.is_file():continue
 b=p.read_bytes()
 if b[:4]==b'\x7fELF':continue
 if len(b)!=r['bytes']or hashlib.sha256(b).hexdigest()!=r['sha256']:kept.append(name);continue
 p.unlink();removed.append(r)
result=dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),archive_payloads_verified=len(seen),archive=str(archive),removed_files=len(removed),removed_bytes=sum(r['bytes']for r in removed),removed=removed,kept_mismatch=kept,active_cwd=[],purpose='only inactive untracked archived raw nested evidence; root scripts/logs, all frozen directories, ELF, tracked sources, snapshots and archives retained');Path('artifacts/cover-restarts-cleanup-rejected-lazy.json').write_text(json.dumps(result,indent=2));print({k:v for k,v in result.items()if k not in ['removed','kept_mismatch']})
