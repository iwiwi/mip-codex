NAME component
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
 L r40
 L r41
 L r42
 L r43
 L r44
 L r45
 L r46
 L r47
 L r48
 L r49
 L r50
 L r51
 L r52
 L r53
 L r54
 L r55
 L r56
 L r57
 L r58
 L r59
 L r60
 L r61
 L r62
 L r63
 L r64
 L r65
 L r66
 L r67
 L r68
 L r69
 L r70
 L r71
 L r72
 L r73
 L r74
 L r75
 L r76
 L r77
 L r78
 L r79
 L r80
 L r81
 L r82
 L r83
 L r84
 L r85
 L r86
 L r87
 L r88
 L r89
 L r90
 L r91
 L r92
 L r93
 L r94
 L r95
 L r96
 L r97
 L r98
 L r99
 L r100
 L r101
 L r102
 L r103
 L r104
 L r105
 L r106
 L r107
 L r108
 L r109
 L r110
 L r111
 L r112
 L r113
 L r114
 L r115
 L r116
 L r117
 L r118
 L r119
 L r120
 L r121
 L r122
 L r123
 L r124
 L r125
 L r126
 L r127
 L r128
 L r129
 L r130
 L r131
 L r132
 L r133
 L r134
 L r135
 L r136
 L r137
 L r138
 L r139
 L r140
 L r141
 L r142
 L r143
 L r144
 L r145
 L r146
 L r147
 L r148
 L r149
 L r150
 L r151
 L r152
 L r153
 L r154
 L r155
 L r156
 L r157
 L r158
 L r159
 L r160
 L r161
 L r162
 L r163
 L r164
 L r165
 L r166
 L r167
 L r168
 L r169
 L r170
 L r171
 L r172
 L r173
 L r174
 L r175
 L r176
 L r177
 L r178
 L r179
 L r180
 L r181
 L r182
 L r183
 L r184
 L r185
 L r186
 L r187
 L r188
 L r189
 L r190
 L r191
 L r192
 L r193
 L r194
 L r195
 L r196
 L r197
 L r198
 L r199
 L r200
 L r201
 L r202
 L r203
 L r204
 L r205
 L r206
 L r207
 L r208
 L r209
 L r210
 L r211
 L r212
 L r213
 L r214
 L r215
 L r216
 L r217
 L r218
 L r219
 L r220
 L r221
 L r222
 L r223
 L r224
 L r225
 L r226
 L r227
 L r228
 L r229
 L r230
 L r231
 L r232
 L r233
 L r234
 L r235
 L r236
 L r237
 L r238
 L r239
 L r240
 L r241
 L r242
COLUMNS
 x_2045 obj -1
 x_2045 r0 1
 x_2045 r1 1
 x_2045 r2 1
 x_2042 obj -1
 x_2042 r0 1
 x_2042 r3 1
 x_2042 r4 1
 x_2042 r5 1
 x_2042 r6 1
 x_2042 r7 1
 x_2043 obj -1
 x_2043 r1 1
 x_2043 r3 1
 x_2043 r8 1
 x_2043 r9 1
 x_2043 r10 1
 x_2038 obj -1
 x_2038 r4 1
 x_2038 r8 1
 x_2038 r11 1
 x_2038 r12 1
 x_2038 r13 1
 x_2038 r14 1
 x_2038 r15 1
 x_2038 r16 1
 x_1280 obj -1
 x_1280 r17 1
 x_1280 r18 1
 x_1280 r19 1
 x_1280 r20 1
 x_1280 r21 1
 x_1280 r22 1
 x_1504 obj -1
 x_1504 r23 1
 x_1504 r24 1
 x_1504 r25 1
 x_1504 r26 1
 x_1504 r27 1
 x_1504 r28 1
 x_1504 r29 1
 x_1504 r30 1
 x_1504 r31 1
 x_1504 r32 1
 x_1504 r33 1
 x_1976 obj -1
 x_1976 r34 1
 x_1976 r35 1
 x_1976 r36 1
 x_1976 r37 1
 x_1976 r38 1
 x_1976 r39 1
 x_1976 r40 1
 x_1976 r41 1
 x_1976 r42 1
 x_1976 r43 1
 x_1976 r44 1
 x_1976 r45 1
 x_1968 obj -1
 x_1968 r34 1
 x_1968 r46 1
 x_1968 r47 1
 x_1968 r48 1
 x_1968 r49 1
 x_1968 r50 1
 x_1968 r51 1
 x_1968 r52 1
 x_1968 r53 1
 x_1760 obj -1
 x_1760 r23 1
 x_1760 r54 1
 x_1760 r55 1
 x_1760 r56 1
 x_1760 r57 1
 x_1760 r58 1
 x_1760 r59 1
 x_1760 r60 1
 x_1760 r61 1
 x_1760 r62 1
 x_1760 r63 1
 x_1760 r64 1
 x_1784 obj -1
 x_1784 r35 1
 x_1784 r54 1
 x_1784 r65 1
 x_1784 r66 1
 x_1784 r67 1
 x_1784 r68 1
 x_1784 r69 1
 x_1784 r70 1
 x_1784 r71 1
 x_1784 r72 1
 x_1784 r73 1
 x_1784 r74 1
 x_1776 obj -1
 x_1776 r24 1
 x_1776 r46 1
 x_1776 r55 1
 x_1776 r65 1
 x_1776 r75 1
 x_1776 r76 1
 x_1776 r77 1
 x_1776 r78 1
 x_1776 r79 1
 x_1776 r80 1
 x_1776 r81 1
 x_1776 r82 1
 x_1016 obj -1
 x_1016 r66 1
 x_1016 r83 1
 x_1016 r84 1
 x_1016 r85 1
 x_1016 r86 1
 x_1016 r87 1
 x_1016 r88 1
 x_1016 r89 1
 x_1952 obj -1
 x_1952 r36 1
 x_1952 r47 1
 x_1952 r56 1
 x_1952 r90 1
 x_1952 r91 1
 x_1952 r92 1
 x_1952 r93 1
 x_1008 obj -1
 x_1008 r25 1
 x_1008 r75 1
 x_1008 r83 1
 x_1008 r94 1
 x_1008 r95 1
 x_1008 r96 1
 x_1008 r97 1
 x_1008 r98 1
 x_512 obj -1
 x_512 r17 1
 x_512 r99 1
 x_512 r100 1
 x_1535 obj -1
 x_1535 r101 1
 x_1535 r102 1
 x_1535 r103 1
 x_1535 r104 1
 x_1535 r105 1
 x_1535 r106 1
 x_1535 r107 1
 x_1534 obj -1
 x_1534 r101 1
 x_1534 r108 1
 x_1534 r109 1
 x_1534 r110 1
 x_1534 r111 1
 x_1534 r112 1
 x_1534 r113 1
 x_1534 r114 1
 x_1534 r115 1
 x_1534 r116 1
 x_1532 obj -1
 x_1532 r67 1
 x_1532 r84 1
 x_1532 r102 1
 x_1532 r108 1
 x_1532 r117 1
 x_1532 r118 1
 x_1532 r119 1
 x_1532 r120 1
 x_1532 r121 1
 x_1532 r122 1
 x_1532 r123 1
 x_1728 obj -1
 x_1728 r26 1
 x_1728 r57 1
 x_1728 r76 1
 x_1728 r124 1
 x_1728 r125 1
 x_1728 r126 1
 x_1728 r127 1
 x_1728 r128 1
 x_1728 r129 1
 x_1856 obj -1
 x_1856 r58 1
 x_1856 r90 1
 x_1856 r124 1
 x_1856 r130 1
 x_1856 r131 1
 x_1856 r132 1
 x_1856 r133 1
 x_1020 obj -1
 x_1020 r85 1
 x_1020 r94 1
 x_1020 r109 1
 x_1020 r117 1
 x_1020 r134 1
 x_1020 r135 1
 x_1020 r136 1
 x_1020 r137 1
 x_1023 obj -1
 x_1023 r103 1
 x_1023 r110 1
 x_1023 r134 1
 x_1023 r138 1
 x_1023 r139 1
 x_1022 obj -1
 x_1022 r86 1
 x_1022 r104 1
 x_1022 r111 1
 x_1022 r118 1
 x_1022 r135 1
 x_1022 r138 1
 x_1022 r140 1
 x_1904 obj -1
 x_1904 r37 1
 x_1904 r48 1
 x_1904 r59 1
 x_1904 r68 1
 x_1904 r77 1
 x_1904 r91 1
 x_1904 r130 1
 x_1904 r141 1
 x_1904 r142 1
 x_1904 r143 1
 x_1904 r144 1
 x_1904 r145 1
 x_1791 obj -1
 x_1791 r105 1
 x_1791 r112 1
 x_1791 r139 1
 x_1791 r146 1
 x_1791 r147 1
 x_1791 r148 1
 x_1791 r149 1
 x_1791 r150 1
 x_1472 obj -1
 x_1472 r18 1
 x_1472 r27 1
 x_1472 r60 1
 x_1472 r125 1
 x_1472 r131 1
 x_1472 r151 1
 x_1472 r152 1
 x_1472 r153 1
 x_1472 r154 1
 x_1472 r155 1
 x_1472 r156 1
 x_1919 obj -1
 x_1919 r106 1
 x_1919 r146 1
 x_1919 r157 1
 x_1919 r158 1
 x_1919 r159 1
 x_1919 r160 1
 x_1919 r161 1
 x_1919 r162 1
 x_1918 obj -1
 x_1918 r113 1
 x_1918 r147 1
 x_1918 r157 1
 x_1918 r163 1
 x_1918 r164 1
 x_1918 r165 1
 x_1918 r166 1
 x_1918 r167 1
 x_1918 r168 1
 x_1918 r169 1
 x_1918 r170 1
 x_1912 obj -1
 x_1912 r38 1
 x_1912 r49 1
 x_1912 r69 1
 x_1912 r78 1
 x_1912 r141 1
 x_1912 r163 1
 x_1912 r171 1
 x_1912 r172 1
 x_1912 r173 1
 x_1912 r174 1
 x_1912 r175 1
 x_1912 r176 1
 x_1916 obj -1
 x_1916 r39 1
 x_1916 r70 1
 x_1916 r119 1
 x_1916 r142 1
 x_1916 r158 1
 x_1916 r164 1
 x_1916 r171 1
 x_1916 r177 1
 x_1916 r178 1
 x_1916 r179 1
 x_1916 r180 1
 x_1916 r181 1
 x_2024 obj -1
 x_2024 r40 1
 x_2024 r182 1
 x_2024 r183 1
 x_2024 r184 1
 x_2024 r185 1
 x_2024 r186 1
 x_2024 r187 1
 x_2028 obj -1
 x_2028 r11 1
 x_2028 r182 1
 x_2028 r188 1
 x_2028 r189 1
 x_2028 r190 1
 x_2028 r191 1
 x_2028 r192 1
 x_2028 r193 1
 x_2028 r194 1
 x_1520 obj -1
 x_1520 r28 1
 x_1520 r61 1
 x_1520 r71 1
 x_1520 r79 1
 x_1520 r87 1
 x_1520 r95 1
 x_1520 r120 1
 x_1520 r143 1
 x_1520 r151 1
 x_1520 r195 1
 x_1520 r196 1
 x_960 obj -1
 x_960 r29 1
 x_960 r96 1
 x_960 r126 1
 x_960 r152 1
 x_960 r197 1
 x_960 r198 1
 x_960 r199 1
 x_960 r200 1
 x_2036 obj -1
 x_2036 r5 1
 x_2036 r12 1
 x_2036 r183 1
 x_2036 r188 1
 x_2036 r201 1
 x_2036 r202 1
 x_2036 r203 1
 x_2031 obj -1
 x_2031 r9 1
 x_2031 r13 1
 x_2031 r189 1
 x_2031 r204 1
 x_2031 r205 1
 x_2031 r206 1
 x_2031 r207 1
 x_2031 r208 1
 x_2030 obj -1
 x_2030 r6 1
 x_2030 r14 1
 x_2030 r184 1
 x_2030 r190 1
 x_2030 r201 1
 x_2030 r204 1
 x_2030 r209 1
 x_2030 r210 1
 x_2030 r211 1
 x_2030 r212 1
 x_2030 r213 1
 x_2039 obj -1
 x_2039 r2 1
 x_2039 r7 1
 x_2039 r10 1
 x_2039 r15 1
 x_2039 r202 1
 x_2039 r205 1
 x_2039 r209 1
 x_2039 r214 1
 x_896 obj -1
 x_896 r19 1
 x_896 r99 1
 x_896 r153 1
 x_896 r197 1
 x_896 r215 1
 x_896 r216 1
 x_896 r217 1
 x_896 r218 1
 x_1788 obj -1
 x_1788 r72 1
 x_1788 r80 1
 x_1788 r114 1
 x_1788 r121 1
 x_1788 r136 1
 x_1788 r148 1
 x_1788 r165 1
 x_1788 r172 1
 x_1788 r177 1
 x_1788 r219 1
 x_1788 r220 1
 x_1788 r221 1
 x_768 obj -1
 x_768 r20 1
 x_768 r100 1
 x_768 r198 1
 x_768 r215 1
 x_768 r222 1
 x_1528 obj -1
 x_1528 r30 1
 x_1528 r73 1
 x_1528 r81 1
 x_1528 r88 1
 x_1528 r97 1
 x_1528 r115 1
 x_1528 r122 1
 x_1528 r137 1
 x_1528 r173 1
 x_1528 r195 1
 x_1528 r219 1
 x_2000 obj -1
 x_2000 r41 1
 x_2000 r50 1
 x_2000 r92 1
 x_2000 r144 1
 x_2000 r185 1
 x_2000 r223 1
 x_2000 r224 1
 x_2008 obj -1
 x_2008 r42 1
 x_2008 r51 1
 x_2008 r174 1
 x_2008 r186 1
 x_2008 r191 1
 x_2008 r223 1
 x_2008 r225 1
 x_2008 r226 1
 x_2008 r227 1
 x_1790 obj -1
 x_1790 r74 1
 x_1790 r107 1
 x_1790 r116 1
 x_1790 r123 1
 x_1790 r140 1
 x_1790 r149 1
 x_1790 r159 1
 x_1790 r166 1
 x_1790 r178 1
 x_1790 r220 1
 x_1790 r228 1
 x_1664 obj -1
 x_1664 r21 1
 x_1664 r62 1
 x_1664 r127 1
 x_1664 r132 1
 x_1664 r154 1
 x_1664 r216 1
 x_1664 r229 1
 x_1408 obj -1
 x_1408 r22 1
 x_1408 r31 1
 x_1408 r128 1
 x_1408 r155 1
 x_1408 r199 1
 x_1408 r217 1
 x_1408 r222 1
 x_1408 r229 1
 x_1888 obj -1
 x_1888 r32 1
 x_1888 r52 1
 x_1888 r63 1
 x_1888 r82 1
 x_1888 r93 1
 x_1888 r129 1
 x_1888 r133 1
 x_1888 r145 1
 x_1888 r175 1
 x_2015 obj -1
 x_2015 r160 1
 x_2015 r206 1
 x_2015 r210 1
 x_2015 r214 1
 x_2015 r230 1
 x_2015 r231 1
 x_2015 r232 1
 x_2015 r233 1
 x_2014 obj -1
 x_2014 r16 1
 x_2014 r167 1
 x_2014 r192 1
 x_2014 r207 1
 x_2014 r211 1
 x_2014 r225 1
 x_2014 r230 1
 x_2014 r234 1
 x_2014 r235 1
 x_2014 r236 1
 x_2014 r237 1
 x_2012 obj -1
 x_2012 r43 1
 x_2012 r179 1
 x_2012 r187 1
 x_2012 r193 1
 x_2012 r203 1
 x_2012 r212 1
 x_2012 r224 1
 x_2012 r226 1
 x_2012 r231 1
 x_2012 r234 1
 x_2012 r238 1
 x_2012 r239 1
 x_1982 obj -1
 x_1982 r44 1
 x_1982 r161 1
 x_1982 r168 1
 x_1982 r180 1
 x_1982 r213 1
 x_1982 r228 1
 x_1982 r232 1
 x_1982 r235 1
 x_1982 r238 1
 x_1982 r240 1
 x_1982 r241 1
 x_1983 obj -1
 x_1983 r150 1
 x_1983 r162 1
 x_1983 r169 1
 x_1983 r208 1
 x_1983 r233 1
 x_1983 r236 1
 x_1983 r240 1
 x_1983 r242 1
 x_992 obj -1
 x_992 r33 1
 x_992 r64 1
 x_992 r89 1
 x_992 r98 1
 x_992 r156 1
 x_992 r196 1
 x_992 r200 1
 x_992 r218 1
 x_1980 obj -1
 x_1980 r45 1
 x_1980 r53 1
 x_1980 r170 1
 x_1980 r176 1
 x_1980 r181 1
 x_1980 r194 1
 x_1980 r221 1
 x_1980 r227 1
 x_1980 r237 1
 x_1980 r239 1
 x_1980 r241 1
 x_1980 r242 1
RHS
 rhs r0 1
 rhs r1 1
 rhs r2 1
 rhs r3 1
 rhs r4 1
 rhs r5 1
 rhs r6 1
 rhs r7 1
 rhs r8 1
 rhs r9 1
 rhs r10 1
 rhs r11 1
 rhs r12 1
 rhs r13 1
 rhs r14 1
 rhs r15 1
 rhs r16 1
 rhs r17 1
 rhs r18 1
 rhs r19 1
 rhs r20 1
 rhs r21 1
 rhs r22 1
 rhs r23 1
 rhs r24 1
 rhs r25 1
 rhs r26 1
 rhs r27 1
 rhs r28 1
 rhs r29 1
 rhs r30 1
 rhs r31 1
 rhs r32 1
 rhs r33 1
 rhs r34 1
 rhs r35 1
 rhs r36 1
 rhs r37 1
 rhs r38 1
 rhs r39 1
 rhs r40 1
 rhs r41 1
 rhs r42 1
 rhs r43 1
 rhs r44 1
 rhs r45 1
 rhs r46 1
 rhs r47 1
 rhs r48 1
 rhs r49 1
 rhs r50 1
 rhs r51 1
 rhs r52 1
 rhs r53 1
 rhs r54 1
 rhs r55 1
 rhs r56 1
 rhs r57 1
 rhs r58 1
 rhs r59 1
 rhs r60 1
 rhs r61 1
 rhs r62 1
 rhs r63 1
 rhs r64 1
 rhs r65 1
 rhs r66 1
 rhs r67 1
 rhs r68 1
 rhs r69 1
 rhs r70 1
 rhs r71 1
 rhs r72 1
 rhs r73 1
 rhs r74 1
 rhs r75 1
 rhs r76 1
 rhs r77 1
 rhs r78 1
 rhs r79 1
 rhs r80 1
 rhs r81 1
 rhs r82 1
 rhs r83 1
 rhs r84 1
 rhs r85 1
 rhs r86 1
 rhs r87 1
 rhs r88 1
 rhs r89 1
 rhs r90 1
 rhs r91 1
 rhs r92 1
 rhs r93 1
 rhs r94 1
 rhs r95 1
 rhs r96 1
 rhs r97 1
 rhs r98 1
 rhs r99 1
 rhs r100 1
 rhs r101 1
 rhs r102 1
 rhs r103 1
 rhs r104 1
 rhs r105 1
 rhs r106 1
 rhs r107 1
 rhs r108 1
 rhs r109 1
 rhs r110 1
 rhs r111 1
 rhs r112 1
 rhs r113 1
 rhs r114 1
 rhs r115 1
 rhs r116 1
 rhs r117 1
 rhs r118 1
 rhs r119 1
 rhs r120 1
 rhs r121 1
 rhs r122 1
 rhs r123 1
 rhs r124 1
 rhs r125 1
 rhs r126 1
 rhs r127 1
 rhs r128 1
 rhs r129 1
 rhs r130 1
 rhs r131 1
 rhs r132 1
 rhs r133 1
 rhs r134 1
 rhs r135 1
 rhs r136 1
 rhs r137 1
 rhs r138 1
 rhs r139 1
 rhs r140 1
 rhs r141 1
 rhs r142 1
 rhs r143 1
 rhs r144 1
 rhs r145 1
 rhs r146 1
 rhs r147 1
 rhs r148 1
 rhs r149 1
 rhs r150 1
 rhs r151 1
 rhs r152 1
 rhs r153 1
 rhs r154 1
 rhs r155 1
 rhs r156 1
 rhs r157 1
 rhs r158 1
 rhs r159 1
 rhs r160 1
 rhs r161 1
 rhs r162 1
 rhs r163 1
 rhs r164 1
 rhs r165 1
 rhs r166 1
 rhs r167 1
 rhs r168 1
 rhs r169 1
 rhs r170 1
 rhs r171 1
 rhs r172 1
 rhs r173 1
 rhs r174 1
 rhs r175 1
 rhs r176 1
 rhs r177 1
 rhs r178 1
 rhs r179 1
 rhs r180 1
 rhs r181 1
 rhs r182 1
 rhs r183 1
 rhs r184 1
 rhs r185 1
 rhs r186 1
 rhs r187 1
 rhs r188 1
 rhs r189 1
 rhs r190 1
 rhs r191 1
 rhs r192 1
 rhs r193 1
 rhs r194 1
 rhs r195 1
 rhs r196 1
 rhs r197 1
 rhs r198 1
 rhs r199 1
 rhs r200 1
 rhs r201 1
 rhs r202 1
 rhs r203 1
 rhs r204 1
 rhs r205 1
 rhs r206 1
 rhs r207 1
 rhs r208 1
 rhs r209 1
 rhs r210 1
 rhs r211 1
 rhs r212 1
 rhs r213 1
 rhs r214 1
 rhs r215 1
 rhs r216 1
 rhs r217 1
 rhs r218 1
 rhs r219 1
 rhs r220 1
 rhs r221 1
 rhs r222 1
 rhs r223 1
 rhs r224 1
 rhs r225 1
 rhs r226 1
 rhs r227 1
 rhs r228 1
 rhs r229 1
 rhs r230 1
 rhs r231 1
 rhs r232 1
 rhs r233 1
 rhs r234 1
 rhs r235 1
 rhs r236 1
 rhs r237 1
 rhs r238 1
 rhs r239 1
 rhs r240 1
 rhs r241 1
 rhs r242 1
BOUNDS
 BV bound x_2045
 BV bound x_2042
 BV bound x_2043
 BV bound x_2038
 BV bound x_1280
 BV bound x_1504
 BV bound x_1976
 BV bound x_1968
 BV bound x_1760
 BV bound x_1784
 BV bound x_1776
 BV bound x_1016
 BV bound x_1952
 BV bound x_1008
 BV bound x_512
 BV bound x_1535
 BV bound x_1534
 BV bound x_1532
 BV bound x_1728
 BV bound x_1856
 BV bound x_1020
 BV bound x_1023
 BV bound x_1022
 BV bound x_1904
 BV bound x_1791
 BV bound x_1472
 BV bound x_1919
 BV bound x_1918
 BV bound x_1912
 BV bound x_1916
 BV bound x_2024
 BV bound x_2028
 BV bound x_1520
 BV bound x_960
 BV bound x_2036
 BV bound x_2031
 BV bound x_2030
 BV bound x_2039
 BV bound x_896
 BV bound x_1788
 BV bound x_768
 BV bound x_1528
 BV bound x_2000
 BV bound x_2008
 BV bound x_1790
 BV bound x_1664
 BV bound x_1408
 BV bound x_1888
 BV bound x_2015
 BV bound x_2014
 BV bound x_2012
 BV bound x_1982
 BV bound x_1983
 BV bound x_992
 BV bound x_1980
ENDATA
