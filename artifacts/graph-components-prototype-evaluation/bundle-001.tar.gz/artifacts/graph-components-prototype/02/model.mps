NAME component
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
 L r40
 L r41
 L r42
 L r43
 L r44
 L r45
 L r46
 L r47
 L r48
 L r49
 L r50
 L r51
 L r52
 L r53
 L r54
 L r55
 L r56
 L r57
 L r58
 L r59
 L r60
 L r61
 L r62
 L r63
 L r64
 L r65
 L r66
 L r67
 L r68
 L r69
 L r70
 L r71
 L r72
 L r73
 L r74
 L r75
 L r76
 L r77
 L r78
 L r79
 L r80
 L r81
 L r82
 L r83
 L r84
 L r85
 L r86
 L r87
 L r88
 L r89
 L r90
 L r91
 L r92
 L r93
 L r94
 L r95
 L r96
 L r97
 L r98
 L r99
 L r100
 L r101
 L r102
 L r103
 L r104
 L r105
 L r106
 L r107
 L r108
 L r109
 L r110
 L r111
 L r112
 L r113
 L r114
 L r115
 L r116
 L r117
 L r118
 L r119
 L r120
 L r121
 L r122
 L r123
 L r124
 L r125
 L r126
 L r127
 L r128
 L r129
 L r130
 L r131
 L r132
 L r133
 L r134
 L r135
 L r136
 L r137
 L r138
 L r139
 L r140
 L r141
 L r142
 L r143
 L r144
 L r145
 L r146
 L r147
 L r148
 L r149
 L r150
 L r151
 L r152
 L r153
 L r154
 L r155
 L r156
 L r157
 L r158
 L r159
 L r160
 L r161
 L r162
 L r163
 L r164
 L r165
 L r166
 L r167
 L r168
 L r169
 L r170
 L r171
 L r172
 L r173
 L r174
 L r175
 L r176
 L r177
 L r178
 L r179
 L r180
 L r181
 L r182
 L r183
 L r184
 L r185
 L r186
 L r187
 L r188
 L r189
 L r190
 L r191
 L r192
 L r193
 L r194
 L r195
 L r196
 L r197
 L r198
 L r199
 L r200
 L r201
 L r202
 L r203
 L r204
 L r205
 L r206
 L r207
 L r208
 L r209
 L r210
 L r211
 L r212
 L r213
 L r214
 L r215
 L r216
 L r217
 L r218
 L r219
 L r220
 L r221
 L r222
 L r223
 L r224
 L r225
 L r226
 L r227
 L r228
 L r229
 L r230
 L r231
 L r232
 L r233
 L r234
 L r235
 L r236
 L r237
 L r238
 L r239
 L r240
 L r241
 L r242
COLUMNS
 x_273 obj -1
 x_273 r0 1
 x_273 r1 1
 x_273 r2 1
 x_273 r3 1
 x_273 r4 1
 x_273 r5 1
 x_273 r6 1
 x_273 r7 1
 x_273 r8 1
 x_273 r9 1
 x_273 r10 1
 x_273 r11 1
 x_97 obj -1
 x_97 r12 1
 x_97 r13 1
 x_97 r14 1
 x_97 r15 1
 x_97 r16 1
 x_97 r17 1
 x_97 r18 1
 x_1281 obj -1
 x_1281 r19 1
 x_1281 r20 1
 x_1281 r21 1
 x_1281 r22 1
 x_1281 r23 1
 x_545 obj -1
 x_545 r0 1
 x_545 r24 1
 x_545 r25 1
 x_545 r26 1
 x_545 r27 1
 x_545 r28 1
 x_545 r29 1
 x_545 r30 1
 x_545 r31 1
 x_545 r32 1
 x_545 r33 1
 x_385 obj -1
 x_385 r34 1
 x_385 r35 1
 x_385 r36 1
 x_385 r37 1
 x_385 r38 1
 x_385 r39 1
 x_385 r40 1
 x_258 obj -1
 x_258 r41 1
 x_258 r42 1
 x_258 r43 1
 x_258 r44 1
 x_258 r45 1
 x_258 r46 1
 x_258 r47 1
 x_258 r48 1
 x_259 obj -1
 x_259 r41 1
 x_259 r49 1
 x_259 r50 1
 x_259 r51 1
 x_259 r52 1
 x_259 r53 1
 x_259 r54 1
 x_259 r55 1
 x_259 r56 1
 x_259 r57 1
 x_259 r58 1
 x_161 obj -1
 x_161 r1 1
 x_161 r12 1
 x_161 r24 1
 x_161 r59 1
 x_161 r60 1
 x_161 r61 1
 x_161 r62 1
 x_161 r63 1
 x_161 r64 1
 x_1153 obj -1
 x_1153 r19 1
 x_1153 r34 1
 x_1153 r65 1
 x_1153 r66 1
 x_1153 r67 1
 x_1153 r68 1
 x_1153 r69 1
 x_1153 r70 1
 x_521 obj -1
 x_521 r2 1
 x_521 r25 1
 x_521 r71 1
 x_521 r72 1
 x_521 r73 1
 x_521 r74 1
 x_521 r75 1
 x_521 r76 1
 x_521 r77 1
 x_521 r78 1
 x_521 r79 1
 x_529 obj -1
 x_529 r3 1
 x_529 r26 1
 x_529 r71 1
 x_529 r80 1
 x_529 r81 1
 x_529 r82 1
 x_529 r83 1
 x_529 r84 1
 x_529 r85 1
 x_529 r86 1
 x_529 r87 1
 x_145 obj -1
 x_145 r4 1
 x_145 r13 1
 x_145 r59 1
 x_145 r80 1
 x_145 r88 1
 x_145 r89 1
 x_145 r90 1
 x_145 r91 1
 x_145 r92 1
 x_145 r93 1
 x_145 r94 1
 x_145 r95 1
 x_515 obj -1
 x_515 r42 1
 x_515 r49 1
 x_515 r72 1
 x_515 r96 1
 x_515 r97 1
 x_515 r98 1
 x_515 r99 1
 x_515 r100 1
 x_515 r101 1
 x_515 r102 1
 x_514 obj -1
 x_514 r43 1
 x_514 r50 1
 x_514 r96 1
 x_514 r103 1
 x_514 r104 1
 x_514 r105 1
 x_514 r106 1
 x_517 obj -1
 x_517 r51 1
 x_517 r73 1
 x_517 r81 1
 x_517 r97 1
 x_517 r103 1
 x_517 r107 1
 x_517 r108 1
 x_517 r109 1
 x_517 r110 1
 x_517 r111 1
 x_517 r112 1
 x_11 obj -1
 x_11 r113 1
 x_11 r114 1
 x_11 r115 1
 x_11 r116 1
 x_11 r117 1
 x_11 r118 1
 x_11 r119 1
 x_11 r120 1
 x_10 obj -1
 x_10 r113 1
 x_10 r121 1
 x_10 r122 1
 x_10 r123 1
 x_10 r124 1
 x_10 r125 1
 x_10 r126 1
 x_10 r127 1
 x_13 obj -1
 x_13 r114 1
 x_13 r121 1
 x_13 r128 1
 x_13 r129 1
 x_13 r130 1
 x_13 r131 1
 x_13 r132 1
 x_19 obj -1
 x_19 r115 1
 x_19 r122 1
 x_19 r128 1
 x_19 r133 1
 x_19 r134 1
 x_19 r135 1
 x_19 r136 1
 x_19 r137 1
 x_19 r138 1
 x_19 r139 1
 x_19 r140 1
 x_18 obj -1
 x_18 r116 1
 x_18 r123 1
 x_18 r133 1
 x_18 r141 1
 x_18 r142 1
 x_18 r143 1
 x_18 r144 1
 x_18 r145 1
 x_66 obj -1
 x_66 r44 1
 x_66 r141 1
 x_66 r146 1
 x_66 r147 1
 x_66 r148 1
 x_66 r149 1
 x_66 r150 1
 x_66 r151 1
 x_67 obj -1
 x_67 r52 1
 x_67 r134 1
 x_67 r146 1
 x_67 r152 1
 x_67 r153 1
 x_67 r154 1
 x_67 r155 1
 x_67 r156 1
 x_67 r157 1
 x_67 r158 1
 x_67 r159 1
 x_69 obj -1
 x_69 r147 1
 x_69 r152 1
 x_69 r160 1
 x_69 r161 1
 x_69 r162 1
 x_69 r163 1
 x_69 r164 1
 x_69 r165 1
 x_69 r166 1
 x_69 r167 1
 x_69 r168 1
 x_69 r169 1
 x_4 obj -1
 x_4 r124 1
 x_4 r170 1
 x_4 r171 1
 x_1033 obj -1
 x_1033 r74 1
 x_1033 r82 1
 x_1033 r107 1
 x_1033 r172 1
 x_1033 r173 1
 x_1033 r174 1
 x_1033 r175 1
 x_1033 r176 1
 x_1027 obj -1
 x_1027 r53 1
 x_1027 r98 1
 x_1027 r104 1
 x_1027 r108 1
 x_1027 r172 1
 x_1027 r177 1
 x_1027 r178 1
 x_1029 obj -1
 x_1029 r75 1
 x_1029 r99 1
 x_1029 r109 1
 x_1029 r173 1
 x_1029 r177 1
 x_1029 r179 1
 x_1029 r180 1
 x_1029 r181 1
 x_193 obj -1
 x_193 r14 1
 x_193 r35 1
 x_193 r60 1
 x_193 r88 1
 x_193 r182 1
 x_193 r183 1
 x_193 r184 1
 x_6 obj -1
 x_6 r117 1
 x_6 r125 1
 x_6 r142 1
 x_6 r170 1
 x_6 r185 1
 x_1057 obj -1
 x_1057 r27 1
 x_1057 r65 1
 x_1057 r83 1
 x_1057 r174 1
 x_1057 r186 1
 x_1057 r187 1
 x_1057 r188 1
 x_1057 r189 1
 x_25 obj -1
 x_25 r129 1
 x_25 r135 1
 x_25 r190 1
 x_25 r191 1
 x_25 r192 1
 x_25 r193 1
 x_25 r194 1
 x_21 obj -1
 x_21 r118 1
 x_21 r130 1
 x_21 r136 1
 x_21 r143 1
 x_21 r160 1
 x_21 r190 1
 x_21 r195 1
 x_21 r196 1
 x_21 r197 1
 x_7 obj -1
 x_7 r119 1
 x_7 r126 1
 x_7 r131 1
 x_7 r137 1
 x_7 r171 1
 x_7 r185 1
 x_73 obj -1
 x_73 r15 1
 x_73 r89 1
 x_73 r153 1
 x_73 r161 1
 x_73 r191 1
 x_73 r198 1
 x_73 r199 1
 x_73 r200 1
 x_73 r201 1
 x_73 r202 1
 x_73 r203 1
 x_73 r204 1
 x_1041 obj -1
 x_1041 r5 1
 x_1041 r28 1
 x_1041 r76 1
 x_1041 r84 1
 x_1041 r175 1
 x_1041 r179 1
 x_1041 r186 1
 x_1041 r205 1
 x_1537 obj -1
 x_1537 r20 1
 x_1537 r66 1
 x_1537 r206 1
 x_769 obj -1
 x_769 r21 1
 x_769 r36 1
 x_769 r67 1
 x_769 r206 1
 x_769 r207 1
 x_769 r208 1
 x_1089 obj -1
 x_1089 r22 1
 x_1089 r29 1
 x_1089 r68 1
 x_1089 r187 1
 x_1089 r205 1
 x_1089 r209 1
 x_1089 r210 1
 x_1089 r211 1
 x_37 obj -1
 x_37 r132 1
 x_37 r138 1
 x_37 r154 1
 x_37 r162 1
 x_37 r192 1
 x_37 r195 1
 x_37 r198 1
 x_37 r212 1
 x_37 r213 1
 x_37 r214 1
 x_37 r215 1
 x_37 r216 1
 x_35 obj -1
 x_35 r120 1
 x_35 r139 1
 x_35 r144 1
 x_35 r148 1
 x_35 r155 1
 x_35 r163 1
 x_35 r196 1
 x_35 r212 1
 x_35 r217 1
 x_35 r218 1
 x_35 r219 1
 x_34 obj -1
 x_34 r127 1
 x_34 r140 1
 x_34 r145 1
 x_34 r149 1
 x_34 r156 1
 x_34 r213 1
 x_34 r217 1
 x_34 r220 1
 x_641 obj -1
 x_641 r23 1
 x_641 r30 1
 x_641 r37 1
 x_641 r69 1
 x_641 r207 1
 x_641 r209 1
 x_641 r221 1
 x_641 r222 1
 x_1026 obj -1
 x_1026 r45 1
 x_1026 r100 1
 x_1026 r105 1
 x_1026 r178 1
 x_1026 r180 1
 x_133 obj -1
 x_133 r54 1
 x_133 r90 1
 x_133 r110 1
 x_133 r157 1
 x_133 r164 1
 x_133 r199 1
 x_133 r214 1
 x_133 r223 1
 x_133 r224 1
 x_133 r225 1
 x_133 r226 1
 x_133 r227 1
 x_131 obj -1
 x_131 r46 1
 x_131 r55 1
 x_131 r101 1
 x_131 r150 1
 x_131 r158 1
 x_131 r165 1
 x_131 r218 1
 x_131 r223 1
 x_131 r228 1
 x_131 r229 1
 x_131 r230 1
 x_130 obj -1
 x_130 r47 1
 x_130 r56 1
 x_130 r106 1
 x_130 r151 1
 x_130 r159 1
 x_130 r220 1
 x_130 r224 1
 x_130 r228 1
 x_137 obj -1
 x_137 r6 1
 x_137 r61 1
 x_137 r77 1
 x_137 r91 1
 x_137 r166 1
 x_137 r200 1
 x_137 r225 1
 x_137 r229 1
 x_137 r231 1
 x_137 r232 1
 x_137 r233 1
 x_137 r234 1
 x_81 obj -1
 x_81 r7 1
 x_81 r16 1
 x_81 r62 1
 x_81 r92 1
 x_81 r167 1
 x_81 r201 1
 x_81 r231 1
 x_81 r235 1
 x_81 r236 1
 x_321 obj -1
 x_321 r8 1
 x_321 r31 1
 x_321 r38 1
 x_321 r63 1
 x_321 r182 1
 x_321 r210 1
 x_321 r221 1
 x_321 r237 1
 x_321 r238 1
 x_577 obj -1
 x_577 r32 1
 x_577 r39 1
 x_577 r70 1
 x_577 r85 1
 x_577 r183 1
 x_577 r188 1
 x_577 r208 1
 x_577 r211 1
 x_577 r222 1
 x_577 r237 1
 x_577 r239 1
 x_289 obj -1
 x_289 r9 1
 x_289 r17 1
 x_289 r33 1
 x_289 r40 1
 x_289 r64 1
 x_289 r86 1
 x_289 r93 1
 x_289 r184 1
 x_289 r189 1
 x_289 r238 1
 x_289 r239 1
 x_289 r240 1
 x_261 obj -1
 x_261 r10 1
 x_261 r48 1
 x_261 r57 1
 x_261 r78 1
 x_261 r102 1
 x_261 r111 1
 x_261 r168 1
 x_261 r181 1
 x_261 r226 1
 x_261 r230 1
 x_261 r232 1
 x_261 r241 1
 x_265 obj -1
 x_265 r11 1
 x_265 r58 1
 x_265 r79 1
 x_265 r87 1
 x_265 r94 1
 x_265 r112 1
 x_265 r176 1
 x_265 r202 1
 x_265 r227 1
 x_265 r233 1
 x_265 r240 1
 x_265 r241 1
 x_49 obj -1
 x_49 r18 1
 x_49 r95 1
 x_49 r193 1
 x_49 r203 1
 x_49 r215 1
 x_49 r235 1
 x_49 r242 1
 x_41 obj -1
 x_41 r169 1
 x_41 r194 1
 x_41 r197 1
 x_41 r204 1
 x_41 r216 1
 x_41 r219 1
 x_41 r234 1
 x_41 r236 1
 x_41 r242 1
RHS
 rhs r0 1
 rhs r1 1
 rhs r2 1
 rhs r3 1
 rhs r4 1
 rhs r5 1
 rhs r6 1
 rhs r7 1
 rhs r8 1
 rhs r9 1
 rhs r10 1
 rhs r11 1
 rhs r12 1
 rhs r13 1
 rhs r14 1
 rhs r15 1
 rhs r16 1
 rhs r17 1
 rhs r18 1
 rhs r19 1
 rhs r20 1
 rhs r21 1
 rhs r22 1
 rhs r23 1
 rhs r24 1
 rhs r25 1
 rhs r26 1
 rhs r27 1
 rhs r28 1
 rhs r29 1
 rhs r30 1
 rhs r31 1
 rhs r32 1
 rhs r33 1
 rhs r34 1
 rhs r35 1
 rhs r36 1
 rhs r37 1
 rhs r38 1
 rhs r39 1
 rhs r40 1
 rhs r41 1
 rhs r42 1
 rhs r43 1
 rhs r44 1
 rhs r45 1
 rhs r46 1
 rhs r47 1
 rhs r48 1
 rhs r49 1
 rhs r50 1
 rhs r51 1
 rhs r52 1
 rhs r53 1
 rhs r54 1
 rhs r55 1
 rhs r56 1
 rhs r57 1
 rhs r58 1
 rhs r59 1
 rhs r60 1
 rhs r61 1
 rhs r62 1
 rhs r63 1
 rhs r64 1
 rhs r65 1
 rhs r66 1
 rhs r67 1
 rhs r68 1
 rhs r69 1
 rhs r70 1
 rhs r71 1
 rhs r72 1
 rhs r73 1
 rhs r74 1
 rhs r75 1
 rhs r76 1
 rhs r77 1
 rhs r78 1
 rhs r79 1
 rhs r80 1
 rhs r81 1
 rhs r82 1
 rhs r83 1
 rhs r84 1
 rhs r85 1
 rhs r86 1
 rhs r87 1
 rhs r88 1
 rhs r89 1
 rhs r90 1
 rhs r91 1
 rhs r92 1
 rhs r93 1
 rhs r94 1
 rhs r95 1
 rhs r96 1
 rhs r97 1
 rhs r98 1
 rhs r99 1
 rhs r100 1
 rhs r101 1
 rhs r102 1
 rhs r103 1
 rhs r104 1
 rhs r105 1
 rhs r106 1
 rhs r107 1
 rhs r108 1
 rhs r109 1
 rhs r110 1
 rhs r111 1
 rhs r112 1
 rhs r113 1
 rhs r114 1
 rhs r115 1
 rhs r116 1
 rhs r117 1
 rhs r118 1
 rhs r119 1
 rhs r120 1
 rhs r121 1
 rhs r122 1
 rhs r123 1
 rhs r124 1
 rhs r125 1
 rhs r126 1
 rhs r127 1
 rhs r128 1
 rhs r129 1
 rhs r130 1
 rhs r131 1
 rhs r132 1
 rhs r133 1
 rhs r134 1
 rhs r135 1
 rhs r136 1
 rhs r137 1
 rhs r138 1
 rhs r139 1
 rhs r140 1
 rhs r141 1
 rhs r142 1
 rhs r143 1
 rhs r144 1
 rhs r145 1
 rhs r146 1
 rhs r147 1
 rhs r148 1
 rhs r149 1
 rhs r150 1
 rhs r151 1
 rhs r152 1
 rhs r153 1
 rhs r154 1
 rhs r155 1
 rhs r156 1
 rhs r157 1
 rhs r158 1
 rhs r159 1
 rhs r160 1
 rhs r161 1
 rhs r162 1
 rhs r163 1
 rhs r164 1
 rhs r165 1
 rhs r166 1
 rhs r167 1
 rhs r168 1
 rhs r169 1
 rhs r170 1
 rhs r171 1
 rhs r172 1
 rhs r173 1
 rhs r174 1
 rhs r175 1
 rhs r176 1
 rhs r177 1
 rhs r178 1
 rhs r179 1
 rhs r180 1
 rhs r181 1
 rhs r182 1
 rhs r183 1
 rhs r184 1
 rhs r185 1
 rhs r186 1
 rhs r187 1
 rhs r188 1
 rhs r189 1
 rhs r190 1
 rhs r191 1
 rhs r192 1
 rhs r193 1
 rhs r194 1
 rhs r195 1
 rhs r196 1
 rhs r197 1
 rhs r198 1
 rhs r199 1
 rhs r200 1
 rhs r201 1
 rhs r202 1
 rhs r203 1
 rhs r204 1
 rhs r205 1
 rhs r206 1
 rhs r207 1
 rhs r208 1
 rhs r209 1
 rhs r210 1
 rhs r211 1
 rhs r212 1
 rhs r213 1
 rhs r214 1
 rhs r215 1
 rhs r216 1
 rhs r217 1
 rhs r218 1
 rhs r219 1
 rhs r220 1
 rhs r221 1
 rhs r222 1
 rhs r223 1
 rhs r224 1
 rhs r225 1
 rhs r226 1
 rhs r227 1
 rhs r228 1
 rhs r229 1
 rhs r230 1
 rhs r231 1
 rhs r232 1
 rhs r233 1
 rhs r234 1
 rhs r235 1
 rhs r236 1
 rhs r237 1
 rhs r238 1
 rhs r239 1
 rhs r240 1
 rhs r241 1
 rhs r242 1
BOUNDS
 BV bound x_273
 BV bound x_97
 BV bound x_1281
 BV bound x_545
 BV bound x_385
 BV bound x_258
 BV bound x_259
 BV bound x_161
 BV bound x_1153
 BV bound x_521
 BV bound x_529
 BV bound x_145
 BV bound x_515
 BV bound x_514
 BV bound x_517
 BV bound x_11
 BV bound x_10
 BV bound x_13
 BV bound x_19
 BV bound x_18
 BV bound x_66
 BV bound x_67
 BV bound x_69
 BV bound x_4
 BV bound x_1033
 BV bound x_1027
 BV bound x_1029
 BV bound x_193
 BV bound x_6
 BV bound x_1057
 BV bound x_25
 BV bound x_21
 BV bound x_7
 BV bound x_73
 BV bound x_1041
 BV bound x_1537
 BV bound x_769
 BV bound x_1089
 BV bound x_37
 BV bound x_35
 BV bound x_34
 BV bound x_641
 BV bound x_1026
 BV bound x_133
 BV bound x_131
 BV bound x_130
 BV bound x_137
 BV bound x_81
 BV bound x_321
 BV bound x_577
 BV bound x_289
 BV bound x_261
 BV bound x_265
 BV bound x_49
 BV bound x_41
ENDATA
