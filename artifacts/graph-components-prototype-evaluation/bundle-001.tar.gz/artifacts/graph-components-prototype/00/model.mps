NAME component
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
COLUMNS
 x_2046 obj -1
 x_2046 r0 1
 x_2046 r1 1
 x_2046 r2 1
 x_2047 obj -1
 x_2047 r0 1
 x_2047 r3 1
 x_2044 obj -1
 x_2044 r1 1
 x_2044 r3 1
 x_2044 r4 1
 x_2044 r5 1
 x_2040 obj -1
 x_2040 r2 1
 x_2040 r4 1
 x_2040 r6 1
 x_2040 r7 1
 x_1536 obj -1
 x_1536 r8 1
 x_1536 r9 1
 x_1536 r10 1
 x_1920 obj -1
 x_1920 r8 1
 x_1920 r11 1
 x_1920 r12 1
 x_1920 r13 1
 x_1024 obj -1
 x_1024 r9 1
 x_1024 r14 1
 x_2032 obj -1
 x_2032 r5 1
 x_2032 r6 1
 x_2032 r15 1
 x_2032 r16 1
 x_1792 obj -1
 x_1792 r10 1
 x_1792 r11 1
 x_1792 r14 1
 x_1792 r17 1
 x_2016 obj -1
 x_2016 r7 1
 x_2016 r12 1
 x_2016 r15 1
 x_2016 r18 1
 x_1984 obj -1
 x_1984 r13 1
 x_1984 r16 1
 x_1984 r17 1
 x_1984 r18 1
RHS
 rhs r0 1
 rhs r1 1
 rhs r2 1
 rhs r3 1
 rhs r4 1
 rhs r5 1
 rhs r6 1
 rhs r7 1
 rhs r8 1
 rhs r9 1
 rhs r10 1
 rhs r11 1
 rhs r12 1
 rhs r13 1
 rhs r14 1
 rhs r15 1
 rhs r16 1
 rhs r17 1
 rhs r18 1
BOUNDS
 BV bound x_2046
 BV bound x_2047
 BV bound x_2044
 BV bound x_2040
 BV bound x_1536
 BV bound x_1920
 BV bound x_1024
 BV bound x_2032
 BV bound x_1792
 BV bound x_2016
 BV bound x_1984
ENDATA
