NAME component
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
COLUMNS
 x_257 obj -1
 x_257 r0 1
 x_257 r1 1
 x_257 r2 1
 x_257 r3 1
 x_513 obj -1
 x_513 r0 1
 x_513 r4 1
 x_513 r5 1
 x_2 obj -1
 x_2 r6 1
 x_2 r7 1
 x_17 obj -1
 x_17 r8 1
 x_17 r9 1
 x_17 r10 1
 x_17 r11 1
 x_3 obj -1
 x_3 r6 1
 x_3 r12 1
 x_3 r13 1
 x_65 obj -1
 x_65 r1 1
 x_65 r8 1
 x_65 r14 1
 x_65 r15 1
 x_1025 obj -1
 x_1025 r2 1
 x_1025 r4 1
 x_9 obj -1
 x_9 r9 1
 x_9 r12 1
 x_9 r16 1
 x_9 r17 1
 x_5 obj -1
 x_5 r7 1
 x_5 r10 1
 x_5 r13 1
 x_5 r16 1
 x_33 obj -1
 x_33 r11 1
 x_33 r14 1
 x_33 r17 1
 x_33 r18 1
 x_129 obj -1
 x_129 r3 1
 x_129 r5 1
 x_129 r15 1
 x_129 r18 1
RHS
 rhs r0 1
 rhs r1 1
 rhs r2 1
 rhs r3 1
 rhs r4 1
 rhs r5 1
 rhs r6 1
 rhs r7 1
 rhs r8 1
 rhs r9 1
 rhs r10 1
 rhs r11 1
 rhs r12 1
 rhs r13 1
 rhs r14 1
 rhs r15 1
 rhs r16 1
 rhs r17 1
 rhs r18 1
BOUNDS
 BV bound x_257
 BV bound x_513
 BV bound x_2
 BV bound x_17
 BV bound x_3
 BV bound x_65
 BV bound x_1025
 BV bound x_9
 BV bound x_5
 BV bound x_33
 BV bound x_129
ENDATA
