from pathlib import Path
import sys,os,json,itertools,collections,subprocess,time,resource
os.sched_setaffinity(0,{40});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,)*2);root=Path.cwd();os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MIP_ABSOLUTE_CHECKER=str(root/'third_party/miplib-checker/bin/solchecker-absolute'));sys.path.insert(0,'scripts')
from verify_cover_cuts import exact_model,validate_cut_proofs
from validate_solution import validate
from benchmark_common import sha256,atomic_json
model=root/'data/raw/exploratory/sorrell8.mps.gz';names,variables,rows,cost,offset=exact_model(model,True);assert offset==0 and all(cost[n]==-1 for n in names);assert all(v['integer']and v['lower']==0 and v['upper']==1 for v in variables.values())
index={n:i for i,n in enumerate(names)};parent=list(range(len(names)));edges=set()
def find(a):
 while parent[a]!=a:parent[a]=parent[parent[a]];a=parent[a]
 return a
for row in rows:
 if row['lower']is None and row['upper']is None:continue
 entries=[(index[n],a)for n,a in row['coefficients'].items()if a];assert len(entries)==2
 assert (row['lower']is None and row['upper']==1 and all(a==1 for _,a in entries))or(row['upper']is None and row['lower']==-1 and all(a==-1 for _,a in entries))
 a,b=sorted(j for j,_ in entries);edges.add((a,b));parent[find(a)]=find(b)
groups=collections.defaultdict(list)
for j in range(len(names)):groups[find(j)].append(j)
parts=sorted(groups.values(),key=lambda p:(len(p),min(p)));assert len(parts)==10
assert sorted(j for part in parts for j in part)==list(range(len(names)))
owner={j:k for k,part in enumerate(parts)for j in part};assert all(owner[a]==owner[b]for a,b in edges)
out=root/'artifacts/graph-components-prototype';out.mkdir();binary=root/'artifacts/graph-components-baseline/bin/mip-codex';atomic_json(out/'experiment.json',dict(cpu=40,seconds_per_component=30,max_total_optimization_seconds=300,threads=1,memory_bytes=16*1024**3,binary_sha256=sha256(binary),source='main1289c9; unchanged Rust optimizer',input_sha256=sha256(model),components=parts,cross_component_edges=0,original_bound_or_optimality_claim=False,optimizer_targets=None));records=[];point={}
for k,part in enumerate(parts):
 d=out/f'{k:02}';d.mkdir();included=set(part);localedges=[(a,b)for a,b in sorted(edges)if a in included];inc=collections.defaultdict(list)
 for i,(a,b)in enumerate(localedges):inc[a].append(i);inc[b].append(i)
 lines=['NAME component','OBJSENSE',' MIN','ROWS',' N obj']+[f' L r{i}'for i in range(len(localedges))]+['COLUMNS']
 for j in part:
  lines.append(f' {names[j]} obj -1');lines.extend(f' {names[j]} r{i} 1'for i in inc[j])
 lines+=['RHS']+[f' rhs r{i} 1'for i in range(len(localedges))]+['BOUNDS']+[f' BV bound {names[j]}'for j in part]+['ENDATA'];m=d/'model.mps';m.write_text('\n'.join(lines)+'\n')
 cmd=[str(binary),'solve',str(m),'30'];atomic_json(d/'job.json',dict(command=cmd,model_sha256=sha256(m)));start=time.monotonic();run=subprocess.run(cmd,capture_output=True,text=True,timeout=90);(d/'stdout.log').write_text(run.stdout);(d/'stderr.log').write_text(run.stderr);atomic_json(d/'execution.json',dict(exit_code=run.returncode,wall_seconds=time.monotonic()-start));assert run.returncode==0,run.stderr
 r=json.loads(run.stdout);atomic_json(d/'result.json',r);v=validate(m,r);atomic_json(d/'validation.json',v);assert v['valid'];proof=validate_cut_proofs(m,r);atomic_json(d/'proof.json',proof);assert proof['valid'];assert set(r['values'])=={names[j]for j in part};point.update(r['values']);records.append(dict(component=k,variables=len(part),edges=len(localedges),status=r['status'],objective=r['objective'],dual_bound=r['dual_bound'],seconds=r['seconds'],nodes=r['nodes'],gmp_valid=True,proof_valid=True,independent_root_optimality=proof['binary_graph']['independent_optimality']));atomic_json(out/'records.json',records);print(json.dumps(records[-1]),flush=True)
assert set(point)==set(names);objective=-sum(point.values());r=dict(status='feasible',objective=objective,values=point);atomic_json(out/'combined-result.json',r);v=validate(model,r);atomic_json(out/'combined-validation.json',v);assert v['valid'];atomic_json(out/'summary.json',dict(components=len(records),component_gmp_valid=len(records),component_proof_valid=len(records),component_optimal_status=sum(x['status']=='optimal'for x in records),combined_objective=objective,combined_original_gmp_valid=True,optimization_seconds_sum=sum(x['seconds']for x in records),original_bound_or_optimality_claim=False,known_solution_used=False));print(json.dumps(json.load(open(out/'summary.json'))),flush=True)
