from pathlib import Path
import os,json,subprocess,sys
root=Path.cwd();sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256
import time
prior=Path('/home/ubuntu/mip-adaptive-fractional-groups/artifacts/fractional-groups-development-screen')
while True:
 exits=list(prior.glob('worker-*-exit.json'))
 if len(exits)==5:
  assert all(json.loads(p.read_text())['status']=='complete' for p in exits)
  break
 time.sleep(10)
out=root/'artifacts/color-repair-development-screen';out.mkdir();origin=json.load(open('artifacts/color-repair-origin.json'));binary=root/'artifacts/color-repair-frozen/bin/mip-codex';record=dict(path=str(binary),sha256=sha256(binary),build_info=origin['build_info']);atomic_json(out/'experiment.json',dict(shards=5,binaries={k:record for k in ['before','after']},seconds=10,threads=1,memory_bytes=16*1024**3,cpus=[31,32,33,34,35],color_repair={'before':'explicit 0','after':'explicit 1'},purpose='development188 only; same frozen binary node coloring repair off/on; candidate default off; both explicit'))
workers=[]
for shard,cpu in enumerate([31,32,33,34,35]):
 with (out/f'worker-{shard}.log').open('w')as log:p=subprocess.Popen([sys.executable,'artifacts/color-repair-development-screen.py',str(cpu),str(shard),'5'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 workers.append(dict(shard=shard,cpu=cpu,pid=p.pid))
atomic_json(out/'workers.json',workers);print(json.dumps(workers))
