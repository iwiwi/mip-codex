from pathlib import Path
import shutil,json,sys
sys.path.insert(0,'scripts');from benchmark_common import require_solver_origin,sha256,atomic_json
repo=Path('/home/ubuntu/mip-zero-phase-one');out=Path('artifacts/zero-phase-one-main119-diagnostic');out.mkdir();info=require_solver_origin(repo,repo/'target/release/mip-codex');ledger=[]
for p in [*repo.glob('src/**/*.rs'),*repo.glob('scripts/*.py'),repo/'Cargo.toml',repo/'Cargo.lock',repo/'build.rs',*repo.glob('tests/**/*.rs')]:
 q=out/p.relative_to(repo);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);ledger.append(dict(path=str(p.relative_to(repo)),sha256=sha256(q)))
q=out/'bin/mip-codex';q.parent.mkdir();shutil.copy2(repo/'target/release/mip-codex',q);ledger.append(dict(path='bin/mip-codex',sha256=sha256(q)));atomic_json(out/'sha256.json',ledger);atomic_json(out/'build-info.json',info);print(info)
