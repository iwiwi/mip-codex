from pathlib import Path
from fractions import Fraction as F
import os,json,subprocess,random,shutil,sys
import highspy,numpy as np
sys.path.insert(0,'scripts')
from benchmark_common import atomic_json,sha256
os.sched_setaffinity(0,{42})
root=Path.cwd();repo=Path('/home/ubuntu/mip-zero-phase-one');out=root/'artifacts/zero-phase-one-default-lp-oracle';out.mkdir();rng=random.Random(2026111727);records=[];tol=F(1,1000000)
for name in ['reopt_lp','append_lp']:
 shutil.copy2(repo/f'target/release/examples/{name}',out/name);shutil.copy2(repo/f'examples/{name}.rs',out/f'{name}.rs')
atomic_json(out/'experiment.json',dict(seed=2026111727,templates=100,senses=2,cpu=42,columns=1300,binaries={n:sha256(out/n)for n in ['reopt_lp','append_lp']},purpose='half zero feasible initial point, half general planted LPs; HiGHS comparison only; cost changes and formerly empty column row activation'))
def oracle(v,c,m):
 active=[j for j,col in enumerate(v['columns'])if any(i<m for i,a in col)or c[j]]
 h=highspy.Highs();h.setOptionValue('output_flag',False);h.setOptionValue('threads',1);h.setOptionValue('presolve','off')
 lp=highspy.HighsLp();lp.num_col_=len(active);lp.num_row_=m;lp.col_cost_=np.array([c[j]for j in active],dtype=float);lp.col_lower_=np.zeros(len(active));lp.col_upper_=np.array([v['upper'][j]for j in active],dtype=float);lp.row_lower_=np.array([v['rhs'][i]if v['equality'][i]else-highspy.kHighsInf for i in range(m)]);lp.row_upper_=np.array(v['rhs'][:m],dtype=float)
 cols=[[(i,a)for i,a in v['columns'][j]if i<m]for j in active];lp.a_matrix_.format_=highspy.MatrixFormat.kColwise;lp.a_matrix_.start_=np.array([sum(len(z)for z in cols[:j])for j in range(len(cols)+1)],dtype=np.int32);lp.a_matrix_.index_=np.array([i for z in cols for i,a in z],dtype=np.int32);lp.a_matrix_.value_=np.array([a for z in cols for i,a in z],dtype=float);h.passModel(lp);h.run();assert h.getModelStatus()==highspy.HighsModelStatus.kOptimal;return h.getObjectiveValue()
def verify(v,c,m,a,expected):
 assert a['status']=='optimal',a
 x=[F(str(z))for z in a['x']];assert len(x)==1300;assert all(-tol<=z<=F(str(u))+tol for z,u in zip(x,v['upper']))
 sums=[F(0)for _ in range(m)]
 for col,z in zip(v['columns'],x):
  for i,coefficient in col:
   if i<m:sums[i]+=F(str(coefficient))*z
 assert all(abs(s-F(str(b)))<=tol if e else s<=F(str(b))+tol for s,b,e in zip(sums,v['rhs'],v['equality']))
 obj=sum(F(str(a))*z for a,z in zip(c,x));assert abs(F(str(a['objective']))-obj)<=F(1,10**8)*(1+abs(obj));assert abs(a['objective']-expected)<=1e-7*(1+abs(expected))
for case in range(100):
 n=rng.randint(2,8);m=rng.randint(2,8);plant=[rng.randint(0,3)for _ in range(1300)];upper=[4.]*1300;rows=[];rhs=[];eq=[]
 if case%2==0:plant=[0]*1300
 for i in range(m+2):
  row=[rng.randint(-4,4)for _ in range(n)]+[0]*(1300-n)
  if i>=m:row[100+i-m]=rng.choice([-2,-1,1,2])
  e=i%4==0;rows.append(row);rhs.append(sum(a*z for a,z in zip(row,plant))+(0 if e else rng.randint(0,4)));eq.append(e)
 columns=[[(i,row[j])for i,row in enumerate(rows)if row[j]]for j in range(1300)]
 for sense in [1,-1]:
  c=[sense*rng.randint(-5,5)for _ in range(n)]+[0]*(1300-n);c1=c.copy();c1[500]=-2*sense;c2=c1.copy();c2[500]=3*sense;c2[501]=-1e-19
  for name in ['reopt_lp','append_lp']:
   v=dict(columns=columns if name=='append_lp'else[[(i,a)for i,a in col if i<m]for col in columns],rhs=rhs if name=='append_lp'else rhs[:m],upper=upper,equality=eq if name=='append_lp'else eq[:m],costs=[c,c1,c2]if name=='reopt_lp'else c)
   if name=='append_lp':v['base_rows']=m
   d=out/f'{case}-{sense}-{name}';d.mkdir();atomic_json(d/'input.json',[v]);results={}
   for flag in [0,1]:
    env={k:z for k,z in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_LP_ZERO_PHASE_ONE=str(flag),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    run=subprocess.run([str(out/name)],input=json.dumps([v]),text=True,capture_output=True,env=env,timeout=30);(d/f'{flag}.jsonl').write_text(run.stdout);(d/f'{flag}.stderr').write_text(run.stderr);assert run.returncode==0;results[flag]=[json.loads(line)for line in run.stdout.splitlines()]
   assert len(results[0])==len(results[1])==3
   for step,(a,b)in enumerate(zip(results[0],results[1])):
    cost=[c,c1,c2][step]if name=='reopt_lp'else c;count=m if name=='reopt_lp'else m+step;expected=oracle(v,cost,count)
    for flag,r in [(0,a),(1,b)]:
     for mode in ['warm','cold']:verify(v,cost,count,r[mode],expected)
    assert abs(a['cold']['objective']-b['cold']['objective'])<=1e-7*(1+abs(expected)),(case,sense,name,step)
    records.append(dict(case=case,sense=sense,example=name,step=step,point_checks=4,expected=expected,calls=b['warm_zero_phase_one_skips']+b['cold_zero_phase_one_skips'],skips=b['warm_zero_phase_one_skips']+b['cold_zero_phase_one_skips'],successes=0,fallbacks=0))
   atomic_json(out/'progress.json',dict(comparisons=len(records),point_checks=4*len(records),calls=sum(r['calls']for r in records),skips=sum(r['skips']for r in records)))
atomic_json(out/'records.json',records);atomic_json(out/'summary.json',dict(templates=100,senses=2,comparisons=len(records),point_checks=4*len(records),calls=sum(r['calls']for r in records),skips=sum(r['skips']for r in records)));atomic_json(out/'exit.json',dict(status='complete'));print((out/'summary.json').read_text())
