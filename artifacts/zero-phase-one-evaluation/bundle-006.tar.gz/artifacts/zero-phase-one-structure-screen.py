from pathlib import Path
from decimal import Decimal
import gzip,json,sys,os
sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256
os.sched_setaffinity(0,{42});root=Path.cwd();manifest=json.loads((root/'data/manifest.json').read_text());records=[]
for entry in manifest['instances']:
 if entry['split']!='development':continue
 section='';rows={};rhs={};bounds_zero=True;ranged=False;error=None
 try:
  with gzip.open(root/entry['path'],'rt')as f:
   for line in f:
    if not line.strip()or line.startswith('*'):continue
    t=line.split();t=t[:next((i for i,x in enumerate(t)if x.startswith('$')),len(t))]
    if not t:continue
    if not line[0].isspace():section=t[0];continue
    if section=='ROWS'and t[0]!='N':rows[t[1]]=t[0]
    elif section=='RHS':
     for k in range(1,len(t),2):rhs[t[k]]=Decimal(t[k+1].replace('D','E').replace('d','e'))
    elif section=='RANGES':ranged=True
    elif section=='BOUNDS':
     kind=t[0];v=Decimal(t[3].replace('D','E').replace('d','e'))if len(t)>3 else None
     if kind in ['FR','MI']or(kind in ['LO','LI','FX']and v!=0)or(kind in ['UP','UI']and v<0):bounds_zero=False
  eq=sum(k=='E'for k in rows.values());feasible=all((rhs.get(n,Decimal(0))==0 if k=='E'else rhs.get(n,Decimal(0))>=0 if k=='L'else rhs.get(n,Decimal(0))<=0)for n,k in rows.items());qualified=bounds_zero and not ranged and feasible and eq>0
  records.append(dict(name=entry['name'],input_sha256=entry['sha256'],equalities=eq,rows=len(rows),lower_shift_zero=bounds_zero,no_ranges=not ranged,zero_satisfies_rhs=feasible,qualified=qualified))
 except Exception as e:records.append(dict(name=entry['name'],qualified=False,error=str(e)))
assert len(records)==188;qualified=sorted((r for r in records if r['qualified']),key=lambda r:(-r['equalities'],r['name']));atomic_json(root/'artifacts/zero-phase-one-structure-screen.json',dict(manifest_sha256=sha256(root/'data/manifest.json'),development_only=True,records=records,qualified=qualified));print(json.dumps(qualified))
