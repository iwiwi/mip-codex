from pathlib import Path
import os,json,subprocess,sys,shutil,time,resource
sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256,require_solver_origin
from validate_solution import validate
root=Path.cwd();repo=Path('/home/ubuntu/mip-resource-improve');out=root/'artifacts/resource-objective-bundle-prototype';out.mkdir();origin=require_solver_origin(repo,repo/'target/release/mip-codex');b=out/'incumbent_feasibility_bundle';shutil.copy2(repo/'target/release/examples/incumbent_feasibility_bundle',b);shutil.copy2(repo/'examples/incumbent_feasibility_bundle.rs',out/'source.rs');info=json.loads(subprocess.check_output([str(b),'build-info']));assert info['source_fingerprint']==origin['source_fingerprint'];os.sched_setaffinity(0,{45});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));r=next(r for r in json.loads((root/'data/manifest.json').read_text())['instances']if r['name']=='map10.mps.gz');assert r['split']=='development';m=root/r['path'];assert sha256(m)==r['sha256'];indices=root/'artifacts/resource-objective-prototype-map10.mps.gz-0/indices.json';parent=root/'artifacts/resource-objective-default-development-screen/cases/map10.mps.gz/before/result.json';assert json.loads(parent.read_text())['objective']==0
atomic_json(out/'experiment.json',dict(cpu=45,memory_bytes=16*1024**3,budget_loop_seconds=3,preparation_and_input_read_outside_loop_budget=True,not_main_same_time_comparison=True,claim='primal prototype only; forced endpoint subsets never yield a global infeasibility or bound claim',binary_sha256=sha256(b),example_source_sha256=sha256(out/'source.rs'),build_info=info,input_sha256=r['sha256'],parent_sha256=sha256(parent),indices_sha256=sha256(indices)));records=[]
for count in [4,8,16,32]:
 d=out/str(count);d.mkdir();candidate=d/'candidate.json';cmd=[str(b),str(m),str(indices),'3','0',str(parent),'0',str(candidate),'0','0',str(count)];atomic_json(d/'command.json',dict(command=cmd,bundle_size=count));start=time.monotonic()
 with (d/'stdout.log').open('w')as f,(d/'stderr.log').open('w')as e:p=subprocess.run(cmd,stdout=f,stderr=e,timeout=63)
 assert p.returncode==0;record=dict(bundle_size=count,wall_seconds=time.monotonic()-start,candidate=False)
 if candidate.exists():
  v=json.loads(candidate.read_text());check=validate(m,v);atomic_json(d/'validation.json',check);assert check['valid']is True;assert v['objective']<0;record.update(candidate=True,objective=v['objective'],strict_valid=True)
 records.append(record);atomic_json(out/'records.json',records);print(record,flush=True)
atomic_json(out/'summary.json',dict(attempts=4,records=records));atomic_json(out/'exit.json',dict(status='complete'))
