from pathlib import Path
import json,hashlib,tarfile,subprocess,shutil
root=Path.cwd();out=root/'artifacts/zero-phase-one-evaluation';assert not out.exists()
for name in ['development-audit','mip-point-audit','zero-feasible-point-audit','mip-oracle','zero-feasible-mip-oracle']:
 p=root/f'artifacts/zero-phase-one-main119-{name}/exit.json';assert json.loads(p.read_text())['status']=='complete'
assert json.loads((root/'artifacts/zero-phase-one-main119-lp-oracle/summary.json').read_text())['comparisons']==1200
assert json.loads((root/'artifacts/zero-phase-one-main119-native-audit/summary.json').read_text())['strict_valid']==11
assert json.loads((root/'artifacts/zero-phase-one-main119-long-audit/summary.json').read_text())['strict_valid']==6
logs=root/'artifacts/zero-phase-one-research-logs';assert not logs.exists();logs.mkdir()
for p in Path('/home/ubuntu/mip-zero-phase-one/artifacts').glob('zero-phase-one-*'):
 if p.is_file():shutil.copy2(p,logs/p.name)
paths=set()
for pattern in ['zero-phase-one-*','resource-objective-bundle-prototype*']:
 for p in (root/'artifacts').glob(pattern):
  if p==out or p.name=='zero-phase-one-archive-run.log':continue
  if p.is_file():paths.add(p)
  elif p.is_dir():paths.update(q for q in p.rglob('*')if q.is_file())
for name in ['smoke-20261117-165347-rjwx2mkz','smoke-20261117-193147-9cdtrh2p']:
 paths.update(p for p in (root/'artifacts'/name).rglob('*')if p.is_file())
ledger=[];excluded=[]
for p in sorted(paths):
 assert not p.is_symlink();r=dict(path=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 with p.open('rb')as f:elf=f.read(4)==b'\x7fELF'
 (excluded if elf else ledger).append(r)
out.mkdir();chunks=[];current=[];size=0
for r in ledger:
 if current and size+r['bytes']>160*1024**2:chunks.append(current);current=[];size=0
 current.append(r);size+=r['bytes']
if current:chunks.append(current)
bundles=[]
for number,chunk in enumerate(chunks,1):
 p=out/f'bundle-{number:03}.tar.gz'
 with tarfile.open(p,'w:gz',compresslevel=6)as t:
  for r in chunk:t.add(root/r['path'],arcname=r['path'],recursive=False)
 assert p.stat().st_size<95*1024**2
 with tarfile.open(p,'r:gz')as t:
  assert len(t.getmembers())==len(chunk)
  for m,r in zip(t.getmembers(),chunk):
   assert m.name==r['path'];data=t.extractfile(m).read();assert len(data)==r['bytes']and hashlib.sha256(data).hexdigest()==r['sha256'];r['bundle']=p.name
 bundles.append(dict(path=p.name,files=len(chunk),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(out/'manifest.json').write_text(json.dumps(ledger,indent=2));(out/'excluded-elf.json').write_text(json.dumps(excluded,indent=2));(out/'bundles.json').write_text(json.dumps(bundles,indent=2));s=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/home/ubuntu/mip-zero-phase-one',text=True).strip(),build_info=json.loads((root/'artifacts/zero-phase-one-main119-diagnostic/build-info.json').read_text()),files=len(ledger),raw_bytes=sum(r['bytes']for r in ledger),compressed_bytes=sum(r['bytes']for r in bundles),bundles=len(bundles),excluded_elfs=len(excluded),all_payload_sha256_verified=True);(out/'summary.json').write_text(json.dumps(s,indent=2));print(s)
