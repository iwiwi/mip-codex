NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 E r0
 G r1
 E r2
 L r3
 L r4
 E r5
 E r6
 E r7
COLUMNS
 x0 obj -3
 x0 r0 3
 x0 r1 -3
 x0 r3 -3
 x0 r4 1
 x0 r5 4
 x0 r6 -1
 x0 r7 2
 x1 obj -5
 x1 r0 -4
 x1 r1 2
 x1 r2 2
 x1 r4 -4
 x1 r5 -4
 x1 r6 -1
 x1 r7 -3
 x2 obj 0
 x2 r0 -1
 x2 r1 1
 x2 r2 -1
 x2 r3 -1
 x2 r4 -4
 x2 r5 3
 x2 r6 2
 x2 r7 -2
 x3 obj 2
 x3 r1 -2
 x3 r2 -1
 x3 r3 4
 x3 r4 -4
 x3 r5 3
 x3 r7 -1
 x4 obj -1
 x4 r0 3
 x4 r1 2
 x4 r2 1
 x4 r3 1
 x4 r5 -4
 x4 r6 -4
 x4 r7 -4
 x5 obj -3
 x5 r0 2
 x5 r1 -2
 x5 r2 4
 x5 r3 -3
 x5 r4 -3
 x5 r5 -3
 x5 r6 4
 x5 r7 -2
RHS
 rhs obj -3
 rhs r0 5
 rhs r1 -7
 rhs r2 4
 rhs r3 2
 rhs r4 -6
 rhs r5 -4
 rhs r6 0
 rhs r7 -7
BOUNDS
 LI bounds x0 0
 UP bounds x0 1
 LI bounds x1 0
 UP bounds x1 1
 LI bounds x2 0
 UP bounds x2 1
 LI bounds x3 0
 UP bounds x3 1
 LI bounds x4 0
 UP bounds x4 1
 LI bounds x5 0
 UP bounds x5 1
ENDATA
