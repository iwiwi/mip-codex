NAME synthetic
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 G r3
 G r4
 E r5
 G r6
 G r7
 E r8
 E r9
 G r10
COLUMNS
 x0 obj 5
 x0 r0 3
 x0 r1 -4
 x0 r2 1
 x0 r4 -2
 x0 r5 3
 x0 r7 -1
 x0 r8 -4
 x0 r9 2
 x0 r10 4
 x1 obj 1
 x1 r0 2
 x1 r1 -2
 x1 r2 -1
 x1 r3 -2
 x1 r6 4
 x1 r7 -2
 x1 r8 -3
 x1 r9 -4
 x1 r10 2
 x2 obj -4
 x2 r1 2
 x2 r2 4
 x2 r4 3
 x2 r5 1
 x2 r6 -3
 x2 r7 -1
 x2 r8 -4
 x2 r9 2
 x3 obj 1
 x3 r0 -4
 x3 r1 -1
 x3 r2 3
 x3 r3 -4
 x3 r4 -4
 x3 r5 -3
 x3 r6 2
 x3 r7 -4
 x3 r8 4
 x3 r9 -1
 x3 r10 -3
 x4 obj 0
 x4 r0 -1
 x4 r1 -4
 x4 r2 4
 x4 r3 -1
 x4 r4 -4
 x4 r5 4
 x4 r6 -3
 x4 r7 -4
 x4 r8 -3
 x4 r9 2
 x4 r10 1
RHS
 rhs obj 0
 rhs r0 -1
 rhs r1 -13
 rhs r2 7
 rhs r3 -4
 rhs r4 -8
 rhs r5 7
 rhs r6 0
 rhs r7 -10
 rhs r8 -10
 rhs r9 0
 rhs r10 4
BOUNDS
 LI bounds x0 0
 UP bounds x0 1
 LI bounds x1 0
 UP bounds x1 1
 LI bounds x2 0
 UP bounds x2 1
 LI bounds x3 0
 UP bounds x3 1
 LI bounds x4 0
 UP bounds x4 1
ENDATA
