NAME synthetic
OBJSENSE
 MIN
ROWS
 N obj
 E r0
 E r1
 L r2
 L r3
 L r4
 E r5
COLUMNS
 x0 obj 4
 x0 r2 -4
 x0 r4 -3
 x0 r5 3
 x1 obj 4
 x1 r1 -4
 x1 r2 -3
 x1 r3 1
 x1 r4 4
 x1 r5 -1
 x2 obj 0
 x2 r0 1
 x2 r1 -2
 x2 r2 -1
 x2 r3 -3
 x2 r5 -1
 x3 obj 4
 x3 r0 -3
 x3 r1 -3
 x3 r2 1
 x3 r3 1
 x3 r4 -3
 x3 r5 -1
 x4 obj 5
 x4 r0 -4
 x4 r1 3
 x4 r2 -3
 x4 r3 -4
 x4 r4 2
 x4 r5 2
 x5 obj 1
 x5 r1 3
 x5 r2 -3
 x5 r3 -1
 x5 r5 1
 x6 obj -1
 x6 r0 -3
 x6 r1 -3
 x6 r2 -4
 x6 r3 -1
 x6 r4 2
 x6 r5 -2
 x7 obj -3
 x7 r0 -2
 x7 r1 4
 x7 r2 -4
 x7 r3 1
 x7 r4 -2
 x7 r5 -1
 x8 obj -2
 x8 r0 2
 x8 r1 2
 x8 r2 -1
 x8 r3 4
 x8 r4 3
 x9 obj 3
 x9 r0 -4
 x9 r1 4
 x9 r2 -1
 x9 r3 -1
 x9 r4 -2
 x9 r5 -2
RHS
 rhs obj 3
 rhs r0 -8
 rhs r1 4
 rhs r2 -2
 rhs r3 -2
 rhs r4 4
 rhs r5 -2
BOUNDS
 LI bounds x0 0
 UP bounds x0 1
 LI bounds x1 0
 UP bounds x1 1
 LI bounds x2 0
 UP bounds x2 1
 LI bounds x3 0
 UP bounds x3 1
 LI bounds x4 0
 UP bounds x4 1
 LI bounds x5 0
 UP bounds x5 1
 LI bounds x6 0
 UP bounds x6 1
 LI bounds x7 0
 UP bounds x7 1
 LI bounds x8 0
 UP bounds x8 1
 LI bounds x9 0
 UP bounds x9 1
ENDATA
