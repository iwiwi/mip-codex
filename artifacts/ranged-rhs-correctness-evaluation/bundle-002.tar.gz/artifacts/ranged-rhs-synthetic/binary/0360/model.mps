NAME synthetic
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
 L r4
 G r5
 G r6
 L r7
 L r8
 G r9
 L r10
 L r11
COLUMNS
 x0 obj -4
 x0 r0 -4
 x0 r1 -3
 x0 r2 -3
 x0 r3 -3
 x0 r4 1
 x0 r5 2
 x0 r6 1
 x0 r7 3
 x0 r8 3
 x0 r9 3
 x0 r10 3
 x0 r11 4
 x1 obj -5
 x1 r0 -1
 x1 r1 -4
 x1 r2 4
 x1 r3 3
 x1 r4 -3
 x1 r5 3
 x1 r6 4
 x1 r8 4
 x1 r9 4
 x1 r10 2
 x1 r11 -4
 x2 obj -3
 x2 r0 -2
 x2 r1 -4
 x2 r2 1
 x2 r4 1
 x2 r5 -2
 x2 r6 -2
 x2 r7 -4
 x2 r8 -4
 x2 r9 -3
 x2 r10 4
 x2 r11 -2
 x3 obj 0
 x3 r0 -4
 x3 r2 -1
 x3 r3 2
 x3 r4 -1
 x3 r7 -1
 x3 r8 -2
 x3 r9 2
 x3 r10 4
 x3 r11 3
 x4 obj 0
 x4 r0 -2
 x4 r1 -3
 x4 r2 2
 x4 r3 -4
 x4 r4 -2
 x4 r6 -1
 x4 r7 -4
 x4 r9 1
 x4 r10 -3
 x4 r11 -4
 x5 obj -3
 x5 r0 4
 x5 r1 -3
 x5 r2 1
 x5 r3 -1
 x5 r4 2
 x5 r5 1
 x5 r6 -1
 x5 r8 2
 x5 r9 3
 x5 r10 -2
RHS
 rhs obj 0
 rhs r0 -7
 rhs r1 -17
 rhs r2 4
 rhs r3 5
 rhs r4 0
 rhs r5 1
 rhs r6 -2
 rhs r7 0
 rhs r8 4
 rhs r9 8
 rhs r10 12
 rhs r11 3
BOUNDS
 LI bounds x0 0
 UP bounds x0 1
 LI bounds x1 0
 UP bounds x1 1
 LI bounds x2 0
 UP bounds x2 1
 LI bounds x3 0
 UP bounds x3 1
 LI bounds x4 0
 UP bounds x4 1
 LI bounds x5 0
 UP bounds x5 1
ENDATA
