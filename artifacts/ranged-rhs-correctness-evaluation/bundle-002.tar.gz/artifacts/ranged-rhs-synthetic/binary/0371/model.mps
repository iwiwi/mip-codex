NAME synthetic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 E r2
 E r3
 L r4
COLUMNS
 x0 obj -1
 x0 r0 -2
 x0 r1 2
 x0 r2 4
 x0 r4 -1
 x1 obj 5
 x1 r2 4
 x1 r3 -2
 x1 r4 -2
 x2 obj -3
 x2 r1 4
 x2 r2 -2
 x2 r3 1
 x2 r4 -1
 x3 obj 4
 x3 r0 -3
 x3 r1 4
 x3 r2 1
 x3 r3 1
 x3 r4 -3
 x4 obj 0
 x4 r0 -1
 x4 r2 -3
 x4 r3 3
 x4 r4 -2
 x5 obj -2
 x5 r1 -2
 x5 r2 3
 x5 r3 -1
 x5 r4 -1
 x6 obj 5
 x6 r0 -4
 x6 r1 3
 x6 r2 -3
 x6 r3 -2
 x6 r4 -1
 x7 obj 1
 x7 r0 -1
 x7 r1 1
 x7 r2 -2
 x7 r3 -2
 x7 r4 2
RHS
 rhs obj 4
 rhs r0 -9
 rhs r1 15
 rhs r2 -5
 rhs r3 -1
 rhs r4 -5
BOUNDS
 LI bounds x0 0
 UP bounds x0 1
 LI bounds x1 0
 UP bounds x1 1
 LI bounds x2 0
 UP bounds x2 1
 LI bounds x3 0
 UP bounds x3 1
 LI bounds x4 0
 UP bounds x4 1
 LI bounds x5 0
 UP bounds x5 1
 LI bounds x6 0
 UP bounds x6 1
 LI bounds x7 0
 UP bounds x7 1
ENDATA
