from pathlib import Path
from fractions import Fraction as F
import os,sys,json,subprocess,resource,time,signal
root=Path.cwd();solver,cpu=sys.argv[1],int(sys.argv[2]);os.sched_setaffinity(0,{cpu});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,)*2);sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256;from validate_solution import validate
os.environ['MIP_ABSOLUTE_CHECKER']='/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker-absolute'
out=root/'artifacts/ranged-rhs-native-oracle'/solver;out.mkdir(parents=True);records=[];env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_GLPK_DRIVER='/home/ubuntu/mip-codex/target/glpk-benchmark',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');atomic_json(out/'experiment.json',dict(solver=solver,cpu=cpu,seconds=4,threads=1,memory_bytes=16*1024**3,watchdog=15,cases=200,point_transfer=False))
for case in range(200):
 source=root/'artifacts/ranged-rhs-exact-oracle'/f'{case:04d}';model=source/'model.mps';oracle=json.load(open(source/'oracle.json'));expected=F(oracle['objective'])if oracle['objective']is not None else None;d=out/f'{case:04d}';d.mkdir();cmd=[str(root/'.venv/bin/python'),'scripts/comparison_worker.py',solver,str(model),'4',str(d)];atomic_json(d/'job.json',dict(command=cmd,input_sha256=sha256(model)));start=time.monotonic();watchdog=False
 with(d/'stdout.log').open('w')as so,(d/'stderr.log').open('w')as se:
  p=subprocess.Popen(cmd,stdout=so,stderr=se,env=env,start_new_session=True)
  try:p.wait(timeout=15)
  except subprocess.TimeoutExpired:watchdog=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
 atomic_json(d/'execution.json',dict(exit_code=p.returncode,watchdog=watchdog,wall_seconds=time.monotonic()-start));r=json.load(open(d/'result.json'))if(d/'result.json').exists()else{};validation=None;errors=[]
 if r.get('values')is not None:
  validation=validate(model,r);atomic_json(d/'point-validation.json',validation)
  if validation.get('valid')is not True:errors.append('point failed original GMP checker')
 status=str(r.get('status','')).lower();isopt=status=='optimal';isinf=status in ['infeasible','no primal feasible solution','no feasible solution']
 if isopt and(expected is None or r.get('objective')is None or abs(F(str(r['objective']))-expected)>F(1,10**7)*(1+abs(expected))):errors.append('optimal status disagrees with exact oracle')
 if isinf and expected is not None:errors.append('infeasible status disagrees with exact oracle')
 rec=dict(case=case,status=r.get('status'),version=r.get('version'),objective=r.get('objective'),dual_bound=r.get('dual_bound'),expected=str(expected)if expected is not None else None,point_valid=validation.get('valid')if validation else None,accepted_objective=r.get('objective')if validation and validation.get('valid')is True else None,errors=errors,exit_code=p.returncode,watchdog=watchdog);records.append(rec);atomic_json(out/'records.json',records)
from collections import Counter
summary=dict(status='complete',solver=solver,outputs=len(records),statuses=dict(Counter(r['status']for r in records)),gmp_valid=sum(r['point_valid']is True for r in records),errors=[r for r in records if r['errors']],execution_failures=sum(r['exit_code']!=0 or r['watchdog']for r in records));atomic_json(out/'summary.json',summary);print(json.dumps(summary))
