from pathlib import Path
import subprocess
assert not subprocess.run(['ps','-C','cargo,rustc','-o','pid='],capture_output=True,text=True).stdout.strip()
p=Path('src/primal_witness.rs');s=p.read_text().replace('    signature:u64,','    signature:u64,\n    sealed_rows:usize,\n    sealed_variables:usize,',1)
s=s.replace('self.signature=signature(m);','self.signature=signature(m);self.sealed_rows=m.rows.len();self.sealed_variables=m.variables.len();',1)
needle='    pub(crate) fn matches(&self,m:&crate::model::Model)->bool{self.signature==signature(m)}'
s=s.replace(needle,needle+'''\n    /// Original rows and variables must match exactly; appended rows are permitted.
    /// Only used for conservative LP row enclosures, not primal proof reconstruction.
    pub(crate) fn matches_original_prefix(&self,m:&crate::model::Model)->bool{
        m.variables.len()==self.sealed_variables && m.rows.len()>=self.sealed_rows
            && self.signature==signature_prefix(m,self.sealed_rows)
    }''',1)
s=s.replace('fn signature(m:&crate::model::Model)->u64{','fn signature(m:&crate::model::Model)->u64{signature_prefix(m,m.rows.len())}\nfn signature_prefix(m:&crate::model::Model,rows:usize)->u64{',1).replace('    for r in &m.rows{','    for r in m.rows.iter().take(rows){',1).replace('feed(&(m.rows.len()as u64).to_le_bytes());h','feed(&(rows as u64).to_le_bytes());h',1);p.write_text(s)
p=Path('src/solve.rs');s=p.read_text();s=s.replace('    let mut paired_rhs=vec![None;model.rows.len()];\n    if pairs && interval_enabled && (!model.original_decimal || model.decimal_source.as_ref().is_some_and(|s|s.matches(model))) {','    let mut paired_rhs=std::collections::BTreeMap::new();\n    let mut pair_source_valid=None;\n    if pairs && interval_enabled {',1)
needle='                && shifted_bound(row,&shift,false,model.original_decimal,exact_shift).is_finite() {continue;}'
s=s.replace(needle,needle+'\n            let valid=*pair_source_valid.get_or_insert_with(||!model.original_decimal||model.decimal_source.as_ref().is_some_and(|s|s.matches_original_prefix(model)));\n            if !valid {continue;}',1)
s=s.replace('paired_rhs[i]=Some([upper,lower]);','paired_rhs.insert(i,[upper,lower]);',1)
s=s.replace('paired_rhs[i].is_some()','paired_rhs.contains_key(&i)').replace('paired_rhs[source].is_some()','paired_rhs.contains_key(&source)').replace('if let Some(pair)=paired_rhs[source]','if let Some(pair)=paired_rhs.get(&source)')
p.write_text(s)
