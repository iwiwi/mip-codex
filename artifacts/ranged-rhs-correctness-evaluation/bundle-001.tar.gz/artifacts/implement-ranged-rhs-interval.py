from pathlib import Path
import subprocess
assert not subprocess.run(['ps','-C','cargo,rustc','-o','pid='],capture_output=True,text=True).stdout.strip()
p=Path('src/solve.rs');s=p.read_text();needle='    let mut error_terms=Vec::new();\n    if model.original_decimal{';replacement='    interval_shifted_side(model,index,row,shift,upper)\n}\nfn interval_shifted_side(model:&Model,index:usize,row:&crate::model::Row,shift:&[f64],upper:bool)->Option<f64>{\n    let mut error_terms=Vec::new();\n    if model.original_decimal{';assert needle in s;s=s.replace(needle,replacement,1)
a=s.index('fn standard_sparse_selected(');brace=s.index(' {',a)if ' {'in s[a:s.index('\n',a)]else -1
# The original function is written on a single signature line.
print(s[a:s.index('\n',a)])
p.write_text(s)
