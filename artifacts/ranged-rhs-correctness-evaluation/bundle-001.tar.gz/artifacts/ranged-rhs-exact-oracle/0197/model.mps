NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 5 r 2
 x s -2
 w obj -2 r 2
 w s 2
 y obj 0 r 0.1
RHS
 rhs obj -2 r 100000000.9
 rhs s 3.8
RANGES
 rng r 1.4
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
