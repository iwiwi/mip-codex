NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 0 r -3
 x s 3
 w obj 1 r -3
 w s 1
 y obj 0 r 0.1
RHS
 rhs obj -3 r -100000002.3
 rhs s 2.7
RANGES
 rng r 1.1
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
