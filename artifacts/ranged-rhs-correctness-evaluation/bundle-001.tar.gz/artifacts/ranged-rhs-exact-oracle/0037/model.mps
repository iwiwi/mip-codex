NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 3 r -1
 x s -2
 w obj -5 r -1.5
 w s 1
 y obj 0 r 0.3
RHS
 rhs obj 2 r 300000003.5
 rhs s -1.6
RANGES
 rng r 0.7
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
