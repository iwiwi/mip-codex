NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 4 r -1
 x s 3
 w obj 1 r 1
 w s -2
 y obj 0 r 0.333
RHS
 rhs obj 1 r 332999997.3
 rhs s -0.7
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
