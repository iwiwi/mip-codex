NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -5 r -1
 x s 3
 w obj -2 r -1
 w s -2
 y obj 0 r 0.3
RHS
 rhs obj 0 r 299999999.4
 rhs s 3.2
RANGES
 rng r 1
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
