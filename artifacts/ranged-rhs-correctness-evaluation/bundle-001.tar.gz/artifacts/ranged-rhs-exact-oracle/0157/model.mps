NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -5 r -1
 x s -2
 w obj 3 r -3
 w s 2
 y obj 0 r 0.333
RHS
 rhs obj 1 r 333000000.8
 rhs s 3.3
RANGES
 rng r 1.4
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
