NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -2 r 2
 x s -2
 w obj 1 r 0.2
 w s 1
 y obj 0 r 0.07
RHS
 rhs obj 4 r -69999999.41
 rhs s 3.9
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
