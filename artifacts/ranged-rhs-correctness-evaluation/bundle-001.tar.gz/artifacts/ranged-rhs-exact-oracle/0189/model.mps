NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -1 r 1
 x s 1
 w obj 1 r 1.5
 w s 1
 y obj 0 r 0.07
RHS
 rhs obj -1 r 70000001.61
 rhs s 3.3
RANGES
 rng r 1.1
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
