NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -2 r 1
 x s 3
 w obj 3 r 0.2
 w s 2
 y obj 0 r 0.3
RHS
 rhs obj 3 r -299999995.6
 rhs s -1.6
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
