NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 5 r 2
 x s 3
 w obj -2 r -1.5
 w s 2
 y obj 0 r 0.333
RHS
 rhs obj -1 r 333000002.699
 rhs s 1.3
RANGES
 rng r 0.2
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
