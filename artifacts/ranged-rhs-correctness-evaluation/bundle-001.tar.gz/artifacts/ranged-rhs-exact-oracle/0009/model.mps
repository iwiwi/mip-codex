NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 0 r -3
 x s -2
 w obj 3 r -1.5
 w s 1
 y obj 0 r 0.3
RHS
 rhs obj -2 r 299999998.4
 rhs s 0.7
RANGES
 rng r 1.3
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
