NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -5 r -1
 x s 1
 w obj -5 r -1.5
 w s -2
 y obj 0 r 0.1
RHS
 rhs obj -3 r -99999998
 rhs s 0.2
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
