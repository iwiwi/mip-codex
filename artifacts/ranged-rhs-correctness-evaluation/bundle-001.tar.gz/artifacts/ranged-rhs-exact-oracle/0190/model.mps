NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 3 r 5
 x s 3
 w obj 3 r -0.1
 w s -2
 y obj 0 r 0.1
RHS
 rhs obj -3 r 99999999.6
 rhs s 2.9
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
