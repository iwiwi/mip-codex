NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -4 r 5
 x s 1
 w obj -2 r 1.5
 w s -2
 y obj 0 r 0.1
RHS
 rhs obj 3 r 99999999.1
 rhs s 4.1
RANGES
 rng r 0.3
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
