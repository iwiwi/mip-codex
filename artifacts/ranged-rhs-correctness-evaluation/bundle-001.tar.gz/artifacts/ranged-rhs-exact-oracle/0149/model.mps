NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -4 r 5
 x s 1
 w obj 1 r -3
 w s 2
 y obj 0 r 0.07
RHS
 rhs obj -1 r 70000001.8
 rhs s 4.1
RANGES
 rng r 1.1
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
