NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 5 r 1
 x s 1
 w obj -5 r -3
 w s 1
 y obj 0 r 0.07
RHS
 rhs obj 4 r 70000003.61
 rhs s 4.9
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
