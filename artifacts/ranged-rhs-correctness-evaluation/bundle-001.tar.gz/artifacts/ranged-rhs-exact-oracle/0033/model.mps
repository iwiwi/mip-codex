NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 2 r 2
 x s 1
 w obj -5 r 1.5
 w s -2
 y obj 0 r 0.07
RHS
 rhs obj 1 r 70000001.4
 rhs s 0.9
RANGES
 rng r 1.3
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
