NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 3 r -1
 x s -2
 w obj -5 r -0.1
 w s 1
 y obj 0 r 0.1
RHS
 rhs obj -3 r -99999999.8
 rhs s -1
RANGES
 rng r 0.2
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
