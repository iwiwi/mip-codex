NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -5 r 2
 x s 1
 w obj 3 r 2
 w s -2
 y obj 0 r 0.07
RHS
 rhs obj 0 r 69999997.6
 rhs s 2.7
RANGES
 rng r 1.3
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
