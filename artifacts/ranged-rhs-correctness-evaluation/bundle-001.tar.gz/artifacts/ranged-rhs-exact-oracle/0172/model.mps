NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 0 r -3
 x s -2
 w obj -5 r 0.2
 w s 1
 y obj 0 r 0.07
RHS
 rhs obj -1 r 70000002.7
 rhs s 2.9
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
