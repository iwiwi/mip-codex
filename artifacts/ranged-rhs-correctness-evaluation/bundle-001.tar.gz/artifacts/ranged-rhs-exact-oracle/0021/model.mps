NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -4 r 2
 x s -2
 w obj -5 r 2
 w s -2
 y obj 0 r 0.333
RHS
 rhs obj 4 r 333000002.9
 rhs s 2.6
RANGES
 rng r 0.8
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
