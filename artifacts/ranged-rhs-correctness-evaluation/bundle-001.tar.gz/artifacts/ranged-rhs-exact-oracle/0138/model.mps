NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 1 r 5
 x s -2
 w obj 3 r 2
 w s 1
 y obj 0 r 0.07
RHS
 rhs obj 2 r 70000002.8
 rhs s -1.2
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
