NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 1 r 1
 x s 1
 w obj -2 r -0.3
 w s 1
 y obj 0 r 0.07
RHS
 rhs obj -3 r -70000000.51
 rhs s 1.3
RANGES
 rng r 0.2
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
