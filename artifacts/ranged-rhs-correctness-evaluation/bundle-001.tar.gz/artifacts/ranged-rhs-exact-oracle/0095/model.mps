NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 0 r -3
 x s 3
 w obj 3 r 0.3
 w s 1
 y obj 0 r 0.333
RHS
 rhs obj 4 r -333000000.369
 rhs s 0.8
RANGES
 rng r 0.7
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
