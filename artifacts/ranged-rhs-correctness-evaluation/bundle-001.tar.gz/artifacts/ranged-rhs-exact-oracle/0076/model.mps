NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -1 r 5
 x s -2
 w obj 3 r -0.5
 w s 1
 y obj 0 r 0.1
RHS
 rhs obj -4 r 99999998.5
 rhs s -1.8
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
