NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 2 r 5
 x s 1
 w obj 3 r -3
 w s -2
 y obj 0 r 0.1
RHS
 rhs obj -3 r 100000002.7
 rhs s 0.7
RANGES
 rng r 0.7
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
