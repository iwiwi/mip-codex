NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -4 r 5
 x s 3
 w obj 3 r 2
 w s 1
 y obj 0 r 0.3
RHS
 rhs obj -1 r -299999994.3
 rhs s 4.3
RANGES
 rng r 1.3
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
