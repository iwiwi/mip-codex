NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -5 r 1
 x s -2
 w obj 1 r 0.3
 w s 1
 y obj 0 r 0.1
RHS
 rhs obj 1 r 99999997.5
 rhs s 4
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
