NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 4 r 5
 x s 3
 w obj -5 r -1.5
 w s 1
 y obj 0 r 0.1
RHS
 rhs obj 3 r 100000001.4
 rhs s 1.7
RANGES
 rng r 0.1
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
