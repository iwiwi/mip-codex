NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 1 r -3
 x s -2
 w obj -2 r -1
 w s -2
 y obj 0 r 0.07
RHS
 rhs obj 1 r 69999998.01
 rhs s 2.4
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
