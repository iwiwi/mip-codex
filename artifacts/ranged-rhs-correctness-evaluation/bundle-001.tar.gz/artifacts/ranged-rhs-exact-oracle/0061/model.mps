NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 4 r 5
 x s -2
 w obj -5 r 0.5
 w s 1
 y obj 0 r 0.333
RHS
 rhs obj -4 r -332999996.169
 rhs s 3.4
RANGES
 rng r 0.5
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
