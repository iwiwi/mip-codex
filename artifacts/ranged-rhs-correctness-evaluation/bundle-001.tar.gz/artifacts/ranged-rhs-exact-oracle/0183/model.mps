NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 0 r 1
 x s 3
 w obj -5 r -0.5
 w s -2
 y obj 0 r 0.333
RHS
 rhs obj 0 r -332999994.969
 rhs s 3.6
RANGES
 rng r 1
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
