NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 1 r -3
 x s 3
 w obj 1 r 0.1
 w s 1
 y obj 0 r 0.07
RHS
 rhs obj -3 r 69999999.21
 rhs s 3.1
RANGES
 rng r 0.6
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
