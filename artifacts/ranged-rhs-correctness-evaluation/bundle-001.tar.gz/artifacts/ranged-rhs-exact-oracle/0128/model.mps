NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -2 r -1
 x s 3
 w obj -2 r 0.2
 w s 2
 y obj 0 r 0.07
RHS
 rhs obj -2 r 70000000.51
 rhs s -0.5
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
