NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 1 r 1
 x s 1
 w obj -5 r 1
 w s 1
 y obj 0 r 0.1
RHS
 rhs obj 4 r 100000002.3
 rhs s 0.9
RANGES
 rng r 0.1
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
