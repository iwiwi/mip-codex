NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -4 r 1
 x s -2
 w obj 1 r -1
 w s 1
 y obj 0 r 0.333
RHS
 rhs obj 2 r 332999997.999
 rhs s 0.4
RANGES
 rng r 0.4
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
