NAME exactpair
OBJSENSE
 MIN
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -3 r 2
 x s 1
 w obj -5 r 0.3
 w s -2
 y obj 0 r 0.07
RHS
 rhs obj 3 r 69999998.81
 rhs s 4.1
RANGES
 rng r 0.5
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
