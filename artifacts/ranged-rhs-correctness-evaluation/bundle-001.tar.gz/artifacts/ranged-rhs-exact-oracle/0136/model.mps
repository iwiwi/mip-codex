NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 4 r 2
 x s 1
 w obj 1 r 0.3
 w s 1
 y obj 0 r 0.333
RHS
 rhs obj 2 r -332999996.069
 rhs s 2.4
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
