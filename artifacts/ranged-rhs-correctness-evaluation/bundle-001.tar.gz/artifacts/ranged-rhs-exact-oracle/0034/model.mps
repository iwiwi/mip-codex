NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 0 r -1
 x s 1
 w obj -5 r 0.1
 w s 2
 y obj 0 r 0.1
RHS
 rhs obj 1 r 100000001.6
 rhs s -1.5
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
