NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -2 r 5
 x s -2
 w obj -2 r 0.5
 w s 1
 y obj 0 r 0.07
RHS
 rhs obj 3 r 69999997.61
 rhs s -1.8
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
