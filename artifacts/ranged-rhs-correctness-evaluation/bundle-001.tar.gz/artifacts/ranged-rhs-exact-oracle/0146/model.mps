NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -3 r 2
 x s 1
 w obj 3 r -3
 w s 1
 y obj 0 r 0.333
RHS
 rhs obj 3 r -332999997.369
 rhs s 1.5
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
