NAME exactpair
OBJSENSE
 MAX
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -5 r 5
 x s 1
 w obj 3 r 1.5
 w s 2
 y obj 0 r 0.333
RHS
 rhs obj 4 r -333000000.069
 rhs s -1.9
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
