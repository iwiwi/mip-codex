from pathlib import Path
import subprocess
assert not subprocess.run(['ps','-C','cargo,rustc','-o','pid='],capture_output=True,text=True).stdout.strip()
p=Path('src/solve.rs');s=p.read_text().replace('    pub lp_rhs_interval_fallbacks:Option<usize>,','    pub lp_rhs_interval_fallbacks:Option<usize>,\n    pub lp_rhs_interval_pairs:Option<usize>,',1)
s=s.replace('thread_local!{static RHS_INTERVAL_COUNT:','thread_local!{static RHS_PAIR_COUNT:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};}\nthread_local!{static RHS_INTERVAL_COUNT:',1)
s=s.replace('            if interval_applied {\n                    RHS_INTERVAL_COUNT','            if interval_applied {\n                    if row_sign>0. && paired_rhs.contains_key(&source){RHS_PAIR_COUNT.with(|n|n.set(n.get().saturating_add(1)));}\n                    RHS_INTERVAL_COUNT',1)
s=s.replace('    let rhs_interval_start=RHS_INTERVAL_COUNT.with(|n|n.get());','    let rhs_interval_start=RHS_INTERVAL_COUNT.with(|n|n.get());\n    let rhs_pairs_start=RHS_PAIR_COUNT.with(|n|n.get());',1)
s=s.replace('        lp_rhs_interval_fallbacks:matches!(limits.engine,Engine::Revised).then(||RHS_INTERVAL_COUNT.with(|n|n.get()).saturating_sub(rhs_interval_start)),','        lp_rhs_interval_fallbacks:matches!(limits.engine,Engine::Revised).then(||RHS_INTERVAL_COUNT.with(|n|n.get()).saturating_sub(rhs_interval_start)),\n        lp_rhs_interval_pairs:matches!(limits.engine,Engine::Revised).then(||RHS_PAIR_COUNT.with(|n|n.get()).saturating_sub(rhs_pairs_start)),',1)
p.write_text(s)
