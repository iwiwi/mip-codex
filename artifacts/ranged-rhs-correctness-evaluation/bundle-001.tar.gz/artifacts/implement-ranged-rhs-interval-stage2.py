from pathlib import Path
import subprocess
assert not subprocess.run(['ps','-C','cargo,rustc','-o','pid='],capture_output=True,text=True).stdout.strip()
p=Path('src/solve.rs');s=p.read_text();sig='fn standard_sparse_selected(model:&Model,node:&Node,limit:usize,track_rows:bool,fixed_columns:bool,selected:Option<&[usize]>)->Relaxation {'
s=s.replace(sig,sig+'\n    standard_sparse_selected_pairs(model,node,limit,track_rows,fixed_columns,selected,std::env::var("MIP_RHS_INTERVAL_PAIRS").is_ok_and(|v|v=="1"))\n}\nfn standard_sparse_selected_pairs(model:&Model,node:&Node,limit:usize,track_rows:bool,fixed_columns:bool,selected:Option<&[usize]>,pairs:bool)->Relaxation {',1)
a=s.index('    let sources=sparse_source_rows(model,selected);');s=s[:a]+s[a:].replace('    let sources=sparse_source_rows(model,selected);','''    let sources=sparse_source_rows(model,selected);
    let exact_shift = shift.iter().all(|&x| crate::model::point_error(x) == 0.);
    let interval_enabled=std::env::var("MIP_RHS_INTERVAL_FALLBACK").map_or(true,|v|v=="1");
    let mut paired_rhs=vec![None;model.rows.len()];
    if pairs && interval_enabled && (!model.original_decimal || model.decimal_source.as_ref().is_some_and(|s|s.matches(model))) {
        for (i,row) in sources.clone() {
            if row.lower.zip(row.upper).is_none_or(|(l,u)|!l.is_finite()||!u.is_finite()||l>u) {continue;}
            if shifted_bound(row,&shift,true,model.original_decimal,exact_shift).is_finite()
                && shifted_bound(row,&shift,false,model.original_decimal,exact_shift).is_finite() {continue;}
            if let (Some(upper),Some(lower))=(interval_shifted_side(model,i,row,&shift,true),interval_shifted_side(model,i,row,&shift,false)) {
                paired_rhs[i]=Some([upper,lower]);
            }
        }
    }''',1)
s=s.replace('sources.clone().map(|(_,r)|r)\n        .map(|r| r.coefficients.len() as u128 * if split_range(r)||selected.is_some()&&r.lower.zip(r.upper).is_some_and(|(l,u)|l<u)', 'sources.clone()\n        .map(|(i,r)| r.coefficients.len() as u128 * if paired_rhs[i].is_some()||split_range(r)||selected.is_some()&&r.lower.zip(r.upper).is_some_and(|(l,u)|l<u)',1)
s=s.replace('sources.clone().map(|(_,r)|r)\n        .map(|r| if split_range(r)||selected.is_some()&&r.lower.zip(r.upper).is_some_and(|(l,u)|l<u)','sources.clone()\n        .map(|(i,r)| if paired_rhs[i].is_some()||split_range(r)||selected.is_some()&&r.lower.zip(r.upper).is_some_and(|(l,u)|l<u)',1)
# Remove the now duplicated declarations after allocations.
start=s.index('    let mut slack_upper = Vec::new();',s.index('    let paired_rhs')if '    let paired_rhs'in s else s.index('    let sources=sparse_source_rows'))
end=s.index('    let interval_dump=',start);chunk=s[start:end];chunk=chunk.replace('    let exact_shift = shift.iter().all(|&x| crate::model::point_error(x) == 0.);\n','').replace('    let interval_enabled=std::env::var("MIP_RHS_INTERVAL_FALLBACK").map_or(true,|v|v=="1");\n','');s=s[:start]+chunk+s[end:]
s=s.replace('        let split = split_range(row)||selected.is_some()', '        let split = paired_rhs[source].is_some()||split_range(row)||selected.is_some()',1)
a=s.index('            let mut bound = shifted_bound(',s.index('fn standard_sparse_selected_pairs'));b=s.index('            rhs.push(bound);',a)
block=s[a:b]
block=block.replace('            if !bound.is_finite()&&interval_enabled{','            let mut interval_applied=false;\n            if let Some(pair)=paired_rhs[source] {bound=pair[usize::from(row_sign<0.)];interval_applied=true;}\n            if !bound.is_finite()&&interval_enabled{',1)
block=block.replace('                    bound=value;RHS_INTERVAL_COUNT.with(|n|n.set(n.get().saturating_add(1)));','                    bound=value;interval_applied=true;\n                }\n            }\n            if interval_applied {\n                    RHS_INTERVAL_COUNT.with(|n|n.set(n.get().saturating_add(1)));',1)
# One extra closing brace remains from the old nested if.
pos=block.rfind('                }\n            }');assert pos>=0;block=block[:pos]+block[pos:].replace('                }\n            }','            }',1)
block=block.replace('"source_row":source,','"paired":paired_rhs[source].is_some(),"source_row":source,').replace('value.to_bits()','bound.to_bits()')
s=s[:a]+block+s[b:];p.write_text(s)
