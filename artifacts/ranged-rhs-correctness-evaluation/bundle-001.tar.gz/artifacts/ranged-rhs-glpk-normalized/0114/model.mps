NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 4 r 5
 x s 3
 w obj -2 r 0.1
 w s 1
 y obj 0 r 0.07
RHS
 rhs obj 0 r -69999998.11
 rhs s -0.8
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
