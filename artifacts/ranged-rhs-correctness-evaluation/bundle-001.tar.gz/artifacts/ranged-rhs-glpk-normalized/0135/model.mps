NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -3 r 1
 x s 3
 w obj -2 r 2
 w s 1
 y obj 0 r 0.1
RHS
 rhs obj 3 r -100000000
 rhs s -1.9
RANGES
 rng r 1.4
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
