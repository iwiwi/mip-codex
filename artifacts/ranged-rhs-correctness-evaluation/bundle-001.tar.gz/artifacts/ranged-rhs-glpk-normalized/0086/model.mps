NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 5 r 2
 x s -2
 w obj -3 r 3
 w s 1
 y obj -0 r 0.1
RHS
 rhs obj 1 r 100000001.7
 rhs s 0.3
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
