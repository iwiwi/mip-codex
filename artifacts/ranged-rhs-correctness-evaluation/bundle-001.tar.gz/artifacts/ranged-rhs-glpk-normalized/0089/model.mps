NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -3 r 5
 x s 1
 w obj 5 r -0.1
 w s 1
 y obj -0 r 0.1
RHS
 rhs obj 1 r -99999998.1
 rhs s 2.2
RANGES
 rng r 0.1
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
