NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -0 r -3
 x s 1
 w obj -1 r -0.3
 w s -2
 y obj -0 r 0.07
RHS
 rhs obj -0 r 70000003.7
 rhs s -0.6
RANGES
 rng r 1.3
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
