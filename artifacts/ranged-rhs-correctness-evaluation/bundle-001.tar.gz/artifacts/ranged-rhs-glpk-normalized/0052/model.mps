NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 4 r 5
 x s 1
 w obj -1 r -0.1
 w s 1
 y obj -0 r 0.3
RHS
 rhs obj -1 r 299999998.1
 rhs s -0.7
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000003
ENDATA
