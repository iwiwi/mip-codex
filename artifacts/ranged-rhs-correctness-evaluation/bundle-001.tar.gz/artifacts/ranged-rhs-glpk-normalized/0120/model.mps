NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 0 r 2
 x s -2
 w obj 1 r -0.1
 w s 1
 y obj 0 r 0.333
RHS
 rhs obj 4 r -332999995.669
 rhs s -1.2
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
