NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -5 r -3
 x s 1
 w obj -3 r 1.5
 w s 1
 y obj -0 r 0.1
RHS
 rhs obj -1 r 100000000.5
 rhs s 2.1
RANGES
 rng r 1.3
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
