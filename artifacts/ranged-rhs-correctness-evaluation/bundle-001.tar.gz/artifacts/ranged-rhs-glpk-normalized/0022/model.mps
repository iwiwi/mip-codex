NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -1 r 2
 x s 1
 w obj 2 r 1
 w s 2
 y obj -0 r 0.1
RHS
 rhs obj 1 r -99999996.6
 rhs s -1.4
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
