NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -0 r 5
 x s 1
 w obj -1 r -1.5
 w s 2
 y obj -0 r 0.333
RHS
 rhs obj -2 r 333000003.6
 rhs s 2.2
RANGES
 rng r 0.6
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
