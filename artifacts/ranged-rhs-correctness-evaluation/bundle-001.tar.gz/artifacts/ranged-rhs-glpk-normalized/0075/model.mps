NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -4 r 2
 x s 1
 w obj 3 r 2
 w s -2
 y obj 0 r 0.3
RHS
 rhs obj -1 r 299999999.6
 rhs s -0.3
RANGES
 rng r 0.8
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
