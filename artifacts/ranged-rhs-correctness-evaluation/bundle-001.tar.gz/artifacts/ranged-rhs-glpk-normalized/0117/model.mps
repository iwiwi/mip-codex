NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -3 r 5
 x s -2
 w obj 3 r 2
 w s 1
 y obj 0 r 0.07
RHS
 rhs obj 1 r -69999996.61
 rhs s 4.2
RANGES
 rng r 1.5
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
