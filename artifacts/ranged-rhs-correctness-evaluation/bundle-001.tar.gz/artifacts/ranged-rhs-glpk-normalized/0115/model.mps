NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 1 r -1
 x s 3
 w obj -3 r 0.5
 w s -2
 y obj -0 r 0.1
RHS
 rhs obj -0 r 99999998
 rhs s -0.5
RANGES
 rng r 1.1
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
