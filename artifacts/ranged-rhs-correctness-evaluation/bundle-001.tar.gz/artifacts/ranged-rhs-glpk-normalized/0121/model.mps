NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -2 r 5
 x s 1
 w obj 2 r -0.1
 w s -2
 y obj -0 r 0.1
RHS
 rhs obj -2 r -99999998.1
 rhs s -0.6
RANGES
 rng r 0.6
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
