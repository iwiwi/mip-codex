NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 4 r 2
 x s 1
 w obj -3 r -0.5
 w s 2
 y obj -0 r 0.1
RHS
 rhs obj -0 r 100000002.5
 rhs s 3.5
RANGES
 rng r 0.5
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
