NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -1 r 2
 x s 3
 w obj 3 r 0.3
 w s 1
 y obj 0 r 0.1
RHS
 rhs obj -1 r 100000003.1
 rhs s -0.8
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
