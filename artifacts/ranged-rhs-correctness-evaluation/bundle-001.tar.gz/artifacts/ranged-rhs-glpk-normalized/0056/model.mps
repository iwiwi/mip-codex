NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -1 r -3
 x s -2
 w obj 5 r 0.2
 w s -2
 y obj -0 r 0.1
RHS
 rhs obj -2 r 100000000.6
 rhs s -1.5
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
