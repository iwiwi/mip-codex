NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -4 r -3
 x s 1
 w obj 2 r -0.5
 w s 2
 y obj -0 r 0.07
RHS
 rhs obj 1 r 70000002.9
 rhs s -1.5
RANGES
 rng r 0.4
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y 1000000000
ENDATA
