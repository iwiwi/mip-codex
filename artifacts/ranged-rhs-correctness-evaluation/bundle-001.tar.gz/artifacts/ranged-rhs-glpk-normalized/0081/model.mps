NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj -3 r 5
 x s -2
 w obj 3 r -1.5
 w s -2
 y obj 0 r 0.333
RHS
 rhs obj 1 r -332999997.269
 rhs s -0.4
RANGES
 rng r 0.1
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
