NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 5 r 5
 x s -2
 w obj -1 r -1.5
 w s -2
 y obj -0 r 0.07
RHS
 rhs obj -3 r -69999997.91
 rhs s 2
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
