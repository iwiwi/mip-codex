NAME exactpair
ROWS
 N obj
 E r
 L s
COLUMNS
 x obj 2 r 5
 x s -2
 w obj 5 r -3
 w s -2
 y obj -0 r 0.3
RHS
 rhs obj -3 r -299999996
 rhs s -0.4
BOUNDS
 LI bounds x -3
 UI bounds x 4
 LO bounds w -0.5
 UP bounds w 2
 FX bounds y -999999993
ENDATA
