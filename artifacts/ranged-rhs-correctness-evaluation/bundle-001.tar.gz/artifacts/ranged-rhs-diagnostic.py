from pathlib import Path
import os,json,subprocess,resource,sys,signal,time
root=Path.cwd();os.sched_setaffinity(0,{41});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,)*2);sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256
out=root/'artifacts/ranged-rhs-diagnostic';out.mkdir();binary=root/'artifacts/ranged-rhs-frozen/bin/mip-codex';model=root/'data/raw/benchmark/leo1.mps.gz';env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_RHS_INTERVAL_PAIRS='1',MIP_RHS_INTERVAL_DUMP=str(out/'rhs.jsonl'),MIP_RHS_INTERVAL_DUMP_LIMIT='100000');cmd=[str(binary),'solve',str(model),'2'];atomic_json(out/'job.json',dict(command=cmd,cpu=41,memory_bytes=16*1024**3,input_sha256=sha256(model),binary_sha256=sha256(binary),environment={k:v for k,v in env.items()if k.startswith('MIP_')},purpose='validation only; dumped rows never fed back to solver'));start=time.monotonic();watchdog=False
with(out/'stdout.log').open('w')as so,(out/'stderr.log').open('w')as se:
 p=subprocess.Popen(cmd,stdout=so,stderr=se,env=env,start_new_session=True)
 try:p.wait(timeout=62)
 except subprocess.TimeoutExpired:watchdog=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
atomic_json(out/'execution.json',dict(exit_code=p.returncode,watchdog=watchdog,wall_seconds=time.monotonic()-start));assert not watchdog and p.returncode==0
if (out/'rhs.jsonl').exists():
 with(out/'verification.json').open('w')as f:subprocess.run([str(root/'.venv/bin/python'),'scripts/verify_rhs_interval.py',str(model),str(out/'rhs.jsonl')],stdout=f,check=True)
else:atomic_json(out/'verification.json',dict(valid=None,reason='no interval activation'))
