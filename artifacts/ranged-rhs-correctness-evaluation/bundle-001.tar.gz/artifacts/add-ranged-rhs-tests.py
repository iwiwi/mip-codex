from pathlib import Path
import subprocess
assert not subprocess.run(['ps','-C','cargo,rustc','-o','pid='],capture_output=True,text=True).stdout.strip()
p=Path('src/solve.rs');s=p.read_text();s+='''
#[cfg(test)]
mod paired_rhs_interval_tests {
 use super::*;
 fn setup(range:bool)->(Model,Node){
  let text=format!("NAME pair\\nROWS\\n N c\\n E r\\nCOLUMNS\\n x c 1 r 1\\n y c 0 r 0.1\\nRHS\\n rhs r 100000001\\n{}BOUNDS\\n LI b x 0\\n UI b x 3\\n FX b y 1000000000\\nENDATA\\n",if range{"RANGES\\n rng r 1\\n"}else{""});
  let model=crate::mps::parse(std::io::Cursor::new(text)).unwrap();
  let node=Node{certified_bound:None,lower:model.variables.iter().map(|v|v.lower).collect(),upper:model.variables.iter().map(|v|v.upper).collect(),bound:f64::NEG_INFINITY,warm:None,changed:None,edge:None};(model,node)
 }
 #[test]fn equalities_and_ranges_become_two_outer_inequalities_only_on_shift_failure(){
  for range in [false,true]{for fixed in [false,true]{
   let(m,node)=setup(range);let before=serde_json::to_string(&m).unwrap();
   let Relaxation::Ready(old)=standard_sparse_selected_pairs(&m,&node,1<<24,true,fixed,None,false)else{panic!()};
   assert_eq!(old.sparse.as_ref().unwrap().rhs.len(),1);assert!(old.sparse.as_ref().unwrap().rhs.iter().any(|v|!v.is_finite()));
   let Relaxation::Ready(new)=standard_sparse_selected_pairs(&m,&node,1<<24,true,fixed,None,true)else{panic!()};
   let p=new.sparse.as_ref().unwrap();assert_eq!(p.rhs.len(),2);assert!(p.rhs.iter().all(|v|v.is_finite()));assert_eq!(p.equality,vec![false,false]);assert_eq!(p.slack_upper,vec![f64::INFINITY;2]);assert_eq!(new.row_sources,vec![(0,1.),(0,-1.)]);
   for x in if range{vec![1.,2.]}else{vec![1.]}{
    assert!(m.check(&[x,1e9],true,0.).is_ok());let mut point=vec![0.;p.costs.len()];for &(k,a)in &new.terms[0]{point[k]=a*(x-new.shift[0]);}
    for i in 0..2{let activity=crate::exact::dot_bounds(p.columns.iter().enumerate().flat_map(|(j,col)|col.iter().filter(move|&&(r,_)|r==i).map(move|&(_,a)|(a,point[j]))));assert!(activity.unwrap()[1]<=p.rhs[i]);}
   }
   assert_eq!(before,serde_json::to_string(&m).unwrap());
  }}
 }
 #[test]fn uncertain_unbounded_or_changed_sources_stay_rejected(){
  let(mut m,mut node)=setup(false);m.variables[1].upper=None;m.variables[1].upper_enclosure=None;node.upper[1]=None;
  let Relaxation::Ready(p)=standard_sparse_selected_pairs(&m,&node,1<<24,true,false,None,true)else{panic!()};assert_eq!(p.sparse.as_ref().unwrap().rhs.len(),1);assert!(!p.sparse.as_ref().unwrap().rhs[0].is_finite());
  let(mut m,node)=setup(false);m.rows[0].coefficients[1].1=0.2;assert!(!m.decimal_source.as_ref().unwrap().matches(&m));
  let Relaxation::Ready(p)=standard_sparse_selected_pairs(&m,&node,1<<24,true,false,None,true)else{panic!()};assert_eq!(p.sparse.as_ref().unwrap().rhs.len(),1);assert!(!p.sparse.as_ref().unwrap().rhs[0].is_finite());
 }
 #[test]fn duplicated_rows_are_included_in_the_memory_estimate(){
  let(m,node)=setup(false);let limit=2*48+2048+2*128;
  assert!(matches!(standard_sparse_selected_pairs(&m,&node,limit,true,false,None,false),Relaxation::Ready(_)));
  assert!(matches!(standard_sparse_selected_pairs(&m,&node,limit,true,false,None,true),Relaxation::ResourceLimit));
 }
 #[test]fn exact_equalities_keep_the_original_representation(){
  let text="NAME exact\\nROWS\\n N c\\n E r\\nCOLUMNS\\n x c 1 r 1\\nRHS\\n rhs r 1\\nBOUNDS\\n LI b x 0\\n UI b x 3\\nENDATA\\n";
  let m=crate::mps::parse(std::io::Cursor::new(text)).unwrap();let(_,mut node)=setup(false);node.lower=vec![Some(0.)];node.upper=vec![Some(3.)];
  let Relaxation::Ready(p)=standard_sparse_selected_pairs(&m,&node,1<<24,true,false,None,true)else{panic!()};let p=p.sparse.as_ref().unwrap();assert_eq!(p.rhs,vec![1.]);assert_eq!(p.equality,vec![true]);
 }
}
''';p.write_text(s)
