from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext
import os,sys,json,subprocess,resource,random,time,signal
root=Path.cwd();os.sched_setaffinity(0,{42});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,)*2);sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256
from verify_cover_cuts import validate_cut_proofs
from verify_rhs_interval import verify
from validate_solution import validate
os.environ['MIP_ABSOLUTE_CHECKER']='/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker-absolute'
out=root/'artifacts/ranged-rhs-exact-oracle';out.mkdir();binary=root/'artifacts/ranged-rhs-prefix-frozen/bin/mip-codex';rng=random.Random(202611181516);records=[];atomic_json(out/'experiment.json',dict(binary_sha256=sha256(binary),cpu=42,memory_bytes=16*1024**3,seed=202611181516,cases=200,flags=[0,1],seconds=4,watchdog=15,reference='independent exact rational integer enumeration + continuous interval endpoints',input_point_transfer=False))
def dec(v):
 with localcontext()as c:c.prec=100;return format(Decimal(v.numerator)/Decimal(v.denominator),'f')
for case in range(200):
 d=out/f'{case:04d}';d.mkdir();Y=rng.choice([10**9,10**9+3,-10**9+7]);a=F(rng.choice([-3,-1,1,2,5]));b=F(rng.choice([-3,-1,1,2,3]),rng.choice([1,2,10]));c=rng.choice([F(1,10),F(3,10),F(7,100),F(333,1000)]);target=F(rng.randint(-30,40),10);width=F(rng.randint(1,15),10)if case%2 else F(0);lo=target;up=target+width;cost=[rng.randint(-5,5),rng.choice([-5,-2,1,3]),0];maximize=bool(case%3);offset=rng.randint(-4,4);second_a=rng.choice([-2,1,3]);second_b=rng.choice([-2,1,2]);second_rhs=F(rng.randint(-20,50),10)
 feasible=[]
 for x in range(-3,5):
  wl,wu=F(-1,2),F(2)
  l,u=(lo-a*x)/b,(up-a*x)/b
  if b<0:l,u=u,l
  wl=max(wl,l);wu=min(wu,u)
  z=(second_rhs-second_a*x)/second_b
  if second_b>0:wu=min(wu,z)
  else:wl=max(wl,z)
  if wl<=wu:
   w=wu if (cost[1]>0)==maximize else wl;feasible.append(F(offset)+cost[0]*x+cost[1]*w)
 expected=(max(feasible)if maximize else min(feasible))if feasible else None
 text='NAME exactpair\nOBJSENSE\n '+('MAX'if maximize else'MIN')+'\nROWS\n N obj\n E r\n L s\nCOLUMNS\n'
 text+=f' x obj {cost[0]} r {dec(a)}\n x s {second_a}\n w obj {cost[1]} r {dec(b)}\n w s {second_b}\n y obj 0 r {dec(c)}\nRHS\n rhs obj {-offset} r {dec(c*Y+lo)}\n rhs s {dec(second_rhs)}\n'
 if width:text+='RANGES\n rng r '+dec(width)+'\n'
 text+=f'BOUNDS\n LI bounds x -3\n UI bounds x 4\n LO bounds w -0.5\n UP bounds w 2\n FX bounds y {Y}\nENDATA\n';model=d/'model.mps';model.write_text(text);atomic_json(d/'oracle.json',dict(objective=str(expected)if expected is not None else None,maximize=maximize,integer_enumerated=8,feasible_integer_slices=len(feasible)))
 for flag in ([0,1]if case%2==0 else[1,0]):
  run=d/str(flag);run.mkdir();env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_RHS_INTERVAL_PAIRS=str(flag),MIP_RHS_INTERVAL_DUMP=str(run/'rhs.jsonl'),MIP_RHS_INTERVAL_DUMP_LIMIT='100000',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');cmd=[str(binary),'solve',str(model),'4'];atomic_json(run/'job.json',dict(command=cmd,input_sha256=sha256(model),flag=flag));start=time.monotonic();watchdog=False
  with(run/'stdout.log').open('w')as so,(run/'stderr.log').open('w')as se:
   p=subprocess.Popen(cmd,stdout=so,stderr=se,env=env,start_new_session=True)
   try:p.wait(timeout=15)
   except subprocess.TimeoutExpired:watchdog=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
  atomic_json(run/'execution.json',dict(exit_code=p.returncode,watchdog=watchdog,wall_seconds=time.monotonic()-start));errors=[];validation=None;proof=None;rhs=None;r={}
  try:
   assert p.returncode==0 and not watchdog
   r=json.load(open(run/'stdout.log'));atomic_json(run/'result.json',r);proof=validate_cut_proofs(model,r);atomic_json(run/'proof-validation.json',proof);assert proof['valid']is True
   if r.get('values')is not None:
    validation=validate(model,r);atomic_json(run/'point-validation.json',validation);assert validation['valid']is True
   if r.get('status')=='infeasible':assert expected is None,'false infeasible'
   if r.get('status')=='optimal':assert expected is not None and r.get('objective')is not None and abs(F(str(r['objective']))-expected)<=F(1,10**7)*(1+abs(expected)),'wrong optimum'
   if r.get('dual_bound')is not None and expected is not None:
    dual=F(str(r['dual_bound']));assert dual>=expected if maximize else dual<=expected,'wrong dual direction'
   if(run/'rhs.jsonl').exists():rhs=verify(model,run/'rhs.jsonl');atomic_json(run/'rhs-verification.json',rhs)
  except Exception as e:errors.append(type(e).__name__+': '+str(e))
  rec=dict(case=case,flag=flag,status=r.get('status'),objective=r.get('objective'),dual=r.get('dual_bound'),expected=str(expected)if expected is not None else None,point_valid=validation.get('valid')if validation else None,proof_valid=proof.get('valid')if proof else None,rhs_rows=rhs.get('rows',0)if rhs else 0,errors=errors);records.append(rec);atomic_json(out/'records.json',records)
summary=dict(status='complete',outputs=len(records),errors=[r for r in records if r['errors']],by_flag={flag:dict(optimal=sum(r['status']=='optimal'for r in records if r['flag']==flag),infeasible=sum(r['status']=='infeasible'for r in records if r['flag']==flag),numerical=sum(r['status']=='numerical_error'for r in records if r['flag']==flag),points=sum(r['point_valid']is True for r in records if r['flag']==flag),rhs_rows=sum(r['rhs_rows']for r in records if r['flag']==flag))for flag in [0,1]});atomic_json(out/'summary.json',summary);print(json.dumps(summary))
