from pathlib import Path
import os,json,time,subprocess
root=Path.cwd();prior=Path('/home/ubuntu/mip-graph-input-cover/artifacts/input-cover-development-parallel-audit/summary.json')
while not prior.exists():time.sleep(10)
s=json.loads(prior.read_text());assert s['completed']==376 and s['fresh']==376 and s['cut_invalid']==0 and s['strict_invalid']==0
env=dict(os.environ,MIP_AUDIT_CPUS='36,37,42,48');run=subprocess.run([str(root/'.venv/bin/python'),'artifacts/spectral-bound-parallel-audit.py','spectral-bound'],env=env);assert run.returncode==0
