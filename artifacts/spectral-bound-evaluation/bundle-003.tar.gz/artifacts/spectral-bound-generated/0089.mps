NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
COLUMNS
 x0 obj 4
 x0 r0 4
 x0 r1 4
 x0 r2 4
 x0 r3 4
 x0 r4 4
 x1 obj 4
 x1 r0 4
 x1 r5 4
 x1 r6 4
 x1 r7 4
 x1 r8 4
 x2 obj 4
 x2 r1 4
 x2 r9 4
 x2 r10 4
 x2 r11 4
 x2 r12 4
 x3 obj 4
 x3 r2 4
 x3 r13 4
 x3 r14 4
 x3 r15 4
 x3 r16 4
 x4 obj 4
 x4 r3 4
 x4 r17 4
 x4 r18 4
 x4 r19 4
 x4 r20 4
 x5 obj 4
 x5 r5 4
 x5 r9 4
 x5 r21 4
 x5 r22 4
 x5 r23 4
 x6 obj 4
 x6 r6 4
 x6 r13 4
 x6 r24 4
 x6 r25 4
 x6 r26 4
 x7 obj 4
 x7 r10 4
 x7 r14 4
 x7 r27 4
 x7 r28 4
 x7 r29 4
 x8 obj 4
 x8 r7 4
 x8 r17 4
 x8 r27 4
 x8 r30 4
 x8 r31 4
 x9 obj 4
 x9 r11 4
 x9 r18 4
 x9 r24 4
 x9 r32 4
 x9 r33 4
 x10 obj 4
 x10 r15 4
 x10 r19 4
 x10 r21 4
 x10 r34 4
 x10 r35 4
 x11 obj 4
 x11 r20 4
 x11 r22 4
 x11 r25 4
 x11 r28 4
 x11 r36 4
 x12 obj 4
 x12 r16 4
 x12 r23 4
 x12 r30 4
 x12 r32 4
 x12 r37 4
 x13 obj 4
 x13 r12 4
 x13 r26 4
 x13 r31 4
 x13 r34 4
 x13 r38 4
 x14 obj 4
 x14 r8 4
 x14 r29 4
 x14 r33 4
 x14 r35 4
 x14 r39 4
 x15 obj 4
 x15 r4 4
 x15 r36 4
 x15 r37 4
 x15 r38 4
 x15 r39 4
RHS
 rhs obj 0.125
 rhs r0 4
 rhs r1 4
 rhs r2 4
 rhs r3 4
 rhs r4 4
 rhs r5 4
 rhs r6 4
 rhs r7 4
 rhs r8 4
 rhs r9 4
 rhs r10 4
 rhs r11 4
 rhs r12 4
 rhs r13 4
 rhs r14 4
 rhs r15 4
 rhs r16 4
 rhs r17 4
 rhs r18 4
 rhs r19 4
 rhs r20 4
 rhs r21 4
 rhs r22 4
 rhs r23 4
 rhs r24 4
 rhs r25 4
 rhs r26 4
 rhs r27 4
 rhs r28 4
 rhs r29 4
 rhs r30 4
 rhs r31 4
 rhs r32 4
 rhs r33 4
 rhs r34 4
 rhs r35 4
 rhs r36 4
 rhs r37 4
 rhs r38 4
 rhs r39 4
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
