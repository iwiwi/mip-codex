NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
 G r12
 G r13
 G r14
 G r15
 G r16
 G r17
 G r18
 G r19
 G r20
 G r21
 G r22
 G r23
 G r24
 G r25
 G r26
 G r27
 G r28
 G r29
 G r30
 G r31
COLUMNS
 x0 obj -4
 x0 r0 -3
 x0 r1 -3
 x0 r2 -3
 x0 r3 -3
 x1 obj -4
 x1 r4 -3
 x1 r5 -3
 x1 r6 -3
 x1 r7 -3
 x2 obj -4
 x2 r8 -3
 x2 r9 -3
 x2 r10 -3
 x2 r11 -3
 x3 obj -4
 x3 r12 -3
 x3 r13 -3
 x3 r14 -3
 x3 r15 -3
 x4 obj -4
 x4 r12 -3
 x4 r16 -3
 x4 r17 -3
 x4 r18 -3
 x5 obj -4
 x5 r8 -3
 x5 r19 -3
 x5 r20 -3
 x5 r21 -3
 x6 obj -4
 x6 r4 -3
 x6 r22 -3
 x6 r23 -3
 x6 r24 -3
 x7 obj -4
 x7 r0 -3
 x7 r25 -3
 x7 r26 -3
 x7 r27 -3
 x8 obj -4
 x8 r13 -3
 x8 r19 -3
 x8 r22 -3
 x8 r28 -3
 x9 obj -4
 x9 r9 -3
 x9 r16 -3
 x9 r25 -3
 x9 r29 -3
 x10 obj -4
 x10 r5 -3
 x10 r17 -3
 x10 r26 -3
 x10 r30 -3
 x11 obj -4
 x11 r1 -3
 x11 r20 -3
 x11 r23 -3
 x11 r31 -3
 x12 obj -4
 x12 r6 -3
 x12 r10 -3
 x12 r27 -3
 x12 r31 -3
 x13 obj -4
 x13 r2 -3
 x13 r14 -3
 x13 r24 -3
 x13 r30 -3
 x14 obj -4
 x14 r3 -3
 x14 r15 -3
 x14 r21 -3
 x14 r29 -3
 x15 obj -4
 x15 r7 -3
 x15 r11 -3
 x15 r18 -3
 x15 r28 -3
RHS
 rhs obj 0.625
 rhs r0 -3
 rhs r1 -3
 rhs r2 -3
 rhs r3 -3
 rhs r4 -3
 rhs r5 -3
 rhs r6 -3
 rhs r7 -3
 rhs r8 -3
 rhs r9 -3
 rhs r10 -3
 rhs r11 -3
 rhs r12 -3
 rhs r13 -3
 rhs r14 -3
 rhs r15 -3
 rhs r16 -3
 rhs r17 -3
 rhs r18 -3
 rhs r19 -3
 rhs r20 -3
 rhs r21 -3
 rhs r22 -3
 rhs r23 -3
 rhs r24 -3
 rhs r25 -3
 rhs r26 -3
 rhs r27 -3
 rhs r28 -3
 rhs r29 -3
 rhs r30 -3
 rhs r31 -3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
