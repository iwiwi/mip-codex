NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x0 obj 2
 x0 r0 1
 x1 obj 2
 x1 r1 1
 x2 obj 2
 x2 r1 1
 x3 obj 2
 x3 r0 1
RHS
 rhs obj -0.25
 rhs r0 1
 rhs r1 1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
ENDATA
