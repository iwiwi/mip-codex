NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
COLUMNS
 x0 obj -1
 x0 r0 -4
 x0 r1 -4
 x0 r2 -4
 x1 obj -1
 x1 r0 -4
 x1 r3 -4
 x1 r4 -4
 x2 obj -1
 x2 r1 -4
 x2 r5 -4
 x2 r6 -4
 x3 obj -1
 x3 r3 -4
 x3 r5 -4
 x3 r7 -4
 x4 obj -1
 x4 r2 -4
 x4 r8 -4
 x4 r9 -4
 x5 obj -1
 x5 r4 -4
 x5 r8 -4
 x5 r10 -4
 x6 obj -1
 x6 r6 -4
 x6 r9 -4
 x6 r11 -4
 x7 obj -1
 x7 r7 -4
 x7 r10 -4
 x7 r11 -4
RHS
 rhs obj 0.25
 rhs r0 -4
 rhs r1 -4
 rhs r2 -4
 rhs r3 -4
 rhs r4 -4
 rhs r5 -4
 rhs r6 -4
 rhs r7 -4
 rhs r8 -4
 rhs r9 -4
 rhs r10 -4
 rhs r11 -4
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
ENDATA
