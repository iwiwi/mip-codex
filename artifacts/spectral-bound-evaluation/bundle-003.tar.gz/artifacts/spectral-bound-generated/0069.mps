NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x0 obj 1
 x0 r0 -4
 x1 obj 1
 x1 r1 -4
 x2 obj 1
 x2 r1 -4
 x3 obj 1
 x3 r0 -4
RHS
 rhs obj -0.125
 rhs r0 -4
 rhs r1 -4
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
ENDATA
