NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
COLUMNS
 x0 obj -2
 x0 r0 3
 x0 r1 3
 x0 r2 3
 x1 obj -2
 x1 r0 3
 x1 r3 3
 x1 r4 3
 x2 obj -2
 x2 r1 3
 x2 r5 3
 x2 r6 3
 x3 obj -2
 x3 r2 3
 x3 r7 3
 x3 r8 3
 x4 obj -2
 x4 r3 3
 x4 r5 3
 x4 r9 3
 x5 obj -2
 x5 r4 3
 x5 r7 3
 x5 r10 3
 x6 obj -2
 x6 r6 3
 x6 r8 3
 x6 r11 3
 x7 obj -2
 x7 r9 3
 x7 r10 3
 x7 r11 3
RHS
 rhs obj -0.25
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
 rhs r6 3
 rhs r7 3
 rhs r8 3
 rhs r9 3
 rhs r10 3
 rhs r11 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
ENDATA
