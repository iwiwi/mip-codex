NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
 L r40
 L r41
 L r42
 L r43
 L r44
 L r45
 L r46
 L r47
COLUMNS
 x0 obj 4
 x0 r0 4
 x0 r1 4
 x0 r2 4
 x0 r3 4
 x0 r4 4
 x0 r5 4
 x1 obj 4
 x1 r6 4
 x1 r7 4
 x1 r8 4
 x1 r9 4
 x1 r10 4
 x1 r11 4
 x2 obj 4
 x2 r6 4
 x2 r12 4
 x2 r13 4
 x2 r14 4
 x2 r15 4
 x2 r16 4
 x3 obj 4
 x3 r7 4
 x3 r12 4
 x3 r17 4
 x3 r18 4
 x3 r19 4
 x3 r20 4
 x4 obj 4
 x4 r8 4
 x4 r13 4
 x4 r17 4
 x4 r21 4
 x4 r22 4
 x4 r23 4
 x5 obj 4
 x5 r0 4
 x5 r24 4
 x5 r25 4
 x5 r26 4
 x5 r27 4
 x5 r28 4
 x6 obj 4
 x6 r1 4
 x6 r24 4
 x6 r29 4
 x6 r30 4
 x6 r31 4
 x6 r32 4
 x7 obj 4
 x7 r2 4
 x7 r25 4
 x7 r29 4
 x7 r33 4
 x7 r34 4
 x7 r35 4
 x8 obj 4
 x8 r3 4
 x8 r26 4
 x8 r30 4
 x8 r36 4
 x8 r37 4
 x8 r38 4
 x9 obj 4
 x9 r4 4
 x9 r27 4
 x9 r33 4
 x9 r36 4
 x9 r39 4
 x9 r40 4
 x10 obj 4
 x10 r5 4
 x10 r31 4
 x10 r34 4
 x10 r37 4
 x10 r39 4
 x10 r41 4
 x11 obj 4
 x11 r9 4
 x11 r14 4
 x11 r18 4
 x11 r42 4
 x11 r43 4
 x11 r44 4
 x12 obj 4
 x12 r10 4
 x12 r15 4
 x12 r21 4
 x12 r42 4
 x12 r45 4
 x12 r46 4
 x13 obj 4
 x13 r11 4
 x13 r19 4
 x13 r22 4
 x13 r43 4
 x13 r45 4
 x13 r47 4
 x14 obj 4
 x14 r16 4
 x14 r20 4
 x14 r23 4
 x14 r44 4
 x14 r46 4
 x14 r47 4
 x15 obj 4
 x15 r28 4
 x15 r32 4
 x15 r35 4
 x15 r38 4
 x15 r40 4
 x15 r41 4
RHS
 rhs obj -1.0
 rhs r0 4
 rhs r1 4
 rhs r2 4
 rhs r3 4
 rhs r4 4
 rhs r5 4
 rhs r6 4
 rhs r7 4
 rhs r8 4
 rhs r9 4
 rhs r10 4
 rhs r11 4
 rhs r12 4
 rhs r13 4
 rhs r14 4
 rhs r15 4
 rhs r16 4
 rhs r17 4
 rhs r18 4
 rhs r19 4
 rhs r20 4
 rhs r21 4
 rhs r22 4
 rhs r23 4
 rhs r24 4
 rhs r25 4
 rhs r26 4
 rhs r27 4
 rhs r28 4
 rhs r29 4
 rhs r30 4
 rhs r31 4
 rhs r32 4
 rhs r33 4
 rhs r34 4
 rhs r35 4
 rhs r36 4
 rhs r37 4
 rhs r38 4
 rhs r39 4
 rhs r40 4
 rhs r41 4
 rhs r42 4
 rhs r43 4
 rhs r44 4
 rhs r45 4
 rhs r46 4
 rhs r47 4
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
