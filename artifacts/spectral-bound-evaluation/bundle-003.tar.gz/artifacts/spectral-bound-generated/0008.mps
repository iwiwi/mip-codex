NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
 L r40
 L r41
 L r42
 L r43
 L r44
 L r45
 L r46
 L r47
COLUMNS
 x0 obj -1
 x0 r0 1
 x0 r1 1
 x0 r2 1
 x0 r3 1
 x0 r4 1
 x0 r5 1
 x1 obj -1
 x1 r6 1
 x1 r7 1
 x1 r8 1
 x1 r9 1
 x1 r10 1
 x1 r11 1
 x2 obj -1
 x2 r6 1
 x2 r12 1
 x2 r13 1
 x2 r14 1
 x2 r15 1
 x2 r16 1
 x3 obj -1
 x3 r7 1
 x3 r12 1
 x3 r17 1
 x3 r18 1
 x3 r19 1
 x3 r20 1
 x4 obj -1
 x4 r8 1
 x4 r13 1
 x4 r17 1
 x4 r21 1
 x4 r22 1
 x4 r23 1
 x5 obj -1
 x5 r0 1
 x5 r24 1
 x5 r25 1
 x5 r26 1
 x5 r27 1
 x5 r28 1
 x6 obj -1
 x6 r1 1
 x6 r24 1
 x6 r29 1
 x6 r30 1
 x6 r31 1
 x6 r32 1
 x7 obj -1
 x7 r2 1
 x7 r25 1
 x7 r29 1
 x7 r33 1
 x7 r34 1
 x7 r35 1
 x8 obj -1
 x8 r3 1
 x8 r26 1
 x8 r30 1
 x8 r36 1
 x8 r37 1
 x8 r38 1
 x9 obj -1
 x9 r4 1
 x9 r27 1
 x9 r33 1
 x9 r36 1
 x9 r39 1
 x9 r40 1
 x10 obj -1
 x10 r5 1
 x10 r31 1
 x10 r34 1
 x10 r37 1
 x10 r39 1
 x10 r41 1
 x11 obj -1
 x11 r9 1
 x11 r14 1
 x11 r18 1
 x11 r42 1
 x11 r43 1
 x11 r44 1
 x12 obj -1
 x12 r10 1
 x12 r15 1
 x12 r21 1
 x12 r42 1
 x12 r45 1
 x12 r46 1
 x13 obj -1
 x13 r11 1
 x13 r19 1
 x13 r22 1
 x13 r43 1
 x13 r45 1
 x13 r47 1
 x14 obj -1
 x14 r16 1
 x14 r20 1
 x14 r23 1
 x14 r44 1
 x14 r46 1
 x14 r47 1
 x15 obj -1
 x15 r28 1
 x15 r32 1
 x15 r35 1
 x15 r38 1
 x15 r40 1
 x15 r41 1
RHS
 rhs obj 0.875
 rhs r0 1
 rhs r1 1
 rhs r2 1
 rhs r3 1
 rhs r4 1
 rhs r5 1
 rhs r6 1
 rhs r7 1
 rhs r8 1
 rhs r9 1
 rhs r10 1
 rhs r11 1
 rhs r12 1
 rhs r13 1
 rhs r14 1
 rhs r15 1
 rhs r16 1
 rhs r17 1
 rhs r18 1
 rhs r19 1
 rhs r20 1
 rhs r21 1
 rhs r22 1
 rhs r23 1
 rhs r24 1
 rhs r25 1
 rhs r26 1
 rhs r27 1
 rhs r28 1
 rhs r29 1
 rhs r30 1
 rhs r31 1
 rhs r32 1
 rhs r33 1
 rhs r34 1
 rhs r35 1
 rhs r36 1
 rhs r37 1
 rhs r38 1
 rhs r39 1
 rhs r40 1
 rhs r41 1
 rhs r42 1
 rhs r43 1
 rhs r44 1
 rhs r45 1
 rhs r46 1
 rhs r47 1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
