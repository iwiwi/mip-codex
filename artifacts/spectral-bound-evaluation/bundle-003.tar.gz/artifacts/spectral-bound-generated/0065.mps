NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj 4
 x0 r0 2
 x0 r1 2
 x1 obj 4
 x1 r0 2
 x1 r2 2
 x2 obj 4
 x2 r1 2
 x2 r3 2
 x3 obj 4
 x3 r2 2
 x3 r3 2
RHS
 rhs obj -1.125
 rhs r0 2
 rhs r1 2
 rhs r2 2
 rhs r3 2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
ENDATA
