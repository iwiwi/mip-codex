NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
 G r12
 G r13
 G r14
 G r15
 G r16
 G r17
 G r18
 G r19
 G r20
 G r21
 G r22
 G r23
 G r24
 G r25
 G r26
 G r27
 G r28
 G r29
 G r30
 G r31
 G r32
 G r33
 G r34
 G r35
 G r36
 G r37
 G r38
 G r39
 G r40
 G r41
 G r42
 G r43
 G r44
 G r45
 G r46
 G r47
 G r48
 G r49
 G r50
 G r51
 G r52
 G r53
 G r54
 G r55
 G r56
 G r57
 G r58
 G r59
 G r60
 G r61
 G r62
 G r63
 G r64
 G r65
 G r66
 G r67
 G r68
 G r69
 G r70
 G r71
 G r72
 G r73
 G r74
 G r75
 G r76
 G r77
 G r78
 G r79
COLUMNS
 x0 obj 4
 x0 r0 -4
 x0 r1 -4
 x0 r2 -4
 x0 r3 -4
 x0 r4 -4
 x0 r5 -4
 x0 r6 -4
 x0 r7 -4
 x0 r8 -4
 x0 r9 -4
 x1 obj 4
 x1 r10 -4
 x1 r11 -4
 x1 r12 -4
 x1 r13 -4
 x1 r14 -4
 x1 r15 -4
 x1 r16 -4
 x1 r17 -4
 x1 r18 -4
 x1 r19 -4
 x2 obj 4
 x2 r10 -4
 x2 r20 -4
 x2 r21 -4
 x2 r22 -4
 x2 r23 -4
 x2 r24 -4
 x2 r25 -4
 x2 r26 -4
 x2 r27 -4
 x2 r28 -4
 x3 obj 4
 x3 r0 -4
 x3 r29 -4
 x3 r30 -4
 x3 r31 -4
 x3 r32 -4
 x3 r33 -4
 x3 r34 -4
 x3 r35 -4
 x3 r36 -4
 x3 r37 -4
 x4 obj 4
 x4 r11 -4
 x4 r20 -4
 x4 r29 -4
 x4 r38 -4
 x4 r39 -4
 x4 r40 -4
 x4 r41 -4
 x4 r42 -4
 x4 r43 -4
 x4 r44 -4
 x5 obj 4
 x5 r1 -4
 x5 r21 -4
 x5 r30 -4
 x5 r45 -4
 x5 r46 -4
 x5 r47 -4
 x5 r48 -4
 x5 r49 -4
 x5 r50 -4
 x5 r51 -4
 x6 obj 4
 x6 r2 -4
 x6 r12 -4
 x6 r31 -4
 x6 r45 -4
 x6 r52 -4
 x6 r53 -4
 x6 r54 -4
 x6 r55 -4
 x6 r56 -4
 x6 r57 -4
 x7 obj 4
 x7 r3 -4
 x7 r13 -4
 x7 r22 -4
 x7 r38 -4
 x7 r58 -4
 x7 r59 -4
 x7 r60 -4
 x7 r61 -4
 x7 r62 -4
 x7 r63 -4
 x8 obj 4
 x8 r14 -4
 x8 r23 -4
 x8 r32 -4
 x8 r39 -4
 x8 r46 -4
 x8 r52 -4
 x8 r64 -4
 x8 r65 -4
 x8 r66 -4
 x8 r67 -4
 x9 obj 4
 x9 r4 -4
 x9 r24 -4
 x9 r33 -4
 x9 r40 -4
 x9 r47 -4
 x9 r58 -4
 x9 r68 -4
 x9 r69 -4
 x9 r70 -4
 x9 r71 -4
 x10 obj 4
 x10 r5 -4
 x10 r15 -4
 x10 r34 -4
 x10 r41 -4
 x10 r53 -4
 x10 r59 -4
 x10 r68 -4
 x10 r72 -4
 x10 r73 -4
 x10 r74 -4
 x11 obj 4
 x11 r6 -4
 x11 r16 -4
 x11 r25 -4
 x11 r48 -4
 x11 r54 -4
 x11 r60 -4
 x11 r64 -4
 x11 r75 -4
 x11 r76 -4
 x11 r77 -4
 x12 obj 4
 x12 r7 -4
 x12 r17 -4
 x12 r26 -4
 x12 r49 -4
 x12 r55 -4
 x12 r61 -4
 x12 r69 -4
 x12 r72 -4
 x12 r75 -4
 x12 r78 -4
 x13 obj 4
 x13 r8 -4
 x13 r18 -4
 x13 r35 -4
 x13 r42 -4
 x13 r56 -4
 x13 r62 -4
 x13 r65 -4
 x13 r73 -4
 x13 r76 -4
 x13 r79 -4
 x14 obj 4
 x14 r9 -4
 x14 r27 -4
 x14 r36 -4
 x14 r43 -4
 x14 r50 -4
 x14 r63 -4
 x14 r66 -4
 x14 r70 -4
 x14 r77 -4
 x14 r79 -4
 x15 obj 4
 x15 r19 -4
 x15 r28 -4
 x15 r37 -4
 x15 r44 -4
 x15 r51 -4
 x15 r57 -4
 x15 r67 -4
 x15 r71 -4
 x15 r74 -4
 x15 r78 -4
RHS
 rhs obj 1.875
 rhs r0 -4
 rhs r1 -4
 rhs r2 -4
 rhs r3 -4
 rhs r4 -4
 rhs r5 -4
 rhs r6 -4
 rhs r7 -4
 rhs r8 -4
 rhs r9 -4
 rhs r10 -4
 rhs r11 -4
 rhs r12 -4
 rhs r13 -4
 rhs r14 -4
 rhs r15 -4
 rhs r16 -4
 rhs r17 -4
 rhs r18 -4
 rhs r19 -4
 rhs r20 -4
 rhs r21 -4
 rhs r22 -4
 rhs r23 -4
 rhs r24 -4
 rhs r25 -4
 rhs r26 -4
 rhs r27 -4
 rhs r28 -4
 rhs r29 -4
 rhs r30 -4
 rhs r31 -4
 rhs r32 -4
 rhs r33 -4
 rhs r34 -4
 rhs r35 -4
 rhs r36 -4
 rhs r37 -4
 rhs r38 -4
 rhs r39 -4
 rhs r40 -4
 rhs r41 -4
 rhs r42 -4
 rhs r43 -4
 rhs r44 -4
 rhs r45 -4
 rhs r46 -4
 rhs r47 -4
 rhs r48 -4
 rhs r49 -4
 rhs r50 -4
 rhs r51 -4
 rhs r52 -4
 rhs r53 -4
 rhs r54 -4
 rhs r55 -4
 rhs r56 -4
 rhs r57 -4
 rhs r58 -4
 rhs r59 -4
 rhs r60 -4
 rhs r61 -4
 rhs r62 -4
 rhs r63 -4
 rhs r64 -4
 rhs r65 -4
 rhs r66 -4
 rhs r67 -4
 rhs r68 -4
 rhs r69 -4
 rhs r70 -4
 rhs r71 -4
 rhs r72 -4
 rhs r73 -4
 rhs r74 -4
 rhs r75 -4
 rhs r76 -4
 rhs r77 -4
 rhs r78 -4
 rhs r79 -4
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
