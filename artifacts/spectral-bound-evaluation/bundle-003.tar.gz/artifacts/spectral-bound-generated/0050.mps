NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
 L r40
 L r41
 L r42
 L r43
 L r44
 L r45
 L r46
 L r47
 L r48
 L r49
 L r50
 L r51
 L r52
 L r53
 L r54
 L r55
 L r56
 L r57
 L r58
 L r59
 L r60
 L r61
 L r62
 L r63
 L r64
 L r65
 L r66
 L r67
 L r68
 L r69
 L r70
 L r71
 L r72
 L r73
 L r74
 L r75
 L r76
 L r77
 L r78
 L r79
COLUMNS
 x0 obj -4
 x0 r0 3
 x0 r1 3
 x0 r2 3
 x0 r3 3
 x0 r4 3
 x0 r5 3
 x0 r6 3
 x0 r7 3
 x0 r8 3
 x0 r9 3
 x1 obj -4
 x1 r10 3
 x1 r11 3
 x1 r12 3
 x1 r13 3
 x1 r14 3
 x1 r15 3
 x1 r16 3
 x1 r17 3
 x1 r18 3
 x1 r19 3
 x2 obj -4
 x2 r10 3
 x2 r20 3
 x2 r21 3
 x2 r22 3
 x2 r23 3
 x2 r24 3
 x2 r25 3
 x2 r26 3
 x2 r27 3
 x2 r28 3
 x3 obj -4
 x3 r11 3
 x3 r20 3
 x3 r29 3
 x3 r30 3
 x3 r31 3
 x3 r32 3
 x3 r33 3
 x3 r34 3
 x3 r35 3
 x3 r36 3
 x4 obj -4
 x4 r12 3
 x4 r21 3
 x4 r29 3
 x4 r37 3
 x4 r38 3
 x4 r39 3
 x4 r40 3
 x4 r41 3
 x4 r42 3
 x4 r43 3
 x5 obj -4
 x5 r0 3
 x5 r30 3
 x5 r37 3
 x5 r44 3
 x5 r45 3
 x5 r46 3
 x5 r47 3
 x5 r48 3
 x5 r49 3
 x5 r50 3
 x6 obj -4
 x6 r1 3
 x6 r22 3
 x6 r38 3
 x6 r44 3
 x6 r51 3
 x6 r52 3
 x6 r53 3
 x6 r54 3
 x6 r55 3
 x6 r56 3
 x7 obj -4
 x7 r2 3
 x7 r13 3
 x7 r39 3
 x7 r45 3
 x7 r51 3
 x7 r57 3
 x7 r58 3
 x7 r59 3
 x7 r60 3
 x7 r61 3
 x8 obj -4
 x8 r3 3
 x8 r23 3
 x8 r31 3
 x8 r46 3
 x8 r52 3
 x8 r62 3
 x8 r63 3
 x8 r64 3
 x8 r65 3
 x8 r66 3
 x9 obj -4
 x9 r4 3
 x9 r14 3
 x9 r32 3
 x9 r47 3
 x9 r57 3
 x9 r62 3
 x9 r67 3
 x9 r68 3
 x9 r69 3
 x9 r70 3
 x10 obj -4
 x10 r5 3
 x10 r15 3
 x10 r24 3
 x10 r53 3
 x10 r58 3
 x10 r63 3
 x10 r67 3
 x10 r71 3
 x10 r72 3
 x10 r73 3
 x11 obj -4
 x11 r6 3
 x11 r16 3
 x11 r25 3
 x11 r33 3
 x11 r64 3
 x11 r68 3
 x11 r71 3
 x11 r74 3
 x11 r75 3
 x11 r76 3
 x12 obj -4
 x12 r7 3
 x12 r17 3
 x12 r26 3
 x12 r40 3
 x12 r54 3
 x12 r59 3
 x12 r72 3
 x12 r74 3
 x12 r77 3
 x12 r78 3
 x13 obj -4
 x13 r8 3
 x13 r18 3
 x13 r34 3
 x13 r41 3
 x13 r48 3
 x13 r60 3
 x13 r69 3
 x13 r75 3
 x13 r77 3
 x13 r79 3
 x14 obj -4
 x14 r9 3
 x14 r27 3
 x14 r35 3
 x14 r42 3
 x14 r49 3
 x14 r55 3
 x14 r65 3
 x14 r76 3
 x14 r78 3
 x14 r79 3
 x15 obj -4
 x15 r19 3
 x15 r28 3
 x15 r36 3
 x15 r43 3
 x15 r50 3
 x15 r56 3
 x15 r61 3
 x15 r66 3
 x15 r70 3
 x15 r73 3
RHS
 rhs obj 1.625
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
 rhs r6 3
 rhs r7 3
 rhs r8 3
 rhs r9 3
 rhs r10 3
 rhs r11 3
 rhs r12 3
 rhs r13 3
 rhs r14 3
 rhs r15 3
 rhs r16 3
 rhs r17 3
 rhs r18 3
 rhs r19 3
 rhs r20 3
 rhs r21 3
 rhs r22 3
 rhs r23 3
 rhs r24 3
 rhs r25 3
 rhs r26 3
 rhs r27 3
 rhs r28 3
 rhs r29 3
 rhs r30 3
 rhs r31 3
 rhs r32 3
 rhs r33 3
 rhs r34 3
 rhs r35 3
 rhs r36 3
 rhs r37 3
 rhs r38 3
 rhs r39 3
 rhs r40 3
 rhs r41 3
 rhs r42 3
 rhs r43 3
 rhs r44 3
 rhs r45 3
 rhs r46 3
 rhs r47 3
 rhs r48 3
 rhs r49 3
 rhs r50 3
 rhs r51 3
 rhs r52 3
 rhs r53 3
 rhs r54 3
 rhs r55 3
 rhs r56 3
 rhs r57 3
 rhs r58 3
 rhs r59 3
 rhs r60 3
 rhs r61 3
 rhs r62 3
 rhs r63 3
 rhs r64 3
 rhs r65 3
 rhs r66 3
 rhs r67 3
 rhs r68 3
 rhs r69 3
 rhs r70 3
 rhs r71 3
 rhs r72 3
 rhs r73 3
 rhs r74 3
 rhs r75 3
 rhs r76 3
 rhs r77 3
 rhs r78 3
 rhs r79 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
