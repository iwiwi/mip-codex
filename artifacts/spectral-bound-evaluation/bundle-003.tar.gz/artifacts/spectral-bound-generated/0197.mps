NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
COLUMNS
 x0 obj 2
 x0 r0 2
 x0 r1 2
 x0 r2 2
 x0 r3 2
 x0 r4 2
 x1 obj 2
 x1 r5 2
 x1 r6 2
 x1 r7 2
 x1 r8 2
 x1 r9 2
 x2 obj 2
 x2 r10 2
 x2 r11 2
 x2 r12 2
 x2 r13 2
 x2 r14 2
 x3 obj 2
 x3 r15 2
 x3 r16 2
 x3 r17 2
 x3 r18 2
 x3 r19 2
 x4 obj 2
 x4 r20 2
 x4 r21 2
 x4 r22 2
 x4 r23 2
 x4 r24 2
 x5 obj 2
 x5 r15 2
 x5 r20 2
 x5 r25 2
 x5 r26 2
 x5 r27 2
 x6 obj 2
 x6 r10 2
 x6 r21 2
 x6 r28 2
 x6 r29 2
 x6 r30 2
 x7 obj 2
 x7 r5 2
 x7 r22 2
 x7 r31 2
 x7 r32 2
 x7 r33 2
 x8 obj 2
 x8 r11 2
 x8 r16 2
 x8 r31 2
 x8 r34 2
 x8 r35 2
 x9 obj 2
 x9 r6 2
 x9 r17 2
 x9 r28 2
 x9 r36 2
 x9 r37 2
 x10 obj 2
 x10 r7 2
 x10 r12 2
 x10 r25 2
 x10 r38 2
 x10 r39 2
 x11 obj 2
 x11 r0 2
 x11 r23 2
 x11 r34 2
 x11 r36 2
 x11 r38 2
 x12 obj 2
 x12 r1 2
 x12 r18 2
 x12 r29 2
 x12 r32 2
 x12 r39 2
 x13 obj 2
 x13 r2 2
 x13 r13 2
 x13 r26 2
 x13 r33 2
 x13 r37 2
 x14 obj 2
 x14 r3 2
 x14 r8 2
 x14 r27 2
 x14 r30 2
 x14 r35 2
 x15 obj 2
 x15 r4 2
 x15 r9 2
 x15 r14 2
 x15 r19 2
 x15 r24 2
RHS
 rhs obj -0.5
 rhs r0 2
 rhs r1 2
 rhs r2 2
 rhs r3 2
 rhs r4 2
 rhs r5 2
 rhs r6 2
 rhs r7 2
 rhs r8 2
 rhs r9 2
 rhs r10 2
 rhs r11 2
 rhs r12 2
 rhs r13 2
 rhs r14 2
 rhs r15 2
 rhs r16 2
 rhs r17 2
 rhs r18 2
 rhs r19 2
 rhs r20 2
 rhs r21 2
 rhs r22 2
 rhs r23 2
 rhs r24 2
 rhs r25 2
 rhs r26 2
 rhs r27 2
 rhs r28 2
 rhs r29 2
 rhs r30 2
 rhs r31 2
 rhs r32 2
 rhs r33 2
 rhs r34 2
 rhs r35 2
 rhs r36 2
 rhs r37 2
 rhs r38 2
 rhs r39 2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
