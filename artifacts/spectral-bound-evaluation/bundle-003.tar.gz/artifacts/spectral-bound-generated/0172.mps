NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
COLUMNS
 x0 obj -4
 x0 r0 4
 x1 obj -4
 x1 r1 4
 x2 obj -4
 x2 r2 4
 x3 obj -4
 x3 r3 4
 x4 obj -4
 x4 r4 4
 x5 obj -4
 x5 r5 4
 x6 obj -4
 x6 r6 4
 x7 obj -4
 x7 r7 4
 x8 obj -4
 x8 r7 4
 x9 obj -4
 x9 r6 4
 x10 obj -4
 x10 r5 4
 x11 obj -4
 x11 r4 4
 x12 obj -4
 x12 r3 4
 x13 obj -4
 x13 r2 4
 x14 obj -4
 x14 r1 4
 x15 obj -4
 x15 r0 4
RHS
 rhs obj -1.25
 rhs r0 4
 rhs r1 4
 rhs r2 4
 rhs r3 4
 rhs r4 4
 rhs r5 4
 rhs r6 4
 rhs r7 4
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
