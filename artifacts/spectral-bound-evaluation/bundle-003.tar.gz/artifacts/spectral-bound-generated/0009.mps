NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
 G r12
 G r13
 G r14
 G r15
 G r16
 G r17
 G r18
 G r19
 G r20
 G r21
 G r22
 G r23
 G r24
 G r25
 G r26
 G r27
 G r28
 G r29
 G r30
 G r31
 G r32
 G r33
 G r34
 G r35
 G r36
 G r37
 G r38
 G r39
 G r40
 G r41
 G r42
 G r43
 G r44
 G r45
 G r46
 G r47
 G r48
 G r49
 G r50
 G r51
 G r52
 G r53
 G r54
 G r55
 G r56
 G r57
 G r58
 G r59
 G r60
 G r61
 G r62
 G r63
COLUMNS
 x0 obj 2
 x0 r0 -3
 x0 r1 -3
 x0 r2 -3
 x0 r3 -3
 x0 r4 -3
 x0 r5 -3
 x0 r6 -3
 x0 r7 -3
 x1 obj 2
 x1 r0 -3
 x1 r8 -3
 x1 r9 -3
 x1 r10 -3
 x1 r11 -3
 x1 r12 -3
 x1 r13 -3
 x1 r14 -3
 x2 obj 2
 x2 r1 -3
 x2 r15 -3
 x2 r16 -3
 x2 r17 -3
 x2 r18 -3
 x2 r19 -3
 x2 r20 -3
 x2 r21 -3
 x3 obj 2
 x3 r8 -3
 x3 r15 -3
 x3 r22 -3
 x3 r23 -3
 x3 r24 -3
 x3 r25 -3
 x3 r26 -3
 x3 r27 -3
 x4 obj 2
 x4 r2 -3
 x4 r22 -3
 x4 r28 -3
 x4 r29 -3
 x4 r30 -3
 x4 r31 -3
 x4 r32 -3
 x4 r33 -3
 x5 obj 2
 x5 r9 -3
 x5 r16 -3
 x5 r28 -3
 x5 r34 -3
 x5 r35 -3
 x5 r36 -3
 x5 r37 -3
 x5 r38 -3
 x6 obj 2
 x6 r10 -3
 x6 r17 -3
 x6 r29 -3
 x6 r39 -3
 x6 r40 -3
 x6 r41 -3
 x6 r42 -3
 x6 r43 -3
 x7 obj 2
 x7 r3 -3
 x7 r23 -3
 x7 r34 -3
 x7 r39 -3
 x7 r44 -3
 x7 r45 -3
 x7 r46 -3
 x7 r47 -3
 x8 obj 2
 x8 r4 -3
 x8 r24 -3
 x8 r35 -3
 x8 r40 -3
 x8 r48 -3
 x8 r49 -3
 x8 r50 -3
 x8 r51 -3
 x9 obj 2
 x9 r11 -3
 x9 r18 -3
 x9 r30 -3
 x9 r44 -3
 x9 r48 -3
 x9 r52 -3
 x9 r53 -3
 x9 r54 -3
 x10 obj 2
 x10 r12 -3
 x10 r19 -3
 x10 r31 -3
 x10 r45 -3
 x10 r49 -3
 x10 r55 -3
 x10 r56 -3
 x10 r57 -3
 x11 obj 2
 x11 r5 -3
 x11 r25 -3
 x11 r36 -3
 x11 r41 -3
 x11 r52 -3
 x11 r55 -3
 x11 r58 -3
 x11 r59 -3
 x12 obj 2
 x12 r13 -3
 x12 r20 -3
 x12 r32 -3
 x12 r46 -3
 x12 r50 -3
 x12 r58 -3
 x12 r60 -3
 x12 r61 -3
 x13 obj 2
 x13 r6 -3
 x13 r26 -3
 x13 r37 -3
 x13 r42 -3
 x13 r53 -3
 x13 r56 -3
 x13 r60 -3
 x13 r62 -3
 x14 obj 2
 x14 r7 -3
 x14 r27 -3
 x14 r38 -3
 x14 r43 -3
 x14 r54 -3
 x14 r57 -3
 x14 r61 -3
 x14 r63 -3
 x15 obj 2
 x15 r14 -3
 x15 r21 -3
 x15 r33 -3
 x15 r47 -3
 x15 r51 -3
 x15 r59 -3
 x15 r62 -3
 x15 r63 -3
RHS
 rhs obj 0.375
 rhs r0 -3
 rhs r1 -3
 rhs r2 -3
 rhs r3 -3
 rhs r4 -3
 rhs r5 -3
 rhs r6 -3
 rhs r7 -3
 rhs r8 -3
 rhs r9 -3
 rhs r10 -3
 rhs r11 -3
 rhs r12 -3
 rhs r13 -3
 rhs r14 -3
 rhs r15 -3
 rhs r16 -3
 rhs r17 -3
 rhs r18 -3
 rhs r19 -3
 rhs r20 -3
 rhs r21 -3
 rhs r22 -3
 rhs r23 -3
 rhs r24 -3
 rhs r25 -3
 rhs r26 -3
 rhs r27 -3
 rhs r28 -3
 rhs r29 -3
 rhs r30 -3
 rhs r31 -3
 rhs r32 -3
 rhs r33 -3
 rhs r34 -3
 rhs r35 -3
 rhs r36 -3
 rhs r37 -3
 rhs r38 -3
 rhs r39 -3
 rhs r40 -3
 rhs r41 -3
 rhs r42 -3
 rhs r43 -3
 rhs r44 -3
 rhs r45 -3
 rhs r46 -3
 rhs r47 -3
 rhs r48 -3
 rhs r49 -3
 rhs r50 -3
 rhs r51 -3
 rhs r52 -3
 rhs r53 -3
 rhs r54 -3
 rhs r55 -3
 rhs r56 -3
 rhs r57 -3
 rhs r58 -3
 rhs r59 -3
 rhs r60 -3
 rhs r61 -3
 rhs r62 -3
 rhs r63 -3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
