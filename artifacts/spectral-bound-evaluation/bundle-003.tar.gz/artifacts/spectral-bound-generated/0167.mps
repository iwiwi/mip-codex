NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
 L r40
 L r41
 L r42
 L r43
 L r44
 L r45
 L r46
 L r47
COLUMNS
 x0 obj 2
 x0 r0 3
 x0 r1 3
 x0 r2 3
 x0 r3 3
 x0 r4 3
 x0 r5 3
 x1 obj 2
 x1 r6 3
 x1 r7 3
 x1 r8 3
 x1 r9 3
 x1 r10 3
 x1 r11 3
 x2 obj 2
 x2 r6 3
 x2 r12 3
 x2 r13 3
 x2 r14 3
 x2 r15 3
 x2 r16 3
 x3 obj 2
 x3 r7 3
 x3 r12 3
 x3 r17 3
 x3 r18 3
 x3 r19 3
 x3 r20 3
 x4 obj 2
 x4 r8 3
 x4 r13 3
 x4 r17 3
 x4 r21 3
 x4 r22 3
 x4 r23 3
 x5 obj 2
 x5 r0 3
 x5 r24 3
 x5 r25 3
 x5 r26 3
 x5 r27 3
 x5 r28 3
 x6 obj 2
 x6 r1 3
 x6 r24 3
 x6 r29 3
 x6 r30 3
 x6 r31 3
 x6 r32 3
 x7 obj 2
 x7 r2 3
 x7 r25 3
 x7 r29 3
 x7 r33 3
 x7 r34 3
 x7 r35 3
 x8 obj 2
 x8 r3 3
 x8 r26 3
 x8 r30 3
 x8 r36 3
 x8 r37 3
 x8 r38 3
 x9 obj 2
 x9 r4 3
 x9 r27 3
 x9 r33 3
 x9 r36 3
 x9 r39 3
 x9 r40 3
 x10 obj 2
 x10 r5 3
 x10 r31 3
 x10 r34 3
 x10 r37 3
 x10 r39 3
 x10 r41 3
 x11 obj 2
 x11 r9 3
 x11 r14 3
 x11 r18 3
 x11 r42 3
 x11 r43 3
 x11 r44 3
 x12 obj 2
 x12 r10 3
 x12 r15 3
 x12 r21 3
 x12 r42 3
 x12 r45 3
 x12 r46 3
 x13 obj 2
 x13 r11 3
 x13 r19 3
 x13 r22 3
 x13 r43 3
 x13 r45 3
 x13 r47 3
 x14 obj 2
 x14 r16 3
 x14 r20 3
 x14 r23 3
 x14 r44 3
 x14 r46 3
 x14 r47 3
 x15 obj 2
 x15 r28 3
 x15 r32 3
 x15 r35 3
 x15 r38 3
 x15 r40 3
 x15 r41 3
RHS
 rhs obj -1.75
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
 rhs r6 3
 rhs r7 3
 rhs r8 3
 rhs r9 3
 rhs r10 3
 rhs r11 3
 rhs r12 3
 rhs r13 3
 rhs r14 3
 rhs r15 3
 rhs r16 3
 rhs r17 3
 rhs r18 3
 rhs r19 3
 rhs r20 3
 rhs r21 3
 rhs r22 3
 rhs r23 3
 rhs r24 3
 rhs r25 3
 rhs r26 3
 rhs r27 3
 rhs r28 3
 rhs r29 3
 rhs r30 3
 rhs r31 3
 rhs r32 3
 rhs r33 3
 rhs r34 3
 rhs r35 3
 rhs r36 3
 rhs r37 3
 rhs r38 3
 rhs r39 3
 rhs r40 3
 rhs r41 3
 rhs r42 3
 rhs r43 3
 rhs r44 3
 rhs r45 3
 rhs r46 3
 rhs r47 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
