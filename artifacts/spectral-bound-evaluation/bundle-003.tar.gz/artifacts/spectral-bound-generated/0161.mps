NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
COLUMNS
 x0 obj 4
 x0 r0 1
 x0 r1 1
 x0 r2 1
 x0 r3 1
 x0 r4 1
 x0 r5 1
 x1 obj 4
 x1 r0 1
 x1 r6 1
 x1 r7 1
 x1 r8 1
 x1 r9 1
 x1 r10 1
 x2 obj 4
 x2 r1 1
 x2 r6 1
 x2 r11 1
 x2 r12 1
 x2 r13 1
 x2 r14 1
 x3 obj 4
 x3 r2 1
 x3 r7 1
 x3 r11 1
 x3 r15 1
 x3 r16 1
 x3 r17 1
 x4 obj 4
 x4 r3 1
 x4 r8 1
 x4 r12 1
 x4 r18 1
 x4 r19 1
 x4 r20 1
 x5 obj 4
 x5 r4 1
 x5 r9 1
 x5 r15 1
 x5 r18 1
 x5 r21 1
 x5 r22 1
 x6 obj 4
 x6 r5 1
 x6 r13 1
 x6 r16 1
 x6 r19 1
 x6 r21 1
 x6 r23 1
 x7 obj 4
 x7 r10 1
 x7 r14 1
 x7 r17 1
 x7 r20 1
 x7 r22 1
 x7 r23 1
RHS
 rhs obj 1.25
 rhs r0 1
 rhs r1 1
 rhs r2 1
 rhs r3 1
 rhs r4 1
 rhs r5 1
 rhs r6 1
 rhs r7 1
 rhs r8 1
 rhs r9 1
 rhs r10 1
 rhs r11 1
 rhs r12 1
 rhs r13 1
 rhs r14 1
 rhs r15 1
 rhs r16 1
 rhs r17 1
 rhs r18 1
 rhs r19 1
 rhs r20 1
 rhs r21 1
 rhs r22 1
 rhs r23 1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
ENDATA
