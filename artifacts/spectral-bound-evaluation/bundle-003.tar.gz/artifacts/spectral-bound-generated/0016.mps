NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
COLUMNS
 x0 obj -3
 x0 r0 4
 x0 r1 4
 x0 r2 4
 x0 r3 4
 x1 obj -3
 x1 r4 4
 x1 r5 4
 x1 r6 4
 x1 r7 4
 x2 obj -3
 x2 r4 4
 x2 r8 4
 x2 r9 4
 x2 r10 4
 x3 obj -3
 x3 r5 4
 x3 r8 4
 x3 r11 4
 x3 r12 4
 x4 obj -3
 x4 r0 4
 x4 r11 4
 x4 r13 4
 x4 r14 4
 x5 obj -3
 x5 r1 4
 x5 r9 4
 x5 r13 4
 x5 r15 4
 x6 obj -3
 x6 r2 4
 x6 r6 4
 x6 r14 4
 x6 r15 4
 x7 obj -3
 x7 r3 4
 x7 r7 4
 x7 r10 4
 x7 r12 4
RHS
 rhs obj 0.625
 rhs r0 4
 rhs r1 4
 rhs r2 4
 rhs r3 4
 rhs r4 4
 rhs r5 4
 rhs r6 4
 rhs r7 4
 rhs r8 4
 rhs r9 4
 rhs r10 4
 rhs r11 4
 rhs r12 4
 rhs r13 4
 rhs r14 4
 rhs r15 4
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
ENDATA
