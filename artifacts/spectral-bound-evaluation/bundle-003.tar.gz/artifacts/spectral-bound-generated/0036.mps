NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
 G r12
 G r13
 G r14
 G r15
 G r16
 G r17
 G r18
 G r19
 G r20
 G r21
 G r22
 G r23
 G r24
 G r25
 G r26
 G r27
COLUMNS
 x0 obj -1
 x0 r0 -2
 x0 r1 -2
 x0 r2 -2
 x0 r3 -2
 x0 r4 -2
 x0 r5 -2
 x0 r6 -2
 x1 obj -1
 x1 r0 -2
 x1 r7 -2
 x1 r8 -2
 x1 r9 -2
 x1 r10 -2
 x1 r11 -2
 x1 r12 -2
 x2 obj -1
 x2 r1 -2
 x2 r7 -2
 x2 r13 -2
 x2 r14 -2
 x2 r15 -2
 x2 r16 -2
 x2 r17 -2
 x3 obj -1
 x3 r2 -2
 x3 r8 -2
 x3 r13 -2
 x3 r18 -2
 x3 r19 -2
 x3 r20 -2
 x3 r21 -2
 x4 obj -1
 x4 r3 -2
 x4 r9 -2
 x4 r14 -2
 x4 r18 -2
 x4 r22 -2
 x4 r23 -2
 x4 r24 -2
 x5 obj -1
 x5 r4 -2
 x5 r10 -2
 x5 r15 -2
 x5 r19 -2
 x5 r22 -2
 x5 r25 -2
 x5 r26 -2
 x6 obj -1
 x6 r5 -2
 x6 r11 -2
 x6 r16 -2
 x6 r20 -2
 x6 r23 -2
 x6 r25 -2
 x6 r27 -2
 x7 obj -1
 x7 r6 -2
 x7 r12 -2
 x7 r17 -2
 x7 r21 -2
 x7 r24 -2
 x7 r26 -2
 x7 r27 -2
RHS
 rhs obj 1.125
 rhs r0 -2
 rhs r1 -2
 rhs r2 -2
 rhs r3 -2
 rhs r4 -2
 rhs r5 -2
 rhs r6 -2
 rhs r7 -2
 rhs r8 -2
 rhs r9 -2
 rhs r10 -2
 rhs r11 -2
 rhs r12 -2
 rhs r13 -2
 rhs r14 -2
 rhs r15 -2
 rhs r16 -2
 rhs r17 -2
 rhs r18 -2
 rhs r19 -2
 rhs r20 -2
 rhs r21 -2
 rhs r22 -2
 rhs r23 -2
 rhs r24 -2
 rhs r25 -2
 rhs r26 -2
 rhs r27 -2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
ENDATA
