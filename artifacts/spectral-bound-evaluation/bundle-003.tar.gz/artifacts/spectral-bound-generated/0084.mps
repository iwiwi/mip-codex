NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
 G r12
 G r13
 G r14
 G r15
 G r16
 G r17
 G r18
 G r19
 G r20
 G r21
 G r22
 G r23
 G r24
 G r25
 G r26
 G r27
 G r28
 G r29
 G r30
 G r31
 G r32
 G r33
 G r34
 G r35
 G r36
 G r37
 G r38
 G r39
 G r40
 G r41
 G r42
 G r43
 G r44
 G r45
 G r46
 G r47
COLUMNS
 x0 obj -4
 x0 r0 -2
 x0 r1 -2
 x0 r2 -2
 x0 r3 -2
 x0 r4 -2
 x0 r5 -2
 x1 obj -4
 x1 r6 -2
 x1 r7 -2
 x1 r8 -2
 x1 r9 -2
 x1 r10 -2
 x1 r11 -2
 x2 obj -4
 x2 r6 -2
 x2 r12 -2
 x2 r13 -2
 x2 r14 -2
 x2 r15 -2
 x2 r16 -2
 x3 obj -4
 x3 r0 -2
 x3 r17 -2
 x3 r18 -2
 x3 r19 -2
 x3 r20 -2
 x3 r21 -2
 x4 obj -4
 x4 r7 -2
 x4 r12 -2
 x4 r22 -2
 x4 r23 -2
 x4 r24 -2
 x4 r25 -2
 x5 obj -4
 x5 r1 -2
 x5 r17 -2
 x5 r26 -2
 x5 r27 -2
 x5 r28 -2
 x5 r29 -2
 x6 obj -4
 x6 r2 -2
 x6 r18 -2
 x6 r26 -2
 x6 r30 -2
 x6 r31 -2
 x6 r32 -2
 x7 obj -4
 x7 r8 -2
 x7 r13 -2
 x7 r22 -2
 x7 r33 -2
 x7 r34 -2
 x7 r35 -2
 x8 obj -4
 x8 r9 -2
 x8 r14 -2
 x8 r23 -2
 x8 r36 -2
 x8 r37 -2
 x8 r38 -2
 x9 obj -4
 x9 r3 -2
 x9 r19 -2
 x9 r27 -2
 x9 r39 -2
 x9 r40 -2
 x9 r41 -2
 x10 obj -4
 x10 r4 -2
 x10 r20 -2
 x10 r30 -2
 x10 r39 -2
 x10 r42 -2
 x10 r43 -2
 x11 obj -4
 x11 r10 -2
 x11 r15 -2
 x11 r33 -2
 x11 r36 -2
 x11 r44 -2
 x11 r45 -2
 x12 obj -4
 x12 r5 -2
 x12 r28 -2
 x12 r31 -2
 x12 r40 -2
 x12 r42 -2
 x12 r46 -2
 x13 obj -4
 x13 r11 -2
 x13 r24 -2
 x13 r34 -2
 x13 r37 -2
 x13 r44 -2
 x13 r47 -2
 x14 obj -4
 x14 r16 -2
 x14 r25 -2
 x14 r35 -2
 x14 r38 -2
 x14 r45 -2
 x14 r47 -2
 x15 obj -4
 x15 r21 -2
 x15 r29 -2
 x15 r32 -2
 x15 r41 -2
 x15 r43 -2
 x15 r46 -2
RHS
 rhs obj 0.125
 rhs r0 -2
 rhs r1 -2
 rhs r2 -2
 rhs r3 -2
 rhs r4 -2
 rhs r5 -2
 rhs r6 -2
 rhs r7 -2
 rhs r8 -2
 rhs r9 -2
 rhs r10 -2
 rhs r11 -2
 rhs r12 -2
 rhs r13 -2
 rhs r14 -2
 rhs r15 -2
 rhs r16 -2
 rhs r17 -2
 rhs r18 -2
 rhs r19 -2
 rhs r20 -2
 rhs r21 -2
 rhs r22 -2
 rhs r23 -2
 rhs r24 -2
 rhs r25 -2
 rhs r26 -2
 rhs r27 -2
 rhs r28 -2
 rhs r29 -2
 rhs r30 -2
 rhs r31 -2
 rhs r32 -2
 rhs r33 -2
 rhs r34 -2
 rhs r35 -2
 rhs r36 -2
 rhs r37 -2
 rhs r38 -2
 rhs r39 -2
 rhs r40 -2
 rhs r41 -2
 rhs r42 -2
 rhs r43 -2
 rhs r44 -2
 rhs r45 -2
 rhs r46 -2
 rhs r47 -2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
