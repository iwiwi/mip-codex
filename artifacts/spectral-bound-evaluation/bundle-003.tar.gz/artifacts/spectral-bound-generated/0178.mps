NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
COLUMNS
 x0 obj -4
 x0 r0 1
 x0 r1 1
 x0 r2 1
 x0 r3 1
 x1 obj -4
 x1 r4 1
 x1 r5 1
 x1 r6 1
 x1 r7 1
 x2 obj -4
 x2 r8 1
 x2 r9 1
 x2 r10 1
 x2 r11 1
 x3 obj -4
 x3 r12 1
 x3 r13 1
 x3 r14 1
 x3 r15 1
 x4 obj -4
 x4 r16 1
 x4 r17 1
 x4 r18 1
 x4 r19 1
 x5 obj -4
 x5 r12 1
 x5 r16 1
 x5 r20 1
 x5 r21 1
 x6 obj -4
 x6 r8 1
 x6 r17 1
 x6 r22 1
 x6 r23 1
 x7 obj -4
 x7 r9 1
 x7 r13 1
 x7 r24 1
 x7 r25 1
 x8 obj -4
 x8 r4 1
 x8 r18 1
 x8 r26 1
 x8 r27 1
 x9 obj -4
 x9 r5 1
 x9 r14 1
 x9 r28 1
 x9 r29 1
 x10 obj -4
 x10 r6 1
 x10 r10 1
 x10 r30 1
 x10 r31 1
 x11 obj -4
 x11 r0 1
 x11 r24 1
 x11 r28 1
 x11 r30 1
 x12 obj -4
 x12 r1 1
 x12 r22 1
 x12 r26 1
 x12 r31 1
 x13 obj -4
 x13 r2 1
 x13 r20 1
 x13 r27 1
 x13 r29 1
 x14 obj -4
 x14 r3 1
 x14 r21 1
 x14 r23 1
 x14 r25 1
 x15 obj -4
 x15 r7 1
 x15 r11 1
 x15 r15 1
 x15 r19 1
RHS
 rhs obj 0.5
 rhs r0 1
 rhs r1 1
 rhs r2 1
 rhs r3 1
 rhs r4 1
 rhs r5 1
 rhs r6 1
 rhs r7 1
 rhs r8 1
 rhs r9 1
 rhs r10 1
 rhs r11 1
 rhs r12 1
 rhs r13 1
 rhs r14 1
 rhs r15 1
 rhs r16 1
 rhs r17 1
 rhs r18 1
 rhs r19 1
 rhs r20 1
 rhs r21 1
 rhs r22 1
 rhs r23 1
 rhs r24 1
 rhs r25 1
 rhs r26 1
 rhs r27 1
 rhs r28 1
 rhs r29 1
 rhs r30 1
 rhs r31 1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
