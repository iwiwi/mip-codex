NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
COLUMNS
 x0 obj -1
 x0 r0 -3
 x0 r1 -3
 x1 obj -1
 x1 r0 -3
 x1 r2 -3
 x2 obj -1
 x2 r1 -3
 x2 r3 -3
 x3 obj -1
 x3 r2 -3
 x3 r3 -3
RHS
 rhs obj -0.75
 rhs r0 -3
 rhs r1 -3
 rhs r2 -3
 rhs r3 -3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
ENDATA
