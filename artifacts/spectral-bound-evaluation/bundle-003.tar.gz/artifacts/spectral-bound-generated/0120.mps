NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x0 obj -1
 x0 r0 -2
 x1 obj -1
 x1 r1 -2
 x2 obj -1
 x2 r1 -2
 x3 obj -1
 x3 r0 -2
RHS
 rhs obj -1.125
 rhs r0 -2
 rhs r1 -2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
ENDATA
