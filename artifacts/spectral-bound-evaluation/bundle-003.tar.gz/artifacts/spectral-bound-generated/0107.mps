NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj 4
 x0 r0 1
 x1 obj 4
 x1 r1 1
 x2 obj 4
 x2 r2 1
 x3 obj 4
 x3 r3 1
 x4 obj 4
 x4 r3 1
 x5 obj 4
 x5 r2 1
 x6 obj 4
 x6 r1 1
 x7 obj 4
 x7 r0 1
RHS
 rhs obj -1.75
 rhs r0 1
 rhs r1 1
 rhs r2 1
 rhs r3 1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
ENDATA
