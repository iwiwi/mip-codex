NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
 L r40
 L r41
 L r42
 L r43
 L r44
 L r45
 L r46
 L r47
 L r48
 L r49
 L r50
 L r51
 L r52
 L r53
 L r54
 L r55
 L r56
 L r57
 L r58
 L r59
 L r60
 L r61
 L r62
 L r63
COLUMNS
 x0 obj 3
 x0 r0 2
 x0 r1 2
 x0 r2 2
 x0 r3 2
 x0 r4 2
 x0 r5 2
 x0 r6 2
 x0 r7 2
 x1 obj 3
 x1 r0 2
 x1 r8 2
 x1 r9 2
 x1 r10 2
 x1 r11 2
 x1 r12 2
 x1 r13 2
 x1 r14 2
 x2 obj 3
 x2 r1 2
 x2 r15 2
 x2 r16 2
 x2 r17 2
 x2 r18 2
 x2 r19 2
 x2 r20 2
 x2 r21 2
 x3 obj 3
 x3 r2 2
 x3 r22 2
 x3 r23 2
 x3 r24 2
 x3 r25 2
 x3 r26 2
 x3 r27 2
 x3 r28 2
 x4 obj 3
 x4 r3 2
 x4 r29 2
 x4 r30 2
 x4 r31 2
 x4 r32 2
 x4 r33 2
 x4 r34 2
 x4 r35 2
 x5 obj 3
 x5 r8 2
 x5 r15 2
 x5 r22 2
 x5 r29 2
 x5 r36 2
 x5 r37 2
 x5 r38 2
 x5 r39 2
 x6 obj 3
 x6 r9 2
 x6 r16 2
 x6 r23 2
 x6 r30 2
 x6 r40 2
 x6 r41 2
 x6 r42 2
 x6 r43 2
 x7 obj 3
 x7 r10 2
 x7 r17 2
 x7 r24 2
 x7 r31 2
 x7 r44 2
 x7 r45 2
 x7 r46 2
 x7 r47 2
 x8 obj 3
 x8 r11 2
 x8 r18 2
 x8 r25 2
 x8 r32 2
 x8 r48 2
 x8 r49 2
 x8 r50 2
 x8 r51 2
 x9 obj 3
 x9 r12 2
 x9 r19 2
 x9 r26 2
 x9 r33 2
 x9 r52 2
 x9 r53 2
 x9 r54 2
 x9 r55 2
 x10 obj 3
 x10 r13 2
 x10 r20 2
 x10 r27 2
 x10 r34 2
 x10 r56 2
 x10 r57 2
 x10 r58 2
 x10 r59 2
 x11 obj 3
 x11 r4 2
 x11 r36 2
 x11 r40 2
 x11 r44 2
 x11 r48 2
 x11 r52 2
 x11 r56 2
 x11 r60 2
 x12 obj 3
 x12 r5 2
 x12 r37 2
 x12 r41 2
 x12 r45 2
 x12 r49 2
 x12 r53 2
 x12 r57 2
 x12 r61 2
 x13 obj 3
 x13 r6 2
 x13 r38 2
 x13 r42 2
 x13 r46 2
 x13 r50 2
 x13 r54 2
 x13 r58 2
 x13 r62 2
 x14 obj 3
 x14 r7 2
 x14 r39 2
 x14 r43 2
 x14 r47 2
 x14 r51 2
 x14 r55 2
 x14 r59 2
 x14 r63 2
 x15 obj 3
 x15 r14 2
 x15 r21 2
 x15 r28 2
 x15 r35 2
 x15 r60 2
 x15 r61 2
 x15 r62 2
 x15 r63 2
RHS
 rhs obj -1.75
 rhs r0 2
 rhs r1 2
 rhs r2 2
 rhs r3 2
 rhs r4 2
 rhs r5 2
 rhs r6 2
 rhs r7 2
 rhs r8 2
 rhs r9 2
 rhs r10 2
 rhs r11 2
 rhs r12 2
 rhs r13 2
 rhs r14 2
 rhs r15 2
 rhs r16 2
 rhs r17 2
 rhs r18 2
 rhs r19 2
 rhs r20 2
 rhs r21 2
 rhs r22 2
 rhs r23 2
 rhs r24 2
 rhs r25 2
 rhs r26 2
 rhs r27 2
 rhs r28 2
 rhs r29 2
 rhs r30 2
 rhs r31 2
 rhs r32 2
 rhs r33 2
 rhs r34 2
 rhs r35 2
 rhs r36 2
 rhs r37 2
 rhs r38 2
 rhs r39 2
 rhs r40 2
 rhs r41 2
 rhs r42 2
 rhs r43 2
 rhs r44 2
 rhs r45 2
 rhs r46 2
 rhs r47 2
 rhs r48 2
 rhs r49 2
 rhs r50 2
 rhs r51 2
 rhs r52 2
 rhs r53 2
 rhs r54 2
 rhs r55 2
 rhs r56 2
 rhs r57 2
 rhs r58 2
 rhs r59 2
 rhs r60 2
 rhs r61 2
 rhs r62 2
 rhs r63 2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
