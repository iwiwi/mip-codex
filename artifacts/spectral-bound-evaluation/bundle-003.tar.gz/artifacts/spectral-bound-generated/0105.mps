NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
COLUMNS
 x0 obj 4
 x0 r0 -4
 x1 obj 4
 x1 r1 -4
 x2 obj 4
 x2 r2 -4
 x3 obj 4
 x3 r3 -4
 x4 obj 4
 x4 r3 -4
 x5 obj 4
 x5 r2 -4
 x6 obj 4
 x6 r1 -4
 x7 obj 4
 x7 r0 -4
RHS
 rhs obj 0.875
 rhs r0 -4
 rhs r1 -4
 rhs r2 -4
 rhs r3 -4
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
ENDATA
