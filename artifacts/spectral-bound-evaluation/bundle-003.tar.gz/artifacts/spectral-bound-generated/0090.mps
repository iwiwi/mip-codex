NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
 G r12
 G r13
 G r14
 G r15
 G r16
 G r17
 G r18
 G r19
 G r20
 G r21
 G r22
 G r23
 G r24
 G r25
 G r26
 G r27
 G r28
 G r29
 G r30
 G r31
 G r32
 G r33
 G r34
 G r35
 G r36
 G r37
 G r38
 G r39
COLUMNS
 x0 obj -2
 x0 r0 -1
 x0 r1 -1
 x0 r2 -1
 x0 r3 -1
 x0 r4 -1
 x1 obj -2
 x1 r5 -1
 x1 r6 -1
 x1 r7 -1
 x1 r8 -1
 x1 r9 -1
 x2 obj -2
 x2 r10 -1
 x2 r11 -1
 x2 r12 -1
 x2 r13 -1
 x2 r14 -1
 x3 obj -2
 x3 r15 -1
 x3 r16 -1
 x3 r17 -1
 x3 r18 -1
 x3 r19 -1
 x4 obj -2
 x4 r15 -1
 x4 r20 -1
 x4 r21 -1
 x4 r22 -1
 x4 r23 -1
 x5 obj -2
 x5 r10 -1
 x5 r24 -1
 x5 r25 -1
 x5 r26 -1
 x5 r27 -1
 x6 obj -2
 x6 r5 -1
 x6 r28 -1
 x6 r29 -1
 x6 r30 -1
 x6 r31 -1
 x7 obj -2
 x7 r0 -1
 x7 r32 -1
 x7 r33 -1
 x7 r34 -1
 x7 r35 -1
 x8 obj -2
 x8 r16 -1
 x8 r24 -1
 x8 r28 -1
 x8 r32 -1
 x8 r36 -1
 x9 obj -2
 x9 r11 -1
 x9 r20 -1
 x9 r29 -1
 x9 r33 -1
 x9 r37 -1
 x10 obj -2
 x10 r6 -1
 x10 r21 -1
 x10 r25 -1
 x10 r34 -1
 x10 r38 -1
 x11 obj -2
 x11 r1 -1
 x11 r22 -1
 x11 r26 -1
 x11 r30 -1
 x11 r39 -1
 x12 obj -2
 x12 r7 -1
 x12 r12 -1
 x12 r17 -1
 x12 r35 -1
 x12 r39 -1
 x13 obj -2
 x13 r2 -1
 x13 r13 -1
 x13 r18 -1
 x13 r31 -1
 x13 r38 -1
 x14 obj -2
 x14 r3 -1
 x14 r8 -1
 x14 r19 -1
 x14 r27 -1
 x14 r37 -1
 x15 obj -2
 x15 r4 -1
 x15 r9 -1
 x15 r14 -1
 x15 r23 -1
 x15 r36 -1
RHS
 rhs obj -0.5
 rhs r0 -1
 rhs r1 -1
 rhs r2 -1
 rhs r3 -1
 rhs r4 -1
 rhs r5 -1
 rhs r6 -1
 rhs r7 -1
 rhs r8 -1
 rhs r9 -1
 rhs r10 -1
 rhs r11 -1
 rhs r12 -1
 rhs r13 -1
 rhs r14 -1
 rhs r15 -1
 rhs r16 -1
 rhs r17 -1
 rhs r18 -1
 rhs r19 -1
 rhs r20 -1
 rhs r21 -1
 rhs r22 -1
 rhs r23 -1
 rhs r24 -1
 rhs r25 -1
 rhs r26 -1
 rhs r27 -1
 rhs r28 -1
 rhs r29 -1
 rhs r30 -1
 rhs r31 -1
 rhs r32 -1
 rhs r33 -1
 rhs r34 -1
 rhs r35 -1
 rhs r36 -1
 rhs r37 -1
 rhs r38 -1
 rhs r39 -1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
