NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
 G r12
 G r13
 G r14
 G r15
 G r16
 G r17
 G r18
 G r19
 G r20
 G r21
 G r22
 G r23
 G r24
 G r25
 G r26
 G r27
 G r28
 G r29
 G r30
 G r31
 G r32
 G r33
 G r34
 G r35
 G r36
 G r37
 G r38
 G r39
COLUMNS
 x0 obj -3
 x0 r0 -4
 x0 r1 -4
 x0 r2 -4
 x0 r3 -4
 x0 r4 -4
 x1 obj -3
 x1 r5 -4
 x1 r6 -4
 x1 r7 -4
 x1 r8 -4
 x1 r9 -4
 x2 obj -3
 x2 r10 -4
 x2 r11 -4
 x2 r12 -4
 x2 r13 -4
 x2 r14 -4
 x3 obj -3
 x3 r15 -4
 x3 r16 -4
 x3 r17 -4
 x3 r18 -4
 x3 r19 -4
 x4 obj -3
 x4 r15 -4
 x4 r20 -4
 x4 r21 -4
 x4 r22 -4
 x4 r23 -4
 x5 obj -3
 x5 r10 -4
 x5 r24 -4
 x5 r25 -4
 x5 r26 -4
 x5 r27 -4
 x6 obj -3
 x6 r5 -4
 x6 r28 -4
 x6 r29 -4
 x6 r30 -4
 x6 r31 -4
 x7 obj -3
 x7 r0 -4
 x7 r32 -4
 x7 r33 -4
 x7 r34 -4
 x7 r35 -4
 x8 obj -3
 x8 r16 -4
 x8 r24 -4
 x8 r28 -4
 x8 r32 -4
 x8 r36 -4
 x9 obj -3
 x9 r11 -4
 x9 r20 -4
 x9 r29 -4
 x9 r33 -4
 x9 r37 -4
 x10 obj -3
 x10 r6 -4
 x10 r21 -4
 x10 r25 -4
 x10 r34 -4
 x10 r38 -4
 x11 obj -3
 x11 r1 -4
 x11 r22 -4
 x11 r26 -4
 x11 r30 -4
 x11 r39 -4
 x12 obj -3
 x12 r7 -4
 x12 r12 -4
 x12 r17 -4
 x12 r35 -4
 x12 r39 -4
 x13 obj -3
 x13 r2 -4
 x13 r13 -4
 x13 r18 -4
 x13 r31 -4
 x13 r38 -4
 x14 obj -3
 x14 r3 -4
 x14 r8 -4
 x14 r19 -4
 x14 r27 -4
 x14 r37 -4
 x15 obj -3
 x15 r4 -4
 x15 r9 -4
 x15 r14 -4
 x15 r23 -4
 x15 r36 -4
RHS
 rhs obj 1.625
 rhs r0 -4
 rhs r1 -4
 rhs r2 -4
 rhs r3 -4
 rhs r4 -4
 rhs r5 -4
 rhs r6 -4
 rhs r7 -4
 rhs r8 -4
 rhs r9 -4
 rhs r10 -4
 rhs r11 -4
 rhs r12 -4
 rhs r13 -4
 rhs r14 -4
 rhs r15 -4
 rhs r16 -4
 rhs r17 -4
 rhs r18 -4
 rhs r19 -4
 rhs r20 -4
 rhs r21 -4
 rhs r22 -4
 rhs r23 -4
 rhs r24 -4
 rhs r25 -4
 rhs r26 -4
 rhs r27 -4
 rhs r28 -4
 rhs r29 -4
 rhs r30 -4
 rhs r31 -4
 rhs r32 -4
 rhs r33 -4
 rhs r34 -4
 rhs r35 -4
 rhs r36 -4
 rhs r37 -4
 rhs r38 -4
 rhs r39 -4
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
