NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
 L r40
 L r41
 L r42
 L r43
 L r44
 L r45
 L r46
 L r47
 L r48
 L r49
 L r50
 L r51
 L r52
 L r53
 L r54
 L r55
 L r56
 L r57
 L r58
 L r59
 L r60
 L r61
 L r62
 L r63
 L r64
 L r65
 L r66
 L r67
 L r68
 L r69
 L r70
 L r71
 L r72
 L r73
 L r74
 L r75
 L r76
 L r77
 L r78
 L r79
COLUMNS
 x0 obj -4
 x0 r0 2
 x0 r1 2
 x0 r2 2
 x0 r3 2
 x0 r4 2
 x0 r5 2
 x0 r6 2
 x0 r7 2
 x0 r8 2
 x0 r9 2
 x1 obj -4
 x1 r0 2
 x1 r10 2
 x1 r11 2
 x1 r12 2
 x1 r13 2
 x1 r14 2
 x1 r15 2
 x1 r16 2
 x1 r17 2
 x1 r18 2
 x2 obj -4
 x2 r1 2
 x2 r10 2
 x2 r19 2
 x2 r20 2
 x2 r21 2
 x2 r22 2
 x2 r23 2
 x2 r24 2
 x2 r25 2
 x2 r26 2
 x3 obj -4
 x3 r2 2
 x3 r11 2
 x3 r19 2
 x3 r27 2
 x3 r28 2
 x3 r29 2
 x3 r30 2
 x3 r31 2
 x3 r32 2
 x3 r33 2
 x4 obj -4
 x4 r3 2
 x4 r12 2
 x4 r20 2
 x4 r27 2
 x4 r34 2
 x4 r35 2
 x4 r36 2
 x4 r37 2
 x4 r38 2
 x4 r39 2
 x5 obj -4
 x5 r4 2
 x5 r13 2
 x5 r21 2
 x5 r40 2
 x5 r41 2
 x5 r42 2
 x5 r43 2
 x5 r44 2
 x5 r45 2
 x5 r46 2
 x6 obj -4
 x6 r5 2
 x6 r14 2
 x6 r28 2
 x6 r40 2
 x6 r47 2
 x6 r48 2
 x6 r49 2
 x6 r50 2
 x6 r51 2
 x6 r52 2
 x7 obj -4
 x7 r6 2
 x7 r22 2
 x7 r29 2
 x7 r41 2
 x7 r47 2
 x7 r53 2
 x7 r54 2
 x7 r55 2
 x7 r56 2
 x7 r57 2
 x8 obj -4
 x8 r7 2
 x8 r15 2
 x8 r34 2
 x8 r42 2
 x8 r48 2
 x8 r58 2
 x8 r59 2
 x8 r60 2
 x8 r61 2
 x8 r62 2
 x9 obj -4
 x9 r8 2
 x9 r23 2
 x9 r35 2
 x9 r43 2
 x9 r53 2
 x9 r58 2
 x9 r63 2
 x9 r64 2
 x9 r65 2
 x9 r66 2
 x10 obj -4
 x10 r9 2
 x10 r30 2
 x10 r36 2
 x10 r49 2
 x10 r54 2
 x10 r59 2
 x10 r63 2
 x10 r67 2
 x10 r68 2
 x10 r69 2
 x11 obj -4
 x11 r16 2
 x11 r24 2
 x11 r31 2
 x11 r44 2
 x11 r50 2
 x11 r55 2
 x11 r70 2
 x11 r71 2
 x11 r72 2
 x11 r73 2
 x12 obj -4
 x12 r17 2
 x12 r25 2
 x12 r37 2
 x12 r45 2
 x12 r60 2
 x12 r64 2
 x12 r70 2
 x12 r74 2
 x12 r75 2
 x12 r76 2
 x13 obj -4
 x13 r18 2
 x13 r32 2
 x13 r38 2
 x13 r51 2
 x13 r61 2
 x13 r67 2
 x13 r71 2
 x13 r74 2
 x13 r77 2
 x13 r78 2
 x14 obj -4
 x14 r26 2
 x14 r33 2
 x14 r39 2
 x14 r56 2
 x14 r65 2
 x14 r68 2
 x14 r72 2
 x14 r75 2
 x14 r77 2
 x14 r79 2
 x15 obj -4
 x15 r46 2
 x15 r52 2
 x15 r57 2
 x15 r62 2
 x15 r66 2
 x15 r69 2
 x15 r73 2
 x15 r76 2
 x15 r78 2
 x15 r79 2
RHS
 rhs obj -1.0
 rhs r0 2
 rhs r1 2
 rhs r2 2
 rhs r3 2
 rhs r4 2
 rhs r5 2
 rhs r6 2
 rhs r7 2
 rhs r8 2
 rhs r9 2
 rhs r10 2
 rhs r11 2
 rhs r12 2
 rhs r13 2
 rhs r14 2
 rhs r15 2
 rhs r16 2
 rhs r17 2
 rhs r18 2
 rhs r19 2
 rhs r20 2
 rhs r21 2
 rhs r22 2
 rhs r23 2
 rhs r24 2
 rhs r25 2
 rhs r26 2
 rhs r27 2
 rhs r28 2
 rhs r29 2
 rhs r30 2
 rhs r31 2
 rhs r32 2
 rhs r33 2
 rhs r34 2
 rhs r35 2
 rhs r36 2
 rhs r37 2
 rhs r38 2
 rhs r39 2
 rhs r40 2
 rhs r41 2
 rhs r42 2
 rhs r43 2
 rhs r44 2
 rhs r45 2
 rhs r46 2
 rhs r47 2
 rhs r48 2
 rhs r49 2
 rhs r50 2
 rhs r51 2
 rhs r52 2
 rhs r53 2
 rhs r54 2
 rhs r55 2
 rhs r56 2
 rhs r57 2
 rhs r58 2
 rhs r59 2
 rhs r60 2
 rhs r61 2
 rhs r62 2
 rhs r63 2
 rhs r64 2
 rhs r65 2
 rhs r66 2
 rhs r67 2
 rhs r68 2
 rhs r69 2
 rhs r70 2
 rhs r71 2
 rhs r72 2
 rhs r73 2
 rhs r74 2
 rhs r75 2
 rhs r76 2
 rhs r77 2
 rhs r78 2
 rhs r79 2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
