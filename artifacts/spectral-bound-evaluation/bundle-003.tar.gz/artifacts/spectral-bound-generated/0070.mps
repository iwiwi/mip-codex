NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
COLUMNS
 x0 obj -3
 x0 r0 1
 x1 obj -3
 x1 r1 1
 x2 obj -3
 x2 r2 1
 x3 obj -3
 x3 r3 1
 x4 obj -3
 x4 r4 1
 x5 obj -3
 x5 r5 1
 x6 obj -3
 x6 r6 1
 x7 obj -3
 x7 r7 1
 x8 obj -3
 x8 r7 1
 x9 obj -3
 x9 r6 1
 x10 obj -3
 x10 r5 1
 x11 obj -3
 x11 r4 1
 x12 obj -3
 x12 r3 1
 x13 obj -3
 x13 r2 1
 x14 obj -3
 x14 r1 1
 x15 obj -3
 x15 r0 1
RHS
 rhs obj -0.75
 rhs r0 1
 rhs r1 1
 rhs r2 1
 rhs r3 1
 rhs r4 1
 rhs r5 1
 rhs r6 1
 rhs r7 1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
