NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
 L r40
 L r41
 L r42
 L r43
 L r44
 L r45
 L r46
 L r47
 L r48
 L r49
 L r50
 L r51
 L r52
 L r53
 L r54
 L r55
 L r56
 L r57
 L r58
 L r59
 L r60
 L r61
 L r62
 L r63
 L r64
 L r65
 L r66
 L r67
 L r68
 L r69
 L r70
 L r71
 L r72
 L r73
 L r74
 L r75
 L r76
 L r77
 L r78
 L r79
 L r80
 L r81
 L r82
 L r83
 L r84
 L r85
 L r86
 L r87
 L r88
 L r89
 L r90
 L r91
 L r92
 L r93
 L r94
 L r95
 L r96
 L r97
 L r98
 L r99
 L r100
 L r101
 L r102
 L r103
 L r104
 L r105
 L r106
 L r107
 L r108
 L r109
 L r110
 L r111
 L r112
 L r113
 L r114
 L r115
 L r116
 L r117
 L r118
 L r119
COLUMNS
 x0 obj -4
 x0 r0 4
 x0 r1 4
 x0 r2 4
 x0 r3 4
 x0 r4 4
 x0 r5 4
 x0 r6 4
 x0 r7 4
 x0 r8 4
 x0 r9 4
 x0 r10 4
 x0 r11 4
 x0 r12 4
 x0 r13 4
 x0 r14 4
 x1 obj -4
 x1 r0 4
 x1 r15 4
 x1 r16 4
 x1 r17 4
 x1 r18 4
 x1 r19 4
 x1 r20 4
 x1 r21 4
 x1 r22 4
 x1 r23 4
 x1 r24 4
 x1 r25 4
 x1 r26 4
 x1 r27 4
 x1 r28 4
 x2 obj -4
 x2 r1 4
 x2 r15 4
 x2 r29 4
 x2 r30 4
 x2 r31 4
 x2 r32 4
 x2 r33 4
 x2 r34 4
 x2 r35 4
 x2 r36 4
 x2 r37 4
 x2 r38 4
 x2 r39 4
 x2 r40 4
 x2 r41 4
 x3 obj -4
 x3 r2 4
 x3 r16 4
 x3 r29 4
 x3 r42 4
 x3 r43 4
 x3 r44 4
 x3 r45 4
 x3 r46 4
 x3 r47 4
 x3 r48 4
 x3 r49 4
 x3 r50 4
 x3 r51 4
 x3 r52 4
 x3 r53 4
 x4 obj -4
 x4 r3 4
 x4 r17 4
 x4 r30 4
 x4 r42 4
 x4 r54 4
 x4 r55 4
 x4 r56 4
 x4 r57 4
 x4 r58 4
 x4 r59 4
 x4 r60 4
 x4 r61 4
 x4 r62 4
 x4 r63 4
 x4 r64 4
 x5 obj -4
 x5 r4 4
 x5 r18 4
 x5 r31 4
 x5 r43 4
 x5 r54 4
 x5 r65 4
 x5 r66 4
 x5 r67 4
 x5 r68 4
 x5 r69 4
 x5 r70 4
 x5 r71 4
 x5 r72 4
 x5 r73 4
 x5 r74 4
 x6 obj -4
 x6 r5 4
 x6 r19 4
 x6 r32 4
 x6 r44 4
 x6 r55 4
 x6 r65 4
 x6 r75 4
 x6 r76 4
 x6 r77 4
 x6 r78 4
 x6 r79 4
 x6 r80 4
 x6 r81 4
 x6 r82 4
 x6 r83 4
 x7 obj -4
 x7 r6 4
 x7 r20 4
 x7 r33 4
 x7 r45 4
 x7 r56 4
 x7 r66 4
 x7 r75 4
 x7 r84 4
 x7 r85 4
 x7 r86 4
 x7 r87 4
 x7 r88 4
 x7 r89 4
 x7 r90 4
 x7 r91 4
 x8 obj -4
 x8 r7 4
 x8 r21 4
 x8 r34 4
 x8 r46 4
 x8 r57 4
 x8 r67 4
 x8 r76 4
 x8 r84 4
 x8 r92 4
 x8 r93 4
 x8 r94 4
 x8 r95 4
 x8 r96 4
 x8 r97 4
 x8 r98 4
 x9 obj -4
 x9 r8 4
 x9 r22 4
 x9 r35 4
 x9 r47 4
 x9 r58 4
 x9 r68 4
 x9 r77 4
 x9 r85 4
 x9 r92 4
 x9 r99 4
 x9 r100 4
 x9 r101 4
 x9 r102 4
 x9 r103 4
 x9 r104 4
 x10 obj -4
 x10 r9 4
 x10 r23 4
 x10 r36 4
 x10 r48 4
 x10 r59 4
 x10 r69 4
 x10 r78 4
 x10 r86 4
 x10 r93 4
 x10 r99 4
 x10 r105 4
 x10 r106 4
 x10 r107 4
 x10 r108 4
 x10 r109 4
 x11 obj -4
 x11 r10 4
 x11 r24 4
 x11 r37 4
 x11 r49 4
 x11 r60 4
 x11 r70 4
 x11 r79 4
 x11 r87 4
 x11 r94 4
 x11 r100 4
 x11 r105 4
 x11 r110 4
 x11 r111 4
 x11 r112 4
 x11 r113 4
 x12 obj -4
 x12 r11 4
 x12 r25 4
 x12 r38 4
 x12 r50 4
 x12 r61 4
 x12 r71 4
 x12 r80 4
 x12 r88 4
 x12 r95 4
 x12 r101 4
 x12 r106 4
 x12 r110 4
 x12 r114 4
 x12 r115 4
 x12 r116 4
 x13 obj -4
 x13 r12 4
 x13 r26 4
 x13 r39 4
 x13 r51 4
 x13 r62 4
 x13 r72 4
 x13 r81 4
 x13 r89 4
 x13 r96 4
 x13 r102 4
 x13 r107 4
 x13 r111 4
 x13 r114 4
 x13 r117 4
 x13 r118 4
 x14 obj -4
 x14 r13 4
 x14 r27 4
 x14 r40 4
 x14 r52 4
 x14 r63 4
 x14 r73 4
 x14 r82 4
 x14 r90 4
 x14 r97 4
 x14 r103 4
 x14 r108 4
 x14 r112 4
 x14 r115 4
 x14 r117 4
 x14 r119 4
 x15 obj -4
 x15 r14 4
 x15 r28 4
 x15 r41 4
 x15 r53 4
 x15 r64 4
 x15 r74 4
 x15 r83 4
 x15 r91 4
 x15 r98 4
 x15 r104 4
 x15 r109 4
 x15 r113 4
 x15 r116 4
 x15 r118 4
 x15 r119 4
RHS
 rhs obj -2.0
 rhs r0 4
 rhs r1 4
 rhs r2 4
 rhs r3 4
 rhs r4 4
 rhs r5 4
 rhs r6 4
 rhs r7 4
 rhs r8 4
 rhs r9 4
 rhs r10 4
 rhs r11 4
 rhs r12 4
 rhs r13 4
 rhs r14 4
 rhs r15 4
 rhs r16 4
 rhs r17 4
 rhs r18 4
 rhs r19 4
 rhs r20 4
 rhs r21 4
 rhs r22 4
 rhs r23 4
 rhs r24 4
 rhs r25 4
 rhs r26 4
 rhs r27 4
 rhs r28 4
 rhs r29 4
 rhs r30 4
 rhs r31 4
 rhs r32 4
 rhs r33 4
 rhs r34 4
 rhs r35 4
 rhs r36 4
 rhs r37 4
 rhs r38 4
 rhs r39 4
 rhs r40 4
 rhs r41 4
 rhs r42 4
 rhs r43 4
 rhs r44 4
 rhs r45 4
 rhs r46 4
 rhs r47 4
 rhs r48 4
 rhs r49 4
 rhs r50 4
 rhs r51 4
 rhs r52 4
 rhs r53 4
 rhs r54 4
 rhs r55 4
 rhs r56 4
 rhs r57 4
 rhs r58 4
 rhs r59 4
 rhs r60 4
 rhs r61 4
 rhs r62 4
 rhs r63 4
 rhs r64 4
 rhs r65 4
 rhs r66 4
 rhs r67 4
 rhs r68 4
 rhs r69 4
 rhs r70 4
 rhs r71 4
 rhs r72 4
 rhs r73 4
 rhs r74 4
 rhs r75 4
 rhs r76 4
 rhs r77 4
 rhs r78 4
 rhs r79 4
 rhs r80 4
 rhs r81 4
 rhs r82 4
 rhs r83 4
 rhs r84 4
 rhs r85 4
 rhs r86 4
 rhs r87 4
 rhs r88 4
 rhs r89 4
 rhs r90 4
 rhs r91 4
 rhs r92 4
 rhs r93 4
 rhs r94 4
 rhs r95 4
 rhs r96 4
 rhs r97 4
 rhs r98 4
 rhs r99 4
 rhs r100 4
 rhs r101 4
 rhs r102 4
 rhs r103 4
 rhs r104 4
 rhs r105 4
 rhs r106 4
 rhs r107 4
 rhs r108 4
 rhs r109 4
 rhs r110 4
 rhs r111 4
 rhs r112 4
 rhs r113 4
 rhs r114 4
 rhs r115 4
 rhs r116 4
 rhs r117 4
 rhs r118 4
 rhs r119 4
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
