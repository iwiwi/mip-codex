NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
COLUMNS
 x0 obj 4
 x0 r0 3
 x0 r1 3
 x0 r2 3
 x0 r3 3
 x0 r4 3
 x0 r5 3
 x1 obj 4
 x1 r0 3
 x1 r6 3
 x1 r7 3
 x1 r8 3
 x1 r9 3
 x1 r10 3
 x2 obj 4
 x2 r1 3
 x2 r6 3
 x2 r11 3
 x2 r12 3
 x2 r13 3
 x2 r14 3
 x3 obj 4
 x3 r2 3
 x3 r7 3
 x3 r11 3
 x3 r15 3
 x3 r16 3
 x3 r17 3
 x4 obj 4
 x4 r3 3
 x4 r8 3
 x4 r12 3
 x4 r18 3
 x4 r19 3
 x4 r20 3
 x5 obj 4
 x5 r4 3
 x5 r9 3
 x5 r15 3
 x5 r18 3
 x5 r21 3
 x5 r22 3
 x6 obj 4
 x6 r5 3
 x6 r13 3
 x6 r16 3
 x6 r19 3
 x6 r21 3
 x6 r23 3
 x7 obj 4
 x7 r10 3
 x7 r14 3
 x7 r17 3
 x7 r20 3
 x7 r22 3
 x7 r23 3
RHS
 rhs obj -1.625
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
 rhs r6 3
 rhs r7 3
 rhs r8 3
 rhs r9 3
 rhs r10 3
 rhs r11 3
 rhs r12 3
 rhs r13 3
 rhs r14 3
 rhs r15 3
 rhs r16 3
 rhs r17 3
 rhs r18 3
 rhs r19 3
 rhs r20 3
 rhs r21 3
 rhs r22 3
 rhs r23 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
ENDATA
