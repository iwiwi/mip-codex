NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj -2
 x0 r0 4
 x0 r1 4
 x1 obj -2
 x1 r0 4
 x1 r2 4
 x2 obj -2
 x2 r1 4
 x2 r3 4
 x3 obj -2
 x3 r2 4
 x3 r3 4
RHS
 rhs obj -1.0
 rhs r0 4
 rhs r1 4
 rhs r2 4
 rhs r3 4
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
ENDATA
