NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
COLUMNS
 x0 obj 1
 x0 r0 2
 x0 r1 2
 x0 r2 2
 x0 r3 2
 x1 obj 1
 x1 r4 2
 x1 r5 2
 x1 r6 2
 x1 r7 2
 x2 obj 1
 x2 r8 2
 x2 r9 2
 x2 r10 2
 x2 r11 2
 x3 obj 1
 x3 r12 2
 x3 r13 2
 x3 r14 2
 x3 r15 2
 x4 obj 1
 x4 r16 2
 x4 r17 2
 x4 r18 2
 x4 r19 2
 x5 obj 1
 x5 r12 2
 x5 r16 2
 x5 r20 2
 x5 r21 2
 x6 obj 1
 x6 r8 2
 x6 r17 2
 x6 r22 2
 x6 r23 2
 x7 obj 1
 x7 r9 2
 x7 r13 2
 x7 r24 2
 x7 r25 2
 x8 obj 1
 x8 r4 2
 x8 r18 2
 x8 r26 2
 x8 r27 2
 x9 obj 1
 x9 r5 2
 x9 r14 2
 x9 r28 2
 x9 r29 2
 x10 obj 1
 x10 r6 2
 x10 r10 2
 x10 r30 2
 x10 r31 2
 x11 obj 1
 x11 r0 2
 x11 r24 2
 x11 r28 2
 x11 r30 2
 x12 obj 1
 x12 r1 2
 x12 r22 2
 x12 r26 2
 x12 r31 2
 x13 obj 1
 x13 r2 2
 x13 r20 2
 x13 r27 2
 x13 r29 2
 x14 obj 1
 x14 r3 2
 x14 r21 2
 x14 r23 2
 x14 r25 2
 x15 obj 1
 x15 r7 2
 x15 r11 2
 x15 r15 2
 x15 r19 2
RHS
 rhs obj -0.875
 rhs r0 2
 rhs r1 2
 rhs r2 2
 rhs r3 2
 rhs r4 2
 rhs r5 2
 rhs r6 2
 rhs r7 2
 rhs r8 2
 rhs r9 2
 rhs r10 2
 rhs r11 2
 rhs r12 2
 rhs r13 2
 rhs r14 2
 rhs r15 2
 rhs r16 2
 rhs r17 2
 rhs r18 2
 rhs r19 2
 rhs r20 2
 rhs r21 2
 rhs r22 2
 rhs r23 2
 rhs r24 2
 rhs r25 2
 rhs r26 2
 rhs r27 2
 rhs r28 2
 rhs r29 2
 rhs r30 2
 rhs r31 2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
