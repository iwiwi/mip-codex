NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
 G r12
 G r13
 G r14
 G r15
 G r16
 G r17
 G r18
 G r19
 G r20
 G r21
 G r22
 G r23
 G r24
 G r25
 G r26
 G r27
 G r28
 G r29
 G r30
 G r31
 G r32
 G r33
 G r34
 G r35
 G r36
 G r37
 G r38
 G r39
 G r40
 G r41
 G r42
 G r43
 G r44
 G r45
 G r46
 G r47
 G r48
 G r49
 G r50
 G r51
 G r52
 G r53
 G r54
 G r55
 G r56
 G r57
 G r58
 G r59
 G r60
 G r61
 G r62
 G r63
 G r64
 G r65
 G r66
 G r67
 G r68
 G r69
 G r70
 G r71
 G r72
 G r73
 G r74
 G r75
 G r76
 G r77
 G r78
 G r79
 G r80
 G r81
 G r82
 G r83
 G r84
 G r85
 G r86
 G r87
 G r88
 G r89
 G r90
 G r91
 G r92
 G r93
 G r94
 G r95
 G r96
 G r97
 G r98
 G r99
 G r100
 G r101
 G r102
 G r103
 G r104
 G r105
 G r106
 G r107
 G r108
 G r109
 G r110
 G r111
 G r112
 G r113
 G r114
 G r115
 G r116
 G r117
 G r118
 G r119
COLUMNS
 x0 obj 2
 x0 r0 -3
 x0 r1 -3
 x0 r2 -3
 x0 r3 -3
 x0 r4 -3
 x0 r5 -3
 x0 r6 -3
 x0 r7 -3
 x0 r8 -3
 x0 r9 -3
 x0 r10 -3
 x0 r11 -3
 x0 r12 -3
 x0 r13 -3
 x0 r14 -3
 x1 obj 2
 x1 r0 -3
 x1 r15 -3
 x1 r16 -3
 x1 r17 -3
 x1 r18 -3
 x1 r19 -3
 x1 r20 -3
 x1 r21 -3
 x1 r22 -3
 x1 r23 -3
 x1 r24 -3
 x1 r25 -3
 x1 r26 -3
 x1 r27 -3
 x1 r28 -3
 x2 obj 2
 x2 r1 -3
 x2 r15 -3
 x2 r29 -3
 x2 r30 -3
 x2 r31 -3
 x2 r32 -3
 x2 r33 -3
 x2 r34 -3
 x2 r35 -3
 x2 r36 -3
 x2 r37 -3
 x2 r38 -3
 x2 r39 -3
 x2 r40 -3
 x2 r41 -3
 x3 obj 2
 x3 r2 -3
 x3 r16 -3
 x3 r29 -3
 x3 r42 -3
 x3 r43 -3
 x3 r44 -3
 x3 r45 -3
 x3 r46 -3
 x3 r47 -3
 x3 r48 -3
 x3 r49 -3
 x3 r50 -3
 x3 r51 -3
 x3 r52 -3
 x3 r53 -3
 x4 obj 2
 x4 r3 -3
 x4 r17 -3
 x4 r30 -3
 x4 r42 -3
 x4 r54 -3
 x4 r55 -3
 x4 r56 -3
 x4 r57 -3
 x4 r58 -3
 x4 r59 -3
 x4 r60 -3
 x4 r61 -3
 x4 r62 -3
 x4 r63 -3
 x4 r64 -3
 x5 obj 2
 x5 r4 -3
 x5 r18 -3
 x5 r31 -3
 x5 r43 -3
 x5 r54 -3
 x5 r65 -3
 x5 r66 -3
 x5 r67 -3
 x5 r68 -3
 x5 r69 -3
 x5 r70 -3
 x5 r71 -3
 x5 r72 -3
 x5 r73 -3
 x5 r74 -3
 x6 obj 2
 x6 r5 -3
 x6 r19 -3
 x6 r32 -3
 x6 r44 -3
 x6 r55 -3
 x6 r65 -3
 x6 r75 -3
 x6 r76 -3
 x6 r77 -3
 x6 r78 -3
 x6 r79 -3
 x6 r80 -3
 x6 r81 -3
 x6 r82 -3
 x6 r83 -3
 x7 obj 2
 x7 r6 -3
 x7 r20 -3
 x7 r33 -3
 x7 r45 -3
 x7 r56 -3
 x7 r66 -3
 x7 r75 -3
 x7 r84 -3
 x7 r85 -3
 x7 r86 -3
 x7 r87 -3
 x7 r88 -3
 x7 r89 -3
 x7 r90 -3
 x7 r91 -3
 x8 obj 2
 x8 r7 -3
 x8 r21 -3
 x8 r34 -3
 x8 r46 -3
 x8 r57 -3
 x8 r67 -3
 x8 r76 -3
 x8 r84 -3
 x8 r92 -3
 x8 r93 -3
 x8 r94 -3
 x8 r95 -3
 x8 r96 -3
 x8 r97 -3
 x8 r98 -3
 x9 obj 2
 x9 r8 -3
 x9 r22 -3
 x9 r35 -3
 x9 r47 -3
 x9 r58 -3
 x9 r68 -3
 x9 r77 -3
 x9 r85 -3
 x9 r92 -3
 x9 r99 -3
 x9 r100 -3
 x9 r101 -3
 x9 r102 -3
 x9 r103 -3
 x9 r104 -3
 x10 obj 2
 x10 r9 -3
 x10 r23 -3
 x10 r36 -3
 x10 r48 -3
 x10 r59 -3
 x10 r69 -3
 x10 r78 -3
 x10 r86 -3
 x10 r93 -3
 x10 r99 -3
 x10 r105 -3
 x10 r106 -3
 x10 r107 -3
 x10 r108 -3
 x10 r109 -3
 x11 obj 2
 x11 r10 -3
 x11 r24 -3
 x11 r37 -3
 x11 r49 -3
 x11 r60 -3
 x11 r70 -3
 x11 r79 -3
 x11 r87 -3
 x11 r94 -3
 x11 r100 -3
 x11 r105 -3
 x11 r110 -3
 x11 r111 -3
 x11 r112 -3
 x11 r113 -3
 x12 obj 2
 x12 r11 -3
 x12 r25 -3
 x12 r38 -3
 x12 r50 -3
 x12 r61 -3
 x12 r71 -3
 x12 r80 -3
 x12 r88 -3
 x12 r95 -3
 x12 r101 -3
 x12 r106 -3
 x12 r110 -3
 x12 r114 -3
 x12 r115 -3
 x12 r116 -3
 x13 obj 2
 x13 r12 -3
 x13 r26 -3
 x13 r39 -3
 x13 r51 -3
 x13 r62 -3
 x13 r72 -3
 x13 r81 -3
 x13 r89 -3
 x13 r96 -3
 x13 r102 -3
 x13 r107 -3
 x13 r111 -3
 x13 r114 -3
 x13 r117 -3
 x13 r118 -3
 x14 obj 2
 x14 r13 -3
 x14 r27 -3
 x14 r40 -3
 x14 r52 -3
 x14 r63 -3
 x14 r73 -3
 x14 r82 -3
 x14 r90 -3
 x14 r97 -3
 x14 r103 -3
 x14 r108 -3
 x14 r112 -3
 x14 r115 -3
 x14 r117 -3
 x14 r119 -3
 x15 obj 2
 x15 r14 -3
 x15 r28 -3
 x15 r41 -3
 x15 r53 -3
 x15 r64 -3
 x15 r74 -3
 x15 r83 -3
 x15 r91 -3
 x15 r98 -3
 x15 r104 -3
 x15 r109 -3
 x15 r113 -3
 x15 r116 -3
 x15 r118 -3
 x15 r119 -3
RHS
 rhs obj -1.375
 rhs r0 -3
 rhs r1 -3
 rhs r2 -3
 rhs r3 -3
 rhs r4 -3
 rhs r5 -3
 rhs r6 -3
 rhs r7 -3
 rhs r8 -3
 rhs r9 -3
 rhs r10 -3
 rhs r11 -3
 rhs r12 -3
 rhs r13 -3
 rhs r14 -3
 rhs r15 -3
 rhs r16 -3
 rhs r17 -3
 rhs r18 -3
 rhs r19 -3
 rhs r20 -3
 rhs r21 -3
 rhs r22 -3
 rhs r23 -3
 rhs r24 -3
 rhs r25 -3
 rhs r26 -3
 rhs r27 -3
 rhs r28 -3
 rhs r29 -3
 rhs r30 -3
 rhs r31 -3
 rhs r32 -3
 rhs r33 -3
 rhs r34 -3
 rhs r35 -3
 rhs r36 -3
 rhs r37 -3
 rhs r38 -3
 rhs r39 -3
 rhs r40 -3
 rhs r41 -3
 rhs r42 -3
 rhs r43 -3
 rhs r44 -3
 rhs r45 -3
 rhs r46 -3
 rhs r47 -3
 rhs r48 -3
 rhs r49 -3
 rhs r50 -3
 rhs r51 -3
 rhs r52 -3
 rhs r53 -3
 rhs r54 -3
 rhs r55 -3
 rhs r56 -3
 rhs r57 -3
 rhs r58 -3
 rhs r59 -3
 rhs r60 -3
 rhs r61 -3
 rhs r62 -3
 rhs r63 -3
 rhs r64 -3
 rhs r65 -3
 rhs r66 -3
 rhs r67 -3
 rhs r68 -3
 rhs r69 -3
 rhs r70 -3
 rhs r71 -3
 rhs r72 -3
 rhs r73 -3
 rhs r74 -3
 rhs r75 -3
 rhs r76 -3
 rhs r77 -3
 rhs r78 -3
 rhs r79 -3
 rhs r80 -3
 rhs r81 -3
 rhs r82 -3
 rhs r83 -3
 rhs r84 -3
 rhs r85 -3
 rhs r86 -3
 rhs r87 -3
 rhs r88 -3
 rhs r89 -3
 rhs r90 -3
 rhs r91 -3
 rhs r92 -3
 rhs r93 -3
 rhs r94 -3
 rhs r95 -3
 rhs r96 -3
 rhs r97 -3
 rhs r98 -3
 rhs r99 -3
 rhs r100 -3
 rhs r101 -3
 rhs r102 -3
 rhs r103 -3
 rhs r104 -3
 rhs r105 -3
 rhs r106 -3
 rhs r107 -3
 rhs r108 -3
 rhs r109 -3
 rhs r110 -3
 rhs r111 -3
 rhs r112 -3
 rhs r113 -3
 rhs r114 -3
 rhs r115 -3
 rhs r116 -3
 rhs r117 -3
 rhs r118 -3
 rhs r119 -3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
