NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
 L r40
 L r41
 L r42
 L r43
 L r44
 L r45
 L r46
 L r47
 L r48
 L r49
 L r50
 L r51
 L r52
 L r53
 L r54
 L r55
 L r56
 L r57
 L r58
 L r59
 L r60
 L r61
 L r62
 L r63
 L r64
 L r65
 L r66
 L r67
 L r68
 L r69
 L r70
 L r71
 L r72
 L r73
 L r74
 L r75
 L r76
 L r77
 L r78
 L r79
COLUMNS
 x0 obj -4
 x0 r0 1
 x0 r1 1
 x0 r2 1
 x0 r3 1
 x0 r4 1
 x0 r5 1
 x0 r6 1
 x0 r7 1
 x0 r8 1
 x0 r9 1
 x1 obj -4
 x1 r10 1
 x1 r11 1
 x1 r12 1
 x1 r13 1
 x1 r14 1
 x1 r15 1
 x1 r16 1
 x1 r17 1
 x1 r18 1
 x1 r19 1
 x2 obj -4
 x2 r10 1
 x2 r20 1
 x2 r21 1
 x2 r22 1
 x2 r23 1
 x2 r24 1
 x2 r25 1
 x2 r26 1
 x2 r27 1
 x2 r28 1
 x3 obj -4
 x3 r11 1
 x3 r20 1
 x3 r29 1
 x3 r30 1
 x3 r31 1
 x3 r32 1
 x3 r33 1
 x3 r34 1
 x3 r35 1
 x3 r36 1
 x4 obj -4
 x4 r12 1
 x4 r21 1
 x4 r29 1
 x4 r37 1
 x4 r38 1
 x4 r39 1
 x4 r40 1
 x4 r41 1
 x4 r42 1
 x4 r43 1
 x5 obj -4
 x5 r0 1
 x5 r30 1
 x5 r37 1
 x5 r44 1
 x5 r45 1
 x5 r46 1
 x5 r47 1
 x5 r48 1
 x5 r49 1
 x5 r50 1
 x6 obj -4
 x6 r1 1
 x6 r22 1
 x6 r38 1
 x6 r44 1
 x6 r51 1
 x6 r52 1
 x6 r53 1
 x6 r54 1
 x6 r55 1
 x6 r56 1
 x7 obj -4
 x7 r2 1
 x7 r23 1
 x7 r31 1
 x7 r45 1
 x7 r51 1
 x7 r57 1
 x7 r58 1
 x7 r59 1
 x7 r60 1
 x7 r61 1
 x8 obj -4
 x8 r3 1
 x8 r13 1
 x8 r39 1
 x8 r46 1
 x8 r52 1
 x8 r62 1
 x8 r63 1
 x8 r64 1
 x8 r65 1
 x8 r66 1
 x9 obj -4
 x9 r4 1
 x9 r14 1
 x9 r32 1
 x9 r47 1
 x9 r57 1
 x9 r62 1
 x9 r67 1
 x9 r68 1
 x9 r69 1
 x9 r70 1
 x10 obj -4
 x10 r5 1
 x10 r15 1
 x10 r24 1
 x10 r53 1
 x10 r58 1
 x10 r63 1
 x10 r67 1
 x10 r71 1
 x10 r72 1
 x10 r73 1
 x11 obj -4
 x11 r6 1
 x11 r16 1
 x11 r25 1
 x11 r33 1
 x11 r59 1
 x11 r68 1
 x11 r71 1
 x11 r74 1
 x11 r75 1
 x11 r76 1
 x12 obj -4
 x12 r7 1
 x12 r17 1
 x12 r26 1
 x12 r40 1
 x12 r54 1
 x12 r64 1
 x12 r72 1
 x12 r74 1
 x12 r77 1
 x12 r78 1
 x13 obj -4
 x13 r8 1
 x13 r18 1
 x13 r34 1
 x13 r41 1
 x13 r48 1
 x13 r65 1
 x13 r69 1
 x13 r75 1
 x13 r77 1
 x13 r79 1
 x14 obj -4
 x14 r9 1
 x14 r27 1
 x14 r35 1
 x14 r42 1
 x14 r49 1
 x14 r55 1
 x14 r60 1
 x14 r76 1
 x14 r78 1
 x14 r79 1
 x15 obj -4
 x15 r19 1
 x15 r28 1
 x15 r36 1
 x15 r43 1
 x15 r50 1
 x15 r56 1
 x15 r61 1
 x15 r66 1
 x15 r70 1
 x15 r73 1
RHS
 rhs obj -0.625
 rhs r0 1
 rhs r1 1
 rhs r2 1
 rhs r3 1
 rhs r4 1
 rhs r5 1
 rhs r6 1
 rhs r7 1
 rhs r8 1
 rhs r9 1
 rhs r10 1
 rhs r11 1
 rhs r12 1
 rhs r13 1
 rhs r14 1
 rhs r15 1
 rhs r16 1
 rhs r17 1
 rhs r18 1
 rhs r19 1
 rhs r20 1
 rhs r21 1
 rhs r22 1
 rhs r23 1
 rhs r24 1
 rhs r25 1
 rhs r26 1
 rhs r27 1
 rhs r28 1
 rhs r29 1
 rhs r30 1
 rhs r31 1
 rhs r32 1
 rhs r33 1
 rhs r34 1
 rhs r35 1
 rhs r36 1
 rhs r37 1
 rhs r38 1
 rhs r39 1
 rhs r40 1
 rhs r41 1
 rhs r42 1
 rhs r43 1
 rhs r44 1
 rhs r45 1
 rhs r46 1
 rhs r47 1
 rhs r48 1
 rhs r49 1
 rhs r50 1
 rhs r51 1
 rhs r52 1
 rhs r53 1
 rhs r54 1
 rhs r55 1
 rhs r56 1
 rhs r57 1
 rhs r58 1
 rhs r59 1
 rhs r60 1
 rhs r61 1
 rhs r62 1
 rhs r63 1
 rhs r64 1
 rhs r65 1
 rhs r66 1
 rhs r67 1
 rhs r68 1
 rhs r69 1
 rhs r70 1
 rhs r71 1
 rhs r72 1
 rhs r73 1
 rhs r74 1
 rhs r75 1
 rhs r76 1
 rhs r77 1
 rhs r78 1
 rhs r79 1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
