NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
 G r12
 G r13
 G r14
 G r15
 G r16
 G r17
 G r18
 G r19
 G r20
 G r21
 G r22
 G r23
 G r24
 G r25
 G r26
 G r27
 G r28
 G r29
 G r30
 G r31
COLUMNS
 x0 obj -3
 x0 r0 -2
 x0 r1 -2
 x0 r2 -2
 x0 r3 -2
 x1 obj -3
 x1 r4 -2
 x1 r5 -2
 x1 r6 -2
 x1 r7 -2
 x2 obj -3
 x2 r8 -2
 x2 r9 -2
 x2 r10 -2
 x2 r11 -2
 x3 obj -3
 x3 r12 -2
 x3 r13 -2
 x3 r14 -2
 x3 r15 -2
 x4 obj -3
 x4 r12 -2
 x4 r16 -2
 x4 r17 -2
 x4 r18 -2
 x5 obj -3
 x5 r8 -2
 x5 r19 -2
 x5 r20 -2
 x5 r21 -2
 x6 obj -3
 x6 r4 -2
 x6 r22 -2
 x6 r23 -2
 x6 r24 -2
 x7 obj -3
 x7 r0 -2
 x7 r25 -2
 x7 r26 -2
 x7 r27 -2
 x8 obj -3
 x8 r13 -2
 x8 r19 -2
 x8 r22 -2
 x8 r28 -2
 x9 obj -3
 x9 r9 -2
 x9 r16 -2
 x9 r25 -2
 x9 r29 -2
 x10 obj -3
 x10 r5 -2
 x10 r17 -2
 x10 r26 -2
 x10 r30 -2
 x11 obj -3
 x11 r1 -2
 x11 r20 -2
 x11 r23 -2
 x11 r31 -2
 x12 obj -3
 x12 r6 -2
 x12 r10 -2
 x12 r27 -2
 x12 r31 -2
 x13 obj -3
 x13 r2 -2
 x13 r14 -2
 x13 r24 -2
 x13 r30 -2
 x14 obj -3
 x14 r3 -2
 x14 r15 -2
 x14 r21 -2
 x14 r29 -2
 x15 obj -3
 x15 r7 -2
 x15 r11 -2
 x15 r18 -2
 x15 r28 -2
RHS
 rhs obj -1.75
 rhs r0 -2
 rhs r1 -2
 rhs r2 -2
 rhs r3 -2
 rhs r4 -2
 rhs r5 -2
 rhs r6 -2
 rhs r7 -2
 rhs r8 -2
 rhs r9 -2
 rhs r10 -2
 rhs r11 -2
 rhs r12 -2
 rhs r13 -2
 rhs r14 -2
 rhs r15 -2
 rhs r16 -2
 rhs r17 -2
 rhs r18 -2
 rhs r19 -2
 rhs r20 -2
 rhs r21 -2
 rhs r22 -2
 rhs r23 -2
 rhs r24 -2
 rhs r25 -2
 rhs r26 -2
 rhs r27 -2
 rhs r28 -2
 rhs r29 -2
 rhs r30 -2
 rhs r31 -2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
