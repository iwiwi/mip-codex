NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
COLUMNS
 x0 obj 1
 x0 r0 3
 x0 r1 3
 x0 r2 3
 x1 obj 1
 x1 r0 3
 x1 r3 3
 x1 r4 3
 x2 obj 1
 x2 r1 3
 x2 r3 3
 x2 r5 3
 x3 obj 1
 x3 r2 3
 x3 r4 3
 x3 r5 3
RHS
 rhs obj -0.0
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
ENDATA
