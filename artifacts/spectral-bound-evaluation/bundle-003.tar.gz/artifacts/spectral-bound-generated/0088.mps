NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
 L r40
 L r41
 L r42
 L r43
 L r44
 L r45
 L r46
 L r47
 L r48
 L r49
 L r50
 L r51
 L r52
 L r53
 L r54
 L r55
 L r56
 L r57
 L r58
 L r59
 L r60
 L r61
 L r62
 L r63
 L r64
 L r65
 L r66
 L r67
 L r68
 L r69
 L r70
 L r71
 L r72
 L r73
 L r74
 L r75
 L r76
 L r77
 L r78
 L r79
 L r80
 L r81
 L r82
 L r83
 L r84
 L r85
 L r86
 L r87
 L r88
 L r89
 L r90
 L r91
 L r92
 L r93
 L r94
 L r95
 L r96
 L r97
 L r98
 L r99
 L r100
 L r101
 L r102
 L r103
 L r104
 L r105
 L r106
 L r107
 L r108
 L r109
 L r110
 L r111
COLUMNS
 x0 obj -3
 x0 r0 2
 x0 r1 2
 x0 r2 2
 x0 r3 2
 x0 r4 2
 x0 r5 2
 x0 r6 2
 x0 r7 2
 x0 r8 2
 x0 r9 2
 x0 r10 2
 x0 r11 2
 x0 r12 2
 x0 r13 2
 x1 obj -3
 x1 r0 2
 x1 r14 2
 x1 r15 2
 x1 r16 2
 x1 r17 2
 x1 r18 2
 x1 r19 2
 x1 r20 2
 x1 r21 2
 x1 r22 2
 x1 r23 2
 x1 r24 2
 x1 r25 2
 x1 r26 2
 x2 obj -3
 x2 r1 2
 x2 r14 2
 x2 r27 2
 x2 r28 2
 x2 r29 2
 x2 r30 2
 x2 r31 2
 x2 r32 2
 x2 r33 2
 x2 r34 2
 x2 r35 2
 x2 r36 2
 x2 r37 2
 x2 r38 2
 x3 obj -3
 x3 r2 2
 x3 r15 2
 x3 r27 2
 x3 r39 2
 x3 r40 2
 x3 r41 2
 x3 r42 2
 x3 r43 2
 x3 r44 2
 x3 r45 2
 x3 r46 2
 x3 r47 2
 x3 r48 2
 x3 r49 2
 x4 obj -3
 x4 r3 2
 x4 r16 2
 x4 r28 2
 x4 r39 2
 x4 r50 2
 x4 r51 2
 x4 r52 2
 x4 r53 2
 x4 r54 2
 x4 r55 2
 x4 r56 2
 x4 r57 2
 x4 r58 2
 x4 r59 2
 x5 obj -3
 x5 r4 2
 x5 r17 2
 x5 r29 2
 x5 r40 2
 x5 r50 2
 x5 r60 2
 x5 r61 2
 x5 r62 2
 x5 r63 2
 x5 r64 2
 x5 r65 2
 x5 r66 2
 x5 r67 2
 x5 r68 2
 x6 obj -3
 x6 r5 2
 x6 r18 2
 x6 r30 2
 x6 r41 2
 x6 r51 2
 x6 r60 2
 x6 r69 2
 x6 r70 2
 x6 r71 2
 x6 r72 2
 x6 r73 2
 x6 r74 2
 x6 r75 2
 x6 r76 2
 x7 obj -3
 x7 r6 2
 x7 r19 2
 x7 r31 2
 x7 r42 2
 x7 r52 2
 x7 r61 2
 x7 r69 2
 x7 r77 2
 x7 r78 2
 x7 r79 2
 x7 r80 2
 x7 r81 2
 x7 r82 2
 x7 r83 2
 x8 obj -3
 x8 r7 2
 x8 r20 2
 x8 r32 2
 x8 r43 2
 x8 r53 2
 x8 r62 2
 x8 r70 2
 x8 r84 2
 x8 r85 2
 x8 r86 2
 x8 r87 2
 x8 r88 2
 x8 r89 2
 x8 r90 2
 x9 obj -3
 x9 r8 2
 x9 r21 2
 x9 r33 2
 x9 r44 2
 x9 r54 2
 x9 r63 2
 x9 r77 2
 x9 r84 2
 x9 r91 2
 x9 r92 2
 x9 r93 2
 x9 r94 2
 x9 r95 2
 x9 r96 2
 x10 obj -3
 x10 r9 2
 x10 r22 2
 x10 r34 2
 x10 r45 2
 x10 r55 2
 x10 r71 2
 x10 r78 2
 x10 r85 2
 x10 r91 2
 x10 r97 2
 x10 r98 2
 x10 r99 2
 x10 r100 2
 x10 r101 2
 x11 obj -3
 x11 r10 2
 x11 r23 2
 x11 r35 2
 x11 r46 2
 x11 r64 2
 x11 r72 2
 x11 r79 2
 x11 r86 2
 x11 r92 2
 x11 r97 2
 x11 r102 2
 x11 r103 2
 x11 r104 2
 x11 r105 2
 x12 obj -3
 x12 r11 2
 x12 r24 2
 x12 r36 2
 x12 r56 2
 x12 r65 2
 x12 r73 2
 x12 r80 2
 x12 r87 2
 x12 r93 2
 x12 r98 2
 x12 r102 2
 x12 r106 2
 x12 r107 2
 x12 r108 2
 x13 obj -3
 x13 r12 2
 x13 r25 2
 x13 r47 2
 x13 r57 2
 x13 r66 2
 x13 r74 2
 x13 r81 2
 x13 r88 2
 x13 r94 2
 x13 r99 2
 x13 r103 2
 x13 r106 2
 x13 r109 2
 x13 r110 2
 x14 obj -3
 x14 r13 2
 x14 r37 2
 x14 r48 2
 x14 r58 2
 x14 r67 2
 x14 r75 2
 x14 r82 2
 x14 r89 2
 x14 r95 2
 x14 r100 2
 x14 r104 2
 x14 r107 2
 x14 r109 2
 x14 r111 2
 x15 obj -3
 x15 r26 2
 x15 r38 2
 x15 r49 2
 x15 r59 2
 x15 r68 2
 x15 r76 2
 x15 r83 2
 x15 r90 2
 x15 r96 2
 x15 r101 2
 x15 r105 2
 x15 r108 2
 x15 r110 2
 x15 r111 2
RHS
 rhs obj 1.375
 rhs r0 2
 rhs r1 2
 rhs r2 2
 rhs r3 2
 rhs r4 2
 rhs r5 2
 rhs r6 2
 rhs r7 2
 rhs r8 2
 rhs r9 2
 rhs r10 2
 rhs r11 2
 rhs r12 2
 rhs r13 2
 rhs r14 2
 rhs r15 2
 rhs r16 2
 rhs r17 2
 rhs r18 2
 rhs r19 2
 rhs r20 2
 rhs r21 2
 rhs r22 2
 rhs r23 2
 rhs r24 2
 rhs r25 2
 rhs r26 2
 rhs r27 2
 rhs r28 2
 rhs r29 2
 rhs r30 2
 rhs r31 2
 rhs r32 2
 rhs r33 2
 rhs r34 2
 rhs r35 2
 rhs r36 2
 rhs r37 2
 rhs r38 2
 rhs r39 2
 rhs r40 2
 rhs r41 2
 rhs r42 2
 rhs r43 2
 rhs r44 2
 rhs r45 2
 rhs r46 2
 rhs r47 2
 rhs r48 2
 rhs r49 2
 rhs r50 2
 rhs r51 2
 rhs r52 2
 rhs r53 2
 rhs r54 2
 rhs r55 2
 rhs r56 2
 rhs r57 2
 rhs r58 2
 rhs r59 2
 rhs r60 2
 rhs r61 2
 rhs r62 2
 rhs r63 2
 rhs r64 2
 rhs r65 2
 rhs r66 2
 rhs r67 2
 rhs r68 2
 rhs r69 2
 rhs r70 2
 rhs r71 2
 rhs r72 2
 rhs r73 2
 rhs r74 2
 rhs r75 2
 rhs r76 2
 rhs r77 2
 rhs r78 2
 rhs r79 2
 rhs r80 2
 rhs r81 2
 rhs r82 2
 rhs r83 2
 rhs r84 2
 rhs r85 2
 rhs r86 2
 rhs r87 2
 rhs r88 2
 rhs r89 2
 rhs r90 2
 rhs r91 2
 rhs r92 2
 rhs r93 2
 rhs r94 2
 rhs r95 2
 rhs r96 2
 rhs r97 2
 rhs r98 2
 rhs r99 2
 rhs r100 2
 rhs r101 2
 rhs r102 2
 rhs r103 2
 rhs r104 2
 rhs r105 2
 rhs r106 2
 rhs r107 2
 rhs r108 2
 rhs r109 2
 rhs r110 2
 rhs r111 2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
