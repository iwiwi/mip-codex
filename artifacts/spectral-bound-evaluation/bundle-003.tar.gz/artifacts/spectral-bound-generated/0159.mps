NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x0 obj 2
 x0 r0 -3
 x1 obj 2
 x1 r1 -3
 x2 obj 2
 x2 r1 -3
 x3 obj 2
 x3 r0 -3
RHS
 rhs obj 0.875
 rhs r0 -3
 rhs r1 -3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
ENDATA
