NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
COLUMNS
 x0 obj 1
 x0 r0 3
 x0 r1 3
 x0 r2 3
 x0 r3 3
 x0 r4 3
 x1 obj 1
 x1 r5 3
 x1 r6 3
 x1 r7 3
 x1 r8 3
 x1 r9 3
 x2 obj 1
 x2 r10 3
 x2 r11 3
 x2 r12 3
 x2 r13 3
 x2 r14 3
 x3 obj 1
 x3 r15 3
 x3 r16 3
 x3 r17 3
 x3 r18 3
 x3 r19 3
 x4 obj 1
 x4 r20 3
 x4 r21 3
 x4 r22 3
 x4 r23 3
 x4 r24 3
 x5 obj 1
 x5 r15 3
 x5 r20 3
 x5 r25 3
 x5 r26 3
 x5 r27 3
 x6 obj 1
 x6 r10 3
 x6 r21 3
 x6 r28 3
 x6 r29 3
 x6 r30 3
 x7 obj 1
 x7 r5 3
 x7 r22 3
 x7 r31 3
 x7 r32 3
 x7 r33 3
 x8 obj 1
 x8 r11 3
 x8 r16 3
 x8 r31 3
 x8 r34 3
 x8 r35 3
 x9 obj 1
 x9 r6 3
 x9 r17 3
 x9 r28 3
 x9 r36 3
 x9 r37 3
 x10 obj 1
 x10 r7 3
 x10 r12 3
 x10 r25 3
 x10 r38 3
 x10 r39 3
 x11 obj 1
 x11 r0 3
 x11 r23 3
 x11 r34 3
 x11 r36 3
 x11 r38 3
 x12 obj 1
 x12 r1 3
 x12 r18 3
 x12 r29 3
 x12 r32 3
 x12 r39 3
 x13 obj 1
 x13 r2 3
 x13 r13 3
 x13 r26 3
 x13 r33 3
 x13 r37 3
 x14 obj 1
 x14 r3 3
 x14 r8 3
 x14 r27 3
 x14 r30 3
 x14 r35 3
 x15 obj 1
 x15 r4 3
 x15 r9 3
 x15 r14 3
 x15 r19 3
 x15 r24 3
RHS
 rhs obj -1.375
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
 rhs r6 3
 rhs r7 3
 rhs r8 3
 rhs r9 3
 rhs r10 3
 rhs r11 3
 rhs r12 3
 rhs r13 3
 rhs r14 3
 rhs r15 3
 rhs r16 3
 rhs r17 3
 rhs r18 3
 rhs r19 3
 rhs r20 3
 rhs r21 3
 rhs r22 3
 rhs r23 3
 rhs r24 3
 rhs r25 3
 rhs r26 3
 rhs r27 3
 rhs r28 3
 rhs r29 3
 rhs r30 3
 rhs r31 3
 rhs r32 3
 rhs r33 3
 rhs r34 3
 rhs r35 3
 rhs r36 3
 rhs r37 3
 rhs r38 3
 rhs r39 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
