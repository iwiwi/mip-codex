NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
 L r40
 L r41
 L r42
 L r43
 L r44
 L r45
 L r46
 L r47
 L r48
 L r49
 L r50
 L r51
 L r52
 L r53
 L r54
 L r55
 L r56
 L r57
 L r58
 L r59
 L r60
 L r61
 L r62
 L r63
COLUMNS
 x0 obj 3
 x0 r0 3
 x0 r1 3
 x0 r2 3
 x0 r3 3
 x0 r4 3
 x0 r5 3
 x0 r6 3
 x0 r7 3
 x1 obj 3
 x1 r0 3
 x1 r8 3
 x1 r9 3
 x1 r10 3
 x1 r11 3
 x1 r12 3
 x1 r13 3
 x1 r14 3
 x2 obj 3
 x2 r1 3
 x2 r15 3
 x2 r16 3
 x2 r17 3
 x2 r18 3
 x2 r19 3
 x2 r20 3
 x2 r21 3
 x3 obj 3
 x3 r2 3
 x3 r22 3
 x3 r23 3
 x3 r24 3
 x3 r25 3
 x3 r26 3
 x3 r27 3
 x3 r28 3
 x4 obj 3
 x4 r3 3
 x4 r29 3
 x4 r30 3
 x4 r31 3
 x4 r32 3
 x4 r33 3
 x4 r34 3
 x4 r35 3
 x5 obj 3
 x5 r8 3
 x5 r15 3
 x5 r22 3
 x5 r29 3
 x5 r36 3
 x5 r37 3
 x5 r38 3
 x5 r39 3
 x6 obj 3
 x6 r9 3
 x6 r16 3
 x6 r23 3
 x6 r30 3
 x6 r40 3
 x6 r41 3
 x6 r42 3
 x6 r43 3
 x7 obj 3
 x7 r10 3
 x7 r17 3
 x7 r24 3
 x7 r31 3
 x7 r44 3
 x7 r45 3
 x7 r46 3
 x7 r47 3
 x8 obj 3
 x8 r11 3
 x8 r18 3
 x8 r25 3
 x8 r32 3
 x8 r48 3
 x8 r49 3
 x8 r50 3
 x8 r51 3
 x9 obj 3
 x9 r12 3
 x9 r19 3
 x9 r26 3
 x9 r33 3
 x9 r52 3
 x9 r53 3
 x9 r54 3
 x9 r55 3
 x10 obj 3
 x10 r13 3
 x10 r20 3
 x10 r27 3
 x10 r34 3
 x10 r56 3
 x10 r57 3
 x10 r58 3
 x10 r59 3
 x11 obj 3
 x11 r4 3
 x11 r36 3
 x11 r40 3
 x11 r44 3
 x11 r48 3
 x11 r52 3
 x11 r56 3
 x11 r60 3
 x12 obj 3
 x12 r5 3
 x12 r37 3
 x12 r41 3
 x12 r45 3
 x12 r49 3
 x12 r53 3
 x12 r57 3
 x12 r61 3
 x13 obj 3
 x13 r6 3
 x13 r38 3
 x13 r42 3
 x13 r46 3
 x13 r50 3
 x13 r54 3
 x13 r58 3
 x13 r62 3
 x14 obj 3
 x14 r7 3
 x14 r39 3
 x14 r43 3
 x14 r47 3
 x14 r51 3
 x14 r55 3
 x14 r59 3
 x14 r63 3
 x15 obj 3
 x15 r14 3
 x15 r21 3
 x15 r28 3
 x15 r35 3
 x15 r60 3
 x15 r61 3
 x15 r62 3
 x15 r63 3
RHS
 rhs obj -0.875
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
 rhs r6 3
 rhs r7 3
 rhs r8 3
 rhs r9 3
 rhs r10 3
 rhs r11 3
 rhs r12 3
 rhs r13 3
 rhs r14 3
 rhs r15 3
 rhs r16 3
 rhs r17 3
 rhs r18 3
 rhs r19 3
 rhs r20 3
 rhs r21 3
 rhs r22 3
 rhs r23 3
 rhs r24 3
 rhs r25 3
 rhs r26 3
 rhs r27 3
 rhs r28 3
 rhs r29 3
 rhs r30 3
 rhs r31 3
 rhs r32 3
 rhs r33 3
 rhs r34 3
 rhs r35 3
 rhs r36 3
 rhs r37 3
 rhs r38 3
 rhs r39 3
 rhs r40 3
 rhs r41 3
 rhs r42 3
 rhs r43 3
 rhs r44 3
 rhs r45 3
 rhs r46 3
 rhs r47 3
 rhs r48 3
 rhs r49 3
 rhs r50 3
 rhs r51 3
 rhs r52 3
 rhs r53 3
 rhs r54 3
 rhs r55 3
 rhs r56 3
 rhs r57 3
 rhs r58 3
 rhs r59 3
 rhs r60 3
 rhs r61 3
 rhs r62 3
 rhs r63 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
