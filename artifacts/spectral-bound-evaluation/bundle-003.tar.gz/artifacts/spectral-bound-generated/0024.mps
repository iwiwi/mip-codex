NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
 G r12
 G r13
 G r14
 G r15
COLUMNS
 x0 obj -1
 x0 r0 -3
 x0 r1 -3
 x0 r2 -3
 x0 r3 -3
 x1 obj -1
 x1 r4 -3
 x1 r5 -3
 x1 r6 -3
 x1 r7 -3
 x2 obj -1
 x2 r4 -3
 x2 r8 -3
 x2 r9 -3
 x2 r10 -3
 x3 obj -1
 x3 r0 -3
 x3 r11 -3
 x3 r12 -3
 x3 r13 -3
 x4 obj -1
 x4 r5 -3
 x4 r8 -3
 x4 r11 -3
 x4 r14 -3
 x5 obj -1
 x5 r1 -3
 x5 r9 -3
 x5 r12 -3
 x5 r15 -3
 x6 obj -1
 x6 r2 -3
 x6 r6 -3
 x6 r13 -3
 x6 r15 -3
 x7 obj -1
 x7 r3 -3
 x7 r7 -3
 x7 r10 -3
 x7 r14 -3
RHS
 rhs obj -1.0
 rhs r0 -3
 rhs r1 -3
 rhs r2 -3
 rhs r3 -3
 rhs r4 -3
 rhs r5 -3
 rhs r6 -3
 rhs r7 -3
 rhs r8 -3
 rhs r9 -3
 rhs r10 -3
 rhs r11 -3
 rhs r12 -3
 rhs r13 -3
 rhs r14 -3
 rhs r15 -3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
ENDATA
