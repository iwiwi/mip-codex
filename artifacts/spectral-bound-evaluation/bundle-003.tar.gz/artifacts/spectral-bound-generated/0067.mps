NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
 L r40
 L r41
 L r42
 L r43
 L r44
 L r45
 L r46
 L r47
 L r48
 L r49
 L r50
 L r51
 L r52
 L r53
 L r54
 L r55
 L r56
 L r57
 L r58
 L r59
 L r60
 L r61
 L r62
 L r63
 L r64
 L r65
 L r66
 L r67
 L r68
 L r69
 L r70
 L r71
 L r72
 L r73
 L r74
 L r75
 L r76
 L r77
 L r78
 L r79
 L r80
 L r81
 L r82
 L r83
 L r84
 L r85
 L r86
 L r87
 L r88
 L r89
 L r90
 L r91
 L r92
 L r93
 L r94
 L r95
 L r96
 L r97
 L r98
 L r99
 L r100
 L r101
 L r102
 L r103
 L r104
 L r105
 L r106
 L r107
 L r108
 L r109
 L r110
 L r111
 L r112
 L r113
 L r114
 L r115
 L r116
 L r117
 L r118
 L r119
COLUMNS
 x0 obj 3
 x0 r0 3
 x0 r1 3
 x0 r2 3
 x0 r3 3
 x0 r4 3
 x0 r5 3
 x0 r6 3
 x0 r7 3
 x0 r8 3
 x0 r9 3
 x0 r10 3
 x0 r11 3
 x0 r12 3
 x0 r13 3
 x0 r14 3
 x1 obj 3
 x1 r0 3
 x1 r15 3
 x1 r16 3
 x1 r17 3
 x1 r18 3
 x1 r19 3
 x1 r20 3
 x1 r21 3
 x1 r22 3
 x1 r23 3
 x1 r24 3
 x1 r25 3
 x1 r26 3
 x1 r27 3
 x1 r28 3
 x2 obj 3
 x2 r1 3
 x2 r15 3
 x2 r29 3
 x2 r30 3
 x2 r31 3
 x2 r32 3
 x2 r33 3
 x2 r34 3
 x2 r35 3
 x2 r36 3
 x2 r37 3
 x2 r38 3
 x2 r39 3
 x2 r40 3
 x2 r41 3
 x3 obj 3
 x3 r2 3
 x3 r16 3
 x3 r29 3
 x3 r42 3
 x3 r43 3
 x3 r44 3
 x3 r45 3
 x3 r46 3
 x3 r47 3
 x3 r48 3
 x3 r49 3
 x3 r50 3
 x3 r51 3
 x3 r52 3
 x3 r53 3
 x4 obj 3
 x4 r3 3
 x4 r17 3
 x4 r30 3
 x4 r42 3
 x4 r54 3
 x4 r55 3
 x4 r56 3
 x4 r57 3
 x4 r58 3
 x4 r59 3
 x4 r60 3
 x4 r61 3
 x4 r62 3
 x4 r63 3
 x4 r64 3
 x5 obj 3
 x5 r4 3
 x5 r18 3
 x5 r31 3
 x5 r43 3
 x5 r54 3
 x5 r65 3
 x5 r66 3
 x5 r67 3
 x5 r68 3
 x5 r69 3
 x5 r70 3
 x5 r71 3
 x5 r72 3
 x5 r73 3
 x5 r74 3
 x6 obj 3
 x6 r5 3
 x6 r19 3
 x6 r32 3
 x6 r44 3
 x6 r55 3
 x6 r65 3
 x6 r75 3
 x6 r76 3
 x6 r77 3
 x6 r78 3
 x6 r79 3
 x6 r80 3
 x6 r81 3
 x6 r82 3
 x6 r83 3
 x7 obj 3
 x7 r6 3
 x7 r20 3
 x7 r33 3
 x7 r45 3
 x7 r56 3
 x7 r66 3
 x7 r75 3
 x7 r84 3
 x7 r85 3
 x7 r86 3
 x7 r87 3
 x7 r88 3
 x7 r89 3
 x7 r90 3
 x7 r91 3
 x8 obj 3
 x8 r7 3
 x8 r21 3
 x8 r34 3
 x8 r46 3
 x8 r57 3
 x8 r67 3
 x8 r76 3
 x8 r84 3
 x8 r92 3
 x8 r93 3
 x8 r94 3
 x8 r95 3
 x8 r96 3
 x8 r97 3
 x8 r98 3
 x9 obj 3
 x9 r8 3
 x9 r22 3
 x9 r35 3
 x9 r47 3
 x9 r58 3
 x9 r68 3
 x9 r77 3
 x9 r85 3
 x9 r92 3
 x9 r99 3
 x9 r100 3
 x9 r101 3
 x9 r102 3
 x9 r103 3
 x9 r104 3
 x10 obj 3
 x10 r9 3
 x10 r23 3
 x10 r36 3
 x10 r48 3
 x10 r59 3
 x10 r69 3
 x10 r78 3
 x10 r86 3
 x10 r93 3
 x10 r99 3
 x10 r105 3
 x10 r106 3
 x10 r107 3
 x10 r108 3
 x10 r109 3
 x11 obj 3
 x11 r10 3
 x11 r24 3
 x11 r37 3
 x11 r49 3
 x11 r60 3
 x11 r70 3
 x11 r79 3
 x11 r87 3
 x11 r94 3
 x11 r100 3
 x11 r105 3
 x11 r110 3
 x11 r111 3
 x11 r112 3
 x11 r113 3
 x12 obj 3
 x12 r11 3
 x12 r25 3
 x12 r38 3
 x12 r50 3
 x12 r61 3
 x12 r71 3
 x12 r80 3
 x12 r88 3
 x12 r95 3
 x12 r101 3
 x12 r106 3
 x12 r110 3
 x12 r114 3
 x12 r115 3
 x12 r116 3
 x13 obj 3
 x13 r12 3
 x13 r26 3
 x13 r39 3
 x13 r51 3
 x13 r62 3
 x13 r72 3
 x13 r81 3
 x13 r89 3
 x13 r96 3
 x13 r102 3
 x13 r107 3
 x13 r111 3
 x13 r114 3
 x13 r117 3
 x13 r118 3
 x14 obj 3
 x14 r13 3
 x14 r27 3
 x14 r40 3
 x14 r52 3
 x14 r63 3
 x14 r73 3
 x14 r82 3
 x14 r90 3
 x14 r97 3
 x14 r103 3
 x14 r108 3
 x14 r112 3
 x14 r115 3
 x14 r117 3
 x14 r119 3
 x15 obj 3
 x15 r14 3
 x15 r28 3
 x15 r41 3
 x15 r53 3
 x15 r64 3
 x15 r74 3
 x15 r83 3
 x15 r91 3
 x15 r98 3
 x15 r104 3
 x15 r109 3
 x15 r113 3
 x15 r116 3
 x15 r118 3
 x15 r119 3
RHS
 rhs obj -0.5
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
 rhs r6 3
 rhs r7 3
 rhs r8 3
 rhs r9 3
 rhs r10 3
 rhs r11 3
 rhs r12 3
 rhs r13 3
 rhs r14 3
 rhs r15 3
 rhs r16 3
 rhs r17 3
 rhs r18 3
 rhs r19 3
 rhs r20 3
 rhs r21 3
 rhs r22 3
 rhs r23 3
 rhs r24 3
 rhs r25 3
 rhs r26 3
 rhs r27 3
 rhs r28 3
 rhs r29 3
 rhs r30 3
 rhs r31 3
 rhs r32 3
 rhs r33 3
 rhs r34 3
 rhs r35 3
 rhs r36 3
 rhs r37 3
 rhs r38 3
 rhs r39 3
 rhs r40 3
 rhs r41 3
 rhs r42 3
 rhs r43 3
 rhs r44 3
 rhs r45 3
 rhs r46 3
 rhs r47 3
 rhs r48 3
 rhs r49 3
 rhs r50 3
 rhs r51 3
 rhs r52 3
 rhs r53 3
 rhs r54 3
 rhs r55 3
 rhs r56 3
 rhs r57 3
 rhs r58 3
 rhs r59 3
 rhs r60 3
 rhs r61 3
 rhs r62 3
 rhs r63 3
 rhs r64 3
 rhs r65 3
 rhs r66 3
 rhs r67 3
 rhs r68 3
 rhs r69 3
 rhs r70 3
 rhs r71 3
 rhs r72 3
 rhs r73 3
 rhs r74 3
 rhs r75 3
 rhs r76 3
 rhs r77 3
 rhs r78 3
 rhs r79 3
 rhs r80 3
 rhs r81 3
 rhs r82 3
 rhs r83 3
 rhs r84 3
 rhs r85 3
 rhs r86 3
 rhs r87 3
 rhs r88 3
 rhs r89 3
 rhs r90 3
 rhs r91 3
 rhs r92 3
 rhs r93 3
 rhs r94 3
 rhs r95 3
 rhs r96 3
 rhs r97 3
 rhs r98 3
 rhs r99 3
 rhs r100 3
 rhs r101 3
 rhs r102 3
 rhs r103 3
 rhs r104 3
 rhs r105 3
 rhs r106 3
 rhs r107 3
 rhs r108 3
 rhs r109 3
 rhs r110 3
 rhs r111 3
 rhs r112 3
 rhs r113 3
 rhs r114 3
 rhs r115 3
 rhs r116 3
 rhs r117 3
 rhs r118 3
 rhs r119 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
