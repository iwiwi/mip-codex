NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
 G r12
 G r13
 G r14
 G r15
 G r16
 G r17
 G r18
 G r19
 G r20
 G r21
 G r22
 G r23
 G r24
 G r25
 G r26
 G r27
COLUMNS
 x0 obj -4
 x0 r0 -1
 x0 r1 -1
 x0 r2 -1
 x0 r3 -1
 x0 r4 -1
 x0 r5 -1
 x0 r6 -1
 x1 obj -4
 x1 r0 -1
 x1 r7 -1
 x1 r8 -1
 x1 r9 -1
 x1 r10 -1
 x1 r11 -1
 x1 r12 -1
 x2 obj -4
 x2 r1 -1
 x2 r7 -1
 x2 r13 -1
 x2 r14 -1
 x2 r15 -1
 x2 r16 -1
 x2 r17 -1
 x3 obj -4
 x3 r2 -1
 x3 r8 -1
 x3 r13 -1
 x3 r18 -1
 x3 r19 -1
 x3 r20 -1
 x3 r21 -1
 x4 obj -4
 x4 r3 -1
 x4 r9 -1
 x4 r14 -1
 x4 r18 -1
 x4 r22 -1
 x4 r23 -1
 x4 r24 -1
 x5 obj -4
 x5 r4 -1
 x5 r10 -1
 x5 r15 -1
 x5 r19 -1
 x5 r22 -1
 x5 r25 -1
 x5 r26 -1
 x6 obj -4
 x6 r5 -1
 x6 r11 -1
 x6 r16 -1
 x6 r20 -1
 x6 r23 -1
 x6 r25 -1
 x6 r27 -1
 x7 obj -4
 x7 r6 -1
 x7 r12 -1
 x7 r17 -1
 x7 r21 -1
 x7 r24 -1
 x7 r26 -1
 x7 r27 -1
RHS
 rhs obj -0.25
 rhs r0 -1
 rhs r1 -1
 rhs r2 -1
 rhs r3 -1
 rhs r4 -1
 rhs r5 -1
 rhs r6 -1
 rhs r7 -1
 rhs r8 -1
 rhs r9 -1
 rhs r10 -1
 rhs r11 -1
 rhs r12 -1
 rhs r13 -1
 rhs r14 -1
 rhs r15 -1
 rhs r16 -1
 rhs r17 -1
 rhs r18 -1
 rhs r19 -1
 rhs r20 -1
 rhs r21 -1
 rhs r22 -1
 rhs r23 -1
 rhs r24 -1
 rhs r25 -1
 rhs r26 -1
 rhs r27 -1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
ENDATA
