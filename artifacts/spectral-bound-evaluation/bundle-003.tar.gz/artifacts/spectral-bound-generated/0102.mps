NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
 G r12
 G r13
 G r14
 G r15
 G r16
 G r17
 G r18
 G r19
 G r20
 G r21
 G r22
 G r23
 G r24
 G r25
 G r26
 G r27
 G r28
 G r29
 G r30
 G r31
 G r32
 G r33
 G r34
 G r35
 G r36
 G r37
 G r38
 G r39
 G r40
 G r41
 G r42
 G r43
 G r44
 G r45
 G r46
 G r47
 G r48
 G r49
 G r50
 G r51
 G r52
 G r53
 G r54
 G r55
 G r56
 G r57
 G r58
 G r59
 G r60
 G r61
 G r62
 G r63
 G r64
 G r65
 G r66
 G r67
 G r68
 G r69
 G r70
 G r71
 G r72
 G r73
 G r74
 G r75
 G r76
 G r77
 G r78
 G r79
 G r80
 G r81
 G r82
 G r83
 G r84
 G r85
 G r86
 G r87
 G r88
 G r89
 G r90
 G r91
 G r92
 G r93
 G r94
 G r95
 G r96
 G r97
 G r98
 G r99
 G r100
 G r101
 G r102
 G r103
 G r104
 G r105
 G r106
 G r107
 G r108
 G r109
 G r110
 G r111
 G r112
 G r113
 G r114
 G r115
 G r116
 G r117
 G r118
 G r119
COLUMNS
 x0 obj -1
 x0 r0 -2
 x0 r1 -2
 x0 r2 -2
 x0 r3 -2
 x0 r4 -2
 x0 r5 -2
 x0 r6 -2
 x0 r7 -2
 x0 r8 -2
 x0 r9 -2
 x0 r10 -2
 x0 r11 -2
 x0 r12 -2
 x0 r13 -2
 x0 r14 -2
 x1 obj -1
 x1 r0 -2
 x1 r15 -2
 x1 r16 -2
 x1 r17 -2
 x1 r18 -2
 x1 r19 -2
 x1 r20 -2
 x1 r21 -2
 x1 r22 -2
 x1 r23 -2
 x1 r24 -2
 x1 r25 -2
 x1 r26 -2
 x1 r27 -2
 x1 r28 -2
 x2 obj -1
 x2 r1 -2
 x2 r15 -2
 x2 r29 -2
 x2 r30 -2
 x2 r31 -2
 x2 r32 -2
 x2 r33 -2
 x2 r34 -2
 x2 r35 -2
 x2 r36 -2
 x2 r37 -2
 x2 r38 -2
 x2 r39 -2
 x2 r40 -2
 x2 r41 -2
 x3 obj -1
 x3 r2 -2
 x3 r16 -2
 x3 r29 -2
 x3 r42 -2
 x3 r43 -2
 x3 r44 -2
 x3 r45 -2
 x3 r46 -2
 x3 r47 -2
 x3 r48 -2
 x3 r49 -2
 x3 r50 -2
 x3 r51 -2
 x3 r52 -2
 x3 r53 -2
 x4 obj -1
 x4 r3 -2
 x4 r17 -2
 x4 r30 -2
 x4 r42 -2
 x4 r54 -2
 x4 r55 -2
 x4 r56 -2
 x4 r57 -2
 x4 r58 -2
 x4 r59 -2
 x4 r60 -2
 x4 r61 -2
 x4 r62 -2
 x4 r63 -2
 x4 r64 -2
 x5 obj -1
 x5 r4 -2
 x5 r18 -2
 x5 r31 -2
 x5 r43 -2
 x5 r54 -2
 x5 r65 -2
 x5 r66 -2
 x5 r67 -2
 x5 r68 -2
 x5 r69 -2
 x5 r70 -2
 x5 r71 -2
 x5 r72 -2
 x5 r73 -2
 x5 r74 -2
 x6 obj -1
 x6 r5 -2
 x6 r19 -2
 x6 r32 -2
 x6 r44 -2
 x6 r55 -2
 x6 r65 -2
 x6 r75 -2
 x6 r76 -2
 x6 r77 -2
 x6 r78 -2
 x6 r79 -2
 x6 r80 -2
 x6 r81 -2
 x6 r82 -2
 x6 r83 -2
 x7 obj -1
 x7 r6 -2
 x7 r20 -2
 x7 r33 -2
 x7 r45 -2
 x7 r56 -2
 x7 r66 -2
 x7 r75 -2
 x7 r84 -2
 x7 r85 -2
 x7 r86 -2
 x7 r87 -2
 x7 r88 -2
 x7 r89 -2
 x7 r90 -2
 x7 r91 -2
 x8 obj -1
 x8 r7 -2
 x8 r21 -2
 x8 r34 -2
 x8 r46 -2
 x8 r57 -2
 x8 r67 -2
 x8 r76 -2
 x8 r84 -2
 x8 r92 -2
 x8 r93 -2
 x8 r94 -2
 x8 r95 -2
 x8 r96 -2
 x8 r97 -2
 x8 r98 -2
 x9 obj -1
 x9 r8 -2
 x9 r22 -2
 x9 r35 -2
 x9 r47 -2
 x9 r58 -2
 x9 r68 -2
 x9 r77 -2
 x9 r85 -2
 x9 r92 -2
 x9 r99 -2
 x9 r100 -2
 x9 r101 -2
 x9 r102 -2
 x9 r103 -2
 x9 r104 -2
 x10 obj -1
 x10 r9 -2
 x10 r23 -2
 x10 r36 -2
 x10 r48 -2
 x10 r59 -2
 x10 r69 -2
 x10 r78 -2
 x10 r86 -2
 x10 r93 -2
 x10 r99 -2
 x10 r105 -2
 x10 r106 -2
 x10 r107 -2
 x10 r108 -2
 x10 r109 -2
 x11 obj -1
 x11 r10 -2
 x11 r24 -2
 x11 r37 -2
 x11 r49 -2
 x11 r60 -2
 x11 r70 -2
 x11 r79 -2
 x11 r87 -2
 x11 r94 -2
 x11 r100 -2
 x11 r105 -2
 x11 r110 -2
 x11 r111 -2
 x11 r112 -2
 x11 r113 -2
 x12 obj -1
 x12 r11 -2
 x12 r25 -2
 x12 r38 -2
 x12 r50 -2
 x12 r61 -2
 x12 r71 -2
 x12 r80 -2
 x12 r88 -2
 x12 r95 -2
 x12 r101 -2
 x12 r106 -2
 x12 r110 -2
 x12 r114 -2
 x12 r115 -2
 x12 r116 -2
 x13 obj -1
 x13 r12 -2
 x13 r26 -2
 x13 r39 -2
 x13 r51 -2
 x13 r62 -2
 x13 r72 -2
 x13 r81 -2
 x13 r89 -2
 x13 r96 -2
 x13 r102 -2
 x13 r107 -2
 x13 r111 -2
 x13 r114 -2
 x13 r117 -2
 x13 r118 -2
 x14 obj -1
 x14 r13 -2
 x14 r27 -2
 x14 r40 -2
 x14 r52 -2
 x14 r63 -2
 x14 r73 -2
 x14 r82 -2
 x14 r90 -2
 x14 r97 -2
 x14 r103 -2
 x14 r108 -2
 x14 r112 -2
 x14 r115 -2
 x14 r117 -2
 x14 r119 -2
 x15 obj -1
 x15 r14 -2
 x15 r28 -2
 x15 r41 -2
 x15 r53 -2
 x15 r64 -2
 x15 r74 -2
 x15 r83 -2
 x15 r91 -2
 x15 r98 -2
 x15 r104 -2
 x15 r109 -2
 x15 r113 -2
 x15 r116 -2
 x15 r118 -2
 x15 r119 -2
RHS
 rhs obj -1.75
 rhs r0 -2
 rhs r1 -2
 rhs r2 -2
 rhs r3 -2
 rhs r4 -2
 rhs r5 -2
 rhs r6 -2
 rhs r7 -2
 rhs r8 -2
 rhs r9 -2
 rhs r10 -2
 rhs r11 -2
 rhs r12 -2
 rhs r13 -2
 rhs r14 -2
 rhs r15 -2
 rhs r16 -2
 rhs r17 -2
 rhs r18 -2
 rhs r19 -2
 rhs r20 -2
 rhs r21 -2
 rhs r22 -2
 rhs r23 -2
 rhs r24 -2
 rhs r25 -2
 rhs r26 -2
 rhs r27 -2
 rhs r28 -2
 rhs r29 -2
 rhs r30 -2
 rhs r31 -2
 rhs r32 -2
 rhs r33 -2
 rhs r34 -2
 rhs r35 -2
 rhs r36 -2
 rhs r37 -2
 rhs r38 -2
 rhs r39 -2
 rhs r40 -2
 rhs r41 -2
 rhs r42 -2
 rhs r43 -2
 rhs r44 -2
 rhs r45 -2
 rhs r46 -2
 rhs r47 -2
 rhs r48 -2
 rhs r49 -2
 rhs r50 -2
 rhs r51 -2
 rhs r52 -2
 rhs r53 -2
 rhs r54 -2
 rhs r55 -2
 rhs r56 -2
 rhs r57 -2
 rhs r58 -2
 rhs r59 -2
 rhs r60 -2
 rhs r61 -2
 rhs r62 -2
 rhs r63 -2
 rhs r64 -2
 rhs r65 -2
 rhs r66 -2
 rhs r67 -2
 rhs r68 -2
 rhs r69 -2
 rhs r70 -2
 rhs r71 -2
 rhs r72 -2
 rhs r73 -2
 rhs r74 -2
 rhs r75 -2
 rhs r76 -2
 rhs r77 -2
 rhs r78 -2
 rhs r79 -2
 rhs r80 -2
 rhs r81 -2
 rhs r82 -2
 rhs r83 -2
 rhs r84 -2
 rhs r85 -2
 rhs r86 -2
 rhs r87 -2
 rhs r88 -2
 rhs r89 -2
 rhs r90 -2
 rhs r91 -2
 rhs r92 -2
 rhs r93 -2
 rhs r94 -2
 rhs r95 -2
 rhs r96 -2
 rhs r97 -2
 rhs r98 -2
 rhs r99 -2
 rhs r100 -2
 rhs r101 -2
 rhs r102 -2
 rhs r103 -2
 rhs r104 -2
 rhs r105 -2
 rhs r106 -2
 rhs r107 -2
 rhs r108 -2
 rhs r109 -2
 rhs r110 -2
 rhs r111 -2
 rhs r112 -2
 rhs r113 -2
 rhs r114 -2
 rhs r115 -2
 rhs r116 -2
 rhs r117 -2
 rhs r118 -2
 rhs r119 -2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
