NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
COLUMNS
 x0 obj 3
 x0 r0 -4
 x0 r1 -4
 x0 r2 -4
 x1 obj 3
 x1 r0 -4
 x1 r3 -4
 x1 r4 -4
 x2 obj 3
 x2 r1 -4
 x2 r3 -4
 x2 r5 -4
 x3 obj 3
 x3 r2 -4
 x3 r4 -4
 x3 r5 -4
RHS
 rhs obj 1.0
 rhs r0 -4
 rhs r1 -4
 rhs r2 -4
 rhs r3 -4
 rhs r4 -4
 rhs r5 -4
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
ENDATA
