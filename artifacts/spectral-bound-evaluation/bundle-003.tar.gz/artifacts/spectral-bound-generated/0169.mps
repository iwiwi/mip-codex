NAME spectral
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
 L r40
 L r41
 L r42
 L r43
 L r44
 L r45
 L r46
 L r47
 L r48
 L r49
 L r50
 L r51
 L r52
 L r53
 L r54
 L r55
 L r56
 L r57
 L r58
 L r59
 L r60
 L r61
 L r62
 L r63
COLUMNS
 x0 obj 3
 x0 r0 4
 x0 r1 4
 x0 r2 4
 x0 r3 4
 x0 r4 4
 x0 r5 4
 x0 r6 4
 x0 r7 4
 x1 obj 3
 x1 r0 4
 x1 r8 4
 x1 r9 4
 x1 r10 4
 x1 r11 4
 x1 r12 4
 x1 r13 4
 x1 r14 4
 x2 obj 3
 x2 r1 4
 x2 r15 4
 x2 r16 4
 x2 r17 4
 x2 r18 4
 x2 r19 4
 x2 r20 4
 x2 r21 4
 x3 obj 3
 x3 r2 4
 x3 r22 4
 x3 r23 4
 x3 r24 4
 x3 r25 4
 x3 r26 4
 x3 r27 4
 x3 r28 4
 x4 obj 3
 x4 r3 4
 x4 r29 4
 x4 r30 4
 x4 r31 4
 x4 r32 4
 x4 r33 4
 x4 r34 4
 x4 r35 4
 x5 obj 3
 x5 r8 4
 x5 r15 4
 x5 r22 4
 x5 r29 4
 x5 r36 4
 x5 r37 4
 x5 r38 4
 x5 r39 4
 x6 obj 3
 x6 r9 4
 x6 r16 4
 x6 r23 4
 x6 r30 4
 x6 r40 4
 x6 r41 4
 x6 r42 4
 x6 r43 4
 x7 obj 3
 x7 r10 4
 x7 r17 4
 x7 r24 4
 x7 r31 4
 x7 r44 4
 x7 r45 4
 x7 r46 4
 x7 r47 4
 x8 obj 3
 x8 r11 4
 x8 r18 4
 x8 r25 4
 x8 r32 4
 x8 r48 4
 x8 r49 4
 x8 r50 4
 x8 r51 4
 x9 obj 3
 x9 r12 4
 x9 r19 4
 x9 r26 4
 x9 r33 4
 x9 r52 4
 x9 r53 4
 x9 r54 4
 x9 r55 4
 x10 obj 3
 x10 r13 4
 x10 r20 4
 x10 r27 4
 x10 r34 4
 x10 r56 4
 x10 r57 4
 x10 r58 4
 x10 r59 4
 x11 obj 3
 x11 r4 4
 x11 r36 4
 x11 r40 4
 x11 r44 4
 x11 r48 4
 x11 r52 4
 x11 r56 4
 x11 r60 4
 x12 obj 3
 x12 r5 4
 x12 r37 4
 x12 r41 4
 x12 r45 4
 x12 r49 4
 x12 r53 4
 x12 r57 4
 x12 r61 4
 x13 obj 3
 x13 r6 4
 x13 r38 4
 x13 r42 4
 x13 r46 4
 x13 r50 4
 x13 r54 4
 x13 r58 4
 x13 r62 4
 x14 obj 3
 x14 r7 4
 x14 r39 4
 x14 r43 4
 x14 r47 4
 x14 r51 4
 x14 r55 4
 x14 r59 4
 x14 r63 4
 x15 obj 3
 x15 r14 4
 x15 r21 4
 x15 r28 4
 x15 r35 4
 x15 r60 4
 x15 r61 4
 x15 r62 4
 x15 r63 4
RHS
 rhs obj 1.375
 rhs r0 4
 rhs r1 4
 rhs r2 4
 rhs r3 4
 rhs r4 4
 rhs r5 4
 rhs r6 4
 rhs r7 4
 rhs r8 4
 rhs r9 4
 rhs r10 4
 rhs r11 4
 rhs r12 4
 rhs r13 4
 rhs r14 4
 rhs r15 4
 rhs r16 4
 rhs r17 4
 rhs r18 4
 rhs r19 4
 rhs r20 4
 rhs r21 4
 rhs r22 4
 rhs r23 4
 rhs r24 4
 rhs r25 4
 rhs r26 4
 rhs r27 4
 rhs r28 4
 rhs r29 4
 rhs r30 4
 rhs r31 4
 rhs r32 4
 rhs r33 4
 rhs r34 4
 rhs r35 4
 rhs r36 4
 rhs r37 4
 rhs r38 4
 rhs r39 4
 rhs r40 4
 rhs r41 4
 rhs r42 4
 rhs r43 4
 rhs r44 4
 rhs r45 4
 rhs r46 4
 rhs r47 4
 rhs r48 4
 rhs r49 4
 rhs r50 4
 rhs r51 4
 rhs r52 4
 rhs r53 4
 rhs r54 4
 rhs r55 4
 rhs r56 4
 rhs r57 4
 rhs r58 4
 rhs r59 4
 rhs r60 4
 rhs r61 4
 rhs r62 4
 rhs r63 4
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
 BV b x12
 BV b x13
 BV b x14
 BV b x15
ENDATA
