NAME spectral
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj -1
 x0 r0 3
 x1 obj -1
 x1 r1 3
 x2 obj -1
 x2 r2 3
 x3 obj -1
 x3 r3 3
 x4 obj -1
 x4 r3 3
 x5 obj -1
 x5 r2 3
 x6 obj -1
 x6 r1 3
 x7 obj -1
 x7 r0 3
RHS
 rhs obj -1.125
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
ENDATA
