NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
COLUMNS
 x0 obj -4
 x0 r0 -1
 x0 r1 -1
 x0 r2 -1
 x0 r3 -1
 x1 obj -4
 x1 r1 -1
 x1 r2 -1
 x1 r3 -1
 x1 r4 -1
 x2 obj -4
 x2 r2 -1
 x2 r3 -1
 x2 r4 -1
 x2 r5 -1
 x3 obj -4
 x3 r0 -1
 x3 r1 -1
 x3 r5 -1
 x3 r6 -1
 x4 obj -4
 x4 r0 -1
 x4 r4 -1
 x4 r5 -1
 x4 r6 -1
 x5 obj -4
 x5 r0 -1
 x5 r1 -1
 x5 r2 -1
 x5 r6 -1
 x6 obj -4
 x6 r3 -1
 x6 r4 -1
 x6 r5 -1
 x6 r6 -1
RHS
 rhs obj 2.0
 rhs r0 -1
 rhs r1 -1
 rhs r2 -1
 rhs r3 -1
 rhs r4 -1
 rhs r5 -1
 rhs r6 -1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
ENDATA
