NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
COLUMNS
 x0 obj -4
 x0 r3 2
 x0 r4 2
 x0 r5 2
 x0 r6 2
 x1 obj -4
 x1 r2 2
 x1 r3 2
 x1 r4 2
 x1 r5 2
 x2 obj -4
 x2 r0 2
 x2 r1 2
 x2 r2 2
 x2 r3 2
 x3 obj -4
 x3 r0 2
 x3 r1 2
 x3 r6 2
 x3 r7 2
 x4 obj -4
 x4 r4 2
 x4 r5 2
 x4 r6 2
 x4 r7 2
 x5 obj -4
 x5 r0 2
 x5 r5 2
 x5 r6 2
 x5 r7 2
 x6 obj -4
 x6 r0 2
 x6 r1 2
 x6 r2 2
 x6 r7 2
 x7 obj -4
 x7 r1 2
 x7 r2 2
 x7 r3 2
 x7 r4 2
RHS
 rhs obj -0.5
 rhs r0 2
 rhs r1 2
 rhs r2 2
 rhs r3 2
 rhs r4 2
 rhs r5 2
 rhs r6 2
 rhs r7 2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
ENDATA
