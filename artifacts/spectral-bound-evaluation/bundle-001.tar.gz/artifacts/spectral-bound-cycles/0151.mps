NAME cyclic
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
COLUMNS
 x0 obj 3
 x0 r2 3
 x0 r3 3
 x0 r4 3
 x0 r9 3
 x1 obj 3
 x1 r4 3
 x1 r5 3
 x1 r6 3
 x2 obj 3
 x2 r0 3
 x2 r5 3
 x2 r6 3
 x2 r7 3
 x3 obj 3
 x3 r0 3
 x3 r1 3
 x3 r2 3
 x3 r7 3
 x3 r8 3
 x3 r9 3
 x4 obj 3
 x4 r1 3
 x4 r2 3
 x4 r3 3
 x4 r8 3
 x4 r9 3
 x5 obj 3
 x5 r3 3
 x5 r4 3
 x5 r5 3
 x6 obj 3
 x6 r0 3
 x6 r1 3
 x6 r6 3
 x6 r7 3
 x6 r8 3
RHS
 rhs obj 1.625
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
 rhs r6 3
 rhs r7 3
 rhs r8 3
 rhs r9 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
ENDATA
