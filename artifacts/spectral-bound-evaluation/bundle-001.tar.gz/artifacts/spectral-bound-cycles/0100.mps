NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
COLUMNS
 x0 obj -1
 x0 r1 3
 x0 r2 3
 x0 r3 3
 x0 r4 3
 x1 obj -1
 x1 r0 3
 x1 r1 3
 x1 r2 3
 x1 r9 3
 x2 obj -1
 x2 r0 3
 x2 r1 3
 x2 r8 3
 x2 r9 3
 x3 obj -1
 x3 r6 3
 x3 r7 3
 x3 r8 3
 x3 r9 3
 x4 obj -1
 x4 r0 3
 x4 r7 3
 x4 r8 3
 x4 r9 3
 x5 obj -1
 x5 r3 3
 x5 r4 3
 x5 r5 3
 x5 r6 3
 x6 obj -1
 x6 r2 3
 x6 r3 3
 x6 r4 3
 x6 r5 3
 x7 obj -1
 x7 r4 3
 x7 r5 3
 x7 r6 3
 x7 r7 3
 x8 obj -1
 x8 r0 3
 x8 r1 3
 x8 r2 3
 x8 r3 3
 x9 obj -1
 x9 r5 3
 x9 r6 3
 x9 r7 3
 x9 r8 3
RHS
 rhs obj -0.5
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
 rhs r6 3
 rhs r7 3
 rhs r8 3
 rhs r9 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
ENDATA
