NAME cyclic
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
COLUMNS
 x0 obj 4
 x0 r6 2
 x0 r7 2
 x0 r8 2
 x0 r9 2
 x1 obj 4
 x1 r2 2
 x1 r3 2
 x1 r4 2
 x1 r5 2
 x1 r12 2
 x2 obj 4
 x2 r3 2
 x2 r4 2
 x2 r5 2
 x2 r6 2
 x3 obj 4
 x3 r0 2
 x3 r1 2
 x3 r8 2
 x3 r9 2
 x3 r10 2
 x3 r11 2
 x4 obj 4
 x4 r5 2
 x4 r6 2
 x4 r7 2
 x4 r8 2
 x5 obj 4
 x5 r1 2
 x5 r2 2
 x5 r3 2
 x5 r4 2
 x5 r11 2
 x5 r12 2
 x6 obj 4
 x6 r0 2
 x6 r1 2
 x6 r2 2
 x6 r3 2
 x6 r10 2
 x6 r11 2
 x6 r12 2
 x7 obj 4
 x7 r0 2
 x7 r1 2
 x7 r2 2
 x7 r9 2
 x7 r10 2
 x7 r11 2
 x7 r12 2
 x8 obj 4
 x8 r4 2
 x8 r5 2
 x8 r6 2
 x8 r7 2
 x9 obj 4
 x9 r0 2
 x9 r7 2
 x9 r8 2
 x9 r9 2
 x9 r10 2
RHS
 rhs obj 1.5
 rhs r0 2
 rhs r1 2
 rhs r2 2
 rhs r3 2
 rhs r4 2
 rhs r5 2
 rhs r6 2
 rhs r7 2
 rhs r8 2
 rhs r9 2
 rhs r10 2
 rhs r11 2
 rhs r12 2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
ENDATA
