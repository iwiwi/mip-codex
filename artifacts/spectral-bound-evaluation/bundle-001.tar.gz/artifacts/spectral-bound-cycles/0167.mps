NAME cyclic
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
COLUMNS
 x0 obj 3
 x0 r4 3
 x0 r5 3
 x0 r6 3
 x0 r7 3
 x0 r8 3
 x1 obj 3
 x1 r0 3
 x1 r1 3
 x1 r2 3
 x1 r3 3
 x1 r9 3
 x1 r10 3
 x1 r11 3
 x1 r12 3
 x2 obj 3
 x2 r0 3
 x2 r1 3
 x2 r2 3
 x2 r3 3
 x2 r4 3
 x2 r10 3
 x2 r11 3
 x2 r12 3
 x3 obj 3
 x3 r0 3
 x3 r1 3
 x3 r7 3
 x3 r8 3
 x3 r9 3
 x3 r10 3
 x3 r11 3
 x4 obj 3
 x4 r2 3
 x4 r3 3
 x4 r4 3
 x4 r5 3
 x4 r6 3
 x4 r12 3
 x5 obj 3
 x5 r5 3
 x5 r6 3
 x5 r7 3
 x5 r8 3
 x5 r9 3
 x6 obj 3
 x6 r3 3
 x6 r4 3
 x6 r5 3
 x6 r6 3
 x6 r7 3
 x7 obj 3
 x7 r1 3
 x7 r2 3
 x7 r3 3
 x7 r4 3
 x7 r5 3
 x7 r11 3
 x7 r12 3
 x8 obj 3
 x8 r0 3
 x8 r1 3
 x8 r2 3
 x8 r8 3
 x8 r9 3
 x8 r10 3
 x8 r11 3
 x8 r12 3
 x9 obj 3
 x9 r0 3
 x9 r6 3
 x9 r7 3
 x9 r8 3
 x9 r9 3
 x9 r10 3
RHS
 rhs obj -1.875
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
 rhs r6 3
 rhs r7 3
 rhs r8 3
 rhs r9 3
 rhs r10 3
 rhs r11 3
 rhs r12 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
ENDATA
