NAME cyclic
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
 G r12
 G r13
 G r14
COLUMNS
 x0 obj 1
 x0 r9 -3
 x0 r10 -3
 x0 r11 -3
 x1 obj 1
 x1 r0 -3
 x1 r1 -3
 x1 r11 -3
 x1 r12 -3
 x1 r13 -3
 x2 obj 1
 x2 r2 -3
 x2 r3 -3
 x2 r4 -3
 x2 r14 -3
 x3 obj 1
 x3 r8 -3
 x3 r9 -3
 x3 r10 -3
 x4 obj 1
 x4 r5 -3
 x4 r6 -3
 x4 r7 -3
 x5 obj 1
 x5 r1 -3
 x5 r2 -3
 x5 r3 -3
 x5 r13 -3
 x5 r14 -3
 x6 obj 1
 x6 r4 -3
 x6 r5 -3
 x6 r6 -3
 x7 obj 1
 x7 r6 -3
 x7 r7 -3
 x7 r8 -3
 x8 obj 1
 x8 r7 -3
 x8 r8 -3
 x8 r9 -3
 x9 obj 1
 x9 r0 -3
 x9 r1 -3
 x9 r2 -3
 x9 r12 -3
 x9 r13 -3
 x9 r14 -3
 x10 obj 1
 x10 r3 -3
 x10 r4 -3
 x10 r5 -3
 x11 obj 1
 x11 r0 -3
 x11 r10 -3
 x11 r11 -3
 x11 r12 -3
RHS
 rhs obj -1.375
 rhs r0 -3
 rhs r1 -3
 rhs r2 -3
 rhs r3 -3
 rhs r4 -3
 rhs r5 -3
 rhs r6 -3
 rhs r7 -3
 rhs r8 -3
 rhs r9 -3
 rhs r10 -3
 rhs r11 -3
 rhs r12 -3
 rhs r13 -3
 rhs r14 -3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
ENDATA
