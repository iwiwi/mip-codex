NAME cyclic
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
COLUMNS
 x0 obj 1
 x0 r0 3
 x0 r1 3
 x0 r2 3
 x0 r11 3
 x0 r12 3
 x1 obj 1
 x1 r0 3
 x1 r1 3
 x1 r10 3
 x1 r11 3
 x1 r12 3
 x2 obj 1
 x2 r3 3
 x2 r4 3
 x2 r5 3
 x2 r6 3
 x3 obj 1
 x3 r0 3
 x3 r9 3
 x3 r10 3
 x3 r11 3
 x3 r12 3
 x4 obj 1
 x4 r5 3
 x4 r6 3
 x4 r7 3
 x4 r8 3
 x5 obj 1
 x5 r8 3
 x5 r9 3
 x5 r10 3
 x5 r11 3
 x6 obj 1
 x6 r6 3
 x6 r7 3
 x6 r8 3
 x6 r9 3
 x7 obj 1
 x7 r4 3
 x7 r5 3
 x7 r6 3
 x7 r7 3
 x8 obj 1
 x8 r7 3
 x8 r8 3
 x8 r9 3
 x8 r10 3
 x9 obj 1
 x9 r1 3
 x9 r2 3
 x9 r3 3
 x9 r4 3
 x10 obj 1
 x10 r2 3
 x10 r3 3
 x10 r4 3
 x10 r5 3
 x11 obj 1
 x11 r0 3
 x11 r1 3
 x11 r2 3
 x11 r3 3
 x11 r12 3
RHS
 rhs obj -1.375
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
 rhs r6 3
 rhs r7 3
 rhs r8 3
 rhs r9 3
 rhs r10 3
 rhs r11 3
 rhs r12 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
ENDATA
