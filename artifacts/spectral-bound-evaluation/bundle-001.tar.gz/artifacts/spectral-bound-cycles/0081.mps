NAME cyclic
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
 G r12
COLUMNS
 x0 obj 2
 x0 r2 -2
 x0 r3 -2
 x0 r4 -2
 x0 r5 -2
 x0 r6 -2
 x1 obj 2
 x1 r0 -2
 x1 r1 -2
 x1 r2 -2
 x1 r3 -2
 x1 r4 -2
 x1 r12 -2
 x2 obj 2
 x2 r6 -2
 x2 r7 -2
 x2 r8 -2
 x2 r9 -2
 x2 r10 -2
 x3 obj 2
 x3 r3 -2
 x3 r4 -2
 x3 r5 -2
 x3 r6 -2
 x3 r7 -2
 x4 obj 2
 x4 r0 -2
 x4 r1 -2
 x4 r2 -2
 x4 r10 -2
 x4 r11 -2
 x4 r12 -2
 x5 obj 2
 x5 r7 -2
 x5 r8 -2
 x5 r9 -2
 x5 r10 -2
 x5 r11 -2
 x6 obj 2
 x6 r4 -2
 x6 r5 -2
 x6 r6 -2
 x6 r7 -2
 x6 r8 -2
 x7 obj 2
 x7 r1 -2
 x7 r2 -2
 x7 r3 -2
 x7 r4 -2
 x7 r5 -2
 x8 obj 2
 x8 r0 -2
 x8 r8 -2
 x8 r9 -2
 x8 r10 -2
 x8 r11 -2
 x8 r12 -2
 x9 obj 2
 x9 r5 -2
 x9 r6 -2
 x9 r7 -2
 x9 r8 -2
 x9 r9 -2
 x10 obj 2
 x10 r0 -2
 x10 r1 -2
 x10 r2 -2
 x10 r3 -2
 x10 r11 -2
 x10 r12 -2
 x11 obj 2
 x11 r0 -2
 x11 r1 -2
 x11 r9 -2
 x11 r10 -2
 x11 r11 -2
 x11 r12 -2
RHS
 rhs obj 0.5
 rhs r0 -2
 rhs r1 -2
 rhs r2 -2
 rhs r3 -2
 rhs r4 -2
 rhs r5 -2
 rhs r6 -2
 rhs r7 -2
 rhs r8 -2
 rhs r9 -2
 rhs r10 -2
 rhs r11 -2
 rhs r12 -2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
ENDATA
