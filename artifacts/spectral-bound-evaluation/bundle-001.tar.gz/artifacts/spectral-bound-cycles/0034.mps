NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
COLUMNS
 x0 obj -3
 x0 r1 1
 x0 r2 1
 x0 r3 1
 x0 r10 1
 x1 obj -3
 x1 r5 1
 x1 r6 1
 x1 r7 1
 x2 obj -3
 x2 r6 1
 x2 r7 1
 x2 r8 1
 x3 obj -3
 x3 r0 1
 x3 r7 1
 x3 r8 1
 x3 r9 1
 x4 obj -3
 x4 r0 1
 x4 r1 1
 x4 r2 1
 x4 r9 1
 x4 r10 1
 x5 obj -3
 x5 r0 1
 x5 r1 1
 x5 r8 1
 x5 r9 1
 x5 r10 1
 x6 obj -3
 x6 r2 1
 x6 r3 1
 x6 r4 1
 x7 obj -3
 x7 r3 1
 x7 r4 1
 x7 r5 1
 x8 obj -3
 x8 r4 1
 x8 r5 1
 x8 r6 1
RHS
 rhs obj -1.25
 rhs r0 1
 rhs r1 1
 rhs r2 1
 rhs r3 1
 rhs r4 1
 rhs r5 1
 rhs r6 1
 rhs r7 1
 rhs r8 1
 rhs r9 1
 rhs r10 1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
ENDATA
