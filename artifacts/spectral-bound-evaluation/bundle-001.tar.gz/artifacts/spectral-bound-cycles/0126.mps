NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
 G r12
 G r13
COLUMNS
 x0 obj -1
 x0 r6 -1
 x0 r7 -1
 x0 r8 -1
 x0 r9 -1
 x0 r10 -1
 x1 obj -1
 x1 r4 -1
 x1 r5 -1
 x1 r6 -1
 x1 r7 -1
 x1 r8 -1
 x2 obj -1
 x2 r0 -1
 x2 r8 -1
 x2 r9 -1
 x2 r10 -1
 x2 r11 -1
 x2 r12 -1
 x3 obj -1
 x3 r0 -1
 x3 r1 -1
 x3 r2 -1
 x3 r3 -1
 x3 r11 -1
 x3 r12 -1
 x3 r13 -1
 x4 obj -1
 x4 r7 -1
 x4 r8 -1
 x4 r9 -1
 x4 r10 -1
 x4 r11 -1
 x5 obj -1
 x5 r0 -1
 x5 r1 -1
 x5 r2 -1
 x5 r10 -1
 x5 r11 -1
 x5 r12 -1
 x5 r13 -1
 x6 obj -1
 x6 r2 -1
 x6 r3 -1
 x6 r4 -1
 x6 r5 -1
 x6 r6 -1
 x7 obj -1
 x7 r3 -1
 x7 r4 -1
 x7 r5 -1
 x7 r6 -1
 x7 r7 -1
 x8 obj -1
 x8 r5 -1
 x8 r6 -1
 x8 r7 -1
 x8 r8 -1
 x8 r9 -1
 x9 obj -1
 x9 r0 -1
 x9 r1 -1
 x9 r2 -1
 x9 r3 -1
 x9 r4 -1
 x9 r12 -1
 x9 r13 -1
 x10 obj -1
 x10 r1 -1
 x10 r2 -1
 x10 r3 -1
 x10 r4 -1
 x10 r5 -1
 x10 r13 -1
 x11 obj -1
 x11 r0 -1
 x11 r1 -1
 x11 r9 -1
 x11 r10 -1
 x11 r11 -1
 x11 r12 -1
 x11 r13 -1
RHS
 rhs obj -0.5
 rhs r0 -1
 rhs r1 -1
 rhs r2 -1
 rhs r3 -1
 rhs r4 -1
 rhs r5 -1
 rhs r6 -1
 rhs r7 -1
 rhs r8 -1
 rhs r9 -1
 rhs r10 -1
 rhs r11 -1
 rhs r12 -1
 rhs r13 -1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
ENDATA
