NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
COLUMNS
 x0 obj -2
 x0 r6 3
 x0 r7 3
 x0 r8 3
 x0 r9 3
 x1 obj -2
 x1 r5 3
 x1 r6 3
 x1 r7 3
 x1 r8 3
 x2 obj -2
 x2 r0 3
 x2 r1 3
 x2 r2 3
 x2 r3 3
 x2 r12 3
 x2 r13 3
 x3 obj -2
 x3 r4 3
 x3 r5 3
 x3 r6 3
 x3 r7 3
 x4 obj -2
 x4 r0 3
 x4 r9 3
 x4 r10 3
 x4 r11 3
 x4 r12 3
 x5 obj -2
 x5 r7 3
 x5 r8 3
 x5 r9 3
 x5 r10 3
 x6 obj -2
 x6 r3 3
 x6 r4 3
 x6 r5 3
 x6 r6 3
 x7 obj -2
 x7 r0 3
 x7 r1 3
 x7 r2 3
 x7 r11 3
 x7 r12 3
 x7 r13 3
 x8 obj -2
 x8 r2 3
 x8 r3 3
 x8 r4 3
 x8 r5 3
 x9 obj -2
 x9 r0 3
 x9 r1 3
 x9 r10 3
 x9 r11 3
 x9 r12 3
 x9 r13 3
 x10 obj -2
 x10 r1 3
 x10 r2 3
 x10 r3 3
 x10 r4 3
 x10 r13 3
 x11 obj -2
 x11 r8 3
 x11 r9 3
 x11 r10 3
 x11 r11 3
RHS
 rhs obj 1.0
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
 rhs r6 3
 rhs r7 3
 rhs r8 3
 rhs r9 3
 rhs r10 3
 rhs r11 3
 rhs r12 3
 rhs r13 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
ENDATA
