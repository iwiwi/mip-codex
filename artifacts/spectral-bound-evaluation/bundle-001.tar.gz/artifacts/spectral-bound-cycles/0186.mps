NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
COLUMNS
 x0 obj -1
 x0 r2 -1
 x0 r3 -1
 x0 r4 -1
 x1 obj -1
 x1 r4 -1
 x1 r5 -1
 x1 r6 -1
 x2 obj -1
 x2 r0 -1
 x2 r8 -1
 x2 r9 -1
 x2 r10 -1
 x3 obj -1
 x3 r6 -1
 x3 r7 -1
 x3 r8 -1
 x4 obj -1
 x4 r7 -1
 x4 r8 -1
 x4 r9 -1
 x5 obj -1
 x5 r0 -1
 x5 r1 -1
 x5 r9 -1
 x5 r10 -1
 x5 r11 -1
 x6 obj -1
 x6 r3 -1
 x6 r4 -1
 x6 r5 -1
 x7 obj -1
 x7 r1 -1
 x7 r2 -1
 x7 r3 -1
 x7 r11 -1
 x8 obj -1
 x8 r0 -1
 x8 r1 -1
 x8 r2 -1
 x8 r10 -1
 x8 r11 -1
 x9 obj -1
 x9 r5 -1
 x9 r6 -1
 x9 r7 -1
RHS
 rhs obj 0.625
 rhs r0 -1
 rhs r1 -1
 rhs r2 -1
 rhs r3 -1
 rhs r4 -1
 rhs r5 -1
 rhs r6 -1
 rhs r7 -1
 rhs r8 -1
 rhs r9 -1
 rhs r10 -1
 rhs r11 -1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
ENDATA
