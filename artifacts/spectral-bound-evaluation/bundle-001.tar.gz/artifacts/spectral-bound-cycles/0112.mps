NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
COLUMNS
 x0 obj -3
 x0 r0 2
 x0 r9 2
 x0 r10 2
 x0 r11 2
 x1 obj -3
 x1 r6 2
 x1 r7 2
 x1 r8 2
 x1 r9 2
 x2 obj -3
 x2 r3 2
 x2 r4 2
 x2 r5 2
 x2 r6 2
 x3 obj -3
 x3 r4 2
 x3 r5 2
 x3 r6 2
 x3 r7 2
 x4 obj -3
 x4 r8 2
 x4 r9 2
 x4 r10 2
 x4 r11 2
 x5 obj -3
 x5 r5 2
 x5 r6 2
 x5 r7 2
 x5 r8 2
 x6 obj -3
 x6 r1 2
 x6 r2 2
 x6 r3 2
 x6 r4 2
 x7 obj -3
 x7 r2 2
 x7 r3 2
 x7 r4 2
 x7 r5 2
 x8 obj -3
 x8 r0 2
 x8 r1 2
 x8 r2 2
 x8 r11 2
 x9 obj -3
 x9 r7 2
 x9 r8 2
 x9 r9 2
 x9 r10 2
 x10 obj -3
 x10 r0 2
 x10 r1 2
 x10 r10 2
 x10 r11 2
 x11 obj -3
 x11 r0 2
 x11 r1 2
 x11 r2 2
 x11 r3 2
RHS
 rhs obj -1.25
 rhs r0 2
 rhs r1 2
 rhs r2 2
 rhs r3 2
 rhs r4 2
 rhs r5 2
 rhs r6 2
 rhs r7 2
 rhs r8 2
 rhs r9 2
 rhs r10 2
 rhs r11 2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
ENDATA
