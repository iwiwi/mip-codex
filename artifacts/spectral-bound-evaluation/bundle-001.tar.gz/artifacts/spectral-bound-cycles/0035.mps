NAME cyclic
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
COLUMNS
 x0 obj 2
 x0 r0 1
 x0 r1 1
 x0 r2 1
 x0 r3 1
 x0 r10 1
 x0 r11 1
 x0 r12 1
 x0 r13 1
 x1 obj 2
 x1 r2 1
 x1 r3 1
 x1 r4 1
 x1 r5 1
 x1 r6 1
 x1 r13 1
 x2 obj 2
 x2 r6 1
 x2 r7 1
 x2 r8 1
 x2 r9 1
 x2 r10 1
 x3 obj 2
 x3 r0 1
 x3 r1 1
 x3 r8 1
 x3 r9 1
 x3 r10 1
 x3 r11 1
 x3 r12 1
 x4 obj 2
 x4 r0 1
 x4 r1 1
 x4 r2 1
 x4 r3 1
 x4 r4 1
 x4 r11 1
 x4 r12 1
 x4 r13 1
 x5 obj 2
 x5 r1 1
 x5 r2 1
 x5 r3 1
 x5 r4 1
 x5 r5 1
 x5 r12 1
 x5 r13 1
 x6 obj 2
 x6 r3 1
 x6 r4 1
 x6 r5 1
 x6 r6 1
 x6 r7 1
 x7 obj 2
 x7 r4 1
 x7 r5 1
 x7 r6 1
 x7 r7 1
 x7 r8 1
 x8 obj 2
 x8 r0 1
 x8 r7 1
 x8 r8 1
 x8 r9 1
 x8 r10 1
 x8 r11 1
 x9 obj 2
 x9 r5 1
 x9 r6 1
 x9 r7 1
 x9 r8 1
 x9 r9 1
 x10 obj 2
 x10 r0 1
 x10 r1 1
 x10 r2 1
 x10 r9 1
 x10 r10 1
 x10 r11 1
 x10 r12 1
 x10 r13 1
RHS
 rhs obj 1.875
 rhs r0 1
 rhs r1 1
 rhs r2 1
 rhs r3 1
 rhs r4 1
 rhs r5 1
 rhs r6 1
 rhs r7 1
 rhs r8 1
 rhs r9 1
 rhs r10 1
 rhs r11 1
 rhs r12 1
 rhs r13 1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
ENDATA
