NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
COLUMNS
 x0 obj -2
 x0 r0 2
 x0 r1 2
 x0 r7 2
 x0 r8 2
 x1 obj -2
 x1 r0 2
 x1 r1 2
 x1 r2 2
 x1 r3 2
 x2 obj -2
 x2 r3 2
 x2 r4 2
 x2 r5 2
 x2 r6 2
 x3 obj -2
 x3 r2 2
 x3 r3 2
 x3 r4 2
 x3 r5 2
 x4 obj -2
 x4 r4 2
 x4 r5 2
 x4 r6 2
 x4 r7 2
 x5 obj -2
 x5 r5 2
 x5 r6 2
 x5 r7 2
 x5 r8 2
 x6 obj -2
 x6 r0 2
 x6 r1 2
 x6 r2 2
 x6 r8 2
 x7 obj -2
 x7 r1 2
 x7 r2 2
 x7 r3 2
 x7 r4 2
 x8 obj -2
 x8 r0 2
 x8 r6 2
 x8 r7 2
 x8 r8 2
RHS
 rhs obj 1.875
 rhs r0 2
 rhs r1 2
 rhs r2 2
 rhs r3 2
 rhs r4 2
 rhs r5 2
 rhs r6 2
 rhs r7 2
 rhs r8 2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
ENDATA
