NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
COLUMNS
 x0 obj -3
 x0 r2 2
 x0 r3 2
 x0 r4 2
 x1 obj -3
 x1 r0 2
 x1 r1 2
 x1 r6 2
 x2 obj -3
 x2 r3 2
 x2 r4 2
 x2 r5 2
 x3 obj -3
 x3 r4 2
 x3 r5 2
 x3 r6 2
 x4 obj -3
 x4 r0 2
 x4 r1 2
 x4 r2 2
 x5 obj -3
 x5 r0 2
 x5 r5 2
 x5 r6 2
 x6 obj -3
 x6 r1 2
 x6 r2 2
 x6 r3 2
RHS
 rhs obj -1.375
 rhs r0 2
 rhs r1 2
 rhs r2 2
 rhs r3 2
 rhs r4 2
 rhs r5 2
 rhs r6 2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
ENDATA
