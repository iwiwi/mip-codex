NAME cyclic
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
COLUMNS
 x0 obj 4
 x0 r0 -3
 x0 r1 -3
 x0 r10 -3
 x0 r11 -3
 x1 obj 4
 x1 r6 -3
 x1 r7 -3
 x1 r8 -3
 x2 obj 4
 x2 r8 -3
 x2 r9 -3
 x2 r10 -3
 x3 obj 4
 x3 r1 -3
 x3 r2 -3
 x3 r3 -3
 x4 obj 4
 x4 r3 -3
 x4 r4 -3
 x4 r5 -3
 x5 obj 4
 x5 r0 -3
 x5 r1 -3
 x5 r2 -3
 x5 r11 -3
 x6 obj 4
 x6 r7 -3
 x6 r8 -3
 x6 r9 -3
 x7 obj 4
 x7 r2 -3
 x7 r3 -3
 x7 r4 -3
 x8 obj 4
 x8 r5 -3
 x8 r6 -3
 x8 r7 -3
 x9 obj 4
 x9 r4 -3
 x9 r5 -3
 x9 r6 -3
 x10 obj 4
 x10 r0 -3
 x10 r9 -3
 x10 r10 -3
 x10 r11 -3
RHS
 rhs obj -0.5
 rhs r0 -3
 rhs r1 -3
 rhs r2 -3
 rhs r3 -3
 rhs r4 -3
 rhs r5 -3
 rhs r6 -3
 rhs r7 -3
 rhs r8 -3
 rhs r9 -3
 rhs r10 -3
 rhs r11 -3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
ENDATA
