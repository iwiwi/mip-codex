NAME cyclic
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
COLUMNS
 x0 obj 4
 x0 r5 3
 x0 r6 3
 x0 r7 3
 x1 obj 4
 x1 r0 3
 x1 r1 3
 x1 r2 3
 x1 r9 3
 x2 obj 4
 x2 r1 3
 x2 r2 3
 x2 r3 3
 x3 obj 4
 x3 r4 3
 x3 r5 3
 x3 r6 3
 x4 obj 4
 x4 r3 3
 x4 r4 3
 x4 r5 3
 x5 obj 4
 x5 r0 3
 x5 r1 3
 x5 r8 3
 x5 r9 3
 x6 obj 4
 x6 r2 3
 x6 r3 3
 x6 r4 3
 x7 obj 4
 x7 r0 3
 x7 r7 3
 x7 r8 3
 x7 r9 3
 x8 obj 4
 x8 r6 3
 x8 r7 3
 x8 r8 3
RHS
 rhs obj 0.625
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
 rhs r6 3
 rhs r7 3
 rhs r8 3
 rhs r9 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
ENDATA
