NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
COLUMNS
 x0 obj -4
 x0 r0 -1
 x0 r9 -1
 x0 r10 -1
 x1 obj -4
 x1 r7 -1
 x1 r8 -1
 x1 r9 -1
 x2 obj -4
 x2 r1 -1
 x2 r2 -1
 x2 r3 -1
 x3 obj -4
 x3 r0 -1
 x3 r1 -1
 x3 r2 -1
 x4 obj -4
 x4 r4 -1
 x4 r5 -1
 x4 r6 -1
 x5 obj -4
 x5 r2 -1
 x5 r3 -1
 x5 r4 -1
 x6 obj -4
 x6 r6 -1
 x6 r7 -1
 x6 r8 -1
 x7 obj -4
 x7 r0 -1
 x7 r1 -1
 x7 r10 -1
 x8 obj -4
 x8 r5 -1
 x8 r6 -1
 x8 r7 -1
 x9 obj -4
 x9 r8 -1
 x9 r9 -1
 x9 r10 -1
 x10 obj -4
 x10 r3 -1
 x10 r4 -1
 x10 r5 -1
RHS
 rhs obj -0.875
 rhs r0 -1
 rhs r1 -1
 rhs r2 -1
 rhs r3 -1
 rhs r4 -1
 rhs r5 -1
 rhs r6 -1
 rhs r7 -1
 rhs r8 -1
 rhs r9 -1
 rhs r10 -1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
ENDATA
