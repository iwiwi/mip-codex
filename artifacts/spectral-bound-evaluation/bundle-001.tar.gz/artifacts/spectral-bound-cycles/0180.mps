NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
COLUMNS
 x0 obj -3
 x0 r1 -3
 x0 r2 -3
 x0 r3 -3
 x1 obj -3
 x1 r4 -3
 x1 r5 -3
 x1 r6 -3
 x2 obj -3
 x2 r9 -3
 x2 r10 -3
 x2 r11 -3
 x3 obj -3
 x3 r3 -3
 x3 r4 -3
 x3 r5 -3
 x4 obj -3
 x4 r8 -3
 x4 r9 -3
 x4 r10 -3
 x5 obj -3
 x5 r0 -3
 x5 r1 -3
 x5 r11 -3
 x6 obj -3
 x6 r5 -3
 x6 r6 -3
 x6 r7 -3
 x7 obj -3
 x7 r0 -3
 x7 r1 -3
 x7 r2 -3
 x8 obj -3
 x8 r2 -3
 x8 r3 -3
 x8 r4 -3
 x9 obj -3
 x9 r7 -3
 x9 r8 -3
 x9 r9 -3
 x10 obj -3
 x10 r0 -3
 x10 r10 -3
 x10 r11 -3
 x11 obj -3
 x11 r6 -3
 x11 r7 -3
 x11 r8 -3
RHS
 rhs obj 0.0
 rhs r0 -3
 rhs r1 -3
 rhs r2 -3
 rhs r3 -3
 rhs r4 -3
 rhs r5 -3
 rhs r6 -3
 rhs r7 -3
 rhs r8 -3
 rhs r9 -3
 rhs r10 -3
 rhs r11 -3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
ENDATA
