NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
COLUMNS
 x0 obj -3
 x0 r9 -1
 x0 r10 -1
 x0 r11 -1
 x1 obj -3
 x1 r1 -1
 x1 r2 -1
 x1 r3 -1
 x2 obj -3
 x2 r0 -1
 x2 r1 -1
 x2 r2 -1
 x3 obj -3
 x3 r0 -1
 x3 r1 -1
 x3 r11 -1
 x4 obj -3
 x4 r5 -1
 x4 r6 -1
 x4 r7 -1
 x5 obj -3
 x5 r6 -1
 x5 r7 -1
 x5 r8 -1
 x6 obj -3
 x6 r0 -1
 x6 r10 -1
 x6 r11 -1
 x7 obj -3
 x7 r2 -1
 x7 r3 -1
 x7 r4 -1
 x8 obj -3
 x8 r7 -1
 x8 r8 -1
 x8 r9 -1
 x9 obj -3
 x9 r4 -1
 x9 r5 -1
 x9 r6 -1
 x10 obj -3
 x10 r8 -1
 x10 r9 -1
 x10 r10 -1
 x11 obj -3
 x11 r3 -1
 x11 r4 -1
 x11 r5 -1
RHS
 rhs obj 1.0
 rhs r0 -1
 rhs r1 -1
 rhs r2 -1
 rhs r3 -1
 rhs r4 -1
 rhs r5 -1
 rhs r6 -1
 rhs r7 -1
 rhs r8 -1
 rhs r9 -1
 rhs r10 -1
 rhs r11 -1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
ENDATA
