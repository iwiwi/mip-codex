NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
COLUMNS
 x0 obj -1
 x0 r7 2
 x0 r8 2
 x0 r9 2
 x0 r10 2
 x0 r11 2
 x1 obj -1
 x1 r0 2
 x1 r8 2
 x1 r9 2
 x1 r10 2
 x1 r11 2
 x1 r12 2
 x2 obj -1
 x2 r0 2
 x2 r1 2
 x2 r9 2
 x2 r10 2
 x2 r11 2
 x2 r12 2
 x2 r13 2
 x3 obj -1
 x3 r0 2
 x3 r1 2
 x3 r2 2
 x3 r3 2
 x3 r4 2
 x3 r12 2
 x3 r13 2
 x4 obj -1
 x4 r4 2
 x4 r5 2
 x4 r6 2
 x4 r7 2
 x4 r8 2
 x5 obj -1
 x5 r1 2
 x5 r2 2
 x5 r3 2
 x5 r4 2
 x5 r5 2
 x5 r13 2
 x6 obj -1
 x6 r3 2
 x6 r4 2
 x6 r5 2
 x6 r6 2
 x6 r7 2
 x7 obj -1
 x7 r6 2
 x7 r7 2
 x7 r8 2
 x7 r9 2
 x7 r10 2
 x8 obj -1
 x8 r0 2
 x8 r1 2
 x8 r2 2
 x8 r3 2
 x8 r11 2
 x8 r12 2
 x8 r13 2
 x9 obj -1
 x9 r5 2
 x9 r6 2
 x9 r7 2
 x9 r8 2
 x9 r9 2
 x10 obj -1
 x10 r2 2
 x10 r3 2
 x10 r4 2
 x10 r5 2
 x10 r6 2
 x11 obj -1
 x11 r0 2
 x11 r1 2
 x11 r2 2
 x11 r10 2
 x11 r11 2
 x11 r12 2
 x11 r13 2
RHS
 rhs obj -1.75
 rhs r0 2
 rhs r1 2
 rhs r2 2
 rhs r3 2
 rhs r4 2
 rhs r5 2
 rhs r6 2
 rhs r7 2
 rhs r8 2
 rhs r9 2
 rhs r10 2
 rhs r11 2
 rhs r12 2
 rhs r13 2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
 BV b x11
ENDATA
