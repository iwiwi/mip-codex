NAME cyclic
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
COLUMNS
 x0 obj 4
 x0 r4 3
 x0 r5 3
 x0 r6 3
 x0 r7 3
 x0 r8 3
 x1 obj 4
 x1 r1 3
 x1 r2 3
 x1 r3 3
 x1 r4 3
 x1 r5 3
 x2 obj 4
 x2 r3 3
 x2 r4 3
 x2 r5 3
 x2 r6 3
 x2 r7 3
 x3 obj 4
 x3 r5 3
 x3 r6 3
 x3 r7 3
 x3 r8 3
 x3 r9 3
 x4 obj 4
 x4 r0 3
 x4 r6 3
 x4 r7 3
 x4 r8 3
 x4 r9 3
 x4 r10 3
 x5 obj 4
 x5 r0 3
 x5 r1 3
 x5 r7 3
 x5 r8 3
 x5 r9 3
 x5 r10 3
 x6 obj 4
 x6 r0 3
 x6 r1 3
 x6 r2 3
 x6 r3 3
 x6 r4 3
 x6 r10 3
 x7 obj 4
 x7 r2 3
 x7 r3 3
 x7 r4 3
 x7 r5 3
 x7 r6 3
 x8 obj 4
 x8 r0 3
 x8 r1 3
 x8 r2 3
 x8 r8 3
 x8 r9 3
 x8 r10 3
 x9 obj 4
 x9 r0 3
 x9 r1 3
 x9 r2 3
 x9 r3 3
 x9 r9 3
 x9 r10 3
RHS
 rhs obj -1.25
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
 rhs r6 3
 rhs r7 3
 rhs r8 3
 rhs r9 3
 rhs r10 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
ENDATA
