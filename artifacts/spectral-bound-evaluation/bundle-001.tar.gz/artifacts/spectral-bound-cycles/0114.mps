NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
COLUMNS
 x0 obj -3
 x0 r5 -3
 x0 r6 -3
 x0 r7 -3
 x1 obj -3
 x1 r3 -3
 x1 r4 -3
 x1 r5 -3
 x2 obj -3
 x2 r0 -3
 x2 r1 -3
 x2 r2 -3
 x2 r9 -3
 x2 r10 -3
 x3 obj -3
 x3 r2 -3
 x3 r3 -3
 x3 r4 -3
 x4 obj -3
 x4 r6 -3
 x4 r7 -3
 x4 r8 -3
 x5 obj -3
 x5 r0 -3
 x5 r1 -3
 x5 r8 -3
 x5 r9 -3
 x5 r10 -3
 x6 obj -3
 x6 r1 -3
 x6 r2 -3
 x6 r3 -3
 x6 r10 -3
 x7 obj -3
 x7 r0 -3
 x7 r7 -3
 x7 r8 -3
 x7 r9 -3
 x8 obj -3
 x8 r4 -3
 x8 r5 -3
 x8 r6 -3
RHS
 rhs obj 0.75
 rhs r0 -3
 rhs r1 -3
 rhs r2 -3
 rhs r3 -3
 rhs r4 -3
 rhs r5 -3
 rhs r6 -3
 rhs r7 -3
 rhs r8 -3
 rhs r9 -3
 rhs r10 -3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
ENDATA
