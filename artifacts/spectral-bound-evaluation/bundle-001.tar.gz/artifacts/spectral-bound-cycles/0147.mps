NAME cyclic
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
COLUMNS
 x0 obj 1
 x0 r3 -3
 x0 r4 -3
 x0 r5 -3
 x0 r6 -3
 x1 obj 1
 x1 r1 -3
 x1 r2 -3
 x1 r3 -3
 x1 r4 -3
 x1 r8 -3
 x1 r9 -3
 x2 obj 1
 x2 r0 -3
 x2 r1 -3
 x2 r5 -3
 x2 r6 -3
 x2 r7 -3
 x2 r8 -3
 x3 obj 1
 x3 r2 -3
 x3 r3 -3
 x3 r4 -3
 x3 r5 -3
 x3 r9 -3
 x4 obj 1
 x4 r0 -3
 x4 r1 -3
 x4 r2 -3
 x4 r6 -3
 x4 r7 -3
 x4 r8 -3
 x4 r9 -3
 x5 obj 1
 x5 r0 -3
 x5 r1 -3
 x5 r2 -3
 x5 r3 -3
 x5 r7 -3
 x5 r8 -3
 x5 r9 -3
 x6 obj 1
 x6 r0 -3
 x6 r4 -3
 x6 r5 -3
 x6 r6 -3
 x6 r7 -3
RHS
 rhs obj -0.5
 rhs r0 -3
 rhs r1 -3
 rhs r2 -3
 rhs r3 -3
 rhs r4 -3
 rhs r5 -3
 rhs r6 -3
 rhs r7 -3
 rhs r8 -3
 rhs r9 -3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
ENDATA
