NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
COLUMNS
 x0 obj -2
 x0 r0 -2
 x0 r1 -2
 x0 r7 -2
 x0 r8 -2
 x1 obj -2
 x1 r0 -2
 x1 r1 -2
 x1 r2 -2
 x1 r8 -2
 x2 obj -2
 x2 r4 -2
 x2 r5 -2
 x2 r6 -2
 x2 r7 -2
 x3 obj -2
 x3 r5 -2
 x3 r6 -2
 x3 r7 -2
 x3 r8 -2
 x4 obj -2
 x4 r1 -2
 x4 r2 -2
 x4 r3 -2
 x4 r4 -2
 x5 obj -2
 x5 r0 -2
 x5 r6 -2
 x5 r7 -2
 x5 r8 -2
 x6 obj -2
 x6 r2 -2
 x6 r3 -2
 x6 r4 -2
 x6 r5 -2
 x7 obj -2
 x7 r0 -2
 x7 r1 -2
 x7 r2 -2
 x7 r3 -2
 x8 obj -2
 x8 r3 -2
 x8 r4 -2
 x8 r5 -2
 x8 r6 -2
RHS
 rhs obj -1.375
 rhs r0 -2
 rhs r1 -2
 rhs r2 -2
 rhs r3 -2
 rhs r4 -2
 rhs r5 -2
 rhs r6 -2
 rhs r7 -2
 rhs r8 -2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
ENDATA
