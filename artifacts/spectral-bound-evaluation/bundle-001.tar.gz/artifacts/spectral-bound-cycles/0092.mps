NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
COLUMNS
 x0 obj -1
 x0 r2 1
 x0 r3 1
 x0 r4 1
 x0 r5 1
 x0 r6 1
 x1 obj -1
 x1 r1 1
 x1 r2 1
 x1 r3 1
 x1 r4 1
 x1 r5 1
 x2 obj -1
 x2 r0 1
 x2 r5 1
 x2 r6 1
 x2 r7 1
 x2 r8 1
 x3 obj -1
 x3 r4 1
 x3 r5 1
 x3 r6 1
 x3 r7 1
 x3 r8 1
 x4 obj -1
 x4 r0 1
 x4 r1 1
 x4 r2 1
 x4 r3 1
 x4 r4 1
 x5 obj -1
 x5 r0 1
 x5 r1 1
 x5 r2 1
 x5 r3 1
 x5 r8 1
 x6 obj -1
 x6 r0 1
 x6 r1 1
 x6 r2 1
 x6 r7 1
 x6 r8 1
 x7 obj -1
 x7 r3 1
 x7 r4 1
 x7 r5 1
 x7 r6 1
 x7 r7 1
 x8 obj -1
 x8 r0 1
 x8 r1 1
 x8 r6 1
 x8 r7 1
 x8 r8 1
RHS
 rhs obj -1.75
 rhs r0 1
 rhs r1 1
 rhs r2 1
 rhs r3 1
 rhs r4 1
 rhs r5 1
 rhs r6 1
 rhs r7 1
 rhs r8 1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
ENDATA
