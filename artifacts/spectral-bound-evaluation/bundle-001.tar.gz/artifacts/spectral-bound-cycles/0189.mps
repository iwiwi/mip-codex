NAME cyclic
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
COLUMNS
 x0 obj 2
 x0 r2 -1
 x0 r3 -1
 x0 r4 -1
 x0 r5 -1
 x1 obj 2
 x1 r0 -1
 x1 r1 -1
 x1 r2 -1
 x1 r8 -1
 x1 r9 -1
 x2 obj 2
 x2 r4 -1
 x2 r5 -1
 x2 r6 -1
 x2 r7 -1
 x3 obj 2
 x3 r0 -1
 x3 r1 -1
 x3 r7 -1
 x3 r8 -1
 x3 r9 -1
 x4 obj 2
 x4 r0 -1
 x4 r6 -1
 x4 r7 -1
 x4 r8 -1
 x4 r9 -1
 x5 obj 2
 x5 r0 -1
 x5 r1 -1
 x5 r2 -1
 x5 r3 -1
 x5 r9 -1
 x6 obj 2
 x6 r5 -1
 x6 r6 -1
 x6 r7 -1
 x6 r8 -1
 x7 obj 2
 x7 r3 -1
 x7 r4 -1
 x7 r5 -1
 x7 r6 -1
 x8 obj 2
 x8 r1 -1
 x8 r2 -1
 x8 r3 -1
 x8 r4 -1
RHS
 rhs obj 0.875
 rhs r0 -1
 rhs r1 -1
 rhs r2 -1
 rhs r3 -1
 rhs r4 -1
 rhs r5 -1
 rhs r6 -1
 rhs r7 -1
 rhs r8 -1
 rhs r9 -1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
ENDATA
