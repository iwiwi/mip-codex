NAME cyclic
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
COLUMNS
 x0 obj -3
 x0 r7 3
 x0 r8 3
 x0 r9 3
 x1 obj -3
 x1 r1 3
 x1 r2 3
 x1 r3 3
 x1 r12 3
 x2 obj -3
 x2 r4 3
 x2 r5 3
 x2 r6 3
 x3 obj -3
 x3 r3 3
 x3 r4 3
 x3 r5 3
 x4 obj -3
 x4 r0 3
 x4 r1 3
 x4 r2 3
 x4 r11 3
 x4 r12 3
 x5 obj -3
 x5 r5 3
 x5 r6 3
 x5 r7 3
 x6 obj -3
 x6 r8 3
 x6 r9 3
 x6 r10 3
 x7 obj -3
 x7 r0 3
 x7 r1 3
 x7 r10 3
 x7 r11 3
 x7 r12 3
 x8 obj -3
 x8 r2 3
 x8 r3 3
 x8 r4 3
 x9 obj -3
 x9 r6 3
 x9 r7 3
 x9 r8 3
 x10 obj -3
 x10 r0 3
 x10 r9 3
 x10 r10 3
 x10 r11 3
RHS
 rhs obj -1.5
 rhs r0 3
 rhs r1 3
 rhs r2 3
 rhs r3 3
 rhs r4 3
 rhs r5 3
 rhs r6 3
 rhs r7 3
 rhs r8 3
 rhs r9 3
 rhs r10 3
 rhs r11 3
 rhs r12 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
 BV b x9
 BV b x10
ENDATA
