from pathlib import Path
from fractions import Fraction as F
import json,sys,struct,math
root=Path.cwd();sys.path.insert(0,'scripts');from verify_cover_cuts import exact_model;from benchmark_common import atomic_json,sha256
model=root/'data/raw/benchmark/leo1.mps.gz';names,variables,rows,objective,offset=exact_model(model,True);by={n:i for i,n in enumerate(names)};occurrence={n:0 for n in names}
for row in rows:
 for n,a in row['coefficients'].items():occurrence[n]+=a!=0
out=root/'artifacts/exact-lp-singleton-projection';out.mkdir();records=[]
for p in sorted((root/'artifacts/exact-lp-point-diagnostic-run/diagnostic').glob('failed-point.*.json')):
 d=json.load(open(p));assert d['source_matches'];x=[struct.unpack('>d',bytes.fromhex(v))[0]for v in d['point_bits']];original=list(x)
 for row in rows:
  if row['lower']is None or row['lower']!=row['upper']:continue
  for name,a in row['coefficients'].items():
   v=variables[name];j=by[name]
   if a not in [1,-1]or v['integer']or v['lower']is not None or v['upper']is not None or occurrence[name]!=1:continue
   # Independent diagnostics of the proposed binary-coefficient projection.
   total=sum((F(float(c))*F(x[by[n]])for n,c in row['coefficients'].items()if n!=name),F(0));value=float((F(float(row['lower']))-total)/F(float(a)));assert math.isfinite(value);candidate=list(x);candidate[j]=value;values=dict(zip(names,map(F,candidate)));violations=[];maximum=F(0)
   for check in rows:
    activity=sum((c*values[n]for n,c in check['coefficients'].items()),F(0));bad=max(F(0),check['lower']-activity if check['lower']is not None else F(0),activity-check['upper']if check['upper']is not None else F(0));maximum=max(maximum,bad)
    if bad>F(1,10**6):violations.append(dict(row=check['name'],violation=str(bad)))
   node_bad=max(F(0),F(d['node_lower'][j])-F(value)if d['node_lower'][j]is not None else F(0),F(value)-F(d['node_upper'][j])if d['node_upper'][j]is not None else F(0));record=dict(file=p.name,row=row['name'],variable=name,index=j,before=original[j],after=value,change=value-original[j],max_exact_original_row_violation=str(maximum),node_bound_violation=str(node_bad),node_bounds=[d['node_lower'][j],d['node_upper'][j]],valid_relaxation_point=not violations and node_bad<=F(1,10**6),violations=violations,purpose='diagnostic arithmetic only; not an integer feasible solution or optimality proof; never fed to solver');records.append(record);atomic_json(out/(p.name+'.projection.json'),dict(record=record,point_bits=[struct.pack('>d',v).hex()for v in candidate],input_sha256=sha256(model)))
atomic_json(out/'summary.json',dict(projections=len(records),records=records,point_transfer=False));print(json.dumps(records))
