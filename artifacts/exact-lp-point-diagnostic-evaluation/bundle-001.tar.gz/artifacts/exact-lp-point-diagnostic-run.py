from pathlib import Path
import os,sys,json,resource,subprocess,time,signal
root=Path.cwd();os.sched_setaffinity(0,{40});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,)*2);sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256;from verify_cover_cuts import validate_cut_proofs
out=root/'artifacts/exact-lp-point-diagnostic-run';out.mkdir();model=root/'data/raw/benchmark/leo1.mps.gz';records=[]
for label,binary in [('before',Path('/home/ubuntu/mip-ranged-rhs-interval/artifacts/ranged-rhs-lazy-frozen/bin/mip-codex')),('diagnostic',root/'artifacts/exact-lp-point-diagnostic-frozen/bin/mip-codex')]:
 d=out/label;d.mkdir();env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_RHS_INTERVAL_PAIRS='1',MIP_LP_TRACE='1')
 if label=='diagnostic':env['MIP_ORIGINAL_LP_POINT_DUMP']=str(d/'failed-point')
 cmd=[str(binary),'solve',str(model),'10'];atomic_json(d/'job.json',dict(command=cmd,input_sha256=sha256(model),binary_sha256=sha256(binary),cpu=40,threads=1,memory_bytes=16*1024**3,seconds=10,watchdog=70,environment={k:v for k,v in env.items()if k.startswith('MIP_')},purpose='failure point capture only, no optimization change and no point transfer'));start=time.monotonic();watchdog=False
 with(d/'stdout.log').open('w')as so,(d/'stderr.log').open('w')as se:
  p=subprocess.Popen(cmd,stdout=so,stderr=se,env=env,start_new_session=True)
  try:p.wait(timeout=70)
  except subprocess.TimeoutExpired:watchdog=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
 atomic_json(d/'execution.json',dict(exit_code=p.returncode,watchdog=watchdog,wall_seconds=time.monotonic()-start));assert p.returncode==0 and not watchdog;r=json.load(open(d/'stdout.log'));atomic_json(d/'result.json',r);proof=validate_cut_proofs(model,r);atomic_json(d/'proof.json',proof);assert proof['valid']is True;records.append(dict(label=label,**{k:r.get(k)for k in ['status','objective','dual_bound','nodes','lp_rhs_interval_pairs']},proof_valid=True,dumps=len(list(d.glob('failed-point.*.json')))));atomic_json(out/'records.json',records)
atomic_json(out/'exit.json',dict(status='complete',records=records));print(json.dumps(records))
