from pathlib import Path
from fractions import Fraction as F
import json,sys,math,struct,hashlib
root=Path.cwd();sys.path.insert(0,'scripts');from verify_cover_cuts import exact_model;from benchmark_common import atomic_json,sha256
model=root/'data/raw/benchmark/leo1.mps.gz';names,variables,rows,objective,offset=exact_model(model,True);tol=F(1,10**6);out=root/'artifacts/exact-lp-point-audit';out.mkdir();records=[]
for p in sorted((root/'artifacts/exact-lp-point-diagnostic-run/diagnostic').glob('failed-point.*.json')):
 d=json.load(open(p));assert len(names)==d['variables'];assert len(rows)==d['original_rows']
 if not d['source_matches']:records.append(dict(file=p.name,source_matches=False,verdict='not audited against original model'));continue
 x=[struct.unpack('>d',bytes.fromhex(v))[0]for v in d['point_bits']];assert all(map(math.isfinite,x));modes={'binary':[F(v)for v in x],'short_decimal':[F(int(v))if v.is_integer()else F(str(v))for v in x]};audits={}
 for mode,values in modes.items():
  values=dict(zip(names,values));violations=[];maxrow=F(0);maxbound=F(0);details=[]
  for i,name in enumerate(names):
   v=variables[name];z=values[name];bad=max(F(0),v['lower']-z if v['lower']is not None else F(0),z-v['upper']if v['upper']is not None else F(0));maxbound=max(maxbound,bad)
   if bad>tol:violations.append(dict(variable=name,violation=str(bad)))
  for row in rows:
   a=sum((c*values[n]for n,c in row['coefficients'].items()),F(0));bad=max(F(0),row['lower']-a if row['lower']is not None else F(0),a-row['upper']if row['upper']is not None else F(0));maxrow=max(maxrow,bad);details.append(dict(name=row['name'],activity=str(a),lower=str(row['lower'])if row['lower']is not None else None,upper=str(row['upper'])if row['upper']is not None else None,violation=str(bad)))
   if bad>tol:violations.append(dict(row=row['name'],violation=str(bad)))
  audits[mode]=dict(valid_relaxation_point=not violations,tolerance=str(tol),max_row_violation=str(maxrow),max_bound_violation=str(maxbound),violations=violations,rows=details)
 atomic_json(out/(p.name+'.audit.json'),dict(source_sha256=sha256(p),input_sha256=sha256(model),purpose='LP relaxation point only; no integrality or global bound claim',audits=audits));records.append(dict(file=p.name,source_matches=True,node=d['node'],error=d['error'],audits={k:{z:v[z]for z in ['valid_relaxation_point','max_row_violation','max_bound_violation','violations']}for k,v in audits.items()}))
assert records,'no failure point captured';atomic_json(out/'summary.json',dict(points=len(records),records=records,reference_point_transfer=False));print(json.dumps(dict(points=len(records),records=records)))
