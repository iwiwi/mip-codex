from pathlib import Path
import sys,os,json,argparse,hashlib,subprocess
sys.path.insert(0,'scripts');import benchmark
root=Path.cwd();assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='c7888a44a18b0bf9c63f7b7097cc6ebf15550408';assert json.load(open('artifacts/spectral-bound-main-primary-audit/exit.json'))['gmp_valid']==3
oldpath=root/'artifacts/runs/cover-portfolio-final-20261118/config.json';assert hashlib.sha256(oldpath.read_bytes()).hexdigest()=='faae57bdeaea22cb60f3d046c53a83681acd4a14f47895c94f7b3f35b8d4f007';old=json.load(open(oldpath));destination=root/'artifacts/runs/spectral-bound-final-20261118';assert not destination.exists();solvers=sorted({j['solver']for j in old['jobs']});assert solvers==['rust'];original=benchmark.require_solver_origin
def pinned_origin(*a,**kw):
 # CPU availability is checked by create() before this hook pins hashing/copying.
 os.sched_setaffinity(0,{43});info=original(*a,**kw);assert info['source_fingerprint']==info['library_source_fingerprint']=='e5dfb6151bba081e';return info
benchmark.require_solver_origin=pinned_origin
benchmark.create(argparse.Namespace(directory=str(destination),seconds=old['seconds'],cores=','.join(map(str,old['cores'])),solvers=','.join(solvers),manifest=str(root/'data/manifest.json'),names=None,allow_dirty=False))
