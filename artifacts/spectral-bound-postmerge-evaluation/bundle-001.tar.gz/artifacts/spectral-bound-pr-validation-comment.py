from pathlib import Path
import os,json,subprocess,sys
os.sched_setaffinity(0,{43});root=Path.cwd();sys.path.insert(0,'scripts');from benchmark_common import require_solver_origin
assert require_solver_origin(root,root/'target/release/mip-codex')['source_fingerprint']=='e5dfb6151bba081e'
assert json.load(open('artifacts/spectral-bound-main-controls/exit.json'))['gmp_valid']==8
for prefix in ['spectral-bound','spectral-bound-default']:
 assert json.load(open('artifacts/'+prefix+'-test-summary.json'))==dict(passed=346,failed=0,ignored=4)
 assert json.load(open('artifacts/'+prefix+'-graph-oracle/summary.json'))['failures']==0
 assert json.load(open('artifacts/'+prefix+'-generated/summary.json'))['gmp_valid']==600
 assert json.load(open('artifacts/'+prefix+'-cycles/summary.json'))['gmp_valid']==600
text='''初期本体78f449d595/FPbb1e47d94be27422と、既定有効候補8a959e1ce1/FPe5dfb6151bba081eを別凍結しました。両者のRust差分はLimitsの2つの既定boolだけです。mainへの統合はまだ行わず、188件と全出力監査の完了を待ちます。

同一凍結CLIの両0/両1・CPU45・1thread・16GiBでcod105は10秒/60秒とも従来−12/−37/time_limit、候補は−12/−12/optimal、0探索節点、0.020694419/0.020832658秒。補助自作Rust LPは1回13pivotですが、その近似状態を証明へ転用せず、量子化した行列の非辺符号と全整数固有値D=88429880,L=−1048580から独立に上界12を検証しました。元MPSのGMP点検査も成功し、rootでの独立最適性証明です。既定有効候補をCPU44で両0/フラグ未設定にしても0.020658109/0.020688249秒を再現しました。報告solver時間であり、CLIの壁時計も実行JSONに保持しています。

初期sorrell3は両optimal−16、6042153節点、19.421961/19.399934秒。240件外のsorrell7は180秒で両主解−198/双対−241、23597041/23631537節点。初期8点GMP・8出力独立root/prefix/被覆/スペクトル検査が成功。sorrell3の完了探索木自体は全再生せず、cod105と区別します。sorrell7は公開最良と同値で新記録ではありません。

60秒cod105のnative比較（CPU46・1thread・16GiB、既存の新規比較をSHA確認して再利用）はHiGHS1.16.0が−12/−16/time_limit、SCIP10.0.2が45.908415秒でoptimal−12、GLPK5.0が−12/−18、65.577798秒の超過も保持。全3点GMP成功。この1件の証明高速化を全体優位と扱いません。sorrell3と別枠sorrell7のnative資料も同入力SHA/driver一致を確認して保存しました。

初期・既定有効の双方で346 Rust成功/4ignored、各600生成モデル/2400出力の全列挙・元MPS証明・GMP成功。標準1200出力で7410改変拒否、Cayley600出力では実際のスペクトル証明75件/450改変拒否、循環600出力では元行被覆証明297件/1485改変拒否。原型の私的403整数証明/2421改変拒否も別archiveへ保存済みで、元行列・直接Walsh和を検査します。外部最適化への委譲はありません。

元行だけの先行成分、初期の統合候補、既定有効候補の188件比較を区別して実行しています。全376出力を毎回新規に監査し、点はGMP絶対1e−6と公式補助検査を行います。完了値を次のコメントへ追記します。試作統合scriptが複数行ifを検索できず、module未接続のまま旧lib検査を走らせた失敗も保持し、接続後の129lib/346全Rustと混同しません。'''
u=json.loads(subprocess.check_output(['python3','scripts/ai_usage.py'],text=True));Path('artifacts/spectral-bound-pr-validation-ai-usage.json').write_text(json.dumps(u,ensure_ascii=False,indent=2));t=u['totals'];text+=f"\n\nAI使用量（直前ローカル最終累積、{u['sessions']} sessions）: total {t['total_tokens']:,}, input {t['input_tokens']:,}（cached {t['cached_input_tokens']:,}を含む）, output {t['output_tokens']:,}（reasoning {t['reasoning_output_tokens']:,}を含む）。内数の二重加算なし。\n";p=Path('artifacts/spectral-bound-pr-validation-comment.txt');p.write_text(text);r=subprocess.run(['gh','pr','comment','126','--repo','iwiwi/mip-codex','--body-file',str(p)],capture_output=True,text=True);Path('artifacts/spectral-bound-pr-validation-comment.log').write_text(r.stdout+r.stderr);r.check_returncode();print(r.stdout)
