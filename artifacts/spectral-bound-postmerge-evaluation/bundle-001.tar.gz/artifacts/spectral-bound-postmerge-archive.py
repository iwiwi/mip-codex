from pathlib import Path
import json,subprocess,hashlib,tarfile,os,shutil
os.sched_setaffinity(0,{43});root=Path.cwd();other=Path('/home/ubuntu/mip-graph-spectral-bound')
for source in (other/'artifacts').iterdir():
 if source.is_file() and source.name.startswith(('spectral-bound-adopt','spectral-bound-pr-','spectral-bound-merge','spectral-bound-ready','spectral-bound-sparse-materialization')):
  destination=root/'artifacts'/source.name
  if destination.exists():assert destination.read_bytes()==source.read_bytes(),destination
  else:shutil.copy2(source,destination)
out=root/'artifacts/spectral-bound-postmerge-evaluation';assert not out.exists();a=json.load(open('artifacts/spectral-bound-main-primary-audit/exit.json'));assert a['outputs']==a['gmp_valid']==a['proof_valid']==3;assert 'issuecomment-'in Path('artifacts/spectral-bound-postmerge-comment.log').read_text();tracked=set(subprocess.check_output(['git','ls-files'],text=True).splitlines());roots=[p for p in(root/'artifacts').iterdir()if p.name.startswith('spectral-bound')and p!=out and p.name!='spectral-bound-postmerge-archive.log'];roots += [root/'artifacts/spectral-bound-main-primary-audit',root/'artifacts/runs/spectral-bound-final-20261118',root/'experiments/spectral-bound-snapshot-20261118.json',root/'artifacts/runs/cover-portfolio-final-20261118/config.json',root/'artifacts/runs/cover-portfolio-final-20261118/OBSOLETE.json'];files=sorted({f for p in roots for f in([p]if p.is_file()else p.rglob('*'))if f.is_file()and str(f.relative_to(root))not in tracked});manifest=[];excluded=[];groups=[];group=[];size=0
for f in files:
 b=f.read_bytes();r=dict(path=str(f.relative_to(root)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 if b[:4]==b'\x7fELF':excluded.append(r);continue
 manifest.append(r)
 if group and size+len(b)>90*1024**2:groups.append(group);group=[];size=0
 group.append(f);size+=len(b)
if group:groups.append(group)
out.mkdir()
for i,group in enumerate(groups,1):
 p=out/f'bundle-{i:03d}.tar.gz'
 with tarfile.open(p,'w:gz',compresslevel=6)as t:
  for f in group:t.add(f,arcname=str(f.relative_to(root)),recursive=False)
 assert p.stat().st_size<95*1024**2
lookup={r['path']:r for r in manifest};seen=set()
for p in sorted(out.glob('bundle-*.tar.gz')):
 with tarfile.open(p)as t:
  for m in t:
   assert m.name not in seen;seen.add(m.name);b=t.extractfile(m).read();r=lookup[m.name];assert len(b)==r['bytes']and hashlib.sha256(b).hexdigest()==r['sha256']
assert seen==set(lookup)
for r in excluded:assert hashlib.sha256((root/r['path']).read_bytes()).hexdigest()==r['sha256']
(out/'manifest.json').write_text(json.dumps(manifest,indent=2));(out/'excluded-elf.json').write_text(json.dumps(excluded,indent=2));s=dict(files=len(manifest),raw_bytes=sum(r['bytes']for r in manifest),compressed_bytes=sum(p.stat().st_size for p in out.glob('bundle-*.tar.gz')),bundles=len(groups),excluded_elf=len(excluded),all_payload_sha256_verified=True);(out/'summary.json').write_text(json.dumps(s,indent=2));print(json.dumps(s))
