from pathlib import Path
import os,sys,json,subprocess,tarfile,hashlib,time
root=Path.cwd();os.sched_setaffinity(0,{43});sys.path.insert(0,'scripts');from benchmark_common import require_solver_origin
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='07d6cb67267a4975e846e054d008f23fe267cd8d';assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no']);assert not subprocess.check_output(['git','diff','8a959e1ce1','HEAD','--','src','scripts','tests','Cargo.toml','Cargo.lock','build.rs']);assert require_solver_origin(root,root/'target/release/mip-codex')['source_fingerprint']=='e5dfb6151bba081e'
for prefix in ['spectral-bound','spectral-bound-default']:
 assert json.load(open('artifacts/'+prefix+'-test-summary.json'))==dict(passed=346,failed=0,ignored=4)
 a=json.load(open('artifacts/'+prefix+'-development-parallel-audit/summary.json'));assert a['completed']==376 and a['fresh']==376 and a['strict_valid']==a['official_valid']==128
 assert json.load(open('artifacts/'+prefix+'-main-controls/exit.json'))['gmp_valid']==8
 assert json.load(open('artifacts/'+prefix+'-graph-oracle/summary.json'))['failures']==0
 for suffix in ['generated','cycles']:assert json.load(open('artifacts/'+prefix+'-'+suffix+'/summary.json'))['gmp_valid']==600
assert json.load(open('artifacts/spectral-bound-configurations/summary.json'))['gmp_valid']==96
archives=[('spectral-bound-evaluation',root),('spectral-bound-default-evaluation',root),('input-cover-evaluation',Path('/home/ubuntu/mip-graph-input-cover')),('cayley-spectral-evaluation',Path('/home/ubuntu/mip-cayley-spectral-profile')),('color-repair-evaluation',Path('/home/ubuntu/mip-graph-color-repair')),('fractional-groups-evaluation',Path('/home/ubuntu/mip-adaptive-fractional-groups')),('orbit-research-evaluation',Path('/home/ubuntu/mip-complement-orbits')),('spectral-bound-configuration-evaluation',root)];verified=[]
for name,original in archives:
 d=root/'artifacts'/name;manifest=json.load(open(d/'manifest.json'));lookup={r['path']:r for r in manifest};seen=set();bundles={}
 for p in sorted(d.glob('bundle-*.tar.gz')):
  bundles[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
  with tarfile.open(p)as t:
   for m in t:
    assert m.isfile()and m.name not in seen;seen.add(m.name);b=t.extractfile(m).read();r=lookup[m.name];assert len(b)==r['bytes']and hashlib.sha256(b).hexdigest()==r['sha256']
 assert seen==set(lookup)
 excluded=json.load(open(d/'excluded-elf.json'))
 for r in excluded:assert hashlib.sha256((original/r['path']).read_bytes()).hexdigest()==r['sha256']
 verified.append(dict(archive=name,payloads=len(seen),bundles_sha256=bundles,retained_elf=len(excluded)))
Path('artifacts/spectral-bound-adoption-archive-verification.json').write_text(json.dumps(verified,indent=2));print('all8archives verified; retained ELF hashes valid',flush=True)
state=json.loads(subprocess.check_output(['gh','api','repos/iwiwi/mip-codex/pulls/126'],text=True));assert state['draft']and state['state']=='open'and state['head']['sha']==head and state['base']['sha']=='91f82c627525b83170f270d954650ab8a6e74a1a'
body='''packingの根上界が彩色だけでは弱かった問題を、元行クリークの整数被覆と整数スペクトルで改善します。厳密な構造照合後、自作Rust LPで重みを提案し、非辺の符号と全整数固有値で境界を再証明します。LPの近似可行性・最適性に依存せず、問題名・既知値も使いません。補助LPの回数/pivotをResultへ報告し、旧公開関数の動作を保ちます。

cod105は同じ凍結CLIの明示無効では10/60秒とも主解−12・双対−37で時間切れ、既定有効では約0.021秒・0探索節点・補助LP1回13pivotで独立にoptimal−12を証明。元MPSのGMP点検査と別Pythonの直接Walsh和検査に合格しました。同資源のnative60秒はHiGHS1.16.0 −12/−16、SCIP10.0.2は45.908415秒でoptimal−12、GLPK5.0 −12/−18（65.577798秒超過保持）、全3点GMP成功。

初期/既定有効の双方で346 Rust passed/4ignored、各600生成モデル2400出力の全列挙・元MPS証明・GMP成功。設定組合せ96出力も全成功。各188件の比較と376出力の新規監査を完了し、128点ずつGMP絶対/公式成功。最終既定有効は主解188同値、双対3改善/1悪化/171同値/13比較不能、最適1→2、shift1幾何平均9.860598→9.724130（未解10秒）。実際の新証明発動はcod105だけです。

初期の主解1/双対3悪化を集計から除かず、機能不発動ケースの反復24出力と60秒4出力も保存。60秒では主解/双対とも一致しました。sorrell3の証明ノード/時間と、240件外のsorrell7の主解−198/双対−241を維持。全体優位・新記録の主張ではなく、Benchmark v2全240の本実装評価はまだ未起動です。

初期/既定有効/成分/私的/不採用の証拠8セットを保存し、全payload SHA256と除外して元場所に保持したELFのSHAを再照合しました。詳細はdocs/GRAPH_SPECTRAL_BOUND_RESULTS.md、独立検査の手順はdocs/GRAPH_SPECTRAL_CERTIFICATE_VERIFICATION.md。'''
Path('artifacts/spectral-bound-pr-final-body.json').write_text(json.dumps(dict(title='packingの元行被覆と整数スペクトルで根上界を強化する',body=body),ensure_ascii=False));subprocess.run(['gh','api','--method','PATCH','repos/iwiwi/mip-codex/pulls/126','--input','artifacts/spectral-bound-pr-final-body.json'],stdout=subprocess.DEVNULL,check=True)
text='''採用確認を完了しました。最終head 07d6cb67267a4975e846e054d008f23fe267cd8d、optimizer core8a959e1ce1/FPe5dfb6151bba081e（初期core78f449d595/FPbb1e47d94be27422との差は既定bool2個だけ）。

最終development188×10秒は主解188同等、双対3改善/1悪化/171同等/13比較不能、有限175ずつ、最適1→2・time183→182・numerical4ずつ。shift1幾何平均9.860597743→9.724130380（未解10秒）。全376出力を新規独立監査し、全128点GMP絶対1e−6/公式成功。発動した新証明はcod105だけで、他の双対変化を機能の利益と主張しません。

初期188は主解187同/1悪、双対1改善/3悪化/171同/13比較不能、最適1→2。悪化を消しません。機能不発動のneos911970・neos1456979・seymour1・sp98arを各3対、全24証明/18点GMPで確認。主解低下とneos145の154→0は再現せず、seymourは双対が両方向、sp98は10秒では3対とも有効側が低い観測を保持。60秒の追加対照はsp98arが両640295597.76/524472090.3097024、neos911970が両140.59/23.259999999973406、全4点/4証明有効。両旗でgraph=Noneの同じ既存経路なので時間境界の変動が考えられますが、因果を断定して結果を除外しません。

最終cod105は10秒/60秒対照で無効が-12/-37/time_limit、有効が-12/-12/optimal、0節点、0.020658109/0.020688249秒、補助Rust LP1回13pivot。sorrell3は両6042153節点・19.361175/19.308766秒、別枠sorrell7は180秒で両-198/-241。最終8点/8出力証明はすべて有効。native比較も本文へ記載し、cod105の既知最適値の証明高速化と、全体優位/新記録を区別しています。

初期/最終とも346Rust成功/4ignored、各600生成モデル2400出力の全列挙/GMP/元MPS証明成功、各標準7410・循環1485・スペクトル450の改変を拒否。さらに3小モデル×5flag全32設定=96出力を全列挙/元MPS/GMPで確認し、実スペクトル証明32件・元行被覆32件を発動。初回driverが非2冪モデルへCayley専用guardを誤用して64件後に止まった失敗も保持、driverだけ修正して全96件を新規完了し、optimizer変更はありません。

初期archive11886 files/320627376B→42990776B（4bundle）、最終11986 files/300451784B→37638927B（4bundle）。初期/最終・元行成分・私的403証明・不採用の補充/彩色修復/軌道探索・設定検査の全8セットで、全tar payload SHA256と元場所へ保持したELF SHAを統合直前に再検証済み。未起動の旧最終snapshotは統合後に新sourceで置換します。mainへ統合し、primary再build・元点/証明再監査・create-only snapshotを確認します。全体優位・新記録は未達のため、元の期限まで研究を続けます。'''
u=json.loads(subprocess.check_output(['python3','scripts/ai_usage.py'],text=True));Path('artifacts/spectral-bound-adoption-ai-usage.json').write_text(json.dumps(u,ensure_ascii=False,indent=2));t=u['totals'];text+=f"\n\nAI使用量（直前ローカル最終累積、{u['sessions']} sessions）: total {t['total_tokens']:,}, input {t['input_tokens']:,}（cached {t['cached_input_tokens']:,}を含む）, output {t['output_tokens']:,}（reasoning {t['reasoning_output_tokens']:,}を含む）。内数の二重加算なし。\n";p=Path('artifacts/spectral-bound-adoption-comment.txt');p.write_text(text);r=subprocess.run(['gh','pr','comment','126','--repo','iwiwi/mip-codex','--body-file',str(p)],capture_output=True,text=True);Path('artifacts/spectral-bound-adoption-comment.log').write_text(r.stdout+r.stderr);r.check_returncode();print(r.stdout,flush=True)
for label,cmd in [('ready',['gh','pr','ready','126','--repo','iwiwi/mip-codex']),('merge',['gh','pr','merge','126','--repo','iwiwi/mip-codex','--squash','--match-head-commit',head])]:
 r=subprocess.run(cmd,capture_output=True,text=True);Path('artifacts/spectral-bound-'+label+'.log').write_text(r.stdout+r.stderr);r.check_returncode()
state=json.loads(subprocess.check_output(['gh','api','repos/iwiwi/mip-codex/pulls/126'],text=True));assert state['merged']is True and state['head']['sha']==head;record=dict(url=state['html_url'],state='MERGED',mergedAt=state['merged_at'],mergeCommit=dict(oid=state['merge_commit_sha']),headRefOid=head,source_fingerprint='e5dfb6151bba081e');Path('artifacts/spectral-bound-merged-state.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
