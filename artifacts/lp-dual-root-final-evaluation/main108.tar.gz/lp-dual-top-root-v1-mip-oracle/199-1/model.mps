NAME dom
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 L r3
 L r4
 L r5
 L r6
 L r7
 G r8
 L r9
 G r10
 L r11
 L r12
 L r13
 L r14
 L r15
 G r16
 L r17
 G r18
 L r19
 L r20
 L r21
 L r22
 L r23
 G r24
 L r25
 G r26
 L r27
 L r28
 L r29
 L r30
 L r31
 G r32
 L r33
 G r34
 L r35
 L r36
 L r37
 L r38
 L r39
COLUMNS
 x0 obj -3
 x0 r0 -3
 x0 r1 -2
 x0 r2 3
 x0 r3 2
 x0 r5 -2
 x0 r7 3
 x0 r8 -3
 x0 r9 -2
 x0 r10 3
 x0 r11 2
 x0 r13 -2
 x0 r15 3
 x0 r16 -3
 x0 r17 -2
 x0 r18 3
 x0 r19 2
 x0 r21 -2
 x0 r23 3
 x0 r24 -3
 x0 r25 -2
 x0 r26 3
 x0 r27 2
 x0 r29 -2
 x0 r31 3
 x0 r32 -3
 x0 r33 -2
 x0 r34 3
 x0 r35 2
 x0 r37 -2
 x0 r39 3
 x1 obj -3
 x1 r1 2
 x1 r2 2
 x1 r3 2
 x1 r5 2
 x1 r6 1
 x1 r9 2
 x1 r10 2
 x1 r11 2
 x1 r13 2
 x1 r14 1
 x1 r17 2
 x1 r18 2
 x1 r19 2
 x1 r21 2
 x1 r22 1
 x1 r25 2
 x1 r26 2
 x1 r27 2
 x1 r29 2
 x1 r30 1
 x1 r33 2
 x1 r34 2
 x1 r35 2
 x1 r37 2
 x1 r38 1
 x2 obj -9
 x2 r0 -1
 x2 r2 3
 x2 r3 3
 x2 r4 1
 x2 r5 3
 x2 r6 -2
 x2 r8 -1
 x2 r10 3
 x2 r11 3
 x2 r12 1
 x2 r13 3
 x2 r14 -2
 x2 r16 -1
 x2 r18 3
 x2 r19 3
 x2 r20 1
 x2 r21 3
 x2 r22 -2
 x2 r24 -1
 x2 r26 3
 x2 r27 3
 x2 r28 1
 x2 r29 3
 x2 r30 -2
 x2 r32 -1
 x2 r34 3
 x2 r35 3
 x2 r36 1
 x2 r37 3
 x2 r38 -2
 x3 obj 0
 x3 r3 -1
 x3 r5 -2
 x3 r7 -2
 x3 r11 -1
 x3 r13 -2
 x3 r15 -2
 x3 r19 -1
 x3 r21 -2
 x3 r23 -2
 x3 r27 -1
 x3 r29 -2
 x3 r31 -2
 x3 r35 -1
 x3 r37 -2
 x3 r39 -2
 x4 obj 0
 x4 r4 -1
 x4 r6 -2
 x4 r7 -2
 x4 r12 -1
 x4 r14 -2
 x4 r15 -2
 x4 r20 -1
 x4 r22 -2
 x4 r23 -2
 x4 r28 -1
 x4 r30 -2
 x4 r31 -2
 x4 r36 -1
 x4 r38 -2
 x4 r39 -2
RHS
 rhs obj -16
 rhs r0 -3
 rhs r1 2
 rhs r2 5
 rhs r3 6
 rhs r4 1
 rhs r5 0
 rhs r6 1
 rhs r7 3
 rhs r8 -3
 rhs r9 2
 rhs r10 5
 rhs r11 6
 rhs r12 1
 rhs r13 0
 rhs r14 1
 rhs r15 3
 rhs r16 -3
 rhs r17 2
 rhs r18 5
 rhs r19 6
 rhs r20 1
 rhs r21 0
 rhs r22 1
 rhs r23 3
 rhs r24 -3
 rhs r25 2
 rhs r26 5
 rhs r27 6
 rhs r28 1
 rhs r29 0
 rhs r30 1
 rhs r31 3
 rhs r32 -3
 rhs r33 2
 rhs r34 5
 rhs r35 6
 rhs r36 1
 rhs r37 0
 rhs r38 1
 rhs r39 3
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
