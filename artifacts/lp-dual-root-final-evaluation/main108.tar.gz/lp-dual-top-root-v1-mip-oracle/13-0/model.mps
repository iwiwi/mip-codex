NAME dom
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 L r4
 G r5
 L r6
 L r7
 G r8
 L r9
 G r10
 G r11
 L r12
 G r13
 L r14
 L r15
 G r16
 L r17
 G r18
 G r19
 L r20
 G r21
 L r22
 L r23
 G r24
 L r25
 G r26
 G r27
 L r28
 G r29
 L r30
 L r31
 G r32
 L r33
 G r34
 G r35
 L r36
 G r37
 L r38
 L r39
COLUMNS
 x0 obj 7
 x0 r0 2
 x0 r1 1
 x0 r2 2
 x0 r4 -2
 x0 r5 1
 x0 r6 -3
 x0 r7 3
 x0 r8 2
 x0 r9 1
 x0 r10 2
 x0 r12 -2
 x0 r13 1
 x0 r14 -3
 x0 r15 3
 x0 r16 2
 x0 r17 1
 x0 r18 2
 x0 r20 -2
 x0 r21 1
 x0 r22 -3
 x0 r23 3
 x0 r24 2
 x0 r25 1
 x0 r26 2
 x0 r28 -2
 x0 r29 1
 x0 r30 -3
 x0 r31 3
 x0 r32 2
 x0 r33 1
 x0 r34 2
 x0 r36 -2
 x0 r37 1
 x0 r38 -3
 x0 r39 3
 x1 obj 8
 x1 r2 -3
 x1 r3 -3
 x1 r4 1
 x1 r5 -3
 x1 r6 -1
 x1 r7 2
 x1 r10 -3
 x1 r11 -3
 x1 r12 1
 x1 r13 -3
 x1 r14 -1
 x1 r15 2
 x1 r18 -3
 x1 r19 -3
 x1 r20 1
 x1 r21 -3
 x1 r22 -1
 x1 r23 2
 x1 r26 -3
 x1 r27 -3
 x1 r28 1
 x1 r29 -3
 x1 r30 -1
 x1 r31 2
 x1 r34 -3
 x1 r35 -3
 x1 r36 1
 x1 r37 -3
 x1 r38 -1
 x1 r39 2
 x2 obj 9
 x2 r3 -1
 x2 r4 1
 x2 r5 -3
 x2 r6 1
 x2 r7 -3
 x2 r11 -1
 x2 r12 1
 x2 r13 -3
 x2 r14 1
 x2 r15 -3
 x2 r19 -1
 x2 r20 1
 x2 r21 -3
 x2 r22 1
 x2 r23 -3
 x2 r27 -1
 x2 r28 1
 x2 r29 -3
 x2 r30 1
 x2 r31 -3
 x2 r35 -1
 x2 r36 1
 x2 r37 -3
 x2 r38 1
 x2 r39 -3
 x3 obj 0
 x3 r3 2
 x3 r5 4
 x3 r7 -2
 x3 r11 2
 x3 r13 4
 x3 r15 -2
 x3 r19 2
 x3 r21 4
 x3 r23 -2
 x3 r27 2
 x3 r29 4
 x3 r31 -2
 x3 r35 2
 x3 r37 4
 x3 r39 -2
 x4 obj 0
 x4 r4 3
 x4 r6 6
 x4 r7 2
 x4 r12 3
 x4 r14 6
 x4 r15 2
 x4 r20 3
 x4 r22 6
 x4 r23 2
 x4 r28 3
 x4 r30 6
 x4 r31 2
 x4 r36 3
 x4 r38 6
 x4 r39 2
RHS
 rhs obj -3
 rhs r0 1
 rhs r1 1
 rhs r2 2
 rhs r3 0
 rhs r4 4
 rhs r5 2
 rhs r6 4
 rhs r7 0
 rhs r8 1
 rhs r9 1
 rhs r10 2
 rhs r11 0
 rhs r12 4
 rhs r13 2
 rhs r14 4
 rhs r15 0
 rhs r16 1
 rhs r17 1
 rhs r18 2
 rhs r19 0
 rhs r20 4
 rhs r21 2
 rhs r22 4
 rhs r23 0
 rhs r24 1
 rhs r25 1
 rhs r26 2
 rhs r27 0
 rhs r28 4
 rhs r29 2
 rhs r30 4
 rhs r31 0
 rhs r32 1
 rhs r33 1
 rhs r34 2
 rhs r35 0
 rhs r36 4
 rhs r37 2
 rhs r38 4
 rhs r39 0
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
