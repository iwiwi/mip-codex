NAME dom
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
COLUMNS
 x0 obj -9
 x0 r0 -2
 x0 r1 -2
 x0 r2 -1
 x0 r3 -1
 x0 r4 1
 x0 r5 -3
 x0 r6 -3
 x0 r7 3
 x0 r8 -2
 x0 r9 -2
 x0 r10 -1
 x0 r11 -1
 x0 r12 1
 x0 r13 -3
 x0 r14 -3
 x0 r15 3
 x0 r16 -2
 x0 r17 -2
 x0 r18 -1
 x0 r19 -1
 x0 r20 1
 x0 r21 -3
 x0 r22 -3
 x0 r23 3
 x0 r24 -2
 x0 r25 -2
 x0 r26 -1
 x0 r27 -1
 x0 r28 1
 x0 r29 -3
 x0 r30 -3
 x0 r31 3
 x0 r32 -2
 x0 r33 -2
 x0 r34 -1
 x0 r35 -1
 x0 r36 1
 x0 r37 -3
 x0 r38 -3
 x0 r39 3
 x1 obj -7
 x1 r0 1
 x1 r1 3
 x1 r2 -2
 x1 r3 1
 x1 r4 1
 x1 r5 -1
 x1 r6 -2
 x1 r7 2
 x1 r8 1
 x1 r9 3
 x1 r10 -2
 x1 r11 1
 x1 r12 1
 x1 r13 -1
 x1 r14 -2
 x1 r15 2
 x1 r16 1
 x1 r17 3
 x1 r18 -2
 x1 r19 1
 x1 r20 1
 x1 r21 -1
 x1 r22 -2
 x1 r23 2
 x1 r24 1
 x1 r25 3
 x1 r26 -2
 x1 r27 1
 x1 r28 1
 x1 r29 -1
 x1 r30 -2
 x1 r31 2
 x1 r32 1
 x1 r33 3
 x1 r34 -2
 x1 r35 1
 x1 r36 1
 x1 r37 -1
 x1 r38 -2
 x1 r39 2
 x2 obj 5
 x2 r1 1
 x2 r2 -2
 x2 r3 -2
 x2 r4 2
 x2 r5 -2
 x2 r6 3
 x2 r7 -1
 x2 r9 1
 x2 r10 -2
 x2 r11 -2
 x2 r12 2
 x2 r13 -2
 x2 r14 3
 x2 r15 -1
 x2 r17 1
 x2 r18 -2
 x2 r19 -2
 x2 r20 2
 x2 r21 -2
 x2 r22 3
 x2 r23 -1
 x2 r25 1
 x2 r26 -2
 x2 r27 -2
 x2 r28 2
 x2 r29 -2
 x2 r30 3
 x2 r31 -1
 x2 r33 1
 x2 r34 -2
 x2 r35 -2
 x2 r36 2
 x2 r37 -2
 x2 r38 3
 x2 r39 -1
 x3 obj 0
 x3 r3 1
 x3 r5 2
 x3 r7 2
 x3 r11 1
 x3 r13 2
 x3 r15 2
 x3 r19 1
 x3 r21 2
 x3 r23 2
 x3 r27 1
 x3 r29 2
 x3 r31 2
 x3 r35 1
 x3 r37 2
 x3 r39 2
 x4 obj 0
 x4 r4 1
 x4 r6 2
 x4 r7 2
 x4 r12 1
 x4 r14 2
 x4 r15 2
 x4 r20 1
 x4 r22 2
 x4 r23 2
 x4 r28 1
 x4 r30 2
 x4 r31 2
 x4 r36 1
 x4 r38 2
 x4 r39 2
RHS
 rhs obj 15
 rhs r0 0
 rhs r1 7
 rhs r2 -8
 rhs r3 0
 rhs r4 7
 rhs r5 -5
 rhs r6 -1
 rhs r7 10
 rhs r8 0
 rhs r9 7
 rhs r10 -8
 rhs r11 0
 rhs r12 7
 rhs r13 -5
 rhs r14 -1
 rhs r15 10
 rhs r16 0
 rhs r17 7
 rhs r18 -8
 rhs r19 0
 rhs r20 7
 rhs r21 -5
 rhs r22 -1
 rhs r23 10
 rhs r24 0
 rhs r25 7
 rhs r26 -8
 rhs r27 0
 rhs r28 7
 rhs r29 -5
 rhs r30 -1
 rhs r31 10
 rhs r32 0
 rhs r33 7
 rhs r34 -8
 rhs r35 0
 rhs r36 7
 rhs r37 -5
 rhs r38 -1
 rhs r39 10
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
