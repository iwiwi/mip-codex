NAME dom
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 G r3
 L r4
 G r5
 L r6
 L r7
 G r8
 L r9
 L r10
 G r11
 L r12
 G r13
 L r14
 L r15
 G r16
 L r17
 L r18
 G r19
 L r20
 G r21
 L r22
 L r23
 G r24
 L r25
 L r26
 G r27
 L r28
 G r29
 L r30
 L r31
 G r32
 L r33
 L r34
 G r35
 L r36
 G r37
 L r38
 L r39
COLUMNS
 x0 obj 8
 x0 r0 2
 x0 r1 1
 x0 r3 3
 x0 r4 2
 x0 r5 1
 x0 r6 3
 x0 r7 2
 x0 r8 2
 x0 r9 1
 x0 r11 3
 x0 r12 2
 x0 r13 1
 x0 r14 3
 x0 r15 2
 x0 r16 2
 x0 r17 1
 x0 r19 3
 x0 r20 2
 x0 r21 1
 x0 r22 3
 x0 r23 2
 x0 r24 2
 x0 r25 1
 x0 r27 3
 x0 r28 2
 x0 r29 1
 x0 r30 3
 x0 r31 2
 x0 r32 2
 x0 r33 1
 x0 r35 3
 x0 r36 2
 x0 r37 1
 x0 r38 3
 x0 r39 2
 x1 obj -2
 x1 r0 -2
 x1 r1 3
 x1 r2 3
 x1 r3 3
 x1 r5 -2
 x1 r8 -2
 x1 r9 3
 x1 r10 3
 x1 r11 3
 x1 r13 -2
 x1 r16 -2
 x1 r17 3
 x1 r18 3
 x1 r19 3
 x1 r21 -2
 x1 r24 -2
 x1 r25 3
 x1 r26 3
 x1 r27 3
 x1 r29 -2
 x1 r32 -2
 x1 r33 3
 x1 r34 3
 x1 r35 3
 x1 r37 -2
 x2 obj -8
 x2 r0 -2
 x2 r1 3
 x2 r2 1
 x2 r3 -1
 x2 r5 2
 x2 r6 3
 x2 r7 -2
 x2 r8 -2
 x2 r9 3
 x2 r10 1
 x2 r11 -1
 x2 r13 2
 x2 r14 3
 x2 r15 -2
 x2 r16 -2
 x2 r17 3
 x2 r18 1
 x2 r19 -1
 x2 r21 2
 x2 r22 3
 x2 r23 -2
 x2 r24 -2
 x2 r25 3
 x2 r26 1
 x2 r27 -1
 x2 r29 2
 x2 r30 3
 x2 r31 -2
 x2 r32 -2
 x2 r33 3
 x2 r34 1
 x2 r35 -1
 x2 r37 2
 x2 r38 3
 x2 r39 -2
 x3 obj 0
 x3 r3 3
 x3 r5 6
 x3 r7 -2
 x3 r11 3
 x3 r13 6
 x3 r15 -2
 x3 r19 3
 x3 r21 6
 x3 r23 -2
 x3 r27 3
 x3 r29 6
 x3 r31 -2
 x3 r35 3
 x3 r37 6
 x3 r39 -2
 x4 obj 0
 x4 r4 2
 x4 r6 4
 x4 r7 2
 x4 r12 2
 x4 r14 4
 x4 r15 2
 x4 r20 2
 x4 r22 4
 x4 r23 2
 x4 r28 2
 x4 r30 4
 x4 r31 2
 x4 r36 2
 x4 r38 4
 x4 r39 2
RHS
 rhs obj 1
 rhs r0 0
 rhs r1 7
 rhs r2 5
 rhs r3 9
 rhs r4 7
 rhs r5 -1
 rhs r6 12
 rhs r7 6
 rhs r8 0
 rhs r9 7
 rhs r10 5
 rhs r11 9
 rhs r12 7
 rhs r13 -1
 rhs r14 12
 rhs r15 6
 rhs r16 0
 rhs r17 7
 rhs r18 5
 rhs r19 9
 rhs r20 7
 rhs r21 -1
 rhs r22 12
 rhs r23 6
 rhs r24 0
 rhs r25 7
 rhs r26 5
 rhs r27 9
 rhs r28 7
 rhs r29 -1
 rhs r30 12
 rhs r31 6
 rhs r32 0
 rhs r33 7
 rhs r34 5
 rhs r35 9
 rhs r36 7
 rhs r37 -1
 rhs r38 12
 rhs r39 6
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
