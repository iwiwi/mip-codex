NAME dom
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 G r2
 L r3
 G r4
 L r5
 G r6
 L r7
 L r8
 L r9
 G r10
 L r11
 G r12
 L r13
 G r14
 L r15
 L r16
 L r17
 G r18
 L r19
 G r20
 L r21
 G r22
 L r23
 L r24
 L r25
 G r26
 L r27
 G r28
 L r29
 G r30
 L r31
 L r32
 L r33
 G r34
 L r35
 G r36
 L r37
 G r38
 L r39
COLUMNS
 x0 obj 8
 x0 r0 -3
 x0 r1 -1
 x0 r2 3
 x0 r3 1
 x0 r4 -2
 x0 r5 -2
 x0 r7 3
 x0 r8 -3
 x0 r9 -1
 x0 r10 3
 x0 r11 1
 x0 r12 -2
 x0 r13 -2
 x0 r15 3
 x0 r16 -3
 x0 r17 -1
 x0 r18 3
 x0 r19 1
 x0 r20 -2
 x0 r21 -2
 x0 r23 3
 x0 r24 -3
 x0 r25 -1
 x0 r26 3
 x0 r27 1
 x0 r28 -2
 x0 r29 -2
 x0 r31 3
 x0 r32 -3
 x0 r33 -1
 x0 r34 3
 x0 r35 1
 x0 r36 -2
 x0 r37 -2
 x0 r39 3
 x1 obj 6
 x1 r0 2
 x1 r1 2
 x1 r3 2
 x1 r6 -2
 x1 r7 -1
 x1 r8 2
 x1 r9 2
 x1 r11 2
 x1 r14 -2
 x1 r15 -1
 x1 r16 2
 x1 r17 2
 x1 r19 2
 x1 r22 -2
 x1 r23 -1
 x1 r24 2
 x1 r25 2
 x1 r27 2
 x1 r30 -2
 x1 r31 -1
 x1 r32 2
 x1 r33 2
 x1 r35 2
 x1 r38 -2
 x1 r39 -1
 x2 obj 7
 x2 r0 -3
 x2 r1 2
 x2 r3 -1
 x2 r4 3
 x2 r5 -3
 x2 r7 -3
 x2 r8 -3
 x2 r9 2
 x2 r11 -1
 x2 r12 3
 x2 r13 -3
 x2 r15 -3
 x2 r16 -3
 x2 r17 2
 x2 r19 -1
 x2 r20 3
 x2 r21 -3
 x2 r23 -3
 x2 r24 -3
 x2 r25 2
 x2 r27 -1
 x2 r28 3
 x2 r29 -3
 x2 r31 -3
 x2 r32 -3
 x2 r33 2
 x2 r35 -1
 x2 r36 3
 x2 r37 -3
 x2 r39 -3
 x3 obj 0
 x3 r3 -1
 x3 r5 -2
 x3 r7 -2
 x3 r11 -1
 x3 r13 -2
 x3 r15 -2
 x3 r19 -1
 x3 r21 -2
 x3 r23 -2
 x3 r27 -1
 x3 r29 -2
 x3 r31 -2
 x3 r35 -1
 x3 r37 -2
 x3 r39 -2
 x4 obj 0
 x4 r4 3
 x4 r6 6
 x4 r7 -2
 x4 r12 3
 x4 r14 6
 x4 r15 -2
 x4 r20 3
 x4 r22 6
 x4 r23 -2
 x4 r28 3
 x4 r30 6
 x4 r31 -2
 x4 r36 3
 x4 r38 6
 x4 r39 -2
RHS
 rhs obj 19
 rhs r0 -8
 rhs r1 6
 rhs r2 4
 rhs r3 0
 rhs r4 0
 rhs r5 -12
 rhs r6 -2
 rhs r7 -4
 rhs r8 -8
 rhs r9 6
 rhs r10 4
 rhs r11 0
 rhs r12 0
 rhs r13 -12
 rhs r14 -2
 rhs r15 -4
 rhs r16 -8
 rhs r17 6
 rhs r18 4
 rhs r19 0
 rhs r20 0
 rhs r21 -12
 rhs r22 -2
 rhs r23 -4
 rhs r24 -8
 rhs r25 6
 rhs r26 4
 rhs r27 0
 rhs r28 0
 rhs r29 -12
 rhs r30 -2
 rhs r31 -4
 rhs r32 -8
 rhs r33 6
 rhs r34 4
 rhs r35 0
 rhs r36 0
 rhs r37 -12
 rhs r38 -2
 rhs r39 -4
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
