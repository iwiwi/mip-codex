NAME dom
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 G r4
 L r5
 G r6
 L r7
 L r8
 G r9
 G r10
 L r11
 G r12
 L r13
 G r14
 L r15
 L r16
 G r17
 G r18
 L r19
 G r20
 L r21
 G r22
 L r23
 L r24
 G r25
 G r26
 L r27
 G r28
 L r29
 G r30
 L r31
 L r32
 G r33
 G r34
 L r35
 G r36
 L r37
 G r38
 L r39
COLUMNS
 x0 obj -9
 x0 r0 3
 x0 r1 2
 x0 r2 -2
 x0 r3 -2
 x0 r4 -3
 x0 r5 -1
 x0 r6 -3
 x0 r7 -1
 x0 r8 3
 x0 r9 2
 x0 r10 -2
 x0 r11 -2
 x0 r12 -3
 x0 r13 -1
 x0 r14 -3
 x0 r15 -1
 x0 r16 3
 x0 r17 2
 x0 r18 -2
 x0 r19 -2
 x0 r20 -3
 x0 r21 -1
 x0 r22 -3
 x0 r23 -1
 x0 r24 3
 x0 r25 2
 x0 r26 -2
 x0 r27 -2
 x0 r28 -3
 x0 r29 -1
 x0 r30 -3
 x0 r31 -1
 x0 r32 3
 x0 r33 2
 x0 r34 -2
 x0 r35 -2
 x0 r36 -3
 x0 r37 -1
 x0 r38 -3
 x0 r39 -1
 x1 obj -1
 x1 r0 -3
 x1 r2 -3
 x1 r3 3
 x1 r4 1
 x1 r5 2
 x1 r6 -2
 x1 r7 -2
 x1 r8 -3
 x1 r10 -3
 x1 r11 3
 x1 r12 1
 x1 r13 2
 x1 r14 -2
 x1 r15 -2
 x1 r16 -3
 x1 r18 -3
 x1 r19 3
 x1 r20 1
 x1 r21 2
 x1 r22 -2
 x1 r23 -2
 x1 r24 -3
 x1 r26 -3
 x1 r27 3
 x1 r28 1
 x1 r29 2
 x1 r30 -2
 x1 r31 -2
 x1 r32 -3
 x1 r34 -3
 x1 r35 3
 x1 r36 1
 x1 r37 2
 x1 r38 -2
 x1 r39 -2
 x2 obj 2
 x2 r0 3
 x2 r1 3
 x2 r2 2
 x2 r4 -2
 x2 r5 -2
 x2 r6 1
 x2 r8 3
 x2 r9 3
 x2 r10 2
 x2 r12 -2
 x2 r13 -2
 x2 r14 1
 x2 r16 3
 x2 r17 3
 x2 r18 2
 x2 r20 -2
 x2 r21 -2
 x2 r22 1
 x2 r24 3
 x2 r25 3
 x2 r26 2
 x2 r28 -2
 x2 r29 -2
 x2 r30 1
 x2 r32 3
 x2 r33 3
 x2 r34 2
 x2 r36 -2
 x2 r37 -2
 x2 r38 1
 x3 obj 0
 x3 r3 1
 x3 r5 2
 x3 r7 2
 x3 r11 1
 x3 r13 2
 x3 r15 2
 x3 r19 1
 x3 r21 2
 x3 r23 2
 x3 r27 1
 x3 r29 2
 x3 r31 2
 x3 r35 1
 x3 r37 2
 x3 r39 2
 x4 obj 0
 x4 r4 -1
 x4 r6 -2
 x4 r7 2
 x4 r12 -1
 x4 r14 -2
 x4 r15 2
 x4 r20 -1
 x4 r22 -2
 x4 r23 2
 x4 r28 -1
 x4 r30 -2
 x4 r31 2
 x4 r36 -1
 x4 r38 -2
 x4 r39 2
RHS
 rhs obj -8
 rhs r0 14
 rhs r1 10
 rhs r2 -1
 rhs r3 -3
 rhs r4 -13
 rhs r5 -2
 rhs r6 -7
 rhs r7 2
 rhs r8 14
 rhs r9 10
 rhs r10 -1
 rhs r11 -3
 rhs r12 -13
 rhs r13 -2
 rhs r14 -7
 rhs r15 2
 rhs r16 14
 rhs r17 10
 rhs r18 -1
 rhs r19 -3
 rhs r20 -13
 rhs r21 -2
 rhs r22 -7
 rhs r23 2
 rhs r24 14
 rhs r25 10
 rhs r26 -1
 rhs r27 -3
 rhs r28 -13
 rhs r29 -2
 rhs r30 -7
 rhs r31 2
 rhs r32 14
 rhs r33 10
 rhs r34 -1
 rhs r35 -3
 rhs r36 -13
 rhs r37 -2
 rhs r38 -7
 rhs r39 2
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
