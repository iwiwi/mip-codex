NAME dom
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
 G r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 G r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 G r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 G r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
COLUMNS
 x0 obj -4
 x0 r0 3
 x0 r1 -2
 x0 r2 -2
 x0 r3 3
 x0 r6 -3
 x0 r8 3
 x0 r9 -2
 x0 r10 -2
 x0 r11 3
 x0 r14 -3
 x0 r16 3
 x0 r17 -2
 x0 r18 -2
 x0 r19 3
 x0 r22 -3
 x0 r24 3
 x0 r25 -2
 x0 r26 -2
 x0 r27 3
 x0 r30 -3
 x0 r32 3
 x0 r33 -2
 x0 r34 -2
 x0 r35 3
 x0 r38 -3
 x1 obj -8
 x1 r0 -3
 x1 r1 2
 x1 r2 -3
 x1 r3 -3
 x1 r5 -3
 x1 r6 -1
 x1 r7 -1
 x1 r8 -3
 x1 r9 2
 x1 r10 -3
 x1 r11 -3
 x1 r13 -3
 x1 r14 -1
 x1 r15 -1
 x1 r16 -3
 x1 r17 2
 x1 r18 -3
 x1 r19 -3
 x1 r21 -3
 x1 r22 -1
 x1 r23 -1
 x1 r24 -3
 x1 r25 2
 x1 r26 -3
 x1 r27 -3
 x1 r29 -3
 x1 r30 -1
 x1 r31 -1
 x1 r32 -3
 x1 r33 2
 x1 r34 -3
 x1 r35 -3
 x1 r37 -3
 x1 r38 -1
 x1 r39 -1
 x2 obj -7
 x2 r0 -1
 x2 r1 -1
 x2 r3 2
 x2 r4 2
 x2 r5 -1
 x2 r6 -3
 x2 r7 3
 x2 r8 -1
 x2 r9 -1
 x2 r11 2
 x2 r12 2
 x2 r13 -1
 x2 r14 -3
 x2 r15 3
 x2 r16 -1
 x2 r17 -1
 x2 r19 2
 x2 r20 2
 x2 r21 -1
 x2 r22 -3
 x2 r23 3
 x2 r24 -1
 x2 r25 -1
 x2 r27 2
 x2 r28 2
 x2 r29 -1
 x2 r30 -3
 x2 r31 3
 x2 r32 -1
 x2 r33 -1
 x2 r35 2
 x2 r36 2
 x2 r37 -1
 x2 r38 -3
 x2 r39 3
 x3 obj 0
 x3 r3 3
 x3 r5 6
 x3 r7 2
 x3 r11 3
 x3 r13 6
 x3 r15 2
 x3 r19 3
 x3 r21 6
 x3 r23 2
 x3 r27 3
 x3 r29 6
 x3 r31 2
 x3 r35 3
 x3 r37 6
 x3 r39 2
 x4 obj 0
 x4 r4 -2
 x4 r6 -4
 x4 r7 -2
 x4 r12 -2
 x4 r14 -4
 x4 r15 -2
 x4 r20 -2
 x4 r22 -4
 x4 r23 -2
 x4 r28 -2
 x4 r30 -4
 x4 r31 -2
 x4 r36 -2
 x4 r38 -4
 x4 r39 -2
RHS
 rhs obj 13
 rhs r0 2
 rhs r1 -1
 rhs r2 -5
 rhs r3 4
 rhs r4 -1
 rhs r5 -2
 rhs r6 -11
 rhs r7 -3
 rhs r8 2
 rhs r9 -1
 rhs r10 -5
 rhs r11 4
 rhs r12 -1
 rhs r13 -2
 rhs r14 -11
 rhs r15 -3
 rhs r16 2
 rhs r17 -1
 rhs r18 -5
 rhs r19 4
 rhs r20 -1
 rhs r21 -2
 rhs r22 -11
 rhs r23 -3
 rhs r24 2
 rhs r25 -1
 rhs r26 -5
 rhs r27 4
 rhs r28 -1
 rhs r29 -2
 rhs r30 -11
 rhs r31 -3
 rhs r32 2
 rhs r33 -1
 rhs r34 -5
 rhs r35 4
 rhs r36 -1
 rhs r37 -2
 rhs r38 -11
 rhs r39 -3
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
