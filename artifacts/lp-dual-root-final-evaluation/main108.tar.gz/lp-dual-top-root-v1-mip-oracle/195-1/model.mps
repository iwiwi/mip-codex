NAME dom
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 L r4
 G r5
 L r6
 L r7
 L r8
 G r9
 L r10
 G r11
 L r12
 G r13
 L r14
 L r15
 L r16
 G r17
 L r18
 G r19
 L r20
 G r21
 L r22
 L r23
 L r24
 G r25
 L r26
 G r27
 L r28
 G r29
 L r30
 L r31
 L r32
 G r33
 L r34
 G r35
 L r36
 G r37
 L r38
 L r39
COLUMNS
 x0 obj 6
 x0 r0 -3
 x0 r1 -1
 x0 r2 3
 x0 r4 -1
 x0 r5 -1
 x0 r7 1
 x0 r8 -3
 x0 r9 -1
 x0 r10 3
 x0 r12 -1
 x0 r13 -1
 x0 r15 1
 x0 r16 -3
 x0 r17 -1
 x0 r18 3
 x0 r20 -1
 x0 r21 -1
 x0 r23 1
 x0 r24 -3
 x0 r25 -1
 x0 r26 3
 x0 r28 -1
 x0 r29 -1
 x0 r31 1
 x0 r32 -3
 x0 r33 -1
 x0 r34 3
 x0 r36 -1
 x0 r37 -1
 x0 r39 1
 x1 obj 1
 x1 r0 -3
 x1 r2 2
 x1 r4 -1
 x1 r5 1
 x1 r6 2
 x1 r7 -2
 x1 r8 -3
 x1 r10 2
 x1 r12 -1
 x1 r13 1
 x1 r14 2
 x1 r15 -2
 x1 r16 -3
 x1 r18 2
 x1 r20 -1
 x1 r21 1
 x1 r22 2
 x1 r23 -2
 x1 r24 -3
 x1 r26 2
 x1 r28 -1
 x1 r29 1
 x1 r30 2
 x1 r31 -2
 x1 r32 -3
 x1 r34 2
 x1 r36 -1
 x1 r37 1
 x1 r38 2
 x1 r39 -2
 x2 obj -7
 x2 r0 3
 x2 r1 -1
 x2 r2 -3
 x2 r4 3
 x2 r5 2
 x2 r6 1
 x2 r7 3
 x2 r8 3
 x2 r9 -1
 x2 r10 -3
 x2 r12 3
 x2 r13 2
 x2 r14 1
 x2 r15 3
 x2 r16 3
 x2 r17 -1
 x2 r18 -3
 x2 r20 3
 x2 r21 2
 x2 r22 1
 x2 r23 3
 x2 r24 3
 x2 r25 -1
 x2 r26 -3
 x2 r28 3
 x2 r29 2
 x2 r30 1
 x2 r31 3
 x2 r32 3
 x2 r33 -1
 x2 r34 -3
 x2 r36 3
 x2 r37 2
 x2 r38 1
 x2 r39 3
 x3 obj 0
 x3 r3 -1
 x3 r5 -2
 x3 r7 2
 x3 r11 -1
 x3 r13 -2
 x3 r15 2
 x3 r19 -1
 x3 r21 -2
 x3 r23 2
 x3 r27 -1
 x3 r29 -2
 x3 r31 2
 x3 r35 -1
 x3 r37 -2
 x3 r39 2
 x4 obj 0
 x4 r4 -2
 x4 r6 -4
 x4 r7 -2
 x4 r12 -2
 x4 r14 -4
 x4 r15 -2
 x4 r20 -2
 x4 r22 -4
 x4 r23 -2
 x4 r28 -2
 x4 r30 -4
 x4 r31 -2
 x4 r36 -2
 x4 r38 -4
 x4 r39 -2
RHS
 rhs obj -20
 rhs r0 2
 rhs r1 -4
 rhs r2 0
 rhs r3 -1
 rhs r4 1
 rhs r5 0
 rhs r6 -2
 rhs r7 5
 rhs r8 2
 rhs r9 -4
 rhs r10 0
 rhs r11 -1
 rhs r12 1
 rhs r13 0
 rhs r14 -2
 rhs r15 5
 rhs r16 2
 rhs r17 -4
 rhs r18 0
 rhs r19 -1
 rhs r20 1
 rhs r21 0
 rhs r22 -2
 rhs r23 5
 rhs r24 2
 rhs r25 -4
 rhs r26 0
 rhs r27 -1
 rhs r28 1
 rhs r29 0
 rhs r30 -2
 rhs r31 5
 rhs r32 2
 rhs r33 -4
 rhs r34 0
 rhs r35 -1
 rhs r36 1
 rhs r37 0
 rhs r38 -2
 rhs r39 5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
