NAME dom
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 G r2
 L r3
 L r4
 L r5
 L r6
 L r7
 L r8
 G r9
 G r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 G r17
 G r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 G r25
 G r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 G r33
 G r34
 L r35
 L r36
 L r37
 L r38
 L r39
COLUMNS
 x0 obj -2
 x0 r0 -3
 x0 r1 1
 x0 r2 1
 x0 r4 2
 x0 r5 3
 x0 r6 -3
 x0 r8 -3
 x0 r9 1
 x0 r10 1
 x0 r12 2
 x0 r13 3
 x0 r14 -3
 x0 r16 -3
 x0 r17 1
 x0 r18 1
 x0 r20 2
 x0 r21 3
 x0 r22 -3
 x0 r24 -3
 x0 r25 1
 x0 r26 1
 x0 r28 2
 x0 r29 3
 x0 r30 -3
 x0 r32 -3
 x0 r33 1
 x0 r34 1
 x0 r36 2
 x0 r37 3
 x0 r38 -3
 x1 obj 9
 x1 r0 3
 x1 r1 -1
 x1 r2 3
 x1 r3 -2
 x1 r4 2
 x1 r5 -3
 x1 r6 -3
 x1 r7 3
 x1 r8 3
 x1 r9 -1
 x1 r10 3
 x1 r11 -2
 x1 r12 2
 x1 r13 -3
 x1 r14 -3
 x1 r15 3
 x1 r16 3
 x1 r17 -1
 x1 r18 3
 x1 r19 -2
 x1 r20 2
 x1 r21 -3
 x1 r22 -3
 x1 r23 3
 x1 r24 3
 x1 r25 -1
 x1 r26 3
 x1 r27 -2
 x1 r28 2
 x1 r29 -3
 x1 r30 -3
 x1 r31 3
 x1 r32 3
 x1 r33 -1
 x1 r34 3
 x1 r35 -2
 x1 r36 2
 x1 r37 -3
 x1 r38 -3
 x1 r39 3
 x2 obj -4
 x2 r1 3
 x2 r2 -1
 x2 r5 -1
 x2 r7 1
 x2 r9 3
 x2 r10 -1
 x2 r13 -1
 x2 r15 1
 x2 r17 3
 x2 r18 -1
 x2 r21 -1
 x2 r23 1
 x2 r25 3
 x2 r26 -1
 x2 r29 -1
 x2 r31 1
 x2 r33 3
 x2 r34 -1
 x2 r37 -1
 x2 r39 1
 x3 obj 0
 x3 r3 1
 x3 r5 2
 x3 r7 2
 x3 r11 1
 x3 r13 2
 x3 r15 2
 x3 r19 1
 x3 r21 2
 x3 r23 2
 x3 r27 1
 x3 r29 2
 x3 r31 2
 x3 r35 1
 x3 r37 2
 x3 r39 2
 x4 obj 0
 x4 r4 -2
 x4 r6 -4
 x4 r7 -2
 x4 r12 -2
 x4 r14 -4
 x4 r15 -2
 x4 r20 -2
 x4 r22 -4
 x4 r23 -2
 x4 r28 -2
 x4 r30 -4
 x4 r31 -2
 x4 r36 -2
 x4 r38 -4
 x4 r39 -2
RHS
 rhs obj 20
 rhs r0 0
 rhs r1 3
 rhs r2 -2
 rhs r3 2
 rhs r4 -4
 rhs r5 1
 rhs r6 -7
 rhs r7 -3
 rhs r8 0
 rhs r9 3
 rhs r10 -2
 rhs r11 2
 rhs r12 -4
 rhs r13 1
 rhs r14 -7
 rhs r15 -3
 rhs r16 0
 rhs r17 3
 rhs r18 -2
 rhs r19 2
 rhs r20 -4
 rhs r21 1
 rhs r22 -7
 rhs r23 -3
 rhs r24 0
 rhs r25 3
 rhs r26 -2
 rhs r27 2
 rhs r28 -4
 rhs r29 1
 rhs r30 -7
 rhs r31 -3
 rhs r32 0
 rhs r33 3
 rhs r34 -2
 rhs r35 2
 rhs r36 -4
 rhs r37 1
 rhs r38 -7
 rhs r39 -3
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
