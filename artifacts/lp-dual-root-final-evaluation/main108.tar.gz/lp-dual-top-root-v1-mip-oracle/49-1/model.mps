NAME dom
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 L r2
 G r3
 G r4
 G r5
 G r6
 L r7
 L r8
 G r9
 L r10
 G r11
 G r12
 G r13
 G r14
 L r15
 L r16
 G r17
 L r18
 G r19
 G r20
 G r21
 G r22
 L r23
 L r24
 G r25
 L r26
 G r27
 G r28
 G r29
 G r30
 L r31
 L r32
 G r33
 L r34
 G r35
 G r36
 G r37
 G r38
 L r39
COLUMNS
 x0 obj 1
 x0 r0 -2
 x0 r2 3
 x0 r4 3
 x0 r5 -3
 x0 r6 2
 x0 r8 -2
 x0 r10 3
 x0 r12 3
 x0 r13 -3
 x0 r14 2
 x0 r16 -2
 x0 r18 3
 x0 r20 3
 x0 r21 -3
 x0 r22 2
 x0 r24 -2
 x0 r26 3
 x0 r28 3
 x0 r29 -3
 x0 r30 2
 x0 r32 -2
 x0 r34 3
 x0 r36 3
 x0 r37 -3
 x0 r38 2
 x1 obj 3
 x1 r0 -1
 x1 r1 2
 x1 r2 -3
 x1 r3 3
 x1 r5 -2
 x1 r6 -3
 x1 r7 1
 x1 r8 -1
 x1 r9 2
 x1 r10 -3
 x1 r11 3
 x1 r13 -2
 x1 r14 -3
 x1 r15 1
 x1 r16 -1
 x1 r17 2
 x1 r18 -3
 x1 r19 3
 x1 r21 -2
 x1 r22 -3
 x1 r23 1
 x1 r24 -1
 x1 r25 2
 x1 r26 -3
 x1 r27 3
 x1 r29 -2
 x1 r30 -3
 x1 r31 1
 x1 r32 -1
 x1 r33 2
 x1 r34 -3
 x1 r35 3
 x1 r37 -2
 x1 r38 -3
 x1 r39 1
 x2 obj 8
 x2 r0 -2
 x2 r1 2
 x2 r2 1
 x2 r3 -1
 x2 r4 -3
 x2 r6 2
 x2 r7 -3
 x2 r8 -2
 x2 r9 2
 x2 r10 1
 x2 r11 -1
 x2 r12 -3
 x2 r14 2
 x2 r15 -3
 x2 r16 -2
 x2 r17 2
 x2 r18 1
 x2 r19 -1
 x2 r20 -3
 x2 r22 2
 x2 r23 -3
 x2 r24 -2
 x2 r25 2
 x2 r26 1
 x2 r27 -1
 x2 r28 -3
 x2 r30 2
 x2 r31 -3
 x2 r32 -2
 x2 r33 2
 x2 r34 1
 x2 r35 -1
 x2 r36 -3
 x2 r38 2
 x2 r39 -3
 x3 obj 0
 x3 r3 -2
 x3 r5 -4
 x3 r7 2
 x3 r11 -2
 x3 r13 -4
 x3 r15 2
 x3 r19 -2
 x3 r21 -4
 x3 r23 2
 x3 r27 -2
 x3 r29 -4
 x3 r31 2
 x3 r35 -2
 x3 r37 -4
 x3 r39 2
 x4 obj 0
 x4 r4 -3
 x4 r6 -6
 x4 r7 2
 x4 r12 -3
 x4 r14 -6
 x4 r15 2
 x4 r20 -3
 x4 r22 -6
 x4 r23 2
 x4 r28 -3
 x4 r30 -6
 x4 r31 2
 x4 r36 -3
 x4 r38 -6
 x4 r39 2
RHS
 rhs obj -8
 rhs r0 0
 rhs r1 0
 rhs r2 3
 rhs r3 0
 rhs r4 -5
 rhs r5 -5
 rhs r6 -11
 rhs r7 5
 rhs r8 0
 rhs r9 0
 rhs r10 3
 rhs r11 0
 rhs r12 -5
 rhs r13 -5
 rhs r14 -11
 rhs r15 5
 rhs r16 0
 rhs r17 0
 rhs r18 3
 rhs r19 0
 rhs r20 -5
 rhs r21 -5
 rhs r22 -11
 rhs r23 5
 rhs r24 0
 rhs r25 0
 rhs r26 3
 rhs r27 0
 rhs r28 -5
 rhs r29 -5
 rhs r30 -11
 rhs r31 5
 rhs r32 0
 rhs r33 0
 rhs r34 3
 rhs r35 0
 rhs r36 -5
 rhs r37 -5
 rhs r38 -11
 rhs r39 5
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
