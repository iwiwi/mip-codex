NAME dom
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
 G r2
 G r3
 L r4
 G r5
 L r6
 L r7
 G r8
 L r9
 G r10
 G r11
 L r12
 G r13
 L r14
 L r15
 G r16
 L r17
 G r18
 G r19
 L r20
 G r21
 L r22
 L r23
 G r24
 L r25
 G r26
 G r27
 L r28
 G r29
 L r30
 L r31
 G r32
 L r33
 G r34
 G r35
 L r36
 G r37
 L r38
 L r39
COLUMNS
 x0 obj -6
 x0 r0 1
 x0 r1 -2
 x0 r2 1
 x0 r3 2
 x0 r4 2
 x0 r5 2
 x0 r7 3
 x0 r8 1
 x0 r9 -2
 x0 r10 1
 x0 r11 2
 x0 r12 2
 x0 r13 2
 x0 r15 3
 x0 r16 1
 x0 r17 -2
 x0 r18 1
 x0 r19 2
 x0 r20 2
 x0 r21 2
 x0 r23 3
 x0 r24 1
 x0 r25 -2
 x0 r26 1
 x0 r27 2
 x0 r28 2
 x0 r29 2
 x0 r31 3
 x0 r32 1
 x0 r33 -2
 x0 r34 1
 x0 r35 2
 x0 r36 2
 x0 r37 2
 x0 r39 3
 x1 obj -6
 x1 r0 1
 x1 r1 1
 x1 r2 -2
 x1 r3 -3
 x1 r4 -1
 x1 r5 -1
 x1 r7 1
 x1 r8 1
 x1 r9 1
 x1 r10 -2
 x1 r11 -3
 x1 r12 -1
 x1 r13 -1
 x1 r15 1
 x1 r16 1
 x1 r17 1
 x1 r18 -2
 x1 r19 -3
 x1 r20 -1
 x1 r21 -1
 x1 r23 1
 x1 r24 1
 x1 r25 1
 x1 r26 -2
 x1 r27 -3
 x1 r28 -1
 x1 r29 -1
 x1 r31 1
 x1 r32 1
 x1 r33 1
 x1 r34 -2
 x1 r35 -3
 x1 r36 -1
 x1 r37 -1
 x1 r39 1
 x2 obj -4
 x2 r0 -1
 x2 r1 1
 x2 r2 3
 x2 r4 2
 x2 r6 2
 x2 r7 1
 x2 r8 -1
 x2 r9 1
 x2 r10 3
 x2 r12 2
 x2 r14 2
 x2 r15 1
 x2 r16 -1
 x2 r17 1
 x2 r18 3
 x2 r20 2
 x2 r22 2
 x2 r23 1
 x2 r24 -1
 x2 r25 1
 x2 r26 3
 x2 r28 2
 x2 r30 2
 x2 r31 1
 x2 r32 -1
 x2 r33 1
 x2 r34 3
 x2 r36 2
 x2 r38 2
 x2 r39 1
 x3 obj 0
 x3 r3 2
 x3 r5 4
 x3 r7 -2
 x3 r11 2
 x3 r13 4
 x3 r15 -2
 x3 r19 2
 x3 r21 4
 x3 r23 -2
 x3 r27 2
 x3 r29 4
 x3 r31 -2
 x3 r35 2
 x3 r37 4
 x3 r39 -2
 x4 obj 0
 x4 r4 1
 x4 r6 2
 x4 r7 2
 x4 r12 1
 x4 r14 2
 x4 r15 2
 x4 r20 1
 x4 r22 2
 x4 r23 2
 x4 r28 1
 x4 r30 2
 x4 r31 2
 x4 r36 1
 x4 r38 2
 x4 r39 2
RHS
 rhs obj 15
 rhs r0 2
 rhs r1 1
 rhs r2 0
 rhs r3 0
 rhs r4 5
 rhs r5 8
 rhs r6 5
 rhs r7 4
 rhs r8 2
 rhs r9 1
 rhs r10 0
 rhs r11 0
 rhs r12 5
 rhs r13 8
 rhs r14 5
 rhs r15 4
 rhs r16 2
 rhs r17 1
 rhs r18 0
 rhs r19 0
 rhs r20 5
 rhs r21 8
 rhs r22 5
 rhs r23 4
 rhs r24 2
 rhs r25 1
 rhs r26 0
 rhs r27 0
 rhs r28 5
 rhs r29 8
 rhs r30 5
 rhs r31 4
 rhs r32 2
 rhs r33 1
 rhs r34 0
 rhs r35 0
 rhs r36 5
 rhs r37 8
 rhs r38 5
 rhs r39 4
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
