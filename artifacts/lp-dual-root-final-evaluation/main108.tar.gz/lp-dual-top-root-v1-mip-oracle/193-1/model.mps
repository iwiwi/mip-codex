NAME dom
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
 L r2
 L r3
 G r4
 L r5
 G r6
 L r7
 G r8
 G r9
 L r10
 L r11
 G r12
 L r13
 G r14
 L r15
 G r16
 G r17
 L r18
 L r19
 G r20
 L r21
 G r22
 L r23
 G r24
 G r25
 L r26
 L r27
 G r28
 L r29
 G r30
 L r31
 G r32
 G r33
 L r34
 L r35
 G r36
 L r37
 G r38
 L r39
COLUMNS
 x0 obj -4
 x0 r0 1
 x0 r1 3
 x0 r2 -3
 x0 r3 -3
 x0 r4 -3
 x0 r5 1
 x0 r7 1
 x0 r8 1
 x0 r9 3
 x0 r10 -3
 x0 r11 -3
 x0 r12 -3
 x0 r13 1
 x0 r15 1
 x0 r16 1
 x0 r17 3
 x0 r18 -3
 x0 r19 -3
 x0 r20 -3
 x0 r21 1
 x0 r23 1
 x0 r24 1
 x0 r25 3
 x0 r26 -3
 x0 r27 -3
 x0 r28 -3
 x0 r29 1
 x0 r31 1
 x0 r32 1
 x0 r33 3
 x0 r34 -3
 x0 r35 -3
 x0 r36 -3
 x0 r37 1
 x0 r39 1
 x1 obj -8
 x1 r0 -1
 x1 r1 -3
 x1 r2 1
 x1 r3 -2
 x1 r4 3
 x1 r5 -2
 x1 r6 -3
 x1 r8 -1
 x1 r9 -3
 x1 r10 1
 x1 r11 -2
 x1 r12 3
 x1 r13 -2
 x1 r14 -3
 x1 r16 -1
 x1 r17 -3
 x1 r18 1
 x1 r19 -2
 x1 r20 3
 x1 r21 -2
 x1 r22 -3
 x1 r24 -1
 x1 r25 -3
 x1 r26 1
 x1 r27 -2
 x1 r28 3
 x1 r29 -2
 x1 r30 -3
 x1 r32 -1
 x1 r33 -3
 x1 r34 1
 x1 r35 -2
 x1 r36 3
 x1 r37 -2
 x1 r38 -3
 x2 obj 1
 x2 r0 3
 x2 r1 -1
 x2 r3 -1
 x2 r4 -2
 x2 r5 1
 x2 r7 3
 x2 r8 3
 x2 r9 -1
 x2 r11 -1
 x2 r12 -2
 x2 r13 1
 x2 r15 3
 x2 r16 3
 x2 r17 -1
 x2 r19 -1
 x2 r20 -2
 x2 r21 1
 x2 r23 3
 x2 r24 3
 x2 r25 -1
 x2 r27 -1
 x2 r28 -2
 x2 r29 1
 x2 r31 3
 x2 r32 3
 x2 r33 -1
 x2 r35 -1
 x2 r36 -2
 x2 r37 1
 x2 r39 3
 x3 obj 0
 x3 r3 1
 x3 r5 2
 x3 r7 2
 x3 r11 1
 x3 r13 2
 x3 r15 2
 x3 r19 1
 x3 r21 2
 x3 r23 2
 x3 r27 1
 x3 r29 2
 x3 r31 2
 x3 r35 1
 x3 r37 2
 x3 r39 2
 x4 obj 0
 x4 r4 1
 x4 r6 2
 x4 r7 -2
 x4 r12 1
 x4 r14 2
 x4 r15 -2
 x4 r20 1
 x4 r22 2
 x4 r23 -2
 x4 r28 1
 x4 r30 2
 x4 r31 -2
 x4 r36 1
 x4 r38 2
 x4 r39 -2
RHS
 rhs obj 2
 rhs r0 8
 rhs r1 2
 rhs r2 -5
 rhs r3 -5
 rhs r4 -10
 rhs r5 7
 rhs r6 0
 rhs r7 12
 rhs r8 8
 rhs r9 2
 rhs r10 -5
 rhs r11 -5
 rhs r12 -10
 rhs r13 7
 rhs r14 0
 rhs r15 12
 rhs r16 8
 rhs r17 2
 rhs r18 -5
 rhs r19 -5
 rhs r20 -10
 rhs r21 7
 rhs r22 0
 rhs r23 12
 rhs r24 8
 rhs r25 2
 rhs r26 -5
 rhs r27 -5
 rhs r28 -10
 rhs r29 7
 rhs r30 0
 rhs r31 12
 rhs r32 8
 rhs r33 2
 rhs r34 -5
 rhs r35 -5
 rhs r36 -10
 rhs r37 7
 rhs r38 0
 rhs r39 12
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
