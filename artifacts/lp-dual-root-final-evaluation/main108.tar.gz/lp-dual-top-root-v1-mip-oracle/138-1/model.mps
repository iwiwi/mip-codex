NAME dom
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
 G r2
 G r3
 L r4
 G r5
 L r6
 L r7
 L r8
 G r9
 G r10
 G r11
 L r12
 G r13
 L r14
 L r15
 L r16
 G r17
 G r18
 G r19
 L r20
 G r21
 L r22
 L r23
 L r24
 G r25
 G r26
 G r27
 L r28
 G r29
 L r30
 L r31
 L r32
 G r33
 G r34
 G r35
 L r36
 G r37
 L r38
 L r39
COLUMNS
 x0 obj -6
 x0 r0 3
 x0 r1 -2
 x0 r2 -1
 x0 r3 -1
 x0 r5 -3
 x0 r7 1
 x0 r8 3
 x0 r9 -2
 x0 r10 -1
 x0 r11 -1
 x0 r13 -3
 x0 r15 1
 x0 r16 3
 x0 r17 -2
 x0 r18 -1
 x0 r19 -1
 x0 r21 -3
 x0 r23 1
 x0 r24 3
 x0 r25 -2
 x0 r26 -1
 x0 r27 -1
 x0 r29 -3
 x0 r31 1
 x0 r32 3
 x0 r33 -2
 x0 r34 -1
 x0 r35 -1
 x0 r37 -3
 x0 r39 1
 x1 obj 1
 x1 r0 3
 x1 r1 2
 x1 r2 1
 x1 r3 -2
 x1 r4 1
 x1 r5 -1
 x1 r6 -2
 x1 r7 2
 x1 r8 3
 x1 r9 2
 x1 r10 1
 x1 r11 -2
 x1 r12 1
 x1 r13 -1
 x1 r14 -2
 x1 r15 2
 x1 r16 3
 x1 r17 2
 x1 r18 1
 x1 r19 -2
 x1 r20 1
 x1 r21 -1
 x1 r22 -2
 x1 r23 2
 x1 r24 3
 x1 r25 2
 x1 r26 1
 x1 r27 -2
 x1 r28 1
 x1 r29 -1
 x1 r30 -2
 x1 r31 2
 x1 r32 3
 x1 r33 2
 x1 r34 1
 x1 r35 -2
 x1 r36 1
 x1 r37 -1
 x1 r38 -2
 x1 r39 2
 x2 obj -7
 x2 r0 2
 x2 r2 2
 x2 r4 3
 x2 r6 -1
 x2 r7 2
 x2 r8 2
 x2 r10 2
 x2 r12 3
 x2 r14 -1
 x2 r15 2
 x2 r16 2
 x2 r18 2
 x2 r20 3
 x2 r22 -1
 x2 r23 2
 x2 r24 2
 x2 r26 2
 x2 r28 3
 x2 r30 -1
 x2 r31 2
 x2 r32 2
 x2 r34 2
 x2 r36 3
 x2 r38 -1
 x2 r39 2
 x3 obj 0
 x3 r3 -2
 x3 r5 -4
 x3 r7 2
 x3 r11 -2
 x3 r13 -4
 x3 r15 2
 x3 r19 -2
 x3 r21 -4
 x3 r23 2
 x3 r27 -2
 x3 r29 -4
 x3 r31 2
 x3 r35 -2
 x3 r37 -4
 x3 r39 2
 x4 obj 0
 x4 r4 3
 x4 r6 6
 x4 r7 2
 x4 r12 3
 x4 r14 6
 x4 r15 2
 x4 r20 3
 x4 r22 6
 x4 r23 2
 x4 r28 3
 x4 r30 6
 x4 r31 2
 x4 r36 3
 x4 r38 6
 x4 r39 2
RHS
 rhs obj -2
 rhs r0 13
 rhs r1 -2
 rhs r2 0
 rhs r3 -11
 rhs r4 6
 rhs r5 -16
 rhs r6 3
 rhs r7 12
 rhs r8 13
 rhs r9 -2
 rhs r10 0
 rhs r11 -11
 rhs r12 6
 rhs r13 -16
 rhs r14 3
 rhs r15 12
 rhs r16 13
 rhs r17 -2
 rhs r18 0
 rhs r19 -11
 rhs r20 6
 rhs r21 -16
 rhs r22 3
 rhs r23 12
 rhs r24 13
 rhs r25 -2
 rhs r26 0
 rhs r27 -11
 rhs r28 6
 rhs r29 -16
 rhs r30 3
 rhs r31 12
 rhs r32 13
 rhs r33 -2
 rhs r34 0
 rhs r35 -11
 rhs r36 6
 rhs r37 -16
 rhs r38 3
 rhs r39 12
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
