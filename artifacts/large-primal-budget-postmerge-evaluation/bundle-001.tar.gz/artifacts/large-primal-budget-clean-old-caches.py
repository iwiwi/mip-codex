from pathlib import Path
import os,subprocess,time,json,hashlib,shutil,datetime
root=Path.cwd();assert root==Path('/home/ubuntu/mip-codex');os.sched_setaffinity(0,{43});end=time.monotonic()+2400
while True:
 ready=Path('/home/ubuntu/mip-graph-large-primal-budget/artifacts/large-primal-budget-default-long-controls/exit.json').exists()and all(Path(f'/home/ubuntu/mip-cover-choice-heap/artifacts/cover-diverse-1198-long-v1/{i}/summary.json').exists()for i in range(3))
 compilers=any(subprocess.run(['pgrep','-x',n],capture_output=True).returncode==0 for n in ['cargo','rustc'])
 if ready and not compilers:break
 assert time.monotonic()<end;time.sleep(2)
plan=json.load(open('artifacts/large-primal-budget-old-incremental-plan.json'));targets=[Path(r['path'])for r in plan['caches']];assert targets
for p in targets:assert p.is_dir()and not p.is_symlink()and p.name in ['build','incremental']and p.parent.name=='debug'and p.parent.parent.parent==root
for f in Path('/proc').glob('[0-9]*/exe'):
 try:e=os.readlink(f)
 except OSError:continue
 assert not any(e.startswith(str(p)+'/')for p in targets),e
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
keep=[]
for target in sorted(root.glob('target-*')):
 if not target.is_dir()or target.is_symlink():continue
 candidates=list((target/'debug').glob('*'))+list((target/'debug/examples').rglob('*'))+list((target/'release').rglob('*'))
 for p in candidates:
  if p.is_file()and not p.is_symlink():
   with p.open('rb')as f:magic=f.read(4)
   if magic==b'\x7fELF':keep.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
protected=[root/'artifacts/runs/baseline-v2-20261115/config.json',root/'artifacts/runs/baseline-v2-20261115/results.jsonl',root/'artifacts/runs/cover-choice-heap-final-20261118/config.json'];before={str(p):sha(p)for p in protected};free=shutil.disk_usage('/').free;removed=[]
for p in targets:
 assert not any(subprocess.run(['pgrep','-x',n],capture_output=True).returncode==0 for n in ['cargo','rustc'])
 size=int(subprocess.check_output(['du','-sb',str(p)],text=True).split()[0]);shutil.rmtree(p);removed.append(dict(path=str(p),logical_bytes=size))
for r in keep:assert Path(r['path']).stat().st_size==r['bytes']and sha(Path(r['path']))==r['sha256']
assert before=={str(p):sha(p)for p in protected}
receipt=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),removed_regenerable_caches=removed,logical_bytes=sum(r['logical_bytes']for r in removed),free_before=free,free_after=shutil.disk_usage('/').free,retained_debug_cli_examples_and_release_elfs=keep,all_retained_elf_sha256_verified=True,protected_baseline_and_unlaunched_snapshot_sha256=before,current_default_and_private_measurements_terminal_before_cleanup=True)
Path('artifacts/large-primal-budget-old-cache-cleanup.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v for k,v in receipt.items()if k not in ['retained_debug_cli_examples_and_release_elfs','protected_baseline_and_unlaunched_snapshot_sha256']}),flush=True)
