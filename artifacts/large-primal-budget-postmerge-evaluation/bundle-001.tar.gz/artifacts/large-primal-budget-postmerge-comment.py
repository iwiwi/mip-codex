from pathlib import Path
import os,json,subprocess,sys
root=Path.cwd();os.sched_setaffinity(0,{43});sys.path.insert(0,'scripts')
from benchmark_common import sha256,require_solver_origin
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='3a7749008296b6ef33017153a3b4340d6e7a54d6'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
assert not subprocess.check_output(['git','diff','d12fed38e2f91ed80ee10981fcb45b361afa82fd','HEAD','--','src','scripts','tests','Cargo.toml','Cargo.lock','build.rs'])
info=require_solver_origin(root,root/'target/release/mip-codex');assert info['source_fingerprint']==info['library_source_fingerprint']=='6021621d57155bb7'
assert json.load(open('artifacts/large-primal-budget-main-primary-audit/exit.json'))['gmp_valid']==4
s=json.load(open('artifacts/large-primal-budget-final-snapshot-verification.json'));assert s['config_sha256']=='17594c699b0c484d809689cd919dad26076f57f181d516194e9fa71fff8ddae1'and s['own_final_jobs_launched']is False
cleanup=json.load(open('artifacts/large-primal-budget-old-cache-cleanup.json'));assert cleanup['all_retained_elf_sha256_verified'];assert json.load(open('artifacts/large-primal-budget-old-cache-frozen-reference-audit.json'))['references_into_removed_cargo_cache']==[]
assert sha256(root/'artifacts/runs/baseline-v2-20261115/config.json')=='39551a3b530d8c4e1ed4eb4069c361285e929a84a74d73966bb4c574b43c125c'
assert sha256(root/'artifacts/runs/baseline-v2-20261115/results.jsonl')=='6acf941e6bc3c151cb183c3e5f849af4ea823515bbe987c41e383e7cf45c1bab'
text='''main3a7749008296b6ef33017153a3b4340d6e7a54d6へ統合後、primary専用targetでrelease再ビルド。CLI/library双方のdirectoryとFP6021621d57155bb7を確認し、PR headd12fed38からsrc/scripts/tests/Cargo/build差分0。CLI SHA14ca3ffa1cd98e77c8d480452e17581438e95b7afe00906e07700b241c445bec。incomingと重なるuntracked研究記録はSHAを付けて/tmpへ保持、内容の異なるACTIVE_RESEARCHも退避して失わず、pull後に新blobを照合しました。tracked mainはcleanです。

CPU47/16GiB/1threadの4点は全GMP/strict proof valid。cod105 optimal−12/−12（0nodes/.020778258秒）、5000pair optimal−2500/−2500（0nodes/.052828887秒）、depth試験−6113/LB−9173、512nodes/.206265133秒。z26/60秒は−1181/LB−1575、59,487nodes/60.038169229秒。候補の−1178/LB−1578との差も保持し、同値再現とはせず、安全な点・境界の再検証成功として記録します。

新create-only `large-primal-budget-final-20261118`、config17594c699b0c484d809689cd919dad26076f57f181d516194e9fa71fff8ddae1。全240問×3600秒/16GiB/1thread/cores8..15/swap0/pids512。113snapshot/147libraries全SHA、旧9e5とはbin+4Rustだけ変更し、追加削除なし・libraries同一。snapshot自身のcheckerでcod/pair/depthを再検証。新旧240cgroups空、全自作final未起動、旧9e5をOBSOLETEとして保持。Nov19開始予定を維持。

現在のdefault/私的探索がすべて終了し、全compiler/debug実行停止を確認して、古い実験専用targetのbuild/incrementalだけを整理しました。logical19,240,941,584B、実空き2,123,747,328→20,471,410,688B。debug CLI/examplesと全release ELFは前後SHA保持、Git内57 frozen ELF manifestsに削除cacheへの参照0。元native720 config/resultsおよび旧final configのSHA不変。ライブラリ・検査器・計測済み点/ログ/凍結ELFは保持しています。

元native720+事前選択disk回復1は全終端済み、holdout52の個別成績を改善判断へ参照していません。新最終評価は未起動。全体優位/新記録は未達で、次は構造gateを保ったweighted長roundの検証へ進みます。
'''
usage=subprocess.check_output(['python3','scripts/ai_usage.py'],text=True);Path('artifacts/large-primal-budget-postmerge-ai-usage.json').write_text(usage);p=Path('artifacts/large-primal-budget-postmerge-comment.md');p.write_text(text+'\n現在までのAI資源量:\n```json\n'+usage+'```\n');r=subprocess.run(['gh','pr','comment','129','--repo','iwiwi/mip-codex','--body-file',str(p)],capture_output=True,text=True);Path('artifacts/large-primal-budget-postmerge-comment.log').write_text(r.stdout+r.stderr);r.check_returncode();print(r.stdout)
