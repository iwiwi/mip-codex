from pathlib import Path
import sys,json,os,subprocess
sys.path.insert(0,'scripts');from benchmark_common import sha256,atomic_json,require_solver_origin
os.sched_setaffinity(0,{43});root=Path.cwd();run=root/'artifacts/runs/large-primal-budget-final-20261118';c=json.load(open(run/'config.json'))
assert c['git_sha']=='3a7749008296b6ef33017153a3b4340d6e7a54d6'
assert c['solver_build_info']['source_fingerprint']==c['solver_build_info']['library_source_fingerprint']=='6021621d57155bb7'
assert not c['source_dirty']
assert(c['seconds'],c['threads'],c['memory_bytes'],c['cores'])==(3600,1,16*1024**3,list(range(8,16)))
assert len(c['instances'])==len(c['jobs'])==240 and{j['solver']for j in c['jobs']}=={'rust'}
for name,h in c['snapshot_sha256'].items():assert sha256(run/'snapshot'/name)==h
for name,h in c['library_sha256'].items():assert sha256(name)==h
oldrun=root/'artifacts/runs/cover-choice-heap-final-20261118';old=json.load(open(oldrun/'config.json'))
assert sha256(oldrun/'config.json')=='9e5fc98a69b2d1d849d30446c5ccb9cb39b04a3167647e319c2558b50158e846'
assert c['library_sha256']==old['library_sha256']
assert set(c['snapshot_sha256'])==set(old['snapshot_sha256'])
changed=sorted(name for name,h in c['snapshot_sha256'].items()if old['snapshot_sha256'][name]!=h)
assert changed==['bin/mip-codex','src/binary_graph.rs','src/binary_graph/weighted_cover.rs','src/main.rs','src/solve.rs'],changed
for directory,cfg in [(run,c),(oldrun,old)]:
 assert not(directory/'results.jsonl').exists()
 assert not list((directory/'cases').glob('*/summary.json'))
 for j in cfg['jobs']:
  cg=Path('/sys/fs/cgroup/mip-codex-bench')/cfg['id']/j['id'];events=dict(line.split()for line in(cg/'cgroup.events').read_text().splitlines())
  assert events['populated']=='0'and not(cg/'cgroup.procs').read_text().strip()
  assert(cg/'memory.max').read_text().strip()==str(16*1024**3)
  assert(cg/'memory.swap.max').read_text().strip()=='0'and(cg/'pids.max').read_text().strip()=='512'
source=root/'artifacts/large-primal-budget-main-primary-audit'
for label,model in [('cod105',root/'data/raw/benchmark/cod105.mps.gz'),('pairs5000',Path('/home/ubuntu/mip-large-packing-profile/artifacts/large-cover-profile-v1/pairs5000.mps')),('depth-cycles',Path('/home/ubuntu/mip-graph-large-capacity/artifacts/large-capacity-depth-controls/many-cycles-0/model.mps'))]:
 cmd=[str(root/'.venv/bin/python'),str(run/'snapshot/scripts/verify_cover_cuts.py'),str(model),str(source/label/'result.json')]
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=600)
 (root/f'artifacts/large-primal-budget-snapshot-{label}-proof.log').write_text(r.stdout+r.stderr)
 assert r.returncode==0 and json.loads(r.stdout)['valid']is True
info=require_solver_origin(root,root/'target/release/mip-codex');assert info['source_fingerprint']=='6021621d57155bb7'
recovery=json.load(open('artifacts/large-capacity-baseline-disk-recovery-receipt.json'))
proof=dict(run=str(run.relative_to(root)),config_sha256=sha256(run/'config.json'),source_fingerprint='6021621d57155bb7',source_git_sha=c['git_sha'],seconds=3600,threads=1,memory_bytes=16*1024**3,instances=240,jobs=240,status='create-only; neverlaunched',cores=c['cores'],snapshot_files_verified=len(c['snapshot_sha256']),changed_snapshot_files=changed,snapshot_spectral_large_depth_checker_valid=True,libraries_verified=len(c['library_sha256']),libraries_unchanged_from_previous_snapshot=True,creation_hash_copy_cpu=43,verification_cpu=43,cgroups_empty=240,old_cgroups_empty=240,native_disk_recovery_required_before_launch=dict(tag=Path(recovery['directory']).name,config_sha256=recovery['config_sha256'],jobs=1),own_final_jobs_launched=False)
atomic_json(root/'artifacts/large-primal-budget-final-snapshot-verification.json',proof)
atomic_json(root/'experiments/large-primal-budget-snapshot-20261118.json',proof)
atomic_json(oldrun/'OBSOLETE.json',dict(reason='superseded before launch by main129 verified capacity-gated large primal budget snapshot',replacement=str(run.relative_to(root)),replacement_config_sha256=proof['config_sha256'],old_config_sha256=sha256(oldrun/'config.json'),jobs_launched=False))
print(json.dumps(proof),flush=True)
