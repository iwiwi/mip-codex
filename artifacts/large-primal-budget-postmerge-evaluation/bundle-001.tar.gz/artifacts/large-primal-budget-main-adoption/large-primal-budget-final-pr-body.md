大規模で疎な純binary packingで、主解探索の時間配分を5%から25%へ増やします。portfolio/heapが有効で、既存heapのn>4096・operation見積り・追加memory guardすべてに適合する場合だけ適用。`MIP_GRAPH_LARGE_PRIMAL_BUDGET=0/1` の既定はON。旧公開APIは5%のwrapperを維持します。認識・数学・境界・枝刈り・反復上限・乱数・全体期限・memory limitは変えません。問題名や既知点/目標値をsolverへ埋め込みません。

初期515fd/e180と最終939230/602を別凍結。違いはLimits既定boolだけ。各353Rust/4ignored、各1200全列挙/GMP/strict proof・7410改ざん拒否、各12large/component oracle/GMP/proofに成功。最終largeは主解6組同じ、upper2同値/1改善/3悪化も保存。

最終同一CLI35849、1thread/16GiBの主な比較:

| 入力/秒 | OFF primal/dual | ON primal/dual |
|---|---|---|
| cod105/10 | -12/-12 | -12/-12（root最適） |
| S3/30 | -16/-16 | -16/-16（両6042153nodes） |
| z26/60 | -1154/-1578 | -1178/-1578 |
| z26/300 | -1178/-1578 | -1188/-1575 |
| CDC/60 | -279/-434 | -279/-431 |
| CDC/300 | -279/-434 | -285/-426 |

生成5000pair ONのroot最適−2500を含む9controls+4longの13出力は元MPS GMP/strict proof全成功。初期も13出力全成功、z26/300は−1181/−1578→−1188/−1575、CDC/300は−279/−434→−285/−429。初期z26/60では下界が−1575→−1578へ悪化したことも保持。同じ時間制限でも初期局所探索やLPの時刻打切りで値が変動するため、同値再現とは主張しません。

同日native300秒/16GiB/1threadはz26でHS1.16.0−1147/LB−2114、SCIP10.0.2−1013/LB−1539.9495。候補は主解が良く、SCIPの下界が強い。CDCはHS−280/−1111（306.730秒）、SCIP−237/−11744（300.006秒）、両点GMP validで候補の主解/下界が強い。GLPK5は両入力420秒watchdog、時間内点なし。z26の旧研究wrapperでは遅着441.545秒の−460を別GMP確認し時間同条件比較から除外。新CDCはprocess group全体killを行い対応live processなしも確認。全失敗・超過を保持。候補long CPU45/native46は同マシンで専用1core。初期longのmetadata44誤記は訂正receipt+生OS affinity45を保存し、最終はlabelも45です。

最終開発188問はprimal187同値/1悪化、dual172同値/2改善/1悪化/13比較不能、finite各175、両182time_limit/2optimal/4numerical_error。376fresh strict proof全成功、129可行点全GMP/公式valid。認識されたgraphはcod105/S3各1024だけで、新条件n>4096に全件不適合、実発動0。graph20の0点可行解→点なし損失とfast0507下界悪化を保持。graph20追加3交互pairsは両点なし/LB−37（6proof valid、点0でGMP対象0）で、元188を置換しません。初期188も376fresh/128点GMP公式成功、supportcase12−13→−12損失を保持し、追加3pairsは両−13で6GMP/proof成功。未発動路の差について因果は断定しません。

既存gateと期限を保ち、初期/最終の両方で2つの評価外packing入力の300秒主解を改善し、最終では両下界も改善したため採用します。全15archiveのpayload/保持ELFを元保持位置で再SHA照合。初回checker path不在/driver assert/出力directory未作成/広いworktree checkout停止等も全初版ログと修正後検査を保存。詳細はdocs/GRAPH_LARGE_PRIMAL_BUDGET_RESULTS.mdとJOURNAL.md。

この枝はmain128 postmerge/未起動snapshot9e5、私的LNS等の不採用も保存。私的な旧別sourceは自作親から−1198に達し元GMP/公式成功、現在の掲載bestと同着です（SOL/親由来/再検証手順あり）。main602の成績や新記録には帰属しません。最終240は未起動、holdout52個別結果未参照、全体優位/新記録目標は未達です。

AI資源量:
```json
{
  "sessions": 1,
  "totals": {
    "input_tokens": 1844968910,
    "cached_input_tokens": 1831854336,
    "output_tokens": 9154299,
    "reasoning_output_tokens": 5610260,
    "total_tokens": 1854123209
  },
  "note": "input_tokensはキャッシュ分を含む。reasoningはoutputの内数。ローカルログの最終記録まで。"
}
```
