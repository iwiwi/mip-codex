from pathlib import Path
import os,sys,json,subprocess,re,datetime
os.sched_setaffinity(0,{43});root=Path.cwd();sys.path.insert(0,'scripts')
from benchmark_common import sha256,require_solver_origin,atomic_json
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
assert not subprocess.check_output(['git','diff','939230aa1d','HEAD','--','src','scripts','tests','Cargo.toml','Cargo.lock','build.rs'])
initial=subprocess.check_output(['git','show','515fd3555b:src/solve.rs'],text=True);assert initial.replace('graph_large_primal_budget:false,','graph_large_primal_budget:true,')==(root/'src/solve.rs').read_text()
assert subprocess.check_output(['git','diff','--name-only','515fd3555b','939230aa1d','--','src'],text=True).splitlines()==['src/solve.rs']
info=require_solver_origin(root,root/'artifacts/large-primal-budget-default-frozen/bin/mip-codex');assert info['source_fingerprint']==info['library_source_fingerprint']=='6021621d57155bb7'
assert sha256(root/'artifacts/large-primal-budget-default-frozen/bin/mip-codex')=='35849e98ea20f9b65ac21dbd74ce98b50996eb75be9ab37a3015cf96b027f3c8'
for prefix,points in [('large-primal-budget',128),('large-primal-budget-default',129)]:
 tests=(root/f'artifacts/{prefix}-tests.log').read_text();m=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',tests);assert(sum(int(a)for a,b,c in m),sum(int(b)for a,b,c in m),sum(int(c)for a,b,c in m))==(353,0,4)
 a=json.load(open(f'artifacts/{prefix}-development-parallel-audit/summary.json'));assert a['fresh']==a['cut_valid']==376 and a['strict_valid']==a['official_valid']==points
 a=json.load(open(f'artifacts/{prefix}-enumeration/summary.json'));assert a==dict(models=200,runs=1200,failures=0,corruptions_rejected=7410)
 assert json.load(open(f'artifacts/{prefix}-large-generated/summary.json'))['gmp_valid']==12
 assert json.load(open(f'artifacts/{prefix}-main-controls/exit.json'))['gmp_valid']==9
 assert json.load(open(f'artifacts/{prefix}-long-controls/exit.json'))['gmp_valid']==4
 data=json.load(open(f'artifacts/{prefix}-development-analysis.json'))
 assert all(row[k]['binary_graph']is None or row[k]['binary_graph']['vertices']<=4096 for row in data['records']for k in ['before','after'])
for suffix,pattern in [('development-screen/cases','*/*/job.json'),('large-generated','*/job.json'),('main-controls','*/*/*/job.json'),('long-controls','*/*/*/job.json')]:
 jobs=list((root/f'artifacts/large-primal-budget-default-{suffix}').glob(pattern));assert jobs
 for p in jobs:
  d=json.load(open(p));before=p.parent.name=='before'or p.parent.name.endswith('-0')or p.parent.name=='0';assert d['environment'].get('MIP_GRAPH_LARGE_PRIMAL_BUDGET')==('0'if before else None),p
assert json.load(open('artifacts/large-primal-budget-inactive-recheck/summary.json'))==dict(outputs=6,gmp_valid=6,proof_valid=6)
assert json.load(open('artifacts/large-primal-budget-default-inactive-recheck/summary.json'))==dict(outputs=6,gmp_valid=0,proof_valid=6)
long=json.load(open('artifacts/large-primal-budget-default-long-controls/records.json'))
for name in ['z26.mps.gz','cdc7-4-3-2.mps.gz']:
 a,b=[next(r for r in long if r['name']==name and r['flag']==flag)for flag in [0,1]];assert b['objective']<a['objective']and b['dual_bound']>=a['dual_bound']
subprocess.run(['python3','artifacts/large-primal-budget-archive-preflight.py'],check=True,capture_output=True,text=True);archives=json.load(open('artifacts/large-primal-budget-archive-preflight.json'));assert len(archives)==15
subprocess.run(['git','push','origin','graph-large-primal-budget'],check=True,capture_output=True,text=True);head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert subprocess.check_output(['git','ls-remote','origin','refs/heads/graph-large-primal-budget'],text=True).split()[0]==head
atomic_json(root/'artifacts/large-primal-budget-adoption-preflight.json',dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,source_fingerprint='6021621d57155bb7',source_unchanged_since_default_core=True,default_only_bool_change_from_initial=True,archives=archives,default_environment_verified=True,all_valid=True))
body='''大規模で疎な純binary packingで、主解探索の時間配分を5%から25%へ増やします。portfolio/heapが有効で、既存heapのn>4096・operation見積り・追加memory guardすべてに適合する場合だけ適用。`MIP_GRAPH_LARGE_PRIMAL_BUDGET=0/1` の既定はON。旧公開APIは5%のwrapperを維持します。認識・数学・境界・枝刈り・反復上限・乱数・全体期限・memory limitは変えません。問題名や既知点/目標値をsolverへ埋め込みません。

初期515fd/e180と最終939230/602を別凍結。違いはLimits既定boolだけ。各353Rust/4ignored、各1200全列挙/GMP/strict proof・7410改ざん拒否、各12large/component oracle/GMP/proofに成功。最終largeは主解6組同じ、upper2同値/1改善/3悪化も保存。

最終同一CLI35849、1thread/16GiBの主な比較:

| 入力/秒 | OFF primal/dual | ON primal/dual |
|---|---|---|
| cod105/10 | -12/-12 | -12/-12（root最適） |
| S3/30 | -16/-16 | -16/-16（両6042153nodes） |
| z26/60 | -1154/-1578 | -1178/-1578 |
| z26/300 | -1178/-1578 | -1188/-1575 |
| CDC/60 | -279/-434 | -279/-431 |
| CDC/300 | -279/-434 | -285/-426 |

生成5000pair ONのroot最適−2500を含む9controls+4longの13出力は元MPS GMP/strict proof全成功。初期も13出力全成功、z26/300は−1181/−1578→−1188/−1575、CDC/300は−279/−434→−285/−429。初期z26/60では下界が−1575→−1578へ悪化したことも保持。同じ時間制限でも初期局所探索やLPの時刻打切りで値が変動するため、同値再現とは主張しません。

同日native300秒/16GiB/1threadはz26でHS1.16.0−1147/LB−2114、SCIP10.0.2−1013/LB−1539.9495。候補は主解が良く、SCIPの下界が強い。CDCはHS−280/−1111（306.730秒）、SCIP−237/−11744（300.006秒）、両点GMP validで候補の主解/下界が強い。GLPK5は両入力420秒watchdog、時間内点なし。z26の旧研究wrapperでは遅着441.545秒の−460を別GMP確認し時間同条件比較から除外。新CDCはprocess group全体killを行い対応live processなしも確認。全失敗・超過を保持。候補long CPU45/native46は同マシンで専用1core。初期longのmetadata44誤記は訂正receipt+生OS affinity45を保存し、最終はlabelも45です。

最終開発188問はprimal187同値/1悪化、dual172同値/2改善/1悪化/13比較不能、finite各175、両182time_limit/2optimal/4numerical_error。376fresh strict proof全成功、129可行点全GMP/公式valid。認識されたgraphはcod105/S3各1024だけで、新条件n>4096に全件不適合、実発動0。graph20の0点可行解→点なし損失とfast0507下界悪化を保持。graph20追加3交互pairsは両点なし/LB−37（6proof valid、点0でGMP対象0）で、元188を置換しません。初期188も376fresh/128点GMP公式成功、supportcase12−13→−12損失を保持し、追加3pairsは両−13で6GMP/proof成功。未発動路の差について因果は断定しません。

既存gateと期限を保ち、初期/最終の両方で2つの評価外packing入力の300秒主解を改善し、最終では両下界も改善したため採用します。全15archiveのpayload/保持ELFを元保持位置で再SHA照合。初回checker path不在/driver assert/出力directory未作成/広いworktree checkout停止等も全初版ログと修正後検査を保存。詳細はdocs/GRAPH_LARGE_PRIMAL_BUDGET_RESULTS.mdとJOURNAL.md。

この枝はmain128 postmerge/未起動snapshot9e5、私的LNS等の不採用も保存。私的な旧別sourceは自作親から−1198に達し元GMP/公式成功、現在の掲載bestと同着です（SOL/親由来/再検証手順あり）。main602の成績や新記録には帰属しません。最終240は未起動、holdout52個別結果未参照、全体優位/新記録目標は未達です。
'''
usage=subprocess.check_output(['python3','scripts/ai_usage.py'],text=True);Path('artifacts/large-primal-budget-final-body-ai-usage.json').write_text(usage);p=Path('artifacts/large-primal-budget-final-pr-body.md');p.write_text(body+'\nAI資源量:\n```json\n'+usage+'```\n');request=root/'artifacts/large-primal-budget-pr-patch.json';atomic_json(request,dict(body=p.read_text()));r=subprocess.run(['gh','api','--method','PATCH','repos/iwiwi/mip-codex/pulls/129','--input',str(request)],capture_output=True,text=True);Path('artifacts/large-primal-budget-pr-patch-response.json').write_text(r.stdout+r.stderr);r.check_returncode()
text='''採用前再照合が完了しました。default939230/602からsrc/scripts/tests/Cargo/build差分0、初期515fdから既定boolだけ変更。全15archive payloadと除外ELFを元保持位置で再SHA検証、376default job/12large/13controlsでbefore明示0・after unsetを確認しました。

default z26/300秒−1178/LB−1578→−1188/LB−1575、CDC/300秒−279/LB−434→−285/LB−426、全4GMP/strict proof valid。各源353Rust/1200全列挙/7410改ざん拒否/12large/376fresh proof（初期128点・最終129点GMP公式）/13主制御を保持。生成上界悪化、初期z26/60秒下界悪化、初期S12/最終graph20の可行点損失、4numerical_errorも削除しません。188は全認識graph1024変数だけで新size gate未発動。追加S12両−13/graph20両点なしの各3pairsも元損失を置換しません。

native300比較とGLPK watchdog/遅着を別枠で保存。SCIPがz26の強い下界を持つ点も明示。私的旧別sourceの1198点はGMP/公式検査済みの掲載best同着ですが、mainへ帰属せず新記録でもありません。2つの評価外入力の同時間主解改善と正しさ/guardを根拠に本候補を採用します。最終240は未起動、全体優位/新記録は未達です。
'''
usage=subprocess.check_output(['python3','scripts/ai_usage.py'],text=True);Path('artifacts/large-primal-budget-adoption-ai-usage.json').write_text(usage);p=Path('artifacts/large-primal-budget-adoption-comment.md');p.write_text(text+'\nその時点のAI資源量:\n```json\n'+usage+'```\n');r=subprocess.run(['gh','pr','comment','129','--repo','iwiwi/mip-codex','--body-file',str(p)],capture_output=True,text=True);Path('artifacts/large-primal-budget-adoption-comment.log').write_text(r.stdout+r.stderr);r.check_returncode()
v=json.loads(subprocess.check_output(['gh','pr','view','129','--repo','iwiwi/mip-codex','--json','headRefOid,isDraft,state'],text=True));assert v['state']=='OPEN'and v['headRefOid']==head
if v['isDraft']:
 r=subprocess.run(['gh','pr','ready','129','--repo','iwiwi/mip-codex'],capture_output=True,text=True);Path('artifacts/large-primal-budget-pr-ready.log').write_text(r.stdout+r.stderr);r.check_returncode()
r=subprocess.run(['gh','pr','merge','129','--repo','iwiwi/mip-codex','--squash','--match-head-commit',head],capture_output=True,text=True);Path('artifacts/large-primal-budget-pr-merge.log').write_text(r.stdout+r.stderr);r.check_returncode();v=json.loads(subprocess.check_output(['gh','pr','view','129','--repo','iwiwi/mip-codex','--json','headRefOid,state,mergeCommit,mergedAt,url'],text=True));assert v['state']=='MERGED'and v['headRefOid']==head;atomic_json(root/'artifacts/large-primal-budget-pr-merge.json',v);print(json.dumps(v),flush=True)
