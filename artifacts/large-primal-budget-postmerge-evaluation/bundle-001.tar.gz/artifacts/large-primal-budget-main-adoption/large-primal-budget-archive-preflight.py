from pathlib import Path
import os,json,tarfile,hashlib
os.sched_setaffinity(0,{43});root=Path.cwd();mapping={'cover-lns-neutral-evaluation':'/home/ubuntu/mip-cover-choice-heap','cover-diverse-long-evaluation':'/home/ubuntu/mip-cover-choice-heap','cover-choice-heap-postmerge-evaluation':'/home/ubuntu/mip-codex','cdc-packing-evaluation':'/home/ubuntu/mip-codex','cover-parent-lns-evaluation':'/home/ubuntu/mip-cover-choice-heap','graph-components-baseline-evaluation':'/home/ubuntu/mip-codex','graph-components-prototype-evaluation':'/home/ubuntu/mip-codex','cdc-packing-native300-evaluation':'/home/ubuntu/mip-codex'}
names=list(mapping)+['large-primal-budget-'+s+'-evaluation'for s in ['correctness','default-correctness','controls60','initial-long','development','default-development','default-controls']];records=[]
for name in names:
 d=root/'artifacts'/name;manifest=json.load(open(d/'manifest.json'));lookup={r['path']:r for r in manifest};assert len(lookup)==len(manifest);seen=set()
 for p in sorted(d.glob('bundle-*.tar.gz')):
  with tarfile.open(p)as t:
   for m in t:
    assert m.name not in seen;seen.add(m.name);r=lookup[m.name];b=t.extractfile(m).read();assert len(b)==r['bytes']and hashlib.sha256(b).hexdigest()==r['sha256']
 assert seen==set(lookup)
 base=Path(mapping.get(name,str(root)));excluded=json.load(open(d/'excluded-elf.json'))
 for r in excluded:
  p=base/r['path'];assert p.is_file(),p;assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'],p
 records.append(dict(archive=name,payloads=len(manifest),excluded_elfs=len(excluded),elf_original_root=str(base),all_payload_sha256=True,all_excluded_elf_sha256=True))
Path('artifacts/large-primal-budget-archive-preflight.json').write_text(json.dumps(records,indent=2));print(json.dumps(records))
