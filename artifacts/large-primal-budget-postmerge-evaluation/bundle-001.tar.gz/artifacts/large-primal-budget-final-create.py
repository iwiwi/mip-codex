from pathlib import Path
import sys,os,json,argparse,hashlib,subprocess,time
sys.path.insert(0,'scripts');import benchmark
root=Path.cwd()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='3a7749008296b6ef33017153a3b4340d6e7a54d6'
deadline=time.monotonic()+1800
while not(root/'artifacts/large-primal-budget-main-primary-audit/exit.json').exists():
 assert time.monotonic()<deadline,'primary smoke not terminal'
 time.sleep(2)
assert json.load(open('artifacts/large-primal-budget-main-primary-audit/exit.json'))['gmp_valid']==4
oldpath=root/'artifacts/runs/cover-choice-heap-final-20261118/config.json'
assert hashlib.sha256(oldpath.read_bytes()).hexdigest()=='9e5fc98a69b2d1d849d30446c5ccb9cb39b04a3167647e319c2558b50158e846'
old=json.load(open(oldpath));destination=root/'artifacts/runs/large-primal-budget-final-20261118'
assert not destination.exists();solvers=sorted({j['solver']for j in old['jobs']});assert solvers==['rust']
original=benchmark.require_solver_origin
def pinned_origin(*a,**kw):
 os.sched_setaffinity(0,{43});info=original(*a,**kw)
 assert info['source_fingerprint']==info['library_source_fingerprint']=='6021621d57155bb7'
 return info
benchmark.require_solver_origin=pinned_origin
benchmark.create(argparse.Namespace(directory=str(destination),seconds=old['seconds'],cores=','.join(map(str,old['cores'])),solvers=','.join(solvers),manifest=str(root/'data/manifest.json'),names=None,allow_dirty=False))
