NAME graph
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
COLUMNS
 x0 obj -4
 x0 r0 1
 x0 r1 4
 x0 r3 1
 x1 obj -4
 x1 r0 3
 x1 r2 3
 x1 r3 1
 x2 obj -4
 x2 r3 1
 x3 obj -4
 x3 r1 5
 x3 r2 1
 x3 r3 1
RHS
 rhs obj -1.625
 rhs r0 3
 rhs r1 5
 rhs r2 3
 rhs r3 1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
ENDATA
