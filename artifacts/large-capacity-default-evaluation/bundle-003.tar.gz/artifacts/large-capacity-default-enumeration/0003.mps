NAME graph
OBJSENSE
 MAX
ROWS
 N obj
 L r0
COLUMNS
 x0 obj 3
 x0 r0 1
 x1 obj 3
 x2 obj 3
 x2 r0 5
RHS
 rhs obj -3.625
 rhs r0 5
BOUNDS
 BV b x0
 BV b x1
 BV b x2
ENDATA
