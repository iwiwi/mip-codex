NAME graph
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
COLUMNS
 x0 obj -1
 x0 r0 -2
 x0 r1 -4
 x0 r8 -1
 x1 obj -1
 x1 r0 -4
 x1 r2 -2
 x1 r3 -4
 x1 r4 -5
 x2 obj -1
 x2 r1 -1
 x2 r5 -1
 x2 r6 -1
 x2 r8 -1
 x3 obj -1
 x3 r2 -5
 x3 r5 -1
 x3 r7 -5
 x4 obj -1
 x4 r3 -4
 x4 r6 -4
 x4 r8 -1
 x5 obj -1
 x5 r4 -4
 x5 r7 -3
 x5 r8 -1
RHS
 rhs obj -1.625
 rhs r0 -4
 rhs r1 -4
 rhs r2 -5
 rhs r3 -4
 rhs r4 -5
 rhs r5 -1
 rhs r6 -4
 rhs r7 -5
 rhs r8 -1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
ENDATA
