NAME graph
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
 G r2
 G r3
 G r4
 G r5
 G r6
 G r7
 G r8
 G r9
 G r10
 G r11
COLUMNS
 x0 obj -3
 x0 r0 -1
 x0 r1 -2
 x0 r2 -1
 x1 obj -3
 x1 r0 -2
 x1 r3 -1
 x1 r4 -4
 x1 r5 -1
 x2 obj -3
 x2 r6 -3
 x3 obj -3
 x3 r3 -2
 x4 obj -3
 x4 r7 -3
 x4 r8 -4
 x5 obj -3
 x5 r1 -4
 x5 r9 -5
 x5 r10 -1
 x6 obj -3
 x6 r7 -1
 x6 r9 -1
 x6 r11 -2
 x7 obj -3
 x7 r4 -4
 x7 r6 -4
 x7 r11 -1
 x8 obj -3
 x8 r2 -1
 x8 r5 -2
 x8 r8 -4
 x8 r10 -5
RHS
 rhs obj 5.375
 rhs r0 -2
 rhs r1 -4
 rhs r2 -1
 rhs r3 -2
 rhs r4 -4
 rhs r5 -2
 rhs r6 -4
 rhs r7 -3
 rhs r8 -4
 rhs r9 -5
 rhs r10 -5
 rhs r11 -2
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
 BV b x6
 BV b x7
 BV b x8
ENDATA
