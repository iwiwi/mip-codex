NAME graph
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x0 obj 1
 x1 obj 1
 x1 r0 3
 x2 obj 1
 x2 r0 2
 x2 r1 4
 x3 obj 1
 x3 r1 1
RHS
 rhs obj 4.625
 rhs r0 3
 rhs r1 4
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
ENDATA
