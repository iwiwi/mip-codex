NAME graph
OBJSENSE
 MAX
ROWS
 N obj
 L r0
COLUMNS
 x0 obj 2
 x0 r0 1
 x1 obj 2
 x2 obj 2
 x2 r0 1
RHS
 rhs obj 2.75
 rhs r0 1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
ENDATA
