NAME graph
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
COLUMNS
 x0 obj -2
 x0 r0 4
 x0 r1 5
 x0 r2 5
 x1 obj -2
 x1 r0 1
 x1 r3 4
 x1 r4 3
 x2 obj -2
 x2 r3 4
 x2 r5 5
 x2 r6 2
 x3 obj -2
 x3 r1 3
 x3 r4 1
 x3 r5 3
 x3 r7 3
 x4 obj -2
 x4 r2 1
 x4 r6 2
 x4 r7 1
RHS
 rhs obj 1.625
 rhs r0 4
 rhs r1 5
 rhs r2 5
 rhs r3 4
 rhs r4 3
 rhs r5 5
 rhs r6 2
 rhs r7 3
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
ENDATA
