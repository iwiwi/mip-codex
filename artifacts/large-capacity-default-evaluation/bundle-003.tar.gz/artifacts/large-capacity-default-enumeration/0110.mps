NAME graph
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x0 obj -4
 x0 r0 3
 x0 r1 1
 x1 obj -4
 x1 r0 4
 x1 r1 1
 x2 obj -4
 x2 r1 1
RHS
 rhs obj 5.625
 rhs r0 4
 rhs r1 1
BOUNDS
 BV b x0
 BV b x1
 BV b x2
ENDATA
