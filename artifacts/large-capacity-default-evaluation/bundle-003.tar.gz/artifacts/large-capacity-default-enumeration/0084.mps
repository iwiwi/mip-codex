NAME graph
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
 L r2
 L r3
 L r4
 L r5
 L r6
 L r7
COLUMNS
 x0 obj -2
 x0 r0 5
 x0 r1 5
 x0 r2 1
 x0 r3 4
 x1 obj -2
 x1 r4 3
 x2 obj -2
 x2 r0 5
 x2 r5 5
 x2 r6 4
 x3 obj -2
 x3 r1 2
 x3 r4 2
 x3 r7 4
 x4 obj -2
 x4 r2 3
 x4 r5 3
 x5 obj -2
 x5 r3 4
 x5 r6 1
 x5 r7 5
RHS
 rhs obj 3.875
 rhs r0 5
 rhs r1 5
 rhs r2 3
 rhs r3 4
 rhs r4 3
 rhs r5 5
 rhs r6 4
 rhs r7 5
BOUNDS
 BV b x0
 BV b x1
 BV b x2
 BV b x3
 BV b x4
 BV b x5
ENDATA
