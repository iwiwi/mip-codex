from pathlib import Path
import os,sys,json,collections,hashlib
os.sched_setaffinity(0,{43});sys.path.insert(0,'scripts');from verify_cover_cuts import exact_model
records=[]
for name,group in [('cod105.mps.gz','benchmark'),('sorrell3.mps.gz','benchmark'),('sorrell7.mps.gz','exploratory')]:
 p=Path('data/raw')/group/name;names,variables,rows=exact_model(p);n=len(names);index={v:i for i,v in enumerate(names)};conflict=[0]*n
 for row in rows:
  vertices=[index[v]for v,a in row['coefficients'].items()if a]
  for a in vertices:
   for b in vertices:
    if a!=b:conflict[a]|=1<<b
 import re
 import itertools
 graded=sorted(range(n),key=lambda v:(v.bit_count(),v));gradedlex=[sum(1<<b for b in group)for weight in range(n.bit_length())for group in itertools.combinations(range(n.bit_length()-1),weight)];natural=sorted(range(n),key=lambda v:[int(t)if t.isdigit()else t for t in re.split(r'(\d+)',names[v])]);candidates=[]
 for source_name,ordering in [('input',list(range(n))),('natural_variable_order',natural)]:
  for target_name,labels in [('binary',list(range(n))),('weight_graded_binary',graded),('weight_graded_lex',gradedlex)]:
   mapping=[0]*n
   for v,label in zip(ordering,labels):mapping[v]=label
   inverse=[0]*n
   for v,label in enumerate(mapping):inverse[label]=v
   mapped=[]
   for v in inverse:
    bits=conflict[v];row=0
    while bits:
     low=bits&-bits;bits-=low;row|=1<<mapping[low.bit_length()-1]
    mapped.append(row)
   mask=[bool(mapped[0]&(1<<d))for d in range(n)];shells=collections.defaultdict(set)
   for d,val in enumerate(mask):shells[d.bit_count()].add(val)
   symmetric=all(len(vals)==1 for vals in shells.values());cayley=True
   for v in range(n):
    expected=sum(1<<(v^d)for d in range(n)if mask[d])
    if expected!=mapped[v]:cayley=False;break
   r=dict(name=name,n=n,mapping=source_name+'-'+target_name,cayley=cayley,hamming_symmetric_first_row=symmetric,conflict_shells=[k for k,vals in shells.items()if vals=={True}],input_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
   if cayley:
    spectrum=[int(val)for val in mask];step=1
    while step<n:
     for start in range(0,n,step*2):
      for i in range(start,start+step):aa,bb=spectrum[i],spectrum[i+step];spectrum[i],spectrum[i+step]=aa+bb,aa-bb
     step*=2
    D=spectrum[0];L=min(spectrum);r.update(degree=D,minimum_eigenvalue=L,unweighted_upper=n*(-L)//(D-L)if D>L else n,vertex_labels=mapping)
   candidates.append(r);print(json.dumps({k:val for k,val in r.items()if k!='vertex_labels'}),flush=True)
 r=dict(name=name,candidates=candidates)
 records.append(r);
Path('artifacts/cayley-structure-profile-v3.json').write_text(json.dumps(records,indent=2))
