from pathlib import Path
import os,sys,json,collections,hashlib
os.sched_setaffinity(0,{43});sys.path.insert(0,'scripts');from verify_cover_cuts import exact_model
records=[]
for name,group in [('cod105.mps.gz','benchmark'),('sorrell3.mps.gz','benchmark'),('sorrell7.mps.gz','exploratory')]:
 p=Path('data/raw')/group/name;names,variables,rows=exact_model(p);n=len(names);index={v:i for i,v in enumerate(names)};conflict=[0]*n
 for row in rows:
  vertices=[index[v]for v,a in row['coefficients'].items()if a]
  for a in vertices:
   for b in vertices:
    if a!=b:conflict[a]|=1<<b
 mask=[bool(conflict[0]&(1<<d))for d in range(n)];shells=collections.defaultdict(set)
 for d,v in enumerate(mask):shells[d.bit_count()].add(v)
 symmetric=all(len(v)==1 for v in shells.values());cayley=True
 for v in range(n):
  expected=sum(1<<(v^d)for d in range(n)if mask[d])
  if expected!=conflict[v]:cayley=False;break
 r=dict(name=name,n=n,cayley=cayley,hamming_symmetric_first_row=symmetric,conflict_shells=[k for k,v in shells.items()if v=={True}],input_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 if cayley:
  spectrum=[int(v)for v in mask];step=1
  while step<n:
   for start in range(0,n,step*2):
    for i in range(start,start+step):a,b=spectrum[i],spectrum[i+step];spectrum[i],spectrum[i+step]=a+b,a-b
   step*=2
  D=spectrum[0];L=min(spectrum);r.update(degree=D,minimum_eigenvalue=L,unweighted_upper=n*(-L)//(D-L)if D>L else n)
 records.append(r);print(json.dumps(r),flush=True)
Path('artifacts/cayley-structure-profile.json').write_text(json.dumps(records,indent=2))
