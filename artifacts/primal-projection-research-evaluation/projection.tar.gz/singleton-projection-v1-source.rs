//! 厳密な単変数等式と箱冗長行の独立診断。元問題への証明/点検査は別途必要。
use mip_codex::{mps,model::{Model,Row},solve::{self,Limits}};
use std::{path::Path,time::Instant};
fn integer(x:f64)->Option<i128>{(x.is_finite()&&x.fract()==0.&&x.abs()<=1099511627776.).then_some(x as i128)}
fn redundant(m:&Model,r:&Row)->bool{
 let(mut low,mut high)=(0i128,0i128);
 for &(j,a)in &r.coefficients{
  let Some(a)=integer(a)else{return false;};let v=&m.variables[j];let(Some(l),Some(u))=(v.lower.and_then(integer),v.upper.and_then(integer))else{return false;};
  let(Some(x),Some(y))=(a.checked_mul(l),a.checked_mul(u))else{return false;};let(Some(l),Some(h))=(low.checked_add(x.min(y)),high.checked_add(x.max(y)))else{return false;};low=l;high=h;
 }
 r.lower.is_none_or(|b|integer(b).is_some_and(|b|low>=b))&&r.upper.is_none_or(|b|integer(b).is_some_and(|b|high<=b))
}
fn main(){
 let a:Vec<_>=std::env::args().collect();if a.get(1).is_some_and(|s|s=="build-info"){println!("{}",serde_json::json!({"source_directory":mip_codex::BUILD_SOURCE_DIRECTORY,"source_fingerprint":mip_codex::BUILD_SOURCE_FINGERPRINT}));return;}
 let source=mps::read(&a[1]).unwrap();let out=Path::new(&a[3]);std::fs::create_dir_all(out).unwrap();let begin=Instant::now();let mut m=source.clone();
 let exact=source.offset_enclosure==Some([source.offset;2])&&source.variables.iter().all(|v|v.objective_enclosure==Some([v.objective;2])&&v.lower.is_none_or(|b|v.lower_enclosure==Some([b;2]))&&v.upper.is_none_or(|b|v.upper_enclosure==Some([b;2])))&&source.rows.iter().all(|r|r.exact_coefficients&&r.lower.is_none_or(|b|r.lower_enclosure==Some([b;2]))&&r.upper.is_none_or(|b|r.upper_enclosure==Some([b;2])));
 assert!(exact,"diagnostic requires exact input coefficients/costs/bounds");
 let mut fixes=vec![];
 if a.get(4).is_none_or(|s|s!="original"){
  for(i,r)in source.rows.iter().enumerate(){if r.coefficients.len()!=1||r.lower.is_none()||r.lower!=r.upper{continue;}let(j,c)=r.coefficients[0];if c.abs()!=1.{continue;}let value=r.lower.unwrap()/c;if integer(value).is_none(){continue;}let v=&mut m.variables[j];if v.lower.is_some_and(|l|value<l)||v.upper.is_some_and(|u|value>u)||v.lower==Some(value)&&v.upper==Some(value){continue;}v.lower=Some(value);v.upper=Some(value);v.lower_enclosure=Some([value;2]);v.upper_enclosure=Some([value;2]);fixes.push(serde_json::json!({"variable":j,"source_row":i,"value_bits":format!("{:016x}",value.to_bits())}));}
 }
 let retained:Vec<_>=source.rows.iter().enumerate().filter(|(_,r)|a.get(4).is_some_and(|s|s=="original")||!redundant(&m,r)).map(|(i,_)|i).collect();m.rows=retained.iter().map(|&i|source.rows[i].clone()).collect();
 let prepare=begin.elapsed().as_secs_f64();let proof=serde_json::json!({"fixes":fixes,"retained_rows":retained,"input_rows":source.rows.len(),"projected_rows":m.rows.len(),"variables":m.variables.len(),"prepare_seconds":prepare,"claim":"projected model only until independent original Fraction transformation verification"});
 std::fs::write(out.join("projection.json"),serde_json::to_vec(&proof).unwrap()).unwrap();std::fs::write(out.join("projected-model.json"),serde_json::to_vec(&m).unwrap()).unwrap();
 let limits=Limits{seconds:a[2].parse().unwrap(),zero_dominance:false,cover_cuts:false,mir_cuts:false,gomory_cuts:false,aggregate_cuts:false,clique_cuts:false,three_row_cuts:false,rounding_cuts:false,objective_rounding:false,objective_rounding_all:false,objective_box_report:false,objective_domain_report:false,row_ray_report:false,row_packing_report:false,row_subgradient_report:false,row_generation_report:false,..Limits::default()};
 let solve_begin=Instant::now();let result=solve::solve(&m,&limits);let seconds=solve_begin.elapsed().as_secs_f64();let check=result.values.as_ref().map(|values|{let x:Vec<_>=source.variables.iter().map(|v|values[&v.name]).collect();source.check(&x,true,1e-7).is_ok()});
 std::fs::write(out.join("result.json"),serde_json::to_vec(&result).unwrap()).unwrap();println!("{}",serde_json::json!({"projected_status":result.status,"objective":result.objective,"dual_bound_projected":result.dual_bound,"nodes":result.nodes,"prepare_seconds":prepare,"solve_seconds":seconds,"original_float_point_check":check,"rows":m.rows.len(),"variables":m.variables.len(),"fixes":proof["fixes"].as_array().unwrap().len(),"claim":"projected bounds/status only until independent exact transformation check"}));
}
