"""Archive completed development research with per-file and compressed SHA verification."""
from pathlib import Path
import os,sys,json,hashlib,gzip,tarfile,io,subprocess
os.sched_setaffinity(0,{34});root=Path('/home/ubuntu/mip-codex');kind=sys.argv[1]
assert kind=='primal-projection-research';repo=Path('/home/ubuntu/mip-phase-two');groups=[('incumbent',('incumbent-objective-repair','incumbent-forced-repair','incumbent-feasibility-target','incumbent-plateau-repair','incumbent-singleton-target','incumbent-single-column-target','incumbent-propagated-','incumbent-compact-','incumbent-research-point-audit','incumbent-repair-research-commit','incumbent-main115-',),['audit_incumbent_research.py','debug-cache-cleanup-20261117-1211.json']),('projection',('singleton-projection-','singleton-dominance-projection-'),['verify_singleton_projection.py','primal-projection-research-archive.py'])];documents=[('resource-incumbent-repair','INCUMBENT_REPAIR_HYPOTHESIS.md'),('singleton-equality-research','SINGLETON_PROJECTION_HYPOTHESIS.md')];checks=[]
for name,proofs,points in checks:
 a=json.loads((root/f'artifacts/{name}/summary.json').read_text());assert a['completed']==a['cut_valid']==proofs and a['points']==a['strict_valid']==a['official_valid']==points
if False:
 a=json.loads((root/'artifacts/singleton-crash-v1-initial-audit/summary.json').read_text());assert a['checked']==a['strict_valid']==a['official_valid']and a['cut_runs']==a['cut_valid']
out=repo/f'artifacts/{kind}-evaluation';assert not out.exists();out.mkdir();ledger=[];excluded=[];bundles=[]
for label,prefixes,extras in groups:
 paths=sorted(p for p in (root/'artifacts').iterdir()if p.name.startswith(prefixes));paths.extend(root/'artifacts'/name for name in extras);bundle=out/(label+'.tar.gz');count=0
 with bundle.open('wb')as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6)as z,tarfile.open(fileobj=z,mode='w')as tar:
  for source in paths:
   for p in sorted(source.rglob('*'))if source.is_dir()else[source]:
    if not p.is_file():continue
    data=p.read_bytes();h=hashlib.sha256(data).hexdigest();name=str(p.relative_to(root/'artifacts'))
    if data[:4]==b'\x7fELF'or p.name=='model.glp':excluded.append(dict(source=str(p),sha256=h,bytes=len(data),reason='local executable/generated LP retained'));continue
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));ledger.append(dict(source=str(p),bundle=bundle.name,member=name,sha256=h,bytes=len(data)));count+=1
 assert bundle.stat().st_size<95*1024**2
 bundles.append(dict(path=bundle.name,sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),bytes=bundle.stat().st_size,files=count));print(bundles[-1],flush=True)
expected={(r['bundle'],r['member']):r for r in ledger};verified=0
for bundle in bundles:
 with tarfile.open(out/bundle['path'],'r:gz')as tar:
  for member in tar:
   r=expected[(bundle['path'],member.name)];data=tar.extractfile(member).read();assert len(data)==r['bytes']and hashlib.sha256(data).hexdigest()==r['sha256'];verified+=1
assert verified==len(ledger)
for branch,name in documents:(out/name).write_bytes(subprocess.check_output(['git','show',f'{branch}:docs/{name}'],cwd=repo))
(out/'relocation-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n');(out/'bundles.json').write_text(json.dumps(bundles,indent=2)+'\n');(out/'retained-local-files.json').write_text(json.dumps(excluded,indent=2)+'\n');s=dict(files=len(ledger),original_bytes=sum(r['bytes']for r in ledger),bundled_bytes=sum(b['bytes']for b in bundles),excluded=len(excluded),verified_payloads=verified);(out/'archive-summary.json').write_text(json.dumps(s,indent=2)+'\n');(out/'README.txt').write_text('完了済み開発試作の圧縮原記録。空の作業ディレクトリでtar.gzを展開すると元artifacts以下の相対パスが復元される。bundles.jsonで圧縮SHA、relocation-ledger.jsonで展開payloadのSHAを照合。作成時に全payloadの展開SHAを確認済み。元ファイルと除外したELF/生成LPはローカル保持。未採用の主解改善と前処理診断。prototype12整数点は3新GMP検査と9完全同一点照合で全有効。単変数等式投影は厳密Fraction有効/改竄9拒否。段階零費用支配投影の最適値保存証明は未検証で、元モデルの最適/不能/下界を主張しない。研究コードは採用srcへ混ぜない。\n');print(s)
