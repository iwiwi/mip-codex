from pathlib import Path
from fractions import Fraction as F
import json,math,struct,sys,copy
sys.path.insert(0,str(Path.cwd()/'scripts'))
from verify_cover_cuts import exact_model
from verify_binary_graph import maximize_sense
from benchmark_common import sha256,atomic_json
def q(x):
 assert type(x)in [float,int]and math.isfinite(x)
 return F.from_float(float(x))
def check(original,m,p):
 names,variables,rows,obj,offset=original
 assert set(p)=={'fixes','retained_rows','input_rows','projected_rows','variables','prepare_seconds','claim'}
 assert p['input_rows']==len(rows)and p['projected_rows']==len(m['rows'])and p['variables']==len(names)
 assert len(m['variables'])==len(names)and [v['name']for v in m['variables']]==names
 assert q(m['offset'])==offset
 fixed={};last_row=-1
 for f in p['fixes']:
  assert set(f)=={'variable','source_row','value_bits'}
  j,i=f['variable'],f['source_row'];assert type(j)is int and type(i)is int and 0<=j<len(names)and last_row<i<len(rows)and j not in fixed;last_row=i
  text=f['value_bits'];assert isinstance(text,str)and len(text)==16 and all(c in '0123456789abcdef'for c in text);value=struct.unpack('>d',bytes.fromhex(text))[0];value=q(value)
  row=rows[i];terms={name:a for name,a in row['coefficients'].items()if a};assert len(terms)==1 and names[j]in terms and row['lower']is not None and row['lower']==row['upper'];assert value==row['lower']/terms[names[j]]
  v=variables[names[j]];assert(v['lower']is None or value>=v['lower'])and(v['upper']is None or value<=v['upper'])and(not v['integer']or value.denominator==1);fixed[j]=value
 bounds={}
 for j,(name,v)in enumerate(zip(names,m['variables'])):
  old=variables[name];assert type(v['integer'])is bool and v['integer']==old['integer'];assert q(v['objective'])==obj.get(name,F(0))
  actual=tuple(None if v[k]is None else q(v[k])for k in ['lower','upper']);expected=(fixed[j],fixed[j])if j in fixed else(old['lower'],old['upper']);assert actual==expected;bounds[name]=actual
 keep=p['retained_rows'];assert all(type(i)is int and 0<=i<len(rows)for i in keep)and keep==sorted(set(keep))and len(keep)==len(m['rows']);kept=set(keep)
 for row,i in zip(m['rows'],keep):
  old=rows[i];assert row['name']==old['name'];assert all(type(j)is int and 0<=j<len(names)for j,a in row['coefficients']);actual={}
  for j,a in row['coefficients']:actual[names[j]]=actual.get(names[j],F(0))+q(a)
  assert {k:a for k,a in actual.items()if a}=={k:a for k,a in old['coefficients'].items()if a}
  assert all((None if row[k]is None else q(row[k]))==old[k]for k in ['lower','upper'])
 for i,row in enumerate(rows):
  if i in kept:continue
  low=high=F(0)
  for name,a in row['coefficients'].items():
   if not a:continue
   l,u=bounds[name];x,y=(l,u)if a>0 else(u,l);low=None if x is None or low is None else low+a*x;high=None if y is None or high is None else high+a*y
  assert(row['lower']is None or low is not None and low>=row['lower'])and(row['upper']is None or high is not None and high<=row['upper'])
 return dict(valid=True,fixed=len(fixed),retained_rows=len(keep),removed_rows=len(rows)-len(keep),arithmetic='original MPS Fraction; exact unique singleton values and box implication, no tolerance')
if __name__=='__main__':
 source=Path(sys.argv[1]);out=Path(sys.argv[2]);m=json.loads((out/'projected-model.json').read_text());p=json.loads((out/'projection.json').read_text());original=exact_model(source,True);assert m['maximize']==maximize_sense(source);result=check(original,m,p);result.update(input_sha256=sha256(source),projected_model_sha256=sha256(out/'projected-model.json'),projection_sha256=sha256(out/'projection.json'),checker_sha256=sha256(Path(__file__)));atomic_json(out/'transformation-validation.json',result);print(json.dumps(result))
 if '--tamper'in sys.argv:
  rejected=0
  for kind in ['bits','source','missing','duplicate','objective','bound','coefficient','drop_required','extra']:
   a=copy.deepcopy(m);b=copy.deepcopy(p)
   if kind=='bits':b['fixes'][0]['value_bits']=struct.pack('>d',0.5).hex()
   elif kind=='source':b['fixes'][0]['source_row']=len(original[2])
   elif kind=='missing':b['fixes'].pop(0)
   elif kind=='duplicate':b['fixes'].append(copy.deepcopy(b['fixes'][0]))
   elif kind=='objective':a['variables'][0]['objective']+=1
   elif kind=='bound':a['variables'][b['fixes'][0]['variable']]['upper']+=1
   elif kind=='coefficient':a['rows'][0]['coefficients'][0][1]+=1
   elif kind=='drop_required':a['rows'].pop(0);b['retained_rows'].pop(0);b['projected_rows']-=1
   else:b['extra']=True
   try:check(original,a,b)
   except (AssertionError,ValueError,IndexError):rejected+=1
   else:raise AssertionError('tamper accepted: '+kind)
  atomic_json(out/'tamper-validation.json',dict(tested=9,rejected=rejected));print('tampered rejected',rejected)
