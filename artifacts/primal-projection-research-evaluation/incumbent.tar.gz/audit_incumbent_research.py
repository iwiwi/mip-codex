from pathlib import Path
import json,subprocess,sys,hashlib,resource,os,time
sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256
r=Path.cwd();os.sched_setaffinity(0,{42});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));out=r/'artifacts/incumbent-research-point-audit';out.mkdir();refs={};records=[]
def key(v):return hashlib.sha256(json.dumps(dict(objective=v['objective'],values=v['values']),sort_keys=True,separators=(',',':')).encode()).hexdigest()
for name in ['map10','map16715-04']:
 p=r/f'artifacts/resource-primal-default-development-screen/cases/{name}.mps.gz/after/result.json';d=r/f'artifacts/resource-primal-default-development-audit/{name}.mps.gz/after';assert all(json.loads((d/(k+'-validation.json')).read_text())['valid']is True for k in ['strict','official']);refs[(name,key(json.loads(p.read_text())))]=dict(result=str(p),strict=str(d/'strict-validation.json'),official=str(d/'official-validation.json'))
inputs=[]
for folder in sorted((r/'artifacts').glob('incumbent-*v1')):
 if folder.is_dir():
  for p in sorted(folder.glob('*/result.json')):
   if 'map16715-04'in p.parent.name:name='map16715-04'
   elif 'map10'in p.parent.name:name='map10'
   else:continue
   inputs.append((name,p))
for folder in ['singleton-projection-v1','singleton-dominance-projection-v1']:
 inputs += [('map10',p)for p in sorted((r/'artifacts'/folder).glob('*/result.json'))]
for index,(name,p)in enumerate(inputs):
 v=json.loads(p.read_text())
 if v.get('values')is None:continue
 token=(name,key(v));d=out/f'{index:03}';d.mkdir();record=dict(source=str(p),solution_sha256=sha256(p),name=name,objective=v['objective'],values_sha256=token[1])
 if token in refs:record.update(valid=True,method='exact objective/value JSON equality to independently checked point',reference=refs[token])
 else:
  model=r/f'data/raw/benchmark/{name}.mps.gz';cmd=[str(r/'.venv/bin/python'),str(r/'scripts/benchmark_validate.py'),str(model),str(p),str(r/'third_party/miplib-checker/bin/solchecker'),str(d)];start=time.monotonic()
  with(d/'audit.log').open('w')as f:run=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=600)
  checks={k:json.loads((d/(k+'-validation.json')).read_text())for k in ['strict','official']};assert run.returncode==0 and all(c['valid']is True for c in checks.values()),(p,checks);refs[token]=dict(result=str(p),strict=str(d/'strict-validation.json'),official=str(d/'official-validation.json'));record.update(valid=True,method='new independent GMP absolute and official checks',wall_seconds=time.monotonic()-start,reference=refs[token])
 atomic_json(d/'record.json',record);records.append(record);atomic_json(out/'records.json',records);atomic_json(out/'progress.json',dict(points=len(records),valid=sum(x['valid']for x in records),new_gmp_checks=sum(x['method'].startswith('new ')for x in records)))
atomic_json(out/'summary.json',dict(points=len(records),valid=sum(x['valid']for x in records),new_gmp_checks=sum(x['method'].startswith('new ')for x in records),aliases=sum(x['method'].startswith('exact ')for x in records)));atomic_json(out/'exit.json',dict(status='complete'));print((out/'summary.json').read_text())
