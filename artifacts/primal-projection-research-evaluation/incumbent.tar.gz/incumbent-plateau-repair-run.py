from pathlib import Path
import json,sys,shutil,subprocess,os,resource,time
sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256
r=Path.cwd();old=r/'artifacts/incumbent-objective-repair-v1';out=r/'artifacts/incumbent-plateau-repair-v1';out.mkdir();repo=Path('/home/ubuntu/mip-phase-two');shutil.copy2(repo/'target/release/examples/incumbent_objective_repair',out/'incumbent_objective_repair');shutil.copy2(repo/'examples/incumbent_objective_repair.rs',out/'incumbent_objective_repair.rs');info=json.loads(subprocess.check_output([str(out/'incumbent_objective_repair'),'build-info']));shutil.copytree(repo/'src',out/'source/src');[shutil.copy2(repo/n,out/'source'/n)for n in ['Cargo.toml','Cargo.lock','build.rs']];atomic_json(out/'experiment.json',dict(build_info=info,binary_sha256=sha256(out/'incumbent_objective_repair'),source_sha256=sha256(out/'incumbent_objective_repair.rs'),purpose='one objective-improving finite-bound variable forced locally, repair other columns with zero-gain moves and four-step tabu, candidate only; no original state/bound change',seconds=20,memory_bytes=16*1024**3))
processes=[]
for name in ['map10','map16715-04']:
 d=out/name;d.mkdir();job=json.loads((old/name/'job.json').read_text());job['command']=[s.replace(str(old),str(out))for s in job['command']];atomic_json(d/'job.json',job)
 launcher="import sys,subprocess,resource,time,json\nresource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3))\nstart=time.monotonic()\np=subprocess.run(sys.argv[2:],timeout=100)\nopen(sys.argv[1],'w').write(json.dumps(dict(exit_code=p.returncode,wall_seconds=time.monotonic()-start))+'\\n')\n"
 with(d/'stdout.log').open('w')as f:p=subprocess.Popen(['.venv/bin/python','-c',launcher,str(d/'execution.json'),*job['command']],stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 processes.append(p)
for p in processes:assert p.wait()==0
atomic_json(out/'exit.json',dict(status='complete'))
