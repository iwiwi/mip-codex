from pathlib import Path
import os,sys,json,subprocess,time,resource,signal,datetime
solver=sys.argv[1];cpu=int(sys.argv[2]);root=Path.cwd();os.sched_setaffinity(0,{cpu});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,)*2);os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',MIP_MEMORY_MIB='16384',MIP_ABSOLUTE_CHECKER='/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker-absolute');sys.path.insert(0,'scripts')
from benchmark_common import sha256,atomic_json
from validate_solution import validate
out=root/'artifacts/cover-long-round-native-hour'/solver;out.mkdir(parents=True);model=root/'data/raw/exploratory/z26.mps.gz';cmd=[str(root/'.venv/bin/python'),str(root/'scripts/comparison_worker.py'),solver,str(model),'3600',str(out)];atomic_json(out/'job.json',dict(command=cmd,cpu=cpu,seconds=3600,watchdog=3660,memory_bytes=16*1024**3,threads=1,input_sha256=sha256(model),outside_all_240=True,optimizer_point_transfer=False));start=time.monotonic();watchdog=False
with(out/'stdout.log').open('w')as so,(out/'stderr.log').open('w')as se:
 p=subprocess.Popen(cmd,stdout=so,stderr=se,start_new_session=True);atomic_json(out/'process.json',dict(pid=p.pid,process_group=p.pid,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
 try:p.wait(timeout=3660)
 except subprocess.TimeoutExpired:watchdog=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
atomic_json(out/'execution.json',dict(exit_code=p.returncode,wall_seconds=time.monotonic()-start,watchdog=watchdog,process_group_killed=watchdog))
if watchdog or p.returncode!=0:
 atomic_json(out/'summary.json',dict(solver=solver,status='watchdog'if watchdog else'execution_error',gmp_valid=None,exit_code=p.returncode));sys.exit(0)
r=json.load(open(out/'result.json'));v=None
if r.get('values')is not None:
 v=validate(model,r);atomic_json(out/'validation.json',v);assert v['valid']
record=dict(solver=solver,**{k:r.get(k)for k in ['status','objective','dual_bound','seconds','nodes','version']},gmp_valid=None if v is None else v['valid']);atomic_json(out/'summary.json',record);print(json.dumps(record),flush=True)
