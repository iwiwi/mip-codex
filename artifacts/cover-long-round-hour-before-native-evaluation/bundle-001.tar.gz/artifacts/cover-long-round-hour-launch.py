from pathlib import Path
import json,subprocess,sys
root=Path.cwd();workers=[]
for name,script,args in [('rust','cover-long-round-hour-controls',[]),('highs','cover-long-round-native-hour-worker',['highs','51']),('scip','cover-long-round-native-hour-worker',['scip','52']),('glpk','cover-long-round-native-hour-worker',['glpk','53'])]:
 path=root/f'artifacts/cover-long-round-hour-{name}.log'
 with path.open('w')as stream:p=subprocess.Popen([sys.executable,str(root/f'artifacts/{script}.py'),*args],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 workers.append(dict(name=name,pid=p.pid,log=str(path)))
(root/'artifacts/cover-long-round-hour-workers.json').write_text(json.dumps(workers,indent=2));print(json.dumps(workers),flush=True)
