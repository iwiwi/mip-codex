"""Archive completed development research with per-file and compressed SHA verification."""
from pathlib import Path
import os,sys,json,hashlib,gzip,tarfile,io,subprocess
os.sched_setaffinity(0,{32});root=Path('/home/ubuntu/mip-codex');kind=sys.argv[1]
assert kind=='master-bound-final';repo=Path('/home/ubuntu/mip-priced-repair');groups=[('safe-research',('master-bound-safe-',),['audit_master_bound_safe_smoke.py','master-bound-final-archive.py']),('default-main112',('master-bound-default-',),['smoke-20261117-102945-ublkf477','audit_master_bound_default_smoke.py']),('verifier',('master-bound-verifier-unit',),[])];documents=[];checks=[('master-bound-default-development-audit',376,124)]
for name,proofs,points in checks:
 a=json.loads((root/f'artifacts/{name}/summary.json').read_text());assert a['completed']==a['cut_valid']==proofs and a['points']==a['strict_valid']==a['official_valid']==points
if False:
 a=json.loads((root/'artifacts/singleton-crash-v1-initial-audit/summary.json').read_text());assert a['checked']==a['strict_valid']==a['official_valid']and a['cut_runs']==a['cut_valid']
out=repo/f'artifacts/{kind}-evaluation';assert not out.exists();out.mkdir();ledger=[];excluded=[];bundles=[]
for label,prefixes,extras in groups:
 paths=sorted(p for p in (root/'artifacts').iterdir()if p.name.startswith(prefixes));paths.extend(root/'artifacts'/name for name in extras);bundle=out/(label+'.tar.gz');count=0
 with bundle.open('wb')as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6)as z,tarfile.open(fileobj=z,mode='w')as tar:
  for source in paths:
   for p in sorted(source.rglob('*'))if source.is_dir()else[source]:
    if not p.is_file():continue
    data=p.read_bytes();h=hashlib.sha256(data).hexdigest();name=str(p.relative_to(root/'artifacts'))
    if data[:4]==b'\x7fELF'or p.name=='model.glp':excluded.append(dict(source=str(p),sha256=h,bytes=len(data),reason='local executable/generated LP retained'));continue
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));ledger.append(dict(source=str(p),bundle=bundle.name,member=name,sha256=h,bytes=len(data)));count+=1
 assert bundle.stat().st_size<95*1024**2
 bundles.append(dict(path=bundle.name,sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),bytes=bundle.stat().st_size,files=count));print(bundles[-1],flush=True)
expected={(r['bundle'],r['member']):r for r in ledger};verified=0
for bundle in bundles:
 with tarfile.open(out/bundle['path'],'r:gz')as tar:
  for member in tar:
   r=expected[(bundle['path'],member.name)];data=tar.extractfile(member).read();assert len(data)==r['bytes']and hashlib.sha256(data).hexdigest()==r['sha256'];verified+=1
assert verified==len(ledger)
for branch,name in documents:(out/name).write_bytes(subprocess.check_output(['git','show',f'{branch}:docs/{name}'],cwd=repo))
(out/'relocation-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n');(out/'bundles.json').write_text(json.dumps(bundles,indent=2)+'\n');(out/'retained-local-files.json').write_text(json.dumps(excluded,indent=2)+'\n');s=dict(files=len(ledger),original_bytes=sum(r['bytes']for r in ledger),bundled_bytes=sum(b['bytes']for b in bundles),excluded=len(excluded),verified_payloads=verified);(out/'archive-summary.json').write_text(json.dumps(s,indent=2)+'\n');(out/'README.txt').write_text('完了済み開発試作の圧縮原記録。空の作業ディレクトリでtar.gzを展開すると元artifacts以下の相対パスが復元される。bundles.jsonで圧縮SHA、relocation-ledger.jsonで展開payloadのSHAを照合。作成時に全payloadの展開SHAを確認済み。元ファイルと除外したELF/生成LPはローカル保持。原行LPと根下界の候補feab7937b302312bを含む。development-audit-import-failedはModuleNotFoundErrorによる監査セットアップ失敗で、確定結果の監査はdevelopment-audit。全生データはローカル保持。\n');print(s)
