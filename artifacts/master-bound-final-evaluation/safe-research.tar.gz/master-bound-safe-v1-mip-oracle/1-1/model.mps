NAME dom
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
 G r2
 G r3
 L r4
 G r5
 L r6
 L r7
 L r8
 L r9
 L r10
 L r11
 L r12
 L r13
 L r14
 L r15
 L r16
 L r17
 L r18
 L r19
 L r20
 L r21
 L r22
 L r23
 L r24
 L r25
 L r26
 L r27
 L r28
 L r29
 L r30
 L r31
 L r32
 L r33
 L r34
 L r35
 L r36
 L r37
 L r38
 L r39
 L r40
 L r41
 L r42
 L r43
 L r44
 L r45
 L r46
 L r47
 L r48
 L r49
 L r50
 L r51
 L r52
 L r53
 L r54
 L r55
 L r56
 L r57
 L r58
 L r59
 L r60
 L r61
 L r62
 L r63
 L r64
 L r65
 L r66
 L r67
 L r68
 L r69
 L r70
 L r71
 L r72
 L r73
 L r74
 L r75
 L r76
 L r77
 L r78
 L r79
 L r80
 L r81
 L r82
 L r83
 L r84
 L r85
 L r86
 L r87
 L r88
 L r89
 L r90
 L r91
 L r92
 L r93
 L r94
 L r95
 L r96
 L r97
 L r98
 L r99
 L r100
 L r101
 L r102
 L r103
 L r104
 L r105
 L r106
 L r107
 L r108
 L r109
 L r110
 L r111
 L r112
 L r113
 L r114
 L r115
 L r116
 L r117
 L r118
 L r119
 L r120
 L r121
 L r122
 L r123
 L r124
 L r125
 L r126
 L r127
 L r128
 L r129
 L r130
 L r131
 L r132
 L r133
 L r134
 L r135
 L r136
 L r137
 L r138
 L r139
 L r140
 L r141
 L r142
 L r143
 L r144
 L r145
 L r146
 L r147
 L r148
 L r149
 L r150
 L r151
 L r152
 L r153
 L r154
 L r155
 L r156
 L r157
 L r158
 L r159
 L r160
 L r161
 L r162
 L r163
 L r164
 L r165
 L r166
 L r167
 L r168
 L r169
 L r170
 L r171
 L r172
 L r173
 L r174
 L r175
 L r176
 L r177
 L r178
 L r179
 L r180
 L r181
 L r182
 L r183
 L r184
 L r185
 L r186
 L r187
 L r188
 L r189
 L r190
 L r191
 L r192
 L r193
 L r194
 L r195
 L r196
 L r197
 L r198
 L r199
 L r200
 L r201
 L r202
 L r203
 L r204
 L r205
 L r206
 L r207
 L r208
 L r209
 L r210
 L r211
 L r212
 L r213
 L r214
 L r215
 L r216
 L r217
 L r218
 L r219
 L r220
 L r221
 L r222
 L r223
 L r224
 L r225
 L r226
 L r227
 L r228
 L r229
 L r230
 L r231
 L r232
 L r233
 L r234
 L r235
 L r236
 L r237
 L r238
 L r239
 L r240
 L r241
 L r242
 L r243
 L r244
 L r245
 L r246
 L r247
 L r248
 L r249
 L r250
 L r251
 L r252
 L r253
 L r254
 L r255
 L r256
 L r257
 L r258
 L r259
 L r260
 L r261
 L r262
 L r263
 L r264
 L r265
 L r266
 L r267
 L r268
 L r269
 L r270
 L r271
 L r272
 L r273
 L r274
 L r275
 L r276
 L r277
 L r278
 L r279
 L r280
 L r281
 L r282
 L r283
 L r284
 L r285
 L r286
 L r287
 L r288
 L r289
 L r290
 L r291
 L r292
 L r293
 L r294
 L r295
 L r296
 L r297
 L r298
 L r299
 L r300
 L r301
 L r302
 L r303
 L r304
 L r305
 L r306
 L r307
 L r308
 L r309
 L r310
 L r311
 L r312
 L r313
 L r314
 L r315
 L r316
 L r317
 L r318
 L r319
 L r320
 L r321
 L r322
 L r323
 L r324
 L r325
 L r326
 L r327
 L r328
 L r329
 L r330
 L r331
 L r332
 L r333
 L r334
 L r335
 L r336
 L r337
 L r338
 L r339
 L r340
 L r341
 L r342
 L r343
 L r344
 L r345
 L r346
 L r347
 L r348
 L r349
 L r350
 L r351
 L r352
 L r353
 L r354
 L r355
 L r356
 L r357
 L r358
 L r359
 L r360
 L r361
 L r362
 L r363
 L r364
 L r365
 L r366
 L r367
 L r368
 L r369
 L r370
 L r371
 L r372
 L r373
 L r374
 L r375
 L r376
 L r377
 L r378
 L r379
 L r380
 L r381
 L r382
 L r383
 L r384
 L r385
 L r386
 L r387
 L r388
 L r389
 L r390
 L r391
 L r392
 L r393
 L r394
 L r395
 L r396
 L r397
 L r398
 L r399
 L r400
 L r401
 L r402
 L r403
 L r404
 L r405
 L r406
 L r407
 L r408
 L r409
 L r410
 L r411
 L r412
 L r413
 L r414
 L r415
 L r416
 L r417
 L r418
 L r419
 L r420
 L r421
 L r422
 L r423
 L r424
 L r425
 L r426
 L r427
 L r428
 L r429
 L r430
 L r431
 L r432
 L r433
 L r434
 L r435
 L r436
 L r437
 L r438
 L r439
 L r440
 L r441
 L r442
 L r443
 L r444
 L r445
 L r446
 L r447
 L r448
 L r449
 L r450
 L r451
 L r452
 L r453
 L r454
 L r455
 L r456
 L r457
 L r458
 L r459
 L r460
 L r461
 L r462
 L r463
 L r464
 L r465
 L r466
 L r467
 L r468
 L r469
 L r470
 L r471
 L r472
 L r473
 L r474
 L r475
 L r476
 L r477
 L r478
 L r479
 L r480
 L r481
 L r482
 L r483
 L r484
 L r485
 L r486
 L r487
 L r488
 L r489
 L r490
 L r491
 L r492
 L r493
 L r494
 L r495
 L r496
 L r497
 L r498
 L r499
 L r500
 L r501
 L r502
 L r503
 L r504
 L r505
 L r506
 L r507
 L r508
 L r509
 L r510
 L r511
 L r512
 L r513
 L r514
 L r515
 L r516
 L r517
 L r518
 L r519
 L r520
 L r521
 L r522
 L r523
 L r524
 L r525
 L r526
 L r527
 L r528
 L r529
 L r530
 L r531
 L r532
 L r533
 L r534
 L r535
 L r536
 L r537
 L r538
 L r539
 L r540
 L r541
 L r542
 L r543
 L r544
 L r545
 L r546
 L r547
 L r548
 L r549
 L r550
 L r551
 L r552
 L r553
 L r554
 L r555
 L r556
 L r557
 L r558
 L r559
 L r560
 L r561
 L r562
 L r563
 L r564
 L r565
 L r566
 L r567
 L r568
 L r569
 L r570
 L r571
 L r572
 L r573
 L r574
 L r575
 L r576
 L r577
 L r578
 L r579
 L r580
 L r581
 L r582
 L r583
 L r584
 L r585
 L r586
 L r587
 L r588
 L r589
 L r590
 L r591
 L r592
 L r593
 L r594
 L r595
 L r596
 L r597
 L r598
 L r599
 L r600
 L r601
 L r602
 L r603
 L r604
 L r605
 L r606
 L r607
 L r608
 L r609
 L r610
 L r611
 L r612
 L r613
 L r614
 L r615
 L r616
 L r617
 L r618
 L r619
 L r620
 L r621
 L r622
 L r623
 L r624
 L r625
 L r626
 L r627
 L r628
 L r629
 L r630
 L r631
 L r632
 L r633
 L r634
 L r635
 L r636
 L r637
 L r638
 L r639
 L r640
 L r641
 L r642
 L r643
 L r644
 L r645
 L r646
 L r647
 L r648
 L r649
 L r650
 L r651
 L r652
 L r653
 L r654
 L r655
 L r656
 L r657
 L r658
 L r659
 L r660
 L r661
 L r662
 L r663
 L r664
 L r665
 L r666
 L r667
 L r668
 L r669
 L r670
 L r671
 L r672
 L r673
 L r674
 L r675
 L r676
 L r677
 L r678
 L r679
 L r680
 L r681
 L r682
 L r683
 L r684
 L r685
 L r686
 L r687
 L r688
 L r689
 L r690
 L r691
 L r692
 L r693
 L r694
 L r695
 L r696
 L r697
 L r698
 L r699
 L r700
 L r701
 L r702
 L r703
 L r704
 L r705
 L r706
 L r707
 L r708
 L r709
 L r710
 L r711
 L r712
 L r713
 L r714
 L r715
 L r716
 L r717
 L r718
 L r719
 L r720
 L r721
 L r722
 L r723
 L r724
 L r725
 L r726
 L r727
 L r728
 L r729
 L r730
 L r731
 L r732
 L r733
 L r734
 L r735
 L r736
 L r737
 L r738
 L r739
 L r740
 L r741
 L r742
 L r743
 L r744
 L r745
 L r746
 L r747
 L r748
 L r749
 L r750
 L r751
 L r752
 L r753
 L r754
 L r755
 L r756
 L r757
 L r758
 L r759
 L r760
 L r761
 L r762
 L r763
 L r764
 L r765
 L r766
 L r767
 L r768
 L r769
 L r770
 L r771
 L r772
 L r773
 L r774
 L r775
 L r776
 L r777
 L r778
 L r779
 L r780
 L r781
 L r782
 L r783
 L r784
 L r785
 L r786
 L r787
 L r788
 L r789
 L r790
 L r791
 L r792
 L r793
 L r794
 L r795
 L r796
 L r797
 L r798
 L r799
 L r800
 L r801
 L r802
 L r803
 L r804
 L r805
 L r806
 L r807
COLUMNS
 x0 obj -7
 x0 r0 1
 x0 r1 -2
 x0 r2 -3
 x0 r3 -1
 x0 r4 -2
 x0 r5 3
 x0 r6 -2
 x0 r7 3
 x0 r8 1
 x0 r9 1
 x0 r10 1
 x0 r11 1
 x0 r12 1
 x0 r13 1
 x0 r14 1
 x0 r15 1
 x0 r16 1
 x0 r17 1
 x0 r18 1
 x0 r19 1
 x0 r20 1
 x0 r21 1
 x0 r22 1
 x0 r23 1
 x0 r24 1
 x0 r25 1
 x0 r26 1
 x0 r27 1
 x0 r28 1
 x0 r29 1
 x0 r30 1
 x0 r31 1
 x0 r32 1
 x0 r33 1
 x0 r34 1
 x0 r35 1
 x0 r36 1
 x0 r37 1
 x0 r38 1
 x0 r39 1
 x0 r40 1
 x0 r41 1
 x0 r42 1
 x0 r43 1
 x0 r44 1
 x0 r45 1
 x0 r46 1
 x0 r47 1
 x0 r48 1
 x0 r49 1
 x0 r50 1
 x0 r51 1
 x0 r52 1
 x0 r53 1
 x0 r54 1
 x0 r55 1
 x0 r56 1
 x0 r57 1
 x0 r58 1
 x0 r59 1
 x0 r60 1
 x0 r61 1
 x0 r62 1
 x0 r63 1
 x0 r64 1
 x0 r65 1
 x0 r66 1
 x0 r67 1
 x0 r68 1
 x0 r69 1
 x0 r70 1
 x0 r71 1
 x0 r72 1
 x0 r73 1
 x0 r74 1
 x0 r75 1
 x0 r76 1
 x0 r77 1
 x0 r78 1
 x0 r79 1
 x0 r80 1
 x0 r81 1
 x0 r82 1
 x0 r83 1
 x0 r84 1
 x0 r85 1
 x0 r86 1
 x0 r87 1
 x0 r88 1
 x0 r89 1
 x0 r90 1
 x0 r91 1
 x0 r92 1
 x0 r93 1
 x0 r94 1
 x0 r95 1
 x0 r96 1
 x0 r97 1
 x0 r98 1
 x0 r99 1
 x0 r100 1
 x0 r101 1
 x0 r102 1
 x0 r103 1
 x0 r104 1
 x0 r105 1
 x0 r106 1
 x0 r107 1
 x0 r108 1
 x0 r109 1
 x0 r110 1
 x0 r111 1
 x0 r112 1
 x0 r113 1
 x0 r114 1
 x0 r115 1
 x0 r116 1
 x0 r117 1
 x0 r118 1
 x0 r119 1
 x0 r120 1
 x0 r121 1
 x0 r122 1
 x0 r123 1
 x0 r124 1
 x0 r125 1
 x0 r126 1
 x0 r127 1
 x0 r128 1
 x0 r129 1
 x0 r130 1
 x0 r131 1
 x0 r132 1
 x0 r133 1
 x0 r134 1
 x0 r135 1
 x0 r136 1
 x0 r137 1
 x0 r138 1
 x0 r139 1
 x0 r140 1
 x0 r141 1
 x0 r142 1
 x0 r143 1
 x0 r144 1
 x0 r145 1
 x0 r146 1
 x0 r147 1
 x0 r148 1
 x0 r149 1
 x0 r150 1
 x0 r151 1
 x0 r152 1
 x0 r153 1
 x0 r154 1
 x0 r155 1
 x0 r156 1
 x0 r157 1
 x0 r158 1
 x0 r159 1
 x0 r160 1
 x0 r161 1
 x0 r162 1
 x0 r163 1
 x0 r164 1
 x0 r165 1
 x0 r166 1
 x0 r167 1
 x0 r168 1
 x0 r169 1
 x0 r170 1
 x0 r171 1
 x0 r172 1
 x0 r173 1
 x0 r174 1
 x0 r175 1
 x0 r176 1
 x0 r177 1
 x0 r178 1
 x0 r179 1
 x0 r180 1
 x0 r181 1
 x0 r182 1
 x0 r183 1
 x0 r184 1
 x0 r185 1
 x0 r186 1
 x0 r187 1
 x0 r188 1
 x0 r189 1
 x0 r190 1
 x0 r191 1
 x0 r192 1
 x0 r193 1
 x0 r194 1
 x0 r195 1
 x0 r196 1
 x0 r197 1
 x0 r198 1
 x0 r199 1
 x0 r200 1
 x0 r201 1
 x0 r202 1
 x0 r203 1
 x0 r204 1
 x0 r205 1
 x0 r206 1
 x0 r207 1
 x0 r208 1
 x0 r209 1
 x0 r210 1
 x0 r211 1
 x0 r212 1
 x0 r213 1
 x0 r214 1
 x0 r215 1
 x0 r216 1
 x0 r217 1
 x0 r218 1
 x0 r219 1
 x0 r220 1
 x0 r221 1
 x0 r222 1
 x0 r223 1
 x0 r224 1
 x0 r225 1
 x0 r226 1
 x0 r227 1
 x0 r228 1
 x0 r229 1
 x0 r230 1
 x0 r231 1
 x0 r232 1
 x0 r233 1
 x0 r234 1
 x0 r235 1
 x0 r236 1
 x0 r237 1
 x0 r238 1
 x0 r239 1
 x0 r240 1
 x0 r241 1
 x0 r242 1
 x0 r243 1
 x0 r244 1
 x0 r245 1
 x0 r246 1
 x0 r247 1
 x0 r248 1
 x0 r249 1
 x0 r250 1
 x0 r251 1
 x0 r252 1
 x0 r253 1
 x0 r254 1
 x0 r255 1
 x0 r256 1
 x0 r257 1
 x0 r258 1
 x0 r259 1
 x0 r260 1
 x0 r261 1
 x0 r262 1
 x0 r263 1
 x0 r264 1
 x0 r265 1
 x0 r266 1
 x0 r267 1
 x0 r268 1
 x0 r269 1
 x0 r270 1
 x0 r271 1
 x0 r272 1
 x0 r273 1
 x0 r274 1
 x0 r275 1
 x0 r276 1
 x0 r277 1
 x0 r278 1
 x0 r279 1
 x0 r280 1
 x0 r281 1
 x0 r282 1
 x0 r283 1
 x0 r284 1
 x0 r285 1
 x0 r286 1
 x0 r287 1
 x0 r288 1
 x0 r289 1
 x0 r290 1
 x0 r291 1
 x0 r292 1
 x0 r293 1
 x0 r294 1
 x0 r295 1
 x0 r296 1
 x0 r297 1
 x0 r298 1
 x0 r299 1
 x0 r300 1
 x0 r301 1
 x0 r302 1
 x0 r303 1
 x0 r304 1
 x0 r305 1
 x0 r306 1
 x0 r307 1
 x0 r308 1
 x0 r309 1
 x0 r310 1
 x0 r311 1
 x0 r312 1
 x0 r313 1
 x0 r314 1
 x0 r315 1
 x0 r316 1
 x0 r317 1
 x0 r318 1
 x0 r319 1
 x0 r320 1
 x0 r321 1
 x0 r322 1
 x0 r323 1
 x0 r324 1
 x0 r325 1
 x0 r326 1
 x0 r327 1
 x0 r328 1
 x0 r329 1
 x0 r330 1
 x0 r331 1
 x0 r332 1
 x0 r333 1
 x0 r334 1
 x0 r335 1
 x0 r336 1
 x0 r337 1
 x0 r338 1
 x0 r339 1
 x0 r340 1
 x0 r341 1
 x0 r342 1
 x0 r343 1
 x0 r344 1
 x0 r345 1
 x0 r346 1
 x0 r347 1
 x0 r348 1
 x0 r349 1
 x0 r350 1
 x0 r351 1
 x0 r352 1
 x0 r353 1
 x0 r354 1
 x0 r355 1
 x0 r356 1
 x0 r357 1
 x0 r358 1
 x0 r359 1
 x0 r360 1
 x0 r361 1
 x0 r362 1
 x0 r363 1
 x0 r364 1
 x0 r365 1
 x0 r366 1
 x0 r367 1
 x0 r368 1
 x0 r369 1
 x0 r370 1
 x0 r371 1
 x0 r372 1
 x0 r373 1
 x0 r374 1
 x0 r375 1
 x0 r376 1
 x0 r377 1
 x0 r378 1
 x0 r379 1
 x0 r380 1
 x0 r381 1
 x0 r382 1
 x0 r383 1
 x0 r384 1
 x0 r385 1
 x0 r386 1
 x0 r387 1
 x0 r388 1
 x0 r389 1
 x0 r390 1
 x0 r391 1
 x0 r392 1
 x0 r393 1
 x0 r394 1
 x0 r395 1
 x0 r396 1
 x0 r397 1
 x0 r398 1
 x0 r399 1
 x0 r400 1
 x0 r401 1
 x0 r402 1
 x0 r403 1
 x0 r404 1
 x0 r405 1
 x0 r406 1
 x0 r407 1
 x0 r408 1
 x0 r409 1
 x0 r410 1
 x0 r411 1
 x0 r412 1
 x0 r413 1
 x0 r414 1
 x0 r415 1
 x0 r416 1
 x0 r417 1
 x0 r418 1
 x0 r419 1
 x0 r420 1
 x0 r421 1
 x0 r422 1
 x0 r423 1
 x0 r424 1
 x0 r425 1
 x0 r426 1
 x0 r427 1
 x0 r428 1
 x0 r429 1
 x0 r430 1
 x0 r431 1
 x0 r432 1
 x0 r433 1
 x0 r434 1
 x0 r435 1
 x0 r436 1
 x0 r437 1
 x0 r438 1
 x0 r439 1
 x0 r440 1
 x0 r441 1
 x0 r442 1
 x0 r443 1
 x0 r444 1
 x0 r445 1
 x0 r446 1
 x0 r447 1
 x0 r448 1
 x0 r449 1
 x0 r450 1
 x0 r451 1
 x0 r452 1
 x0 r453 1
 x0 r454 1
 x0 r455 1
 x0 r456 1
 x0 r457 1
 x0 r458 1
 x0 r459 1
 x0 r460 1
 x0 r461 1
 x0 r462 1
 x0 r463 1
 x0 r464 1
 x0 r465 1
 x0 r466 1
 x0 r467 1
 x0 r468 1
 x0 r469 1
 x0 r470 1
 x0 r471 1
 x0 r472 1
 x0 r473 1
 x0 r474 1
 x0 r475 1
 x0 r476 1
 x0 r477 1
 x0 r478 1
 x0 r479 1
 x0 r480 1
 x0 r481 1
 x0 r482 1
 x0 r483 1
 x0 r484 1
 x0 r485 1
 x0 r486 1
 x0 r487 1
 x0 r488 1
 x0 r489 1
 x0 r490 1
 x0 r491 1
 x0 r492 1
 x0 r493 1
 x0 r494 1
 x0 r495 1
 x0 r496 1
 x0 r497 1
 x0 r498 1
 x0 r499 1
 x0 r500 1
 x0 r501 1
 x0 r502 1
 x0 r503 1
 x0 r504 1
 x0 r505 1
 x0 r506 1
 x0 r507 1
 x0 r508 1
 x0 r509 1
 x0 r510 1
 x0 r511 1
 x0 r512 1
 x0 r513 1
 x0 r514 1
 x0 r515 1
 x0 r516 1
 x0 r517 1
 x0 r518 1
 x0 r519 1
 x0 r520 1
 x0 r521 1
 x0 r522 1
 x0 r523 1
 x0 r524 1
 x0 r525 1
 x0 r526 1
 x0 r527 1
 x0 r528 1
 x0 r529 1
 x0 r530 1
 x0 r531 1
 x0 r532 1
 x0 r533 1
 x0 r534 1
 x0 r535 1
 x0 r536 1
 x0 r537 1
 x0 r538 1
 x0 r539 1
 x0 r540 1
 x0 r541 1
 x0 r542 1
 x0 r543 1
 x0 r544 1
 x0 r545 1
 x0 r546 1
 x0 r547 1
 x0 r548 1
 x0 r549 1
 x0 r550 1
 x0 r551 1
 x0 r552 1
 x0 r553 1
 x0 r554 1
 x0 r555 1
 x0 r556 1
 x0 r557 1
 x0 r558 1
 x0 r559 1
 x0 r560 1
 x0 r561 1
 x0 r562 1
 x0 r563 1
 x0 r564 1
 x0 r565 1
 x0 r566 1
 x0 r567 1
 x0 r568 1
 x0 r569 1
 x0 r570 1
 x0 r571 1
 x0 r572 1
 x0 r573 1
 x0 r574 1
 x0 r575 1
 x0 r576 1
 x0 r577 1
 x0 r578 1
 x0 r579 1
 x0 r580 1
 x0 r581 1
 x0 r582 1
 x0 r583 1
 x0 r584 1
 x0 r585 1
 x0 r586 1
 x0 r587 1
 x0 r588 1
 x0 r589 1
 x0 r590 1
 x0 r591 1
 x0 r592 1
 x0 r593 1
 x0 r594 1
 x0 r595 1
 x0 r596 1
 x0 r597 1
 x0 r598 1
 x0 r599 1
 x0 r600 1
 x0 r601 1
 x0 r602 1
 x0 r603 1
 x0 r604 1
 x0 r605 1
 x0 r606 1
 x0 r607 1
 x0 r608 1
 x0 r609 1
 x0 r610 1
 x0 r611 1
 x0 r612 1
 x0 r613 1
 x0 r614 1
 x0 r615 1
 x0 r616 1
 x0 r617 1
 x0 r618 1
 x0 r619 1
 x0 r620 1
 x0 r621 1
 x0 r622 1
 x0 r623 1
 x0 r624 1
 x0 r625 1
 x0 r626 1
 x0 r627 1
 x0 r628 1
 x0 r629 1
 x0 r630 1
 x0 r631 1
 x0 r632 1
 x0 r633 1
 x0 r634 1
 x0 r635 1
 x0 r636 1
 x0 r637 1
 x0 r638 1
 x0 r639 1
 x0 r640 1
 x0 r641 1
 x0 r642 1
 x0 r643 1
 x0 r644 1
 x0 r645 1
 x0 r646 1
 x0 r647 1
 x0 r648 1
 x0 r649 1
 x0 r650 1
 x0 r651 1
 x0 r652 1
 x0 r653 1
 x0 r654 1
 x0 r655 1
 x0 r656 1
 x0 r657 1
 x0 r658 1
 x0 r659 1
 x0 r660 1
 x0 r661 1
 x0 r662 1
 x0 r663 1
 x0 r664 1
 x0 r665 1
 x0 r666 1
 x0 r667 1
 x0 r668 1
 x0 r669 1
 x0 r670 1
 x0 r671 1
 x0 r672 1
 x0 r673 1
 x0 r674 1
 x0 r675 1
 x0 r676 1
 x0 r677 1
 x0 r678 1
 x0 r679 1
 x0 r680 1
 x0 r681 1
 x0 r682 1
 x0 r683 1
 x0 r684 1
 x0 r685 1
 x0 r686 1
 x0 r687 1
 x0 r688 1
 x0 r689 1
 x0 r690 1
 x0 r691 1
 x0 r692 1
 x0 r693 1
 x0 r694 1
 x0 r695 1
 x0 r696 1
 x0 r697 1
 x0 r698 1
 x0 r699 1
 x0 r700 1
 x0 r701 1
 x0 r702 1
 x0 r703 1
 x0 r704 1
 x0 r705 1
 x0 r706 1
 x0 r707 1
 x0 r708 1
 x0 r709 1
 x0 r710 1
 x0 r711 1
 x0 r712 1
 x0 r713 1
 x0 r714 1
 x0 r715 1
 x0 r716 1
 x0 r717 1
 x0 r718 1
 x0 r719 1
 x0 r720 1
 x0 r721 1
 x0 r722 1
 x0 r723 1
 x0 r724 1
 x0 r725 1
 x0 r726 1
 x0 r727 1
 x0 r728 1
 x0 r729 1
 x0 r730 1
 x0 r731 1
 x0 r732 1
 x0 r733 1
 x0 r734 1
 x0 r735 1
 x0 r736 1
 x0 r737 1
 x0 r738 1
 x0 r739 1
 x0 r740 1
 x0 r741 1
 x0 r742 1
 x0 r743 1
 x0 r744 1
 x0 r745 1
 x0 r746 1
 x0 r747 1
 x0 r748 1
 x0 r749 1
 x0 r750 1
 x0 r751 1
 x0 r752 1
 x0 r753 1
 x0 r754 1
 x0 r755 1
 x0 r756 1
 x0 r757 1
 x0 r758 1
 x0 r759 1
 x0 r760 1
 x0 r761 1
 x0 r762 1
 x0 r763 1
 x0 r764 1
 x0 r765 1
 x0 r766 1
 x0 r767 1
 x0 r768 1
 x0 r769 1
 x0 r770 1
 x0 r771 1
 x0 r772 1
 x0 r773 1
 x0 r774 1
 x0 r775 1
 x0 r776 1
 x0 r777 1
 x0 r778 1
 x0 r779 1
 x0 r780 1
 x0 r781 1
 x0 r782 1
 x0 r783 1
 x0 r784 1
 x0 r785 1
 x0 r786 1
 x0 r787 1
 x0 r788 1
 x0 r789 1
 x0 r790 1
 x0 r791 1
 x0 r792 1
 x0 r793 1
 x0 r794 1
 x0 r795 1
 x0 r796 1
 x0 r797 1
 x0 r798 1
 x0 r799 1
 x0 r800 1
 x0 r801 1
 x0 r802 1
 x0 r803 1
 x0 r804 1
 x0 r805 1
 x0 r806 1
 x0 r807 1
 x1 obj 6
 x1 r0 2
 x1 r1 3
 x1 r2 2
 x1 r3 3
 x1 r4 1
 x1 r5 -3
 x1 r6 3
 x1 r7 2
 x2 obj 6
 x2 r0 -2
 x2 r1 -3
 x2 r2 3
 x2 r4 -2
 x2 r6 3
 x2 r7 3
 x3 obj 0
 x3 r3 -2
 x3 r5 -4
 x3 r7 2
 x4 obj 0
 x4 r4 1
 x4 r6 2
 x4 r7 2
RHS
 rhs obj 2
 rhs r0 1
 rhs r1 0
 rhs r2 0
 rhs r3 0
 rhs r4 2
 rhs r5 -2
 rhs r6 2
 rhs r7 3
 rhs r8 1000
 rhs r9 1001
 rhs r10 1002
 rhs r11 1003
 rhs r12 1004
 rhs r13 1005
 rhs r14 1006
 rhs r15 1007
 rhs r16 1008
 rhs r17 1009
 rhs r18 1010
 rhs r19 1011
 rhs r20 1012
 rhs r21 1013
 rhs r22 1014
 rhs r23 1015
 rhs r24 1016
 rhs r25 1017
 rhs r26 1018
 rhs r27 1019
 rhs r28 1020
 rhs r29 1021
 rhs r30 1022
 rhs r31 1023
 rhs r32 1024
 rhs r33 1025
 rhs r34 1026
 rhs r35 1027
 rhs r36 1028
 rhs r37 1029
 rhs r38 1030
 rhs r39 1031
 rhs r40 1032
 rhs r41 1033
 rhs r42 1034
 rhs r43 1035
 rhs r44 1036
 rhs r45 1037
 rhs r46 1038
 rhs r47 1039
 rhs r48 1040
 rhs r49 1041
 rhs r50 1042
 rhs r51 1043
 rhs r52 1044
 rhs r53 1045
 rhs r54 1046
 rhs r55 1047
 rhs r56 1048
 rhs r57 1049
 rhs r58 1050
 rhs r59 1051
 rhs r60 1052
 rhs r61 1053
 rhs r62 1054
 rhs r63 1055
 rhs r64 1056
 rhs r65 1057
 rhs r66 1058
 rhs r67 1059
 rhs r68 1060
 rhs r69 1061
 rhs r70 1062
 rhs r71 1063
 rhs r72 1064
 rhs r73 1065
 rhs r74 1066
 rhs r75 1067
 rhs r76 1068
 rhs r77 1069
 rhs r78 1070
 rhs r79 1071
 rhs r80 1072
 rhs r81 1073
 rhs r82 1074
 rhs r83 1075
 rhs r84 1076
 rhs r85 1077
 rhs r86 1078
 rhs r87 1079
 rhs r88 1080
 rhs r89 1081
 rhs r90 1082
 rhs r91 1083
 rhs r92 1084
 rhs r93 1085
 rhs r94 1086
 rhs r95 1087
 rhs r96 1088
 rhs r97 1089
 rhs r98 1090
 rhs r99 1091
 rhs r100 1092
 rhs r101 1093
 rhs r102 1094
 rhs r103 1095
 rhs r104 1096
 rhs r105 1097
 rhs r106 1098
 rhs r107 1099
 rhs r108 1100
 rhs r109 1101
 rhs r110 1102
 rhs r111 1103
 rhs r112 1104
 rhs r113 1105
 rhs r114 1106
 rhs r115 1107
 rhs r116 1108
 rhs r117 1109
 rhs r118 1110
 rhs r119 1111
 rhs r120 1112
 rhs r121 1113
 rhs r122 1114
 rhs r123 1115
 rhs r124 1116
 rhs r125 1117
 rhs r126 1118
 rhs r127 1119
 rhs r128 1120
 rhs r129 1121
 rhs r130 1122
 rhs r131 1123
 rhs r132 1124
 rhs r133 1125
 rhs r134 1126
 rhs r135 1127
 rhs r136 1128
 rhs r137 1129
 rhs r138 1130
 rhs r139 1131
 rhs r140 1132
 rhs r141 1133
 rhs r142 1134
 rhs r143 1135
 rhs r144 1136
 rhs r145 1137
 rhs r146 1138
 rhs r147 1139
 rhs r148 1140
 rhs r149 1141
 rhs r150 1142
 rhs r151 1143
 rhs r152 1144
 rhs r153 1145
 rhs r154 1146
 rhs r155 1147
 rhs r156 1148
 rhs r157 1149
 rhs r158 1150
 rhs r159 1151
 rhs r160 1152
 rhs r161 1153
 rhs r162 1154
 rhs r163 1155
 rhs r164 1156
 rhs r165 1157
 rhs r166 1158
 rhs r167 1159
 rhs r168 1160
 rhs r169 1161
 rhs r170 1162
 rhs r171 1163
 rhs r172 1164
 rhs r173 1165
 rhs r174 1166
 rhs r175 1167
 rhs r176 1168
 rhs r177 1169
 rhs r178 1170
 rhs r179 1171
 rhs r180 1172
 rhs r181 1173
 rhs r182 1174
 rhs r183 1175
 rhs r184 1176
 rhs r185 1177
 rhs r186 1178
 rhs r187 1179
 rhs r188 1180
 rhs r189 1181
 rhs r190 1182
 rhs r191 1183
 rhs r192 1184
 rhs r193 1185
 rhs r194 1186
 rhs r195 1187
 rhs r196 1188
 rhs r197 1189
 rhs r198 1190
 rhs r199 1191
 rhs r200 1192
 rhs r201 1193
 rhs r202 1194
 rhs r203 1195
 rhs r204 1196
 rhs r205 1197
 rhs r206 1198
 rhs r207 1199
 rhs r208 1200
 rhs r209 1201
 rhs r210 1202
 rhs r211 1203
 rhs r212 1204
 rhs r213 1205
 rhs r214 1206
 rhs r215 1207
 rhs r216 1208
 rhs r217 1209
 rhs r218 1210
 rhs r219 1211
 rhs r220 1212
 rhs r221 1213
 rhs r222 1214
 rhs r223 1215
 rhs r224 1216
 rhs r225 1217
 rhs r226 1218
 rhs r227 1219
 rhs r228 1220
 rhs r229 1221
 rhs r230 1222
 rhs r231 1223
 rhs r232 1224
 rhs r233 1225
 rhs r234 1226
 rhs r235 1227
 rhs r236 1228
 rhs r237 1229
 rhs r238 1230
 rhs r239 1231
 rhs r240 1232
 rhs r241 1233
 rhs r242 1234
 rhs r243 1235
 rhs r244 1236
 rhs r245 1237
 rhs r246 1238
 rhs r247 1239
 rhs r248 1240
 rhs r249 1241
 rhs r250 1242
 rhs r251 1243
 rhs r252 1244
 rhs r253 1245
 rhs r254 1246
 rhs r255 1247
 rhs r256 1248
 rhs r257 1249
 rhs r258 1250
 rhs r259 1251
 rhs r260 1252
 rhs r261 1253
 rhs r262 1254
 rhs r263 1255
 rhs r264 1256
 rhs r265 1257
 rhs r266 1258
 rhs r267 1259
 rhs r268 1260
 rhs r269 1261
 rhs r270 1262
 rhs r271 1263
 rhs r272 1264
 rhs r273 1265
 rhs r274 1266
 rhs r275 1267
 rhs r276 1268
 rhs r277 1269
 rhs r278 1270
 rhs r279 1271
 rhs r280 1272
 rhs r281 1273
 rhs r282 1274
 rhs r283 1275
 rhs r284 1276
 rhs r285 1277
 rhs r286 1278
 rhs r287 1279
 rhs r288 1280
 rhs r289 1281
 rhs r290 1282
 rhs r291 1283
 rhs r292 1284
 rhs r293 1285
 rhs r294 1286
 rhs r295 1287
 rhs r296 1288
 rhs r297 1289
 rhs r298 1290
 rhs r299 1291
 rhs r300 1292
 rhs r301 1293
 rhs r302 1294
 rhs r303 1295
 rhs r304 1296
 rhs r305 1297
 rhs r306 1298
 rhs r307 1299
 rhs r308 1300
 rhs r309 1301
 rhs r310 1302
 rhs r311 1303
 rhs r312 1304
 rhs r313 1305
 rhs r314 1306
 rhs r315 1307
 rhs r316 1308
 rhs r317 1309
 rhs r318 1310
 rhs r319 1311
 rhs r320 1312
 rhs r321 1313
 rhs r322 1314
 rhs r323 1315
 rhs r324 1316
 rhs r325 1317
 rhs r326 1318
 rhs r327 1319
 rhs r328 1320
 rhs r329 1321
 rhs r330 1322
 rhs r331 1323
 rhs r332 1324
 rhs r333 1325
 rhs r334 1326
 rhs r335 1327
 rhs r336 1328
 rhs r337 1329
 rhs r338 1330
 rhs r339 1331
 rhs r340 1332
 rhs r341 1333
 rhs r342 1334
 rhs r343 1335
 rhs r344 1336
 rhs r345 1337
 rhs r346 1338
 rhs r347 1339
 rhs r348 1340
 rhs r349 1341
 rhs r350 1342
 rhs r351 1343
 rhs r352 1344
 rhs r353 1345
 rhs r354 1346
 rhs r355 1347
 rhs r356 1348
 rhs r357 1349
 rhs r358 1350
 rhs r359 1351
 rhs r360 1352
 rhs r361 1353
 rhs r362 1354
 rhs r363 1355
 rhs r364 1356
 rhs r365 1357
 rhs r366 1358
 rhs r367 1359
 rhs r368 1360
 rhs r369 1361
 rhs r370 1362
 rhs r371 1363
 rhs r372 1364
 rhs r373 1365
 rhs r374 1366
 rhs r375 1367
 rhs r376 1368
 rhs r377 1369
 rhs r378 1370
 rhs r379 1371
 rhs r380 1372
 rhs r381 1373
 rhs r382 1374
 rhs r383 1375
 rhs r384 1376
 rhs r385 1377
 rhs r386 1378
 rhs r387 1379
 rhs r388 1380
 rhs r389 1381
 rhs r390 1382
 rhs r391 1383
 rhs r392 1384
 rhs r393 1385
 rhs r394 1386
 rhs r395 1387
 rhs r396 1388
 rhs r397 1389
 rhs r398 1390
 rhs r399 1391
 rhs r400 1392
 rhs r401 1393
 rhs r402 1394
 rhs r403 1395
 rhs r404 1396
 rhs r405 1397
 rhs r406 1398
 rhs r407 1399
 rhs r408 1400
 rhs r409 1401
 rhs r410 1402
 rhs r411 1403
 rhs r412 1404
 rhs r413 1405
 rhs r414 1406
 rhs r415 1407
 rhs r416 1408
 rhs r417 1409
 rhs r418 1410
 rhs r419 1411
 rhs r420 1412
 rhs r421 1413
 rhs r422 1414
 rhs r423 1415
 rhs r424 1416
 rhs r425 1417
 rhs r426 1418
 rhs r427 1419
 rhs r428 1420
 rhs r429 1421
 rhs r430 1422
 rhs r431 1423
 rhs r432 1424
 rhs r433 1425
 rhs r434 1426
 rhs r435 1427
 rhs r436 1428
 rhs r437 1429
 rhs r438 1430
 rhs r439 1431
 rhs r440 1432
 rhs r441 1433
 rhs r442 1434
 rhs r443 1435
 rhs r444 1436
 rhs r445 1437
 rhs r446 1438
 rhs r447 1439
 rhs r448 1440
 rhs r449 1441
 rhs r450 1442
 rhs r451 1443
 rhs r452 1444
 rhs r453 1445
 rhs r454 1446
 rhs r455 1447
 rhs r456 1448
 rhs r457 1449
 rhs r458 1450
 rhs r459 1451
 rhs r460 1452
 rhs r461 1453
 rhs r462 1454
 rhs r463 1455
 rhs r464 1456
 rhs r465 1457
 rhs r466 1458
 rhs r467 1459
 rhs r468 1460
 rhs r469 1461
 rhs r470 1462
 rhs r471 1463
 rhs r472 1464
 rhs r473 1465
 rhs r474 1466
 rhs r475 1467
 rhs r476 1468
 rhs r477 1469
 rhs r478 1470
 rhs r479 1471
 rhs r480 1472
 rhs r481 1473
 rhs r482 1474
 rhs r483 1475
 rhs r484 1476
 rhs r485 1477
 rhs r486 1478
 rhs r487 1479
 rhs r488 1480
 rhs r489 1481
 rhs r490 1482
 rhs r491 1483
 rhs r492 1484
 rhs r493 1485
 rhs r494 1486
 rhs r495 1487
 rhs r496 1488
 rhs r497 1489
 rhs r498 1490
 rhs r499 1491
 rhs r500 1492
 rhs r501 1493
 rhs r502 1494
 rhs r503 1495
 rhs r504 1496
 rhs r505 1497
 rhs r506 1498
 rhs r507 1499
 rhs r508 1500
 rhs r509 1501
 rhs r510 1502
 rhs r511 1503
 rhs r512 1504
 rhs r513 1505
 rhs r514 1506
 rhs r515 1507
 rhs r516 1508
 rhs r517 1509
 rhs r518 1510
 rhs r519 1511
 rhs r520 1512
 rhs r521 1513
 rhs r522 1514
 rhs r523 1515
 rhs r524 1516
 rhs r525 1517
 rhs r526 1518
 rhs r527 1519
 rhs r528 1520
 rhs r529 1521
 rhs r530 1522
 rhs r531 1523
 rhs r532 1524
 rhs r533 1525
 rhs r534 1526
 rhs r535 1527
 rhs r536 1528
 rhs r537 1529
 rhs r538 1530
 rhs r539 1531
 rhs r540 1532
 rhs r541 1533
 rhs r542 1534
 rhs r543 1535
 rhs r544 1536
 rhs r545 1537
 rhs r546 1538
 rhs r547 1539
 rhs r548 1540
 rhs r549 1541
 rhs r550 1542
 rhs r551 1543
 rhs r552 1544
 rhs r553 1545
 rhs r554 1546
 rhs r555 1547
 rhs r556 1548
 rhs r557 1549
 rhs r558 1550
 rhs r559 1551
 rhs r560 1552
 rhs r561 1553
 rhs r562 1554
 rhs r563 1555
 rhs r564 1556
 rhs r565 1557
 rhs r566 1558
 rhs r567 1559
 rhs r568 1560
 rhs r569 1561
 rhs r570 1562
 rhs r571 1563
 rhs r572 1564
 rhs r573 1565
 rhs r574 1566
 rhs r575 1567
 rhs r576 1568
 rhs r577 1569
 rhs r578 1570
 rhs r579 1571
 rhs r580 1572
 rhs r581 1573
 rhs r582 1574
 rhs r583 1575
 rhs r584 1576
 rhs r585 1577
 rhs r586 1578
 rhs r587 1579
 rhs r588 1580
 rhs r589 1581
 rhs r590 1582
 rhs r591 1583
 rhs r592 1584
 rhs r593 1585
 rhs r594 1586
 rhs r595 1587
 rhs r596 1588
 rhs r597 1589
 rhs r598 1590
 rhs r599 1591
 rhs r600 1592
 rhs r601 1593
 rhs r602 1594
 rhs r603 1595
 rhs r604 1596
 rhs r605 1597
 rhs r606 1598
 rhs r607 1599
 rhs r608 1600
 rhs r609 1601
 rhs r610 1602
 rhs r611 1603
 rhs r612 1604
 rhs r613 1605
 rhs r614 1606
 rhs r615 1607
 rhs r616 1608
 rhs r617 1609
 rhs r618 1610
 rhs r619 1611
 rhs r620 1612
 rhs r621 1613
 rhs r622 1614
 rhs r623 1615
 rhs r624 1616
 rhs r625 1617
 rhs r626 1618
 rhs r627 1619
 rhs r628 1620
 rhs r629 1621
 rhs r630 1622
 rhs r631 1623
 rhs r632 1624
 rhs r633 1625
 rhs r634 1626
 rhs r635 1627
 rhs r636 1628
 rhs r637 1629
 rhs r638 1630
 rhs r639 1631
 rhs r640 1632
 rhs r641 1633
 rhs r642 1634
 rhs r643 1635
 rhs r644 1636
 rhs r645 1637
 rhs r646 1638
 rhs r647 1639
 rhs r648 1640
 rhs r649 1641
 rhs r650 1642
 rhs r651 1643
 rhs r652 1644
 rhs r653 1645
 rhs r654 1646
 rhs r655 1647
 rhs r656 1648
 rhs r657 1649
 rhs r658 1650
 rhs r659 1651
 rhs r660 1652
 rhs r661 1653
 rhs r662 1654
 rhs r663 1655
 rhs r664 1656
 rhs r665 1657
 rhs r666 1658
 rhs r667 1659
 rhs r668 1660
 rhs r669 1661
 rhs r670 1662
 rhs r671 1663
 rhs r672 1664
 rhs r673 1665
 rhs r674 1666
 rhs r675 1667
 rhs r676 1668
 rhs r677 1669
 rhs r678 1670
 rhs r679 1671
 rhs r680 1672
 rhs r681 1673
 rhs r682 1674
 rhs r683 1675
 rhs r684 1676
 rhs r685 1677
 rhs r686 1678
 rhs r687 1679
 rhs r688 1680
 rhs r689 1681
 rhs r690 1682
 rhs r691 1683
 rhs r692 1684
 rhs r693 1685
 rhs r694 1686
 rhs r695 1687
 rhs r696 1688
 rhs r697 1689
 rhs r698 1690
 rhs r699 1691
 rhs r700 1692
 rhs r701 1693
 rhs r702 1694
 rhs r703 1695
 rhs r704 1696
 rhs r705 1697
 rhs r706 1698
 rhs r707 1699
 rhs r708 1700
 rhs r709 1701
 rhs r710 1702
 rhs r711 1703
 rhs r712 1704
 rhs r713 1705
 rhs r714 1706
 rhs r715 1707
 rhs r716 1708
 rhs r717 1709
 rhs r718 1710
 rhs r719 1711
 rhs r720 1712
 rhs r721 1713
 rhs r722 1714
 rhs r723 1715
 rhs r724 1716
 rhs r725 1717
 rhs r726 1718
 rhs r727 1719
 rhs r728 1720
 rhs r729 1721
 rhs r730 1722
 rhs r731 1723
 rhs r732 1724
 rhs r733 1725
 rhs r734 1726
 rhs r735 1727
 rhs r736 1728
 rhs r737 1729
 rhs r738 1730
 rhs r739 1731
 rhs r740 1732
 rhs r741 1733
 rhs r742 1734
 rhs r743 1735
 rhs r744 1736
 rhs r745 1737
 rhs r746 1738
 rhs r747 1739
 rhs r748 1740
 rhs r749 1741
 rhs r750 1742
 rhs r751 1743
 rhs r752 1744
 rhs r753 1745
 rhs r754 1746
 rhs r755 1747
 rhs r756 1748
 rhs r757 1749
 rhs r758 1750
 rhs r759 1751
 rhs r760 1752
 rhs r761 1753
 rhs r762 1754
 rhs r763 1755
 rhs r764 1756
 rhs r765 1757
 rhs r766 1758
 rhs r767 1759
 rhs r768 1760
 rhs r769 1761
 rhs r770 1762
 rhs r771 1763
 rhs r772 1764
 rhs r773 1765
 rhs r774 1766
 rhs r775 1767
 rhs r776 1768
 rhs r777 1769
 rhs r778 1770
 rhs r779 1771
 rhs r780 1772
 rhs r781 1773
 rhs r782 1774
 rhs r783 1775
 rhs r784 1776
 rhs r785 1777
 rhs r786 1778
 rhs r787 1779
 rhs r788 1780
 rhs r789 1781
 rhs r790 1782
 rhs r791 1783
 rhs r792 1784
 rhs r793 1785
 rhs r794 1786
 rhs r795 1787
 rhs r796 1788
 rhs r797 1789
 rhs r798 1790
 rhs r799 1791
 rhs r800 1792
 rhs r801 1793
 rhs r802 1794
 rhs r803 1795
 rhs r804 1796
 rhs r805 1797
 rhs r806 1798
 rhs r807 1799
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
 LI b x2 0
 UI b x2 2
 LI b x3 0
 UI b x3 2
 LI b x4 0
 UI b x4 2
ENDATA
