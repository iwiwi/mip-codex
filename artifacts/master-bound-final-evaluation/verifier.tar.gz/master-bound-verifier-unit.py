from pathlib import Path
import sys,struct,copy,json
sys.path.insert(0,'/home/ubuntu/mip-priced-repair/scripts');from verify_cover_cuts import validate_cut_proofs
r=Path.cwd();o=r/'artifacts/master-bound-verifier-unit';o.mkdir();m=o/'model.mps';m.write_text('NAME proof\nROWS\n N c\n G need\n G spare\nCOLUMNS\n x c 1 need 1\n x spare 1\nRHS\n rhs need 1 spare 0\n rhs c -3\nBOUNDS\n UP b x 2\nENDATA\n');bits=lambda x:struct.pack('>d',float(x)).hex();base=dict(row_generation=dict(bound_proof=dict(multipliers=[[0,bits(1)]],normalized_bound_bits=bits(4))),dual_bound=4);assert validate_cut_proofs(m,base)['valid']is True
variants=[]
for key,value in [('multipliers',[]),('multipliers',[[0,bits(1)],[0,bits(1)]]),('multipliers',[[1,bits(0.5)],[0,bits(0.5)]]),('multipliers',[[False,bits(1)]]),('multipliers',[[0.0,bits(1)]]),('multipliers',[[-1,bits(1)]]),('multipliers',[[2,bits(1)]]),('multipliers',[[0,bits(0)]]),('multipliers',[[0,bits(-1)]]),('multipliers',[[0,bits(float('inf'))]]),('multipliers',[[0,bits(float('nan'))]]),('multipliers',[[0,'z'*16]]),('normalized_bound_bits',bits(5)),('normalized_bound_bits','0'*15)]:
 v=copy.deepcopy(base);v['row_generation']['bound_proof'][key]=value;variants.append(v)
v=copy.deepcopy(base);v['row_generation']['bound_proof']['extra']=True;variants.append(v)
v=copy.deepcopy(base);del v['row_generation']['bound_proof']['normalized_bound_bits'];variants.append(v)
v=copy.deepcopy(base);v['dual_bound']=3;variants.append(v)
v=copy.deepcopy(base);v['row_generation']=[];variants.append(v)
records=[]
for i,v in enumerate(variants):
 check=validate_cut_proofs(m,v);assert check['valid']is False,(i,check);records.append(dict(index=i,rejected=True,error=check.get('error')))
max_m=o/'max.mps';max_m.write_text(m.read_text().replace('NAME proof\n','NAME proof\nOBJSENSE\n MAX\n').replace('x c 1','x c -1'));v=copy.deepcopy(base);v['row_generation']['bound_proof']['normalized_bound_bits']=bits(-2);v['dual_bound']=2;assert validate_cut_proofs(max_m,v)['valid']is True
(o/'records.json').write_text(json.dumps(records,indent=2)+'\n');(o/'summary.json').write_text(json.dumps(dict(valid_original_proofs=2,tampered=len(records),rejected=len(records)))+'\n');print(dict(valid_original_proofs=2,tampered=len(records),rejected=len(records)))
