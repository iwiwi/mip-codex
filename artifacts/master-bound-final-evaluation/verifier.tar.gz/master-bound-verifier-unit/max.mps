NAME proof
OBJSENSE
 MAX
ROWS
 N c
 G need
 G spare
COLUMNS
 x c -1 need 1
 x spare 1
RHS
 rhs need 1 spare 0
 rhs c -3
BOUNDS
 UP b x 2
ENDATA
