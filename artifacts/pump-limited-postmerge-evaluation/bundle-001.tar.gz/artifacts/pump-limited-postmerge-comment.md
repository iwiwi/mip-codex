PR130は2026-11-18 11:13:48 UTCにmain52e68c010112dc2283bd3307ffd01df7af820334へ統合済みです。primaryで再buildしFP7f77e86310373a31、CLI SHAa04995d59d7d0b4e057f7ac335b985c1800265ccac4d8d1e30e9246e8d522d90を確認。PR head対mainのsrc/scripts/tests/Cargo/build差は空、tracked main cleanです。

primary CPU44/16GiB/1threadで4出力の元GMP/strict proofが成功。cod105根最適−12、生成5000pairs根最適−2500、depth guardは512nodesで保守的depth_limit。mcsched10秒では回収1候補/1改善により317588.0000000117/LB193774.75370663218、10.000815211秒となりました。候補測定の309595とは異なり、時刻依存の打切り点の変動も保持し、同値再現とは主張しません。mainでの可行点回収と独立検査成功は確認済みですが、比較native10秒の212887〜216929より劣ります。

最初のprimary検査はsystem Pythonのhighspy未導入でoptimizer実行前に停止。ログを保持し、既存venvで実行して上記4検査を完了しました。PR説明更新の旧GraphQL Projects廃止エラーも初回ログを保持し、直接pull更新APIで解消済みです。

旧final1759 snapshotは未起動のまま新sourceでsupersededと記録。長round候補の1時間評価を待って次の正式snapshotを作成します。正式240問は全て未起動、holdoutを調整に使わず、全体優位/新記録も未達です。

その時点のAI資源量:
```json
{
  "sessions": 1,
  "totals": {
    "input_tokens": 1875844407,
    "cached_input_tokens": 1862272256,
    "output_tokens": 9349690,
    "reasoning_output_tokens": 5745877,
    "total_tokens": 1885194097
  },
  "note": "input_tokensはキャッシュ分を含む。reasoningはoutputの内数。ローカルログの最終記録まで。"
}
```
