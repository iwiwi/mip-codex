from pathlib import Path
import json,subprocess,sys
root=Path.cwd();mode=sys.argv[1];assert mode in ['create','comment'];head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip();assert branch=='lp-input-validity-diagnostic';a=json.load(open('artifacts/rhs-interval-evaluation/summary.json'));assert a['all_payload_sha256_verified'];d=json.load(open('artifacts/lp-input-validity-default-development-analysis.json'));assert d['completed_pairs']==188 and d['comparisons']['primal_pending']==0;link=f'https://github.com/iwiwi/mip-codex/blob/{head}/docs/RHS_INTERVAL_RESULTS.md'
if mode=='create':
 text=f'''変数shift後のRHS和の誤差で0pivot数値終了していた片側制約を、元問題を包含する区間RHSへ変換します。従来1e−9の判定は変更しません。元係数の誤差を有限の元box上で囲み、Source一致を要求し、等式・有限range・不確かな係数を持つ非有界変数は対象外にします。

main122の元係数下界証明と未証明時の主解継続を維持します。検証はRust337成功4ignored、全55193適用の厳密分数検査/10改ざん拒否、200生成MILPの400出力（最適7→103、誤判定0、全290点GMP）、1200列挙/1028親証明/8224改ざん/GMP1200。開発188対は主解全同値、数値終了5→4、全376出力/128点GMP・公式有効です。

[全検証・中間失敗・比較ソルバー結果]({link})。主解改善・速度優位・新記録はありません。主解を得る前の不要な数値停止を減らし、解ける入力の範囲を広げる変更です。未採用の遅延構築コードは取り込まず、棄却記録とmain122統合後metadataを保持します。'''
else:
 text=f'''最終候補9b884c5d9667c934（production既定有効）の検証結果です。しきい値を緩めず、元の片側行を包含する別表現を使います。

- 変換後rhs ≥ s*b − s*Â*shift + max_original_box s*(Â−A)*x を元MPSのFractionで検査。実問題の全55193適用が有効、非保守的rhs・非有限値・行/shift誤り等10改ざんを全拒否。Source署名、有限box、等式/range除外を保持。
- Rust337成功4ignored。200生成MILPのflag0/1計400出力を整数全列挙と有理数連続端点へ照合し、不正下界・最適/実行不能誤判定0。最適7→103、真の不能6件を新たに証明、numeric193→91。全290点GMP（前131/後159）、全436適用行も厳密検査有効。
- 一般800/二値400出力は全列挙一致、実際の親証明1028件・改ざん拒否8224件・GMP1200点有効。主点の許容（絶対1e−6/目的相対1e−8）を、解析下界・親証明・行証拠へ流用していません。
- 開発188×10秒/1thread/16GiB、CPU31..35、同一凍結binでflag0/1・交互順。主解0改善0悪化188同値、下界3改善1悪化171同値13比較不能、有限175→175。182time/1opt/5numeric→183time/1opt/4numeric。全376出力/128点GMP・公式有効。
- 適用はrd-rplusc-21のみ55193回、numeric0pivot→time_limit。下界差の4問は適用0なので直接効果としません。専用CPU44/dumpなし再測定は10秒10949pivot、主解・下界なし。全dump試行のI/O費用や一部CPU45重複は性能比較に使っていません。

同じCPU46・10秒・1thread・16GiB、HiGHS1.16.0/SCIP10.0.2/GLPK5.0との比較:

|rd-rplusc-21|主解|下界|状態|
|---|---:|---:|---|
|Rust|なし|なし|time_limit|
|HiGHS|なし|なし|Time limit reached|
|SCIP|なし|100.0|timelimit|
|GLPK|なし|100.0000000000004|time_limit|

全ソルバーが点を返さずGMP対象0。Rust1出力の証明構造検査は有効ですが、実際のtyped global proofは0で、全体の最適性を証明したとは扱いません。native下界は報告値です。速度優位や新記録はありません。

[詳細と全中間記録]({link})。{a['files']:,}ファイル{a['raw_bytes']:,}bytes→{a['bundles']}束{a['compressed_bytes']:,}bytes、全payload SHA256検証済み、ELF{a['excluded_elf']}個は実体保持。遅延Certifierは直接改善なしで棄却し、その全証拠も保存しています。統合後はmain再build/代表点検査/未起動240snapshot更新を行い、期限まで汎用の主解・下界品質を改善し続けます。最終240はまだ未起動です。'''
# Fresh cumulative usage immediately before each PR action.
u=json.loads(subprocess.check_output(['python3','scripts/ai_usage.py'],text=True));t=u['totals'];Path(f'artifacts/rhs-interval-pr-{mode}-ai-usage.json').write_text(json.dumps(u,ensure_ascii=False,indent=2));text+=f"\n\nAI使用量（直前ローカル最終累積、{u['sessions']} sessions）: total {t['total_tokens']:,}, input {t['input_tokens']:,}（cached {t['cached_input_tokens']:,}を含む）, output {t['output_tokens']:,}（reasoning {t['reasoning_output_tokens']:,}を含む）。内数の二重加算なし。\n";p=root/f'artifacts/rhs-interval-pr-{mode}.txt';p.write_text(text)
cmd=['gh','pr','create','--repo','iwiwi/mip-codex','--base','main','--head',branch,'--title','片側RHSを元問題を包含する区間へ変換する','--body-file',str(p)]if mode=='create'else['gh','pr','comment',str(int(sys.argv[2])),'--repo','iwiwi/mip-codex','--body-file',str(p)];r=subprocess.run(cmd,capture_output=True,text=True);Path(f'artifacts/rhs-interval-pr-{mode}.log').write_text(r.stdout+r.stderr);r.check_returncode();print(r.stdout)
