from pathlib import Path
import sys,os,json,argparse
sys.path.insert(0,'scripts');import benchmark
root=Path.cwd();old=json.load(open(root/'artifacts/runs/decimal-coefficient-final-20261117/config.json'));assert not(root/'artifacts/runs/rhs-interval-final-20261118').exists();solvers=sorted({j['solver']for j in old['jobs']});assert solvers==['rust'];original=benchmark.require_solver_origin
def pinned_origin(*a,**kw):
 os.sched_setaffinity(0,{43});info=original(*a,**kw);assert info['source_fingerprint']==info['library_source_fingerprint']=='9b884c5d9667c934';return info
benchmark.require_solver_origin=pinned_origin
benchmark.create(argparse.Namespace(directory=str(root/'artifacts/runs/rhs-interval-final-20261118'),seconds=old['seconds'],cores=','.join(map(str,old['cores'])),solvers=','.join(solvers),manifest=str(root/'data/manifest.json'),names=None,allow_dirty=False))
