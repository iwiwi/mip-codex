from pathlib import Path
import json,os,sys,resource
sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256
from validate_solution import validate
from verify_cover_cuts import validate_cut_proofs
os.sched_setaffinity(0,{36});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));root=Path.cwd();out=root/'artifacts/cold-dual-safety-paired-audit';out.mkdir();manifest={r['name']:r for r in json.loads((root/'data/manifest.json').read_text())['instances']};records=[]
for run in sorted((root/'artifacts').glob('cold-dual-safety-paired-*')):
 if not run.is_dir()or run==out:continue
 for p in sorted(run.glob('*/*/result.json')):
  name=p.parent.parent.name;m=manifest[name];assert m['split']=='development';model=root/m['path'];assert sha256(model)==m['sha256'];r=json.loads(p.read_text());proof=validate_cut_proofs(model,r);v=validate(model,r)if r['values']is not None else None;d=out/run.name/name/p.parent.name;d.mkdir(parents=True);record=dict(name=name,variant=p.parent.name,proof=proof,point=v,result_sha256=sha256(p));atomic_json(d/'record.json',record);assert proof['valid']is True and(v is None or v['valid']is True),(name,record);records.append(record);atomic_json(out/'records.json',records)
assert len(records)==12;atomic_json(out/'summary.json',dict(outputs=12,proofs_valid=12,points=sum(r['point']is not None for r in records),points_valid=sum(r['point']is not None and r['point']['valid']is True for r in records)));atomic_json(out/'exit.json',dict(status='complete'))
