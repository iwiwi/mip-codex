from pathlib import Path
import os,sys,json,hashlib,gzip,tarfile,io,subprocess
os.sched_setaffinity(0,{32});root=Path('/home/ubuntu/mip-codex');repo=Path('/home/ubuntu/mip-phase-two');kind='cold-dual-strict-research'
groups=[('rejected-prototypes',('cold-dual-v1-','cold-dual-v2-','cold-dual-v3-','cold-dual-v4-','cold-dual-v5-','cold-dual-boundary-','cold-dual-main116-','cold-dual-strict-','cold-dual-unit-','cold-dual-first-','cold-dual-example-'),[]),('strict-safety',('cold-dual-safety-',),['cold-dual-research-archive.py'])]
documents=[('cold-dual-crash','COLD_DUAL_HYPOTHESIS.md')]
a=json.loads((root/'artifacts/cold-dual-safety-mip-point-audit/summary.json').read_text());assert a['points']==a['strict_valid']==800 and a['invalid']==0
a=json.loads((root/'artifacts/cold-dual-safety-paired-audit/summary.json').read_text());assert a['outputs']==a['proofs_valid']==a['points']==a['points_valid']==12
out=repo/f'artifacts/{kind}-evaluation';assert not out.exists();out.mkdir();ledger=[];excluded=[];bundles=[]
for label,prefixes,extras in groups:
 paths=sorted(p for p in (root/'artifacts').iterdir()if p.name.startswith(prefixes));paths.extend(root/'artifacts'/name for name in extras);bundle=out/(label+'.tar.gz');count=0
 with bundle.open('wb')as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6)as z,tarfile.open(fileobj=z,mode='w')as tar:
  for source in paths:
   for p in sorted(source.rglob('*'))if source.is_dir()else[source]:
    if not p.is_file():continue
    data=p.read_bytes();h=hashlib.sha256(data).hexdigest();name=str(p.relative_to(root/'artifacts'))
    if data[:4]==b'\x7fELF'or p.name=='model.glp':excluded.append(dict(source=str(p),sha256=h,bytes=len(data),reason='local executable/generated LP retained'));continue
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));ledger.append(dict(source=str(p),bundle=bundle.name,member=name,sha256=h,bytes=len(data)));count+=1
 assert bundle.stat().st_size<95*1024**2
 bundles.append(dict(path=bundle.name,sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),bytes=bundle.stat().st_size,files=count));print(bundles[-1],flush=True)
expected={(r['bundle'],r['member']):r for r in ledger};verified=0
for bundle in bundles:
 with tarfile.open(out/bundle['path'],'r:gz')as tar:
  for member in tar:
   r=expected[(bundle['path'],member.name)];data=tar.extractfile(member).read();assert len(data)==r['bytes']and hashlib.sha256(data).hexdigest()==r['sha256'];verified+=1
assert verified==len(ledger)
for branch,name in documents:(out/name).write_bytes(subprocess.check_output(['git','show',f'{branch}:docs/{name}'],cwd=repo))
(out/'relocation-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n');(out/'bundles.json').write_text(json.dumps(bundles,indent=2)+'\n');(out/'retained-local-files.json').write_text(json.dumps(excluded,indent=2)+'\n');s=dict(files=len(ledger),original_bytes=sum(r['bytes']for r in ledger),bundled_bytes=sum(b['bytes']for b in bundles),excluded=len(excluded),verified_payloads=verified);(out/'archive-summary.json').write_text(json.dumps(s,indent=2)+'\n');(out/'README.txt').write_text('完了済み開発試作の圧縮原記録。空の作業ディレクトリでtar.gzを展開すると元artifacts以下の相対パスが復元される。bundles.jsonで圧縮SHA、relocation-ledger.jsonで展開payloadのSHAを照合。作成時に全payloadの展開SHAを確認済み。元ファイルと除外したELF/生成LPはローカル保持。厳密冷dualの未採用研究。旧版の微小境界誤答と全失敗ログ、合成検査成功、実問題6問で成功0回の棄却理由を保全。研究srcは証拠としてのみ含みmainへ採用しない。\n');print(s)
