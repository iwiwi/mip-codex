NAME tiny
ROWS
 N obj
 G r
COLUMNS
 x0 obj 1 r 1
 x1 obj 1 r 1
RHS
 rhs r 1e-16
BOUNDS
 LI b x0 0
 UI b x0 2
 LI b x1 0
 UI b x1 2
ENDATA
