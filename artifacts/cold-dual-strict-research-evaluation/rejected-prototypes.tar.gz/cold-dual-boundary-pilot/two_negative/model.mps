NAME tiny
ROWS
 N obj
 L r
COLUMNS
 x0 obj -1 r 1
 x1 obj -1 r 1
RHS
 rhs r -1e-16
BOUNDS
 LI b x0 -2
 UI b x0 0
 LI b x1 -2
 UI b x1 0
ENDATA
