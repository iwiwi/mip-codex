from pathlib import Path
import sys,json,os,subprocess
sys.path.insert(0,'scripts');from benchmark_common import sha256,atomic_json,require_solver_origin
os.sched_setaffinity(0,{43});root=Path.cwd();run=root/'artifacts/runs/cover-long-round-final-20261118';c=json.load(open(run/'config.json'))
assert c['git_sha']=='f05f294413cd5d460326914748447962ac6162e5'
assert c['solver_build_info']['source_fingerprint']==c['solver_build_info']['library_source_fingerprint']=='cbfa820d2f513238'
assert not c['source_dirty']
assert(c['seconds'],c['threads'],c['memory_bytes'],c['cores'])==(3600,1,16*1024**3,list(range(8,16)))
assert len(c['instances'])==len(c['jobs'])==240 and{j['solver']for j in c['jobs']}=={'rust'}
for name,h in c['snapshot_sha256'].items():assert sha256(run/'snapshot'/name)==h
for name,h in c['library_sha256'].items():assert sha256(name)==h
oldrun=root/'artifacts/runs/large-primal-budget-final-20261118';old=json.load(open(oldrun/'config.json'))
assert sha256(oldrun/'config.json')=='17594c699b0c484d809689cd919dad26076f57f181d516194e9fa71fff8ddae1'
assert c['library_sha256']==old['library_sha256']
assert set(c['snapshot_sha256'])==set(old['snapshot_sha256'])
changed=sorted(name for name,h in c['snapshot_sha256'].items()if old['snapshot_sha256'][name]!=h)
assert changed==['bin/mip-codex','src/binary_graph.rs','src/binary_graph/weighted_cover.rs','src/main.rs','src/solve.rs'],changed
for directory,cfg in [(run,c),(oldrun,old)]:
 assert not(directory/'results.jsonl').exists()
 assert not list((directory/'cases').glob('*/summary.json'))
 for j in cfg['jobs']:
  cg=Path('/sys/fs/cgroup/mip-codex-bench')/cfg['id']/j['id'];events=dict(line.split()for line in(cg/'cgroup.events').read_text().splitlines())
  assert events['populated']=='0'and not(cg/'cgroup.procs').read_text().strip()
  assert(cg/'memory.max').read_text().strip()==str(16*1024**3)
  assert(cg/'memory.swap.max').read_text().strip()=='0'and(cg/'pids.max').read_text().strip()=='512'
source=root/'artifacts/cover-long-round-main-primary-audit'
for label,model in [('cod105',root/'data/raw/benchmark/cod105.mps.gz'),('pairs5000',Path('/home/ubuntu/mip-large-packing-profile/artifacts/large-cover-profile-v1/pairs5000.mps')),('depth-cycles',Path('/home/ubuntu/mip-graph-large-capacity/artifacts/large-capacity-depth-controls/many-cycles-0/model.mps'))]:
 cmd=[str(root/'.venv/bin/python'),str(run/'snapshot/scripts/verify_cover_cuts.py'),str(model),str(source/label/'result.json')]
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=600)
 (root/f'artifacts/cover-long-round-snapshot-{label}-proof.log').write_text(r.stdout+r.stderr)
 assert r.returncode==0 and json.loads(r.stdout)['valid']is True
info=require_solver_origin(root,root/'target/release/mip-codex');assert info['source_fingerprint']=='cbfa820d2f513238'
recovery=json.load(open('artifacts/large-capacity-baseline-disk-recovery-receipt.json'))
proof=dict(run=str(run.relative_to(root)),config_sha256=sha256(run/'config.json'),source_fingerprint='cbfa820d2f513238',source_git_sha=c['git_sha'],seconds=3600,threads=1,memory_bytes=16*1024**3,instances=240,jobs=240,status='create-only; neverlaunched',cores=c['cores'],snapshot_files_verified=len(c['snapshot_sha256']),changed_snapshot_files=changed,snapshot_spectral_large_depth_checker_valid=True,libraries_verified=len(c['library_sha256']),libraries_unchanged_from_previous_snapshot=True,creation_hash_copy_cpu=43,verification_cpu=43,cgroups_empty=240,old_cgroups_empty=240,native_disk_recovery_required_before_launch=dict(tag=Path(recovery['directory']).name,config_sha256=recovery['config_sha256'],jobs=1),own_final_jobs_launched=False)
atomic_json(root/'artifacts/cover-long-round-final-snapshot-verification.json',proof)
atomic_json(root/'experiments/cover-long-round-snapshot-20261118.json',proof)
atomic_json(oldrun/'OBSOLETE.json',dict(reason='superseded before launch by main132 verified large sparse cover long-round snapshot',replacement=str(run.relative_to(root)),replacement_config_sha256=proof['config_sha256'],old_config_sha256=sha256(oldrun/'config.json'),jobs_launched=False))
print(json.dumps(proof),flush=True)
