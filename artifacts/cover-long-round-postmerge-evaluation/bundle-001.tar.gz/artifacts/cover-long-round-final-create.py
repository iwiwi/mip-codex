from pathlib import Path
import sys,os,json,argparse,hashlib,subprocess,time
sys.path.insert(0,'scripts');import benchmark
root=Path.cwd()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='f05f294413cd5d460326914748447962ac6162e5'
deadline=time.monotonic()+1800
while not(root/'artifacts/cover-long-round-main-primary-audit/exit.json').exists():
 assert time.monotonic()<deadline,'primary smoke not terminal'
 time.sleep(2)
assert json.load(open('artifacts/cover-long-round-main-primary-audit/exit.json'))['gmp_valid']==5
oldpath=root/'artifacts/runs/large-primal-budget-final-20261118/config.json'
assert hashlib.sha256(oldpath.read_bytes()).hexdigest()=='17594c699b0c484d809689cd919dad26076f57f181d516194e9fa71fff8ddae1'
old=json.load(open(oldpath));destination=root/'artifacts/runs/cover-long-round-final-20261118'
assert not destination.exists();solvers=sorted({j['solver']for j in old['jobs']});assert solvers==['rust']
original=benchmark.require_solver_origin
def pinned_origin(*a,**kw):
 os.sched_setaffinity(0,{43});info=original(*a,**kw)
 assert info['source_fingerprint']==info['library_source_fingerprint']=='cbfa820d2f513238'
 return info
benchmark.require_solver_origin=pinned_origin
benchmark.create(argparse.Namespace(directory=str(destination),seconds=old['seconds'],cores=','.join(map(str,old['cores'])),solvers=','.join(solvers),manifest=str(root/'data/manifest.json'),names=None,allow_dirty=False))
