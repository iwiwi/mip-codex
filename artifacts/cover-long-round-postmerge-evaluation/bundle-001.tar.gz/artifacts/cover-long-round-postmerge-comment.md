PR132は2026-11-18 12:39:40 UTCにmainf05f294413cd5d460326914748447962ac6162e5へ統合しました。primary再buildはFPcbfa820d2f513238、CLI SHA0bf00779798a657b02581a960261473b3093a21aae08d206b0d180f328a19876。PR headとmainのsrc/scripts/tests/Cargo/build差は空、tracked main cleanです。

primary CPU44/16GiB/1threadで5出力の元GMP/strict proofが成功。cod105根最適−12、5000pairs根最適−2500、depth guard512nodesを維持し、z26/CDCの60秒では長mode実行を確認しました。値とタイミング変動は添付生結果に保持し、候補測定との同値再現は主張しません。

正式評価用cover-long-round-final-20261118 snapshotを作成・検証しました。config SHA46ffdbd56ef5e38d1a493a96b39f23bc0333dd4c08b2960047dcbf836c9609e9、240問×3600秒/16GiB/1thread/cores8..15、swap0/pids512。113snapshot files/147libraries全SHA、旧1759との差はCLIと4Rustファイルだけ。snapshot版checkerでcod105/pair/depthの3証明も再検査、両240cgroupsは空で、own最終ジョブは全て未起動。旧1759はconfigを変えずOBSOLETE→46ffと記録しました。native720+事前規定1再測定は既に完了し、original720とその失敗も保持しています。

別の頂点portfolio候補は現mainへ履歴を合わせ、Rust等の同一性を確認しましたが、まだ採用していません。全体優位/新記録は未達のまま改善を続けます。

その時点のAI資源量:
```json
{
  "sessions": 1,
  "totals": {
    "input_tokens": 1924721488,
    "cached_input_tokens": 1910695808,
    "output_tokens": 9553570,
    "reasoning_output_tokens": 5871265,
    "total_tokens": 1934275058
  },
  "note": "input_tokensはキャッシュ分を含む。reasoningはoutputの内数。ローカルログの最終記録まで。"
}
```
