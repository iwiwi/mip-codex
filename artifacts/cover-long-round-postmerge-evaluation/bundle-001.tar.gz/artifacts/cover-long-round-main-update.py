from pathlib import Path
import os,sys,json,subprocess,shutil,time,hashlib
root=Path.cwd();assert root==Path('/home/ubuntu/mip-codex');os.sched_setaffinity(0,set(range(56,64)));sys.path.insert(0,'scripts')
from benchmark_common import sha256,atomic_json,require_solver_origin
for n in ['cargo','rustc']:assert subprocess.run(['pgrep','-x',n],capture_output=True).returncode==1
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no']);assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='main'
merge=json.load(open('/home/ubuntu/mip-graph-cover-long-rounds/artifacts/cover-long-round-pr-merge.json'));new=merge['mergeCommit']['oid']
subprocess.run(['git','fetch','origin','main'],check=True,capture_output=True,text=True);assert subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()==new
assert not subprocess.check_output(['git','diff',merge['headRefOid'],new,'--','src','scripts','tests','Cargo.toml','Cargo.lock','build.rs'])
old=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();tracked=set(subprocess.check_output(['git','ls-files','-z']).decode().split('\0'));incoming=subprocess.check_output(['git','diff','--name-only','-z',old,new]).decode().split('\0');backup=Path('/tmp/cover-long-round-main132-untracked');moved=[]
for name in incoming:
 p=root/name
 if name and name not in tracked and p.is_file():
  content=subprocess.check_output(['git','show',new+':'+name]);h=sha256(p);target=backup/name;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();equal=p.read_bytes()==content;shutil.move(p,target);moved.append(dict(path=name,sha256=h,incoming_sha256=hashlib.sha256(content).hexdigest(),backup=str(target),bytes_equal_to_incoming_git_blob=equal,preserved_even_when_different=True))
subprocess.run(['git','pull','--ff-only','origin','main'],check=True,capture_output=True,text=True);assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==new
for r in moved:assert sha256(Path(r['backup']))==r['sha256']and sha256(root/r['path'])==r['incoming_sha256']
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
with(root/'artifacts/cover-long-round-main-build.log').open('w')as log:subprocess.run(['cargo','build','--release'],env=dict(os.environ,CARGO_INCREMENTAL='0'),stdout=log,stderr=subprocess.STDOUT,check=True)
info=require_solver_origin(root,root/'target/release/mip-codex');assert info['source_fingerprint']==info['library_source_fingerprint']=='cbfa820d2f513238'
r=dict(old_main=old,new_main=new,source_fingerprint='cbfa820d2f513238',build_info=info,normal_cli_sha256=sha256(root/'target/release/mip-codex'),moved_untracked_collisions=moved,tracked_clean=True,pr_head_source_scripts_tests_Cargo_build_diff_empty=True)
atomic_json(root/'artifacts/cover-long-round-main-update.json',r);print(json.dumps(r),flush=True)
