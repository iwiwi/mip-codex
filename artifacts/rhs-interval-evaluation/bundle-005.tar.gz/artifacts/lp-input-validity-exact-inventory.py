from pathlib import Path
from fractions import Fraction as F
import math,json,os,sys
sys.path.insert(0,'scripts');from verify_cover_cuts import exact_model
from benchmark_common import sha256,atomic_json
os.sched_setaffinity(0,{50});root=Path.cwd();model=root/'data/raw/benchmark/rd-rplusc-21.mps.gz';manifest=json.loads((root/'data/manifest.json').read_text())['instances'];entry=next(r for r in manifest if r['name']==model.name);assert entry['split']=='development'and sha256(model)==entry['sha256'];names,variables,rows=exact_model(model);shift={}
for name,v in variables.items():
 lo=v['lower'];up=v['upper']
 if v['integer']:
  if lo is not None:lo=F(math.ceil(lo))
  if up is not None:up=F(math.floor(up))
 shift[name]=float(lo if lo is not None else up if up is not None else 0)
selected=[]
for r in rows:
 if r['name']not in ['c44','c45','c48','c56','c61']:continue
 upper=r['upper']is not None;b=r['upper']if upper else r['lower'];bf=float(b)
 if upper and F(bf)<b:bf=math.nextafter(bf,math.inf)
 if not upper and F(bf)>b:bf=math.nextafter(bf,-math.inf)
 sign=1 if upper else-1;terms=[(sign*bf,1.)]+[(-sign*float(a),shift[name])for name,a in r['coefficients'].items()];exact=sum(F(a)*F(x)for a,x in terms);near=float(exact)
 selected.append(dict(name=r['name'],lower=None if r['lower']is None else str(r['lower']),upper=None if r['upper']is None else str(r['upper']),coefficient_count=len(r['coefficients']),all_coefficients_binary_exact=all(F(float(a))==a for a in r['coefficients'].values()),all_shift_values_integral=all(x.is_integer()for x in shift.values()),nonzero_shift_terms=[dict(variable=name,coefficient=str(a),binary_coefficient_exact=F(float(a))==a,shift=shift[name])for name,a in r['coefficients'].items()if shift[name]!=0.],binary_rhs_exact=str(exact),binary_rhs_nearest=near,binary_rhs_nearest_error=str(abs(F(near)-exact))))
record=dict(input_sha256=entry['sha256'],variables=len(names),rows=len(rows),noninteger_shift_count=sum(not x.is_integer()for x in shift.values()),selected=selected);atomic_json(root/'artifacts/lp-input-validity-exact-inventory.json',record);print(json.dumps(record))
