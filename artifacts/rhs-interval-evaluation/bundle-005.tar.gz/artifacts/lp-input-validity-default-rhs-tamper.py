from pathlib import Path
from fractions import Fraction as F
import sys,json,copy,struct,os,resource
os.sched_setaffinity(0,{46});resource.setrlimit(resource.RLIMIT_AS,(16*55193**3,16*55193**3));sys.path.insert(0,'scripts');import verify_rhs_interval as checker
root=Path.cwd();model=root/'data/raw/benchmark/rd-rplusc-21.mps.gz';source=root/'artifacts/lp-input-validity-default-pilot/1/rhs-dump.jsonl';out=root/'artifacts/lp-input-validity-default-rhs-tamper';out.mkdir();parsed=checker.exact_model(model);checker.exact_model=lambda p:parsed;positive=checker.verify(model,source);assert positive['valid']and positive['rows']==55193;first=json.loads(source.read_text().splitlines()[0]);required=F(positive['records'][0]['required']);badvalue=float(required-F(1));assert F(badvalue)<required;records=[]
for kind in ['nonconservative_rhs','nonfinite_rhs','bad_name','bad_row_index','wrong_side','duplicate_shift','unknown_shift','nonfinite_shift','extra_field','invalid_boolean']:
 p=copy.deepcopy(first)
 if kind=='nonconservative_rhs':p['rhs_bits']=struct.pack('>d',badvalue).hex()
 elif kind=='nonfinite_rhs':p['rhs_bits']='7ff0000000000000'
 elif kind=='bad_name':p['source_name']='wrong-original-row'
 elif kind=='bad_row_index':p['source_row']=len(parsed[2])
 elif kind=='wrong_side':p['upper']=not p['upper']
 elif kind=='duplicate_shift':p['shift_bits']=[[0,'0000000000000000'],[0,'0000000000000000']]
 elif kind=='unknown_shift':p['shift_bits']=[[len(parsed[0]),'0000000000000000']]
 elif kind=='nonfinite_shift':p['shift_bits']=[[0,'7ff0000000000000']]
 elif kind=='extra_field':p['extra']=True
 else:p['upper']=1
 path=out/(kind+'.jsonl');path.write_text(json.dumps(p)+'\n')
 try:checker.verify(model,path)
 except ValueError as e:
  if kind=='nonconservative_rhs':assert str(e)=='nonconservative shifted RHS'
  records.append(dict(kind=kind,rejected=True,error=str(e)));continue
 raise AssertionError('tamper accepted: '+kind)
(out/'records.json').write_text(json.dumps(records,indent=2));(out/'summary.json').write_text(json.dumps(dict(positive_rows=55193,tampered_rejected=len(records),input_sha256=positive['input_sha256'],dump_sha256=positive['dump_sha256'])));print(len(records),'tamper rejections')
