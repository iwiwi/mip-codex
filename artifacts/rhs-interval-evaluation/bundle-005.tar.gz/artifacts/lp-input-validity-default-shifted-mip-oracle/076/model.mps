NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 7 r0 2
 x r1 -3
 y obj 1 r0 4
 y r1 1
 z r0 -9.87654321
RHS
 rhs obj 4
 rhs r0 -2651214365.78005376 r1 -5.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 268435456
ENDATA
