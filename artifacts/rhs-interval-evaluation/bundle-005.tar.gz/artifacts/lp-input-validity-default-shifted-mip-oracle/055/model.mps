NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj -3 r0 1
 x r1 -1
 y obj -1 r0 4
 y r1 1
 z r0 -9.87654321
RHS
 rhs obj 4
 rhs r0 -5302428760.56010752000000000001 r1 -2
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 536870912
ENDATA
