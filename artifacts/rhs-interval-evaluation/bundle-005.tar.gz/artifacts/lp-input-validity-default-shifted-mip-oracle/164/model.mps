NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj -1 r0 -3
 x r1 2
 y obj -5 r0 1
 y r1 -1
 z r0 -9.87654321
RHS
 rhs obj 1
 rhs r0 -5429687050820.05010048 r1 4
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 549755813888
ENDATA
