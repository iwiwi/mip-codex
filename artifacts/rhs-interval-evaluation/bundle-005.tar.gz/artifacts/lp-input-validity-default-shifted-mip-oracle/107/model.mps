NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj 7 r0 -4
 x r1 -3
 y obj 2 r0 -3
 y r1 -1
 z r0 -9.87654321
RHS
 rhs obj -3
 rhs r0 -1357421762705.88752512 r1 -1.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 137438953472
ENDATA
