NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 1 r0 -4
 x r1 1
 y obj 1 r0 1
 y r1 -3
 z r0 -9.87654321
RHS
 rhs obj -5
 rhs r0 -41425226.19187584 r1 -6
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 4194304
ENDATA
