NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj -1 r0 3
 x r1 1
 y obj 2 r0 -1
 y r1 2
 z r0 3.14159265
RHS
 rhs obj 2
 rhs r0 6588404.30913279999999999999 r1 6
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 2097152
ENDATA
