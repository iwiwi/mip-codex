NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 3 r0 -1
 x r1 -1
 y obj 2 r0 -3
 y r1 -3
 z r0 -9.87654321
RHS
 rhs obj -1
 rhs r0 -84838860174.96172032000000000001 r1 -5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 8589934592
ENDATA
