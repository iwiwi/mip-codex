NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 3 r0 2
 x r1 -1
 y obj -1 r0 -1
 y r1 1
 z r0 -9.87654321
RHS
 rhs obj 1
 rhs r0 -10356305.67296896 r1 1.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1048576
ENDATA
