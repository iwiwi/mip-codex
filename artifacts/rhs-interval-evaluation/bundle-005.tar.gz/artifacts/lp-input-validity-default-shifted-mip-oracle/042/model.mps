NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj 7 r0 -3
 x r1 -1
 y obj -5 r0 2
 y r1 1
 z r0 -9.87654321
RHS
 rhs obj 0
 rhs r0 -82850449.38375167999999999999 r1 1
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 8388608
ENDATA
