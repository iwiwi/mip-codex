NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj 1 r0 -1
 x r1 1
 y obj 5 r0 -3
 y r1 -3
 z r0 -9.87654321
RHS
 rhs obj 5
 rhs r0 -2651214386.28005376000000000001 r1 -8
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 268435456
ENDATA
