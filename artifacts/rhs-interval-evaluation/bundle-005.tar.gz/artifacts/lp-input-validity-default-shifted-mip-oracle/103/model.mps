NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 3 r0 1
 x r1 2
 y obj 1 r0 -3
 y r1 -1
 z r0 -9.87654321
RHS
 rhs obj -3
 rhs r0 -339355440679.84688128000000000001 r1 2.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 34359738368
ENDATA
