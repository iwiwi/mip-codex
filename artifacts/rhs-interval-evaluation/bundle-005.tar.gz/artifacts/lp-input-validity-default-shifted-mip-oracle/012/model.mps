NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 3 r0 1
 x r1 1
 y obj -5 r0 1
 y r1 1
 z r0 3.14159265
RHS
 rhs obj 2
 rhs r0 53972150757.41589759999999999999 r1 2.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 17179869184
ENDATA
