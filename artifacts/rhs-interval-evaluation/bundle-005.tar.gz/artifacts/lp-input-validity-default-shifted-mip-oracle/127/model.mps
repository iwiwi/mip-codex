NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj -7 r0 1
 x r1 2
 y obj 2 r0 2
 y r1 1
 z r0 -9.87654321
RHS
 rhs obj 5
 rhs r0 -20712610.34593791999999999999 r1 0
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 2097152
ENDATA
