NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj 1 r0 1
 x r1 -1
 y obj 1 r0 -3
 y r1 1
 z r0 -9.87654321
RHS
 rhs obj -1
 rhs r0 -339355440678.34688128 r1 -2
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 34359738368
ENDATA
