NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj 3 r0 -1
 x r1 -3
 y obj 5 r0 -3
 y r1 -3
 z r0 -9.87654321
RHS
 rhs obj 3
 rhs r0 -10356309.67296896 r1 -3.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1048576
ENDATA
