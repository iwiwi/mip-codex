NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 7 r0 3
 x r1 1
 y obj -2 r0 4
 y r1 -1
 z r0 3.14159265
RHS
 rhs obj 2
 rhs r0 26353610.23653120000000000001 r1 1
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 8388608
ENDATA
