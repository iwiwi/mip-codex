NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 1 r0 1
 x r1 2
 y obj 1 r0 1
 y r1 -1
 z r0 1.23456789
RHS
 rhs obj 4
 rhs r0 20712618.65719424 r1 3
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 16777216
ENDATA
