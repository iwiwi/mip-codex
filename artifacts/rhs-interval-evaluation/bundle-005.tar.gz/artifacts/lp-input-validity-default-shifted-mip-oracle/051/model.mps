NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj -7 r0 3
 x r1 3
 y obj 1 r0 -3
 y r1 -3
 z r0 1.23456789
RHS
 rhs obj -1
 rhs r0 21209714848.96690175999999999999 r1 2
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 17179869184
ENDATA
