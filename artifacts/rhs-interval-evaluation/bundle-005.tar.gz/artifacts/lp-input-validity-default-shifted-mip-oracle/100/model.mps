NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj -3 r0 1
 x r1 2
 y obj -5 r0 1
 y r1 1
 z r0 1.23456789
RHS
 rhs obj -2
 rhs r0 1325607180.56043136 r1 4
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1073741824
ENDATA
