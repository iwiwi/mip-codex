NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj -7 r0 1
 x r1 -1
 y obj 2 r0 -1
 y r1 -1
 z r0 -9.87654321
RHS
 rhs obj -2
 rhs r0 -10604857521.62021504 r1 -6
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1073741824
ENDATA
