NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj -7 r0 1
 x r1 3
 y obj -5 r0 -3
 y r1 -3
 z r0 3.14159265
RHS
 rhs obj 1
 rhs r0 26986075378.7079488 r1 0
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 8589934592
ENDATA
