NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj -1 r0 -4
 x r1 -3
 y obj -1 r0 -1
 y r1 2
 z r0 -9.87654321
RHS
 rhs obj -1
 rhs r0 -10604857527.62021504 r1 1.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1073741824
ENDATA
