NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj -3 r0 -4
 x r1 1
 y obj 5 r0 -1
 y r1 1
 z r0 -9.87654321
RHS
 rhs obj 0
 rhs r0 -662803602.07001343999999999999 r1 3.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 67108864
ENDATA
