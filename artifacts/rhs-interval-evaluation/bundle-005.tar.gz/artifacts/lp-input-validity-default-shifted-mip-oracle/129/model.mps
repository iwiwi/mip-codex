NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj -7 r0 -3
 x r1 -3
 y obj 2 r0 -3
 y r1 -1
 z r0 -9.87654321
RHS
 rhs obj -4
 rhs r0 -10859374101632.60020096 r1 -4.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1099511627776
ENDATA
