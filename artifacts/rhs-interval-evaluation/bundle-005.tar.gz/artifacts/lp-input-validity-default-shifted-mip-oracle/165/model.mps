NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj -7 r0 -3
 x r1 2
 y obj 1 r0 -1
 y r1 -3
 z r0 1.23456789
RHS
 rhs obj 5
 rhs r0 1357421750328.88171264000000000001 r1 -4
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1099511627776
ENDATA
