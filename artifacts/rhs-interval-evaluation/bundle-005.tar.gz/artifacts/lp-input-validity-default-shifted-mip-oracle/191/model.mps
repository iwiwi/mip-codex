NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 1 r0 -3
 x r1 2
 y obj 2 r0 4
 y r1 2
 z r0 3.14159265
RHS
 rhs obj -1
 rhs r0 1686629706.13799680000000000001 r1 8.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 536870912
ENDATA
