NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj -7 r0 3
 x r1 -1
 y obj -5 r0 4
 y r1 1
 z r0 3.14159265
RHS
 rhs obj 2
 rhs r0 105414375.4461248 r1 1.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 33554432
ENDATA
