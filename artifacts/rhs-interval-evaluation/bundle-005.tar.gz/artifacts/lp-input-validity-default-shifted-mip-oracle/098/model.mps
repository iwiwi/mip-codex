NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj 7 r0 -1
 x r1 -3
 y obj 2 r0 1
 y r1 -1
 z r0 3.14159265
RHS
 rhs obj -2
 rhs r0 3373259424.7759936 r1 -3.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1073741824
ENDATA
