NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj -3 r0 2
 x r1 3
 y obj -2 r0 -1
 y r1 -3
 z r0 -9.87654321
RHS
 rhs obj -3
 rhs r0 -662803594.07001344000000000001 r1 -2
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 67108864
ENDATA
