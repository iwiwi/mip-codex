NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj -3 r0 2
 x r1 -1
 y obj 2 r0 4
 y r1 1
 z r0 3.14159265
RHS
 rhs obj 0
 rhs r0 6746518855.0519872 r1 -3
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 2147483648
ENDATA
