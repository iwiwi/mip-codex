NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj -7 r0 2
 x r1 2
 y obj 5 r0 -3
 y r1 -1
 z r0 1.23456789
RHS
 rhs obj 2
 rhs r0 41425217.81438848 r1 -2
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 33554432
ENDATA
