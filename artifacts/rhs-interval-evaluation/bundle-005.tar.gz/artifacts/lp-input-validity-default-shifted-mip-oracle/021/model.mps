NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 3 r0 -3
 x r1 1
 y obj -2 r0 2
 y r1 1
 z r0 -9.87654321
RHS
 rhs obj 4
 rhs r0 -2714843525409.27505024 r1 3
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 274877906944
ENDATA
