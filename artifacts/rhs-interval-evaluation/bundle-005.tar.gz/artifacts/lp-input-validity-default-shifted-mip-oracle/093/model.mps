NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj -3 r0 -4
 x r1 3
 y obj -2 r0 -3
 y r1 2
 z r0 1.23456789
RHS
 rhs obj -1
 rhs r0 1357421750319.88171263999999999999 r1 8
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1099511627776
ENDATA
