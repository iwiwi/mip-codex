NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj 7 r0 2
 x r1 -3
 y obj -2 r0 -1
 y r1 1
 z r0 1.23456789
RHS
 rhs obj -1
 rhs r0 1294540.75982464 r1 -6.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1048576
ENDATA
