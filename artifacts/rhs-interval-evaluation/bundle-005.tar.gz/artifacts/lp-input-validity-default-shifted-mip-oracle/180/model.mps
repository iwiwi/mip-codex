NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 1 r0 3
 x r1 1
 y obj 2 r0 2
 y r1 -1
 z r0 3.14159265
RHS
 rhs obj 0
 rhs r0 53972150770.9158976 r1 0.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 17179869184
ENDATA
