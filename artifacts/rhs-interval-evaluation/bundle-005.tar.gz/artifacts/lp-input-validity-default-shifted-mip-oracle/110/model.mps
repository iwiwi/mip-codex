NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj -1 r0 -4
 x r1 3
 y obj 2 r0 1
 y r1 -3
 z r0 3.14159265
RHS
 rhs obj 0
 rhs r0 3373259420.7759936 r1 -3
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1073741824
ENDATA
