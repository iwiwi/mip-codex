NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 3 r0 -3
 x r1 -3
 y obj 2 r0 -1
 y r1 -1
 z r0 1.23456789
RHS
 rhs obj 4
 rhs r0 678710875157.94085632000000000001 r1 -8.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 549755813888
ENDATA
