NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj 1 r0 1
 x r1 1
 y obj 5 r0 -3
 y r1 -3
 z r0 1.23456789
RHS
 rhs obj -2
 rhs r0 84838859395.36760704 r1 -2
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 68719476736
ENDATA
