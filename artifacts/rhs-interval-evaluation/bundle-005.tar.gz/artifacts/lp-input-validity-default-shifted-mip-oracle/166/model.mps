NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj -7 r0 -1
 x r1 1
 y obj 5 r0 2
 y r1 -3
 z r0 3.14159265
RHS
 rhs obj -2
 rhs r0 26353593.7365312 r1 -8
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 8388608
ENDATA
