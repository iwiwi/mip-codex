NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj -3 r0 2
 x r1 3
 y obj -5 r0 4
 y r1 2
 z r0 -9.87654321
RHS
 rhs obj -5
 rhs r0 -20712606.34593791999999999999 r1 8.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 2097152
ENDATA
