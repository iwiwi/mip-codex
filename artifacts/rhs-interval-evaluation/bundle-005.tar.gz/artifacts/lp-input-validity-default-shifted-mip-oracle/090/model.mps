NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj 3 r0 -3
 x r1 3
 y obj 1 r0 2
 y r1 1
 z r0 -9.87654321
RHS
 rhs obj 0
 rhs r0 -678710881354.69376255999999999999 r1 1
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 68719476736
ENDATA
