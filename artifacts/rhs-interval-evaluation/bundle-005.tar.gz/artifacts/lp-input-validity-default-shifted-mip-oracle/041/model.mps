NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj 3 r0 -1
 x r1 -1
 y obj 2 r0 2
 y r1 2
 z r0 3.14159265
RHS
 rhs obj 0
 rhs r0 26353590.23653119999999999999 r1 -1
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 8388608
ENDATA
