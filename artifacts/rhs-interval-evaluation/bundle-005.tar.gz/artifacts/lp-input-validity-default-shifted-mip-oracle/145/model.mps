NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 1 r0 2
 x r1 2
 y obj -1 r0 4
 y r1 1
 z r0 3.14159265
RHS
 rhs obj 4
 rhs r0 3373259428.7759936 r1 4.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1073741824
ENDATA
