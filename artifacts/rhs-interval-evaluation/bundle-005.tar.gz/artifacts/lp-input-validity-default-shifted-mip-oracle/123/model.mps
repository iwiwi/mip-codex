NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 3 r0 -4
 x r1 2
 y obj -1 r0 4
 y r1 1
 z r0 3.14159265
RHS
 rhs obj -1
 rhs r0 26353597.23653120000000000001 r1 6.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 8388608
ENDATA
