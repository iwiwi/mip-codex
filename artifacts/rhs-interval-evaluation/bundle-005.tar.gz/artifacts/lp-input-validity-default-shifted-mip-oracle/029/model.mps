NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 7 r0 1
 x r1 3
 y obj 5 r0 -3
 y r1 -3
 z r0 3.14159265
RHS
 rhs obj -3
 rhs r0 843314847.56899839999999999999 r1 -4
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 268435456
ENDATA
