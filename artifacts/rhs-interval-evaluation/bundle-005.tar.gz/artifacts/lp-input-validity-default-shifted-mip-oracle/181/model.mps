NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 7 r0 2
 x r1 -3
 y obj 2 r0 1
 y r1 -3
 z r0 -9.87654321
RHS
 rhs obj -1
 rhs r0 -1357421762695.88752512 r1 -13.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 137438953472
ENDATA
