NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj -3 r0 -3
 x r1 3
 y obj -1 r0 1
 y r1 -1
 z r0 3.14159265
RHS
 rhs obj 3
 rhs r0 3454217648414.1174464 r1 -3
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1099511627776
ENDATA
