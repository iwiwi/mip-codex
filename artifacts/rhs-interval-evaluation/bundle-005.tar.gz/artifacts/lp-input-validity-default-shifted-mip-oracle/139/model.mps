NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj -1 r0 -4
 x r1 -3
 y obj -2 r0 -3
 y r1 2
 z r0 -9.87654321
RHS
 rhs obj 5
 rhs r0 -10356324.67296896 r1 -6.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1048576
ENDATA
