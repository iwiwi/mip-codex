NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj -7 r0 2
 x r1 -1
 y obj 1 r0 1
 y r1 1
 z r0 -9.87654321
RHS
 rhs obj -2
 rhs r0 -5302428758.56010751999999999999 r1 2.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 536870912
ENDATA
