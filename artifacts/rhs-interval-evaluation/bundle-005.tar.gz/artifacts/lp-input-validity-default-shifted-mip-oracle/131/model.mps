NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj 1 r0 -1
 x r1 3
 y obj -5 r0 2
 y r1 -1
 z r0 1.23456789
RHS
 rhs obj 5
 rhs r0 1357421750332.88171263999999999999 r1 7.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1099511627776
ENDATA
