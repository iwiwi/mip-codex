NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 7 r0 1
 x r1 -1
 y obj -2 r0 4
 y r1 -1
 z r0 3.14159265
RHS
 rhs obj 5
 rhs r0 107944301517.83179520000000000001 r1 -1.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 34359738368
ENDATA
