NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj -3 r0 -3
 x r1 -1
 y obj -5 r0 -1
 y r1 2
 z r0 1.23456789
RHS
 rhs obj 5
 rhs r0 5302428706.74172544 r1 6.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 4294967296
ENDATA
