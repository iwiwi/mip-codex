NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj -3 r0 1
 x r1 -3
 y obj -2 r0 1
 y r1 -3
 z r0 1.23456789
RHS
 rhs obj 1
 rhs r0 678710875169.44085632 r1 -7
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 549755813888
ENDATA
