NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj 7 r0 -3
 x r1 1
 y obj -2 r0 -1
 y r1 2
 z r0 1.23456789
RHS
 rhs obj -2
 rhs r0 662803581.53021568 r1 3.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 536870912
ENDATA
