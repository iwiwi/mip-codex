NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj -3 r0 1
 x r1 2
 y obj 2 r0 1
 y r1 2
 z r0 -9.87654321
RHS
 rhs obj 0
 rhs r0 -82850446.38375167999999999999 r1 6.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 8388608
ENDATA
