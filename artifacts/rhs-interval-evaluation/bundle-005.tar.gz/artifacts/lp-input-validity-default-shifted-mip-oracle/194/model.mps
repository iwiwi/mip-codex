NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 1 r0 1
 x r1 -3
 y obj -1 r0 2
 y r1 2
 z r0 1.23456789
RHS
 rhs obj -1
 rhs r0 165700904.75755392 r1 -5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 134217728
ENDATA
