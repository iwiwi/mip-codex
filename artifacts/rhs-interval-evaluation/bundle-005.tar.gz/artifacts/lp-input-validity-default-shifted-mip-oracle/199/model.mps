NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj -1 r0 2
 x r1 -3
 y obj -1 r0 -1
 y r1 1
 z r0 3.14159265
RHS
 rhs obj -3
 rhs r0 431777206054.32718079999999999999 r1 -5.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 137438953472
ENDATA
