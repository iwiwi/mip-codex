NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 3 r0 3
 x r1 -1
 y obj -2 r0 1
 y r1 -3
 z r0 -9.87654321
RHS
 rhs obj 2
 rhs r0 -331401789.03500672 r1 -7.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 33554432
ENDATA
