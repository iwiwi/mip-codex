NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj -7 r0 -4
 x r1 2
 y obj -5 r0 2
 y r1 -1
 z r0 3.14159265
RHS
 rhs obj 0
 rhs r0 431777206043.8271808 r1 5.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 137438953472
ENDATA
