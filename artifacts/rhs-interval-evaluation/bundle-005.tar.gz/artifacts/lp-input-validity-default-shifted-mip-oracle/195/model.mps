NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj -7 r0 -4
 x r1 2
 y obj 1 r0 4
 y r1 -1
 z r0 3.14159265
RHS
 rhs obj 4
 rhs r0 863554412110.65436160000000000001 r1 -1.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 274877906944
ENDATA
