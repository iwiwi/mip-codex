NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 1 r0 2
 x r1 -3
 y obj -1 r0 4
 y r1 -1
 z r0 -9.87654321
RHS
 rhs obj -3
 rhs r0 -2714843525402.27505024 r1 1
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 274877906944
ENDATA
