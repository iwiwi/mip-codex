NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 1 r0 1
 x r1 3
 y obj 5 r0 1
 y r1 2
 z r0 1.23456789
RHS
 rhs obj 4
 rhs r0 1357421750338.38171264 r1 11.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1099511627776
ENDATA
