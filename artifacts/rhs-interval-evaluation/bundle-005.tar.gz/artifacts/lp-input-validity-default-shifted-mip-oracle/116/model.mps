NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 3 r0 -1
 x r1 3
 y obj -2 r0 2
 y r1 2
 z r0 3.14159265
RHS
 rhs obj 0
 rhs r0 6588396.8091328 r1 12
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 2097152
ENDATA
