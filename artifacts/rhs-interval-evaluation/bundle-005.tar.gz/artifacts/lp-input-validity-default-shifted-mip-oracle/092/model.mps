NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 1 r0 3
 x r1 1
 y obj 2 r0 4
 y r1 1
 z r0 1.23456789
RHS
 rhs obj -2
 rhs r0 5302428727.24172544000000000001 r1 5.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 4294967296
ENDATA
