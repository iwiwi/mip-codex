NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 3 r0 3
 x r1 3
 y obj -1 r0 1
 y r1 1
 z r0 1.23456789
RHS
 rhs obj 1
 rhs r0 169677718802.23521408 r1 11
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 137438953472
ENDATA
