NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj 3 r0 3
 x r1 -1
 y obj -5 r0 1
 y r1 1
 z r0 3.14159265
RHS
 rhs obj -5
 rhs r0 26986075379.7079488 r1 1.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 8589934592
ENDATA
