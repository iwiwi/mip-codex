NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj -3 r0 3
 x r1 1
 y obj 5 r0 1
 y r1 2
 z r0 3.14159265
RHS
 rhs obj 0
 rhs r0 26353595.23653120000000000001 r1 7.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 8388608
ENDATA
