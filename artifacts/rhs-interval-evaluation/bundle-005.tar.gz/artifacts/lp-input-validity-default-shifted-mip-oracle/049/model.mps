NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 3 r0 2
 x r1 3
 y obj -1 r0 1
 y r1 -3
 z r0 1.23456789
RHS
 rhs obj 0
 rhs r0 2651214363.12086271999999999999 r1 8
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 2147483648
ENDATA
