NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 7 r0 -3
 x r1 -1
 y obj 2 r0 2
 y r1 2
 z r0 1.23456789
RHS
 rhs obj 5
 rhs r0 84838859402.36760704 r1 7
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 68719476736
ENDATA
