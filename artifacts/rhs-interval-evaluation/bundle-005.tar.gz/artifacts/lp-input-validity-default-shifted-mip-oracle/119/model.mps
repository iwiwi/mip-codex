NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj 7 r0 -4
 x r1 1
 y obj -1 r0 -1
 y r1 -1
 z r0 -9.87654321
RHS
 rhs obj -3
 rhs r0 -21209715053.74043008 r1 -2.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 2147483648
ENDATA
