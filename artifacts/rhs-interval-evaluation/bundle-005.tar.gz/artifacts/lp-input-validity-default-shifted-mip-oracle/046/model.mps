NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj 3 r0 -4
 x r1 -1
 y obj 5 r0 -3
 y r1 2
 z r0 1.23456789
RHS
 rhs obj 5
 rhs r0 82850442.12877696 r1 0.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 67108864
ENDATA
