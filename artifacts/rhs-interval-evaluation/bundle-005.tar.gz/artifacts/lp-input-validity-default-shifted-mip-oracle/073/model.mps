NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj -3 r0 -3
 x r1 1
 y obj 2 r0 -3
 y r1 -1
 z r0 1.23456789
RHS
 rhs obj 0
 rhs r0 42419429688.43380352 r1 -1
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 34359738368
ENDATA
