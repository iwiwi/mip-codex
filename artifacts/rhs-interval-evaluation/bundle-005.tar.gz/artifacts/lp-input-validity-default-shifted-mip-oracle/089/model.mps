NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 1 r0 2
 x r1 2
 y obj 2 r0 1
 y r1 -3
 z r0 -9.87654321
RHS
 rhs obj 3
 rhs r0 -169677720331.92344063999999999999 r1 8
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 17179869184
ENDATA
