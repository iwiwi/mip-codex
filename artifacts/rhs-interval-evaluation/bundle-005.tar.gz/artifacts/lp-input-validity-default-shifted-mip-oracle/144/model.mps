NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj 7 r0 3
 x r1 2
 y obj 1 r0 -1
 y r1 2
 z r0 -9.87654321
RHS
 rhs obj -3
 rhs r0 -10356300.17296896000000000001 r1 12
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1048576
ENDATA
