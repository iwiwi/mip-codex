NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 7 r0 2
 x r1 -1
 y obj -2 r0 -3
 y r1 1
 z r0 -9.87654321
RHS
 rhs obj -4
 rhs r0 -21209715038.24043007999999999999 r1 -0.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 2147483648
ENDATA
