NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj -3 r0 -1
 x r1 -3
 y obj -2 r0 -1
 y r1 -3
 z r0 1.23456789
RHS
 rhs obj -1
 rhs r0 169677718788.23521408 r1 -10
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 137438953472
ENDATA
