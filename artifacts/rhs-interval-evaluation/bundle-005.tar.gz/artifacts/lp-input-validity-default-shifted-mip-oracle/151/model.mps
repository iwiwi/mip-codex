NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj 3 r0 -3
 x r1 1
 y obj -5 r0 2
 y r1 -3
 z r0 -9.87654321
RHS
 rhs obj 2
 rhs r0 -10604857517.12021504000000000001 r1 -7
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1073741824
ENDATA
