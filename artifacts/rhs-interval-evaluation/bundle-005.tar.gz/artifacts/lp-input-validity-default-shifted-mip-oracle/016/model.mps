NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj -3 r0 -4
 x r1 3
 y obj -2 r0 4
 y r1 2
 z r0 -9.87654321
RHS
 rhs obj -5
 rhs r0 -331401806.03500672 r1 9
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 33554432
ENDATA
