NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj -7 r0 2
 x r1 -3
 y obj 5 r0 -1
 y r1 -1
 z r0 -9.87654321
RHS
 rhs obj -3
 rhs r0 -1357421762704.38752512000000000001 r1 -1.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 137438953472
ENDATA
