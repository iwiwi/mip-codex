NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 3 r0 1
 x r1 -3
 y obj 2 r0 2
 y r1 1
 z r0 3.14159265
RHS
 rhs obj 4
 rhs r0 421657433.78449919999999999999 r1 4
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 134217728
ENDATA
