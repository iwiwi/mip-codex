NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 7 r0 1
 x r1 2
 y obj 1 r0 2
 y r1 2
 z r0 1.23456789
RHS
 rhs obj 0
 rhs r0 2651214365.62086272 r1 13
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 2147483648
ENDATA
