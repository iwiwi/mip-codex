NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 1 r0 -1
 x r1 -3
 y obj 1 r0 -1
 y r1 -3
 z r0 1.23456789
RHS
 rhs obj -4
 rhs r0 41425220.31438847999999999999 r1 -11
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 33554432
ENDATA
