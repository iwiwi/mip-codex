NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 3 r0 2
 x r1 1
 y obj 1 r0 4
 y r1 2
 z r0 1.23456789
RHS
 rhs obj 0
 rhs r0 5302428712.24172544000000000001 r1 0
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 4294967296
ENDATA
