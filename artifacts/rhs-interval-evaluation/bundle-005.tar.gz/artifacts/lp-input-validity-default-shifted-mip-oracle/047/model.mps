NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj 1 r0 -4
 x r1 1
 y obj -2 r0 2
 y r1 -3
 z r0 1.23456789
RHS
 rhs obj 3
 rhs r0 2651214356.62086272 r1 0
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 2147483648
ENDATA
