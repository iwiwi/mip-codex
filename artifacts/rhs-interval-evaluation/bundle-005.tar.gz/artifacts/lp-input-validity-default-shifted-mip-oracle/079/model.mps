NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj -3 r0 2
 x r1 1
 y obj 5 r0 2
 y r1 -1
 z r0 1.23456789
RHS
 rhs obj -1
 rhs r0 84838859402.36760704 r1 -3
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 68719476736
ENDATA
