NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj -7 r0 2
 x r1 -3
 y obj 5 r0 2
 y r1 -1
 z r0 3.14159265
RHS
 rhs obj -1
 rhs r0 3373259426.27599359999999999999 r1 0
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1073741824
ENDATA
