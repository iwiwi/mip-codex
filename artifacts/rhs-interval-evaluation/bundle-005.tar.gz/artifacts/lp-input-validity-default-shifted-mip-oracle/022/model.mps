NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj 1 r0 2
 x r1 2
 y obj -5 r0 -1
 y r1 2
 z r0 3.14159265
RHS
 rhs obj -1
 rhs r0 52707181.47306239999999999999 r1 10
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 16777216
ENDATA
