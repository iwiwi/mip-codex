NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj 7 r0 2
 x r1 3
 y obj -5 r0 1
 y r1 1
 z r0 3.14159265
RHS
 rhs obj 4
 rhs r0 215888603031.66359039999999999999 r1 8.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 68719476736
ENDATA
