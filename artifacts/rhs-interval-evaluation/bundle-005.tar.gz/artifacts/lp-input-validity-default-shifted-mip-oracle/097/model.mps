NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj 7 r0 -1
 x r1 -3
 y obj -1 r0 1
 y r1 2
 z r0 -9.87654321
RHS
 rhs obj 3
 rhs r0 -42419430085.98086016 r1 -6.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 4294967296
ENDATA
