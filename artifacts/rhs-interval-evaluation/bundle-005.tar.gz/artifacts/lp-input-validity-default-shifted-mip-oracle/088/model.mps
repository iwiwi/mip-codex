NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj -1 r0 1
 x r1 -1
 y obj -1 r0 2
 y r1 1
 z r0 3.14159265
RHS
 rhs obj 4
 rhs r0 215888603033.66359040000000000001 r1 1.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 68719476736
ENDATA
