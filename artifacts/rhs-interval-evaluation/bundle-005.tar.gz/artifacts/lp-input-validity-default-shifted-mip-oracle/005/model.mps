NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj -7 r0 1
 x r1 1
 y obj 2 r0 4
 y r1 -1
 z r0 1.23456789
RHS
 rhs obj -3
 rhs r0 1357421750336.88171264000000000001 r1 1
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 1099511627776
ENDATA
