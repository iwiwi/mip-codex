NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj -1 r0 -4
 x r1 -1
 y obj 2 r0 1
 y r1 -3
 z r0 1.23456789
RHS
 rhs obj -2
 rhs r0 331401792.01510784 r1 -5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 268435456
ENDATA
