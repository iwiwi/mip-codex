NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj 3 r0 -4
 x r1 1
 y obj 1 r0 -3
 y r1 -3
 z r0 1.23456789
RHS
 rhs obj -4
 rhs r0 10604857416.98345088 r1 -4
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 8589934592
ENDATA
