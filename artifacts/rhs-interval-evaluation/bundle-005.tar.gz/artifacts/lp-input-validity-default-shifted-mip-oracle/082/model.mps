NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 7 r0 1
 x r1 -3
 y obj -2 r0 1
 y r1 -1
 z r0 -9.87654321
RHS
 rhs obj 3
 rhs r0 -2651214373.78005376 r1 -11.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 268435456
ENDATA
