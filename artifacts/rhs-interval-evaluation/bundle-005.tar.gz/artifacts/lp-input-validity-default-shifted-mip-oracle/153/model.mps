NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj 3 r0 -3
 x r1 1
 y obj 2 r0 4
 y r1 -1
 z r0 3.14159265
RHS
 rhs obj 1
 rhs r0 53972150757.41589760000000000001 r1 -2
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 17179869184
ENDATA
