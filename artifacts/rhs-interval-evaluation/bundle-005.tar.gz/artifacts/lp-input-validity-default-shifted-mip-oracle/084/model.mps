NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj -1 r0 -1
 x r1 1
 y obj 1 r0 -3
 y r1 -1
 z r0 -9.87654321
RHS
 rhs obj 2
 rhs r0 -20712617.34593791999999999999 r1 3
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 2097152
ENDATA
