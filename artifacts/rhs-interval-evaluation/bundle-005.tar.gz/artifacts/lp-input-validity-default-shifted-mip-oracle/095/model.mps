NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj -7 r0 -1
 x r1 2
 y obj -2 r0 -3
 y r1 2
 z r0 3.14159265
RHS
 rhs obj 1
 rhs r0 26986075371.20794879999999999999 r1 4.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 8589934592
ENDATA
