NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 7 r0 -4
 x r1 -3
 y obj -5 r0 2
 y r1 2
 z r0 -9.87654321
RHS
 rhs obj 4
 rhs r0 -2651214384.28005375999999999999 r1 -0.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 268435456
ENDATA
