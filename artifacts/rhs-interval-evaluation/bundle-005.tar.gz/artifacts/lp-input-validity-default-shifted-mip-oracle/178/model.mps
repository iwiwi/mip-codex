NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 7 r0 1
 x r1 1
 y obj 1 r0 4
 y r1 2
 z r0 1.23456789
RHS
 rhs obj 5
 rhs r0 662803599.03021568000000000001 r1 6.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 536870912
ENDATA
