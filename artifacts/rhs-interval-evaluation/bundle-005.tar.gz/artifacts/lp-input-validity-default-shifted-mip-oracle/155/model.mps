NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj 1 r0 1
 x r1 1
 y obj 1 r0 4
 y r1 2
 z r0 -9.87654321
RHS
 rhs obj 2
 rhs r0 -5302428746.06010752 r1 9.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 536870912
ENDATA
