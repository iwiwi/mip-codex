NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 L r0
 L r1
COLUMNS
 x obj -3 r0 2
 x r1 2
 y obj -2 r0 2
 y r1 1
 z r0 -9.87654321
RHS
 rhs obj 2
 rhs r0 -662803587.07001344000000000001 r1 6
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 67108864
ENDATA
