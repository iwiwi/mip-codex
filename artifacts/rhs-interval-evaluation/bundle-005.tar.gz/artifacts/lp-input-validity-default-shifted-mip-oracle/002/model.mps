NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj 3 r0 -4
 x r1 -1
 y obj -2 r0 -1
 y r1 -1
 z r0 -9.87654321
RHS
 rhs obj -4
 rhs r0 -169677720340.42344064 r1 -2
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 17179869184
ENDATA
