NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 G r1
COLUMNS
 x obj 3 r0 1
 x r1 -3
 y obj -2 r0 4
 y r1 -1
 z r0 1.23456789
RHS
 rhs obj 0
 rhs r0 10356308.07859712000000000001 r1 -8
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 8388608
ENDATA
