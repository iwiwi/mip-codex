NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj 7 r0 -3
 x r1 2
 y obj 5 r0 1
 y r1 -3
 z r0 3.14159265
RHS
 rhs obj -3
 rhs r0 13176794.61826559999999999999 r1 -8.5
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 4194304
ENDATA
