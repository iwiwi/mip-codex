NAME shifted
OBJSENSE
 MAX
ROWS
 N obj
 L r0
 G r1
COLUMNS
 x obj 3 r0 -1
 x r1 1
 y obj -5 r0 1
 y r1 -1
 z r0 1.23456789
RHS
 rhs obj 2
 rhs r0 5302428711.24172543999999999999 r1 0
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 4294967296
ENDATA
