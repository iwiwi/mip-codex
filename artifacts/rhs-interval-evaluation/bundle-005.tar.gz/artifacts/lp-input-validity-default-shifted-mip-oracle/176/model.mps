NAME shifted
OBJSENSE
 MIN
ROWS
 N obj
 G r0
 L r1
COLUMNS
 x obj -1 r0 2
 x r1 2
 y obj 1 r0 1
 y r1 -3
 z r0 -9.87654321
RHS
 rhs obj 0
 rhs r0 -662803589.57001344 r1 -2
BOUNDS
 LI b x 0
 UI b x 3
 LO b y 0
 UP b y 3
 FX b z 67108864
ENDATA
