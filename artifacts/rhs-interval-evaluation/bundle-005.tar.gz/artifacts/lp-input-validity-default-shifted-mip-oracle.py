from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,getcontext
import json,random,subprocess,os,sys,resource
getcontext().prec=100;os.sched_setaffinity(0,{45});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));root=Path.cwd();sys.path.insert(0,'scripts');from benchmark_common import atomic_json,sha256;from validate_solution import validate;from verify_cover_cuts import validate_cut_proofs;from verify_rhs_interval import verify
out=root/'artifacts/lp-input-validity-default-shifted-mip-oracle';out.mkdir();binary=root/'artifacts/lp-input-validity-default-frozen/bin/mip-codex';rng=random.Random(2026111801);records=[];token=lambda v:format(Decimal(v.numerator)/Decimal(v.denominator),'f')
atomic_json(out/'experiment.json',dict(seed=2026111801,models=200,flags=[0,1],cpu=45,seconds=2,memory_bytes=16*1024**3,binary_sha256=sha256(binary),build_info=json.loads(subprocess.check_output([str(binary),'build-info'])),purpose='fixed large decimal row shift; exact integer/continuous optimum, exact RHS relaxation and independent GMP'))
for case in range(200):
 a=rng.choice([F(123456789,10**8),-F(987654321,10**8),F(314159265,10**8)]);h=F(2**rng.randrange(20,41));b=rng.choice([-4,-3,-1,1,2,3]);c=rng.choice([-3,-1,1,2,4]);plant=(rng.randrange(4),rng.randrange(4));sense=rng.choice(['L','G']);delta=rng.choice([F(1,10**20),-F(1,10**20),F(1,2),-F(1,2)]);residual=b*plant[0]+c*plant[1]+delta;rhs=a*h+residual;d=rng.choice([-3,-1,1,2,3]);e=rng.choice([-3,-1,1,2]);sense2=rng.choice(['L','G']);rhs2=F(d*plant[0]+e*plant[1])+(1 if sense2=='L'else-1)*F(rng.randrange(5),2);cx=rng.choice([-7,-3,-1,1,3,7]);cy=rng.choice([-5,-2,-1,1,2,5]);offset=rng.randint(-5,5);maximize=bool(case%2);vertices=[]
 for x in range(4):
  lo=F(0);up=F(3)
  for bb,cc,s,rr in [(b,c,sense,residual),(d,e,sense2,rhs2)]:
   orient=1 if s=='L'else-1;q=orient*cc;z=orient*(rr-bb*x)
   if q>0:up=min(up,z/q)
   else:lo=max(lo,z/q)
  if lo<=up:
   for y in [lo,up]:vertices.append((offset+cx*x+cy*y,x,y))
 opt=(max if maximize else min)(v[0]for v in vertices)if vertices else None;dest=out/f'{case:03d}';dest.mkdir();m=dest/'model.mps';m.write_text(f'NAME shifted\nOBJSENSE\n {"MAX"if maximize else"MIN"}\nROWS\n N obj\n {sense} r0\n {sense2} r1\nCOLUMNS\n x obj {cx} r0 {b}\n x r1 {d}\n y obj {cy} r0 {c}\n y r1 {e}\n z r0 {token(a)}\nRHS\n rhs obj {-offset}\n rhs r0 {token(rhs)} r1 {token(rhs2)}\nBOUNDS\n LI b x 0\n UI b x 3\n LO b y 0\n UP b y 3\n FX b z {token(h)}\nENDATA\n')
 for flag in [0,1]:
  q=dest/str(flag);q.mkdir();env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_RHS_INTERVAL_FALLBACK=str(flag),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
  if flag:env.update(MIP_RHS_INTERVAL_DUMP=str(q/'rhs-dump.jsonl'),MIP_RHS_INTERVAL_DUMP_LIMIT='100000')
  run=subprocess.run([str(binary),'solve',str(m),'2'],capture_output=True,text=True,env=env,timeout=62);(q/'result.json').write_text(run.stdout);(q/'stderr.log').write_text(run.stderr);assert run.returncode==0;v=json.loads(run.stdout);assert v['status']!='unbounded_relaxation';proof=validate_cut_proofs(m,v);assert proof['valid']is True,(case,flag,proof);atomic_json(q/'proof-validation.json',proof)
  if opt is None:assert v['status']!='optimal',(case,flag,v)
  else:
   assert v['status']!='infeasible',(case,flag,opt)
   if v['dual_bound']is not None:
    dual=v['dual_bound'];assert min(F(dual),F(str(dual)))>=opt if maximize else max(F(dual),F(str(dual)))<=opt,(case,flag,opt,dual)
   if v['status']=='optimal':assert abs(F(str(v['objective']))-opt)<=F(1,10**8)*(1+abs(opt)),(case,flag,opt,v['objective'])
  point=None
  if v.get('values')is not None:point=validate(m,v);assert point['valid']is True,(case,flag,point)
  rowproof=None;count=v.get('lp_rhs_interval_fallbacks')or 0
  if flag and count:
   rowproof=verify(m,q/'rhs-dump.jsonl');assert rowproof['rows']==count;atomic_json(q/'rhs-validation.json',rowproof)
  record=dict(case=case,flag=flag,status=v['status'],objective=v['objective'],dual_bound=v['dual_bound'],exact_optimum=None if opt is None else str(opt),fallbacks=count,rhs_rows_validated=0 if rowproof is None else rowproof['rows'],point=point,proof_valid=True,input_sha256=sha256(m));records.append(record);atomic_json(q/'validation.json',record)
 atomic_json(out/'progress.json',dict(outputs=len(records),optimal=sum(r['status']=='optimal'for r in records),gmp_points=sum(r['point']is not None for r in records),fallbacks=sum(r['fallbacks']for r in records),rhs_rows=sum(r['rhs_rows_validated']for r in records)))
 if case%25==0:print(case,flush=True)
atomic_json(out/'records.json',records);summary={str(flag):dict(outputs=sum(r['flag']==flag for r in records),optimal=sum(r['flag']==flag and r['status']=='optimal'for r in records),gmp_points=sum(r['flag']==flag and r['point']is not None for r in records),fallbacks=sum(r['fallbacks']for r in records if r['flag']==flag),rhs_rows=sum(r['rhs_rows_validated']for r in records if r['flag']==flag))for flag in [0,1]};atomic_json(out/'summary.json',summary);atomic_json(out/'exit.json',dict(status='complete'));print(json.dumps(summary),flush=True)
