from pathlib import Path
import os,json,subprocess,resource,time,sys
os.sched_setaffinity(0,{45});resource.setrlimit(resource.RLIMIT_AS,(16*1024**3,16*1024**3));root=Path.cwd();sys.path.insert(0,'scripts');from benchmark_common import sha256,atomic_json
out=root/'artifacts/lp-input-validity-full-dump-pilot';out.mkdir();entry=next(r for r in json.load(open('data/manifest.json'))['instances']if r['name']=='rd-rplusc-21.mps.gz');assert entry['split']=='development';model=root/entry['path'];assert sha256(model)==entry['sha256'];binary=root/'artifacts/lp-input-validity-full-dump-frozen/bin/mip-codex'
for flag in [0,1]:
 d=out/str(flag);d.mkdir();env={k:v for k,v in os.environ.items()if not k.startswith('MIP_')};env.update(MIP_RHS_INTERVAL_FALLBACK=str(flag),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1');
 if flag:env.update(MIP_RHS_INTERVAL_DUMP=str(d/'rhs-dump.jsonl'),MIP_RHS_INTERVAL_DUMP_LIMIT='100000')
 cmd=[str(binary),'solve',str(model),'10'];atomic_json(d/'job.json',dict(command=cmd,environment={k:v for k,v in env.items()if k.startswith(('MIP_','OMP_','OPENBLAS_'))},cpu=45,input_sha256=sha256(model),binary_sha256=sha256(binary),memory_bytes=16*1024**3));start=time.monotonic();r=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=70);(d/'result.json').write_text(r.stdout);(d/'stderr.log').write_text(r.stderr);atomic_json(d/'execution.json',dict(exit_code=r.returncode,wall_seconds=time.monotonic()-start));assert r.returncode==0;v=json.loads(r.stdout);print(flag,{k:v.get(k)for k in ['status','objective','dual_bound','nodes','lp_solves','lp_pivots','lp_rhs_interval_fallbacks','original_coefficient_bound_checks','original_coefficient_bound_successes']},flush=True)
atomic_json(out/'exit.json',dict(status='complete'))
