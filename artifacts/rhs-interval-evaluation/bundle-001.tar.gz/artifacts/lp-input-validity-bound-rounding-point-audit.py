from pathlib import Path
import os,sys,json
os.sched_setaffinity(0,{45});os.environ['MIP_ABSOLUTE_CHECKER']='/home/ubuntu/mip-codex/third_party/miplib-checker/bin/solchecker-absolute';sys.path.insert(0,'scripts');from validate_solution import validate;from verify_cover_cuts import exact_model;from benchmark_common import sha256,atomic_json
records=[]
for sense in ['MIN','MAX']:
 d=Path('artifacts/lp-input-validity-bound-rounding-controls')/sense;p=d/'model.mps';q=d/'checker-compatible.mps';q.write_text(p.read_text().replace('BOUNDS\n','RHS\n rhs obj 0\nBOUNDS\n'));assert exact_model(p,True)==exact_model(q,True);r=json.load(open(d/'result.json'));v=validate(q,r);assert v['valid']is True;atomic_json(d/'point-validation-compatible.json',v);records.append(dict(sense=sense,original_sha256=sha256(p),compatible_sha256=sha256(q),exact_model_equivalent=True,point_valid=True,reason='independent absolute checker requires explicit zero RHS section'))
atomic_json(Path('artifacts/lp-input-validity-bound-rounding-point-audit.json'),dict(points=2,strict_valid=2,records=records));print('2 GMP points valid on exact-equivalent explicit-RHS models')
