from pathlib import Path
from fractions import Fraction as F
import json,subprocess,os
os.sched_setaffinity(0,{45});out=Path('artifacts/lp-input-validity-bound-rounding-controls');out.mkdir();binary=Path('/home/ubuntu/mip-codex/target/release/mip-codex');records=[]
for sense,coefficient,bounds,opt in [('MIN',1,' LO b x 0.99999999999999999999\n UP b x 2\n',F(10**20-1,10**20)),('MAX',1,' LO b x 0\n UP b x 1.00000000000000000001\n',F(10**20+1,10**20))]:
 d=out/sense;d.mkdir();p=d/'model.mps';p.write_text(f'NAME bound\nOBJSENSE\n {sense}\nROWS\n N obj\nCOLUMNS\n x obj {coefficient}\nBOUNDS\n{bounds}ENDATA\n');r=subprocess.run([str(binary),'solve',str(p),'2'],capture_output=True,text=True,timeout=62);(d/'result.json').write_text(r.stdout);(d/'stderr.log').write_text(r.stderr);assert r.returncode==0;v=json.loads(r.stdout);b=v['dual_bound'];safe=b is None or(min(F(b),F(str(b)))>=opt if sense=='MAX'else max(F(b),F(str(b)))<=opt);record=dict(sense=sense,status=v['status'],objective=v['objective'],dual_bound=b,exact_optimum=str(opt),conservative=safe,rational_proof=v.get('rational_primal_proof'));records.append(record);print(json.dumps(record),flush=True)
(out/'summary.json').write_text(json.dumps(records,indent=2))
